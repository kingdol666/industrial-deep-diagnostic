# 工业诊断报告 — bench_tep_d03_hard

- 运行目录：`D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171632563_bench_tep_d03_hard`
- 场景：Tennessee Eastman（TE）反应-冷凝-分离-汽提-循环化工过程，过程波动诊断（process_only 数据视图，truth_withheld=true）
- 报告人：工程师周·技术报告（reporter，Step 6）
- 质量门状态：judge round-2 通过（score=90，verdict=pass，零 blocking，见 `05_review/judge_feedback.json`）；Step 5b 预审计 NO_FATAL（其 1 项 MAJOR 表述缺陷已在 round-1 修复中关闭，见 `05_review/optimizer_preflight.md`）
- 结论类型：COMPETING_SET（诚实三态），总置信度（overall）=55/MEDIUM，INDISTINGUISHABLE 帽 65 内；竞争集 CS1={H1=55, H6=50} 近并列

## 1. 执行摘要

**一句话结论**：扰动主位点定量定位于汽提塔蒸汽热回路（XMV_9 蒸汽阀 / XMEAS_19 蒸汽流量 / XMEAS_18 塔温），效应量为标准差×2.5-2.7（对应方差×4.3-7.4）；反应器、进料流量、传感器伪象三类原因以 95/95/93 置信度排除；但一次因在 H1（蒸汽侧热扰动）与 H6（汽提塔进料热状态变化）之间经同一热平衡通道（Q_steam=Q_vap+ΣF_i·cp·ΔT）表达、判别量未测量，故诚实结论为 COMPETING_SET——CS1 近并列 {H1=55, H6=50}、帽 65、总置信度 55/MEDIUM。

**给管理者的三句话**：

1. 异常自样本 161（第 8 小时）开始，蒸汽回路的签名是「方差爆炸而均值不动」——供汽没有中断（蒸汽均值仅 -0.76%，234.46→232.68 kg/h），但热负荷波动剧烈；塔温单调下漂（半窗 z -0.585σ→-1.065σ，最长越限游程 3.8 小时）。
2. 下一步该做什么取决于一个尚未测量的量：蒸汽 header 压力/品质，或 D/E 进料温度——补上其中任一通道即可把 COMPETING_SET 升级为单一根因（可证伪条件见 6.4 节）。
3. 在补测完成前，请勿依据本报告在 H1/H6 之间下注改动操作点——现有数据不足以支持方向性结论。

分级行动建议（P0 判别补测 / P1 主动判别 / P2 关闭残余不确定性）见第 8 节。

## 2. 诊断背景与数据概况

- **用户问题**：「诊断本次异常的根本原因」（`00_input/user_context.json`）。
- **工艺对象**：TE 过程——反应器-冷凝器-气液分离器-汽提塔+循环压缩机；XMEAS_1..41 过程测量 + XMV_1..11 操纵变量（`01_ontology/ontology.json`：7 设备 / 4 工段本体，5 个显式 confounders）。
- **数据**：`00_input/data.csv`，960 行 × 52 数值通道 + timestamp，180 s 均匀单调采样，0 NaN（`00_input/input_inspection.json`）。基线=样本 1-160，异常段=161-960；用户声明第 161 样本（8 h）起进入异常（L2），rolling-mean 起始点在样本 161-168 独立佐证。
- **弱签名场景**：全列均值偏移 ≤0.92σ（最大 XMEAS_16 +0.923σ，`06_scripts/semantic_analysis_results.json`）——用户提示与数据预检一致：判别必须依赖位点结构（方差 / 游程 / 时序 / 排除法），均值幅度天然失效。
- **数据视图**：无产品/批次分组列（单一连续牌号，batch_integrity applicable=false）；无实验室/质量列（process_only）→ 按产品分层与双驱动联动 not_applicable（`02_processed/data_analysis_conclusion.json` 已记录原因）。时间分层（基线 / 异常前半 161-480 / 异常后半 480-960）等效替代产品分层。

![关键变量时序总览（±3σ红线，prepare阶段生成）](03_figures/fig_temporal_overview.png)

图示说明：该图为全记录 z 口径的时序网格总览（plot_manifest 注明弱签名位点宜用基线参照 z 读图；本报告全部数值统一采用基线段 1-160 参照口径）。其对应的时间形态三件套——塔温单调下漂、蒸汽回路方差爆炸、反应器组平直——以 `06_scripts/semantic_analysis_results.json` 的 rolling_onset / sustained_runs / all_shifts 为量化来源（本环境未做像素判读，见 4.3 节口径披露）。

## 3. 数据质量评估

| 检查项 | 结果 | 来源 |
|---|---|---|
| 时间列有效性 | 960 值单调、180 s 均匀，Time-sorted 通过 | `02_processed/validate_report.json` sorting_validation |
| 缺失与清洗 | 0 NaN；cleaned_data 与原始数据逐列全等（IDENTICAL）——清洗未改动数据 | `02_processed/cleaned_data.json`；`05_review/optimizer_preflight.md` S2 |
| 基线定义 | 样本 1-160（用户 L2 声明 + rolling onset 佐证）；异常段保留不剔除（剔除即销毁故障签名） | `00_input/user_context.json`；`06_scripts/semantic_analysis_results.json` |
| 孤立尖峰 | 全记录 406 起 1 样本尖峰（XMEAS_6 max 4.48σ 等）判为噪声，以游程判据与主信号分离 | `06_scripts/semantic_analysis_results.json` spike_census |
| 变更点模块 | 对 XMEAS_9 过分割（>60 变更点）判不可用，改用滚动 20 样本均值起始点法 | `02_processed/validate_report.json` change_point_detection |
| 复位/操作点重置 | reset_found=false——无复位掩蔽类解释 | `02_processed/anomaly_report.json` |
| 分组/质量列 | 无产品列、无检验列 → per_product 与 dual_drive not_applicable（已记录原因，非疏漏） | `02_processed/data_analysis_conclusion.json` adaptive_decision_audit |

结论：数据质量足以支撑时序类判别（时间先序 / 滞后补偿 CCF 合法）；弱签名 + process_only 视图约束了可用的证据类型，本诊断据此采用位点结构策略。

## 4. 统计分析发现

### 4.1 主位点：汽提塔蒸汽热回路（方差结构证据）

| 通道 | std 基线→异常 | 标准差比 | Levene | ≥3σ 越限（基线 0 次） | max\|z\| | 最长 ≥2σ 游程 |
|---|---|---|---|---|---|---|
| XMV_9（蒸汽阀，%） | 1.230→3.129 | 2.544 | p<1e-4 | 196 | 6.49 | 71 样本（3.6 h，自 683） |
| XMEAS_19（蒸汽流量，kg/h） | 4.429→12.072 | 2.725 | p<1e-4 | 223 | 7.51 | 67 样本（3.4 h，自 684） |
| XMEAS_18（塔温，°C） | 0.229→0.474 | 2.068 | p<1e-4 | 122 | 6.04 | 76 样本（3.8 h，自 688） |

- **效应量口径（judge round-2 绑定表述）**：上表「标准差比」为 std_post/std_base（工件中的 var_ratio 字段经 judge 复核确认实为标准差比，真实方差比为 6.47/7.43/4.28）。本报告统一表述为：**标准差×2.5-2.7（对应方差×4.3-7.4）**。
- **均值场**：settled 滚动 200 均值 z = +0.067 / -0.060 / -0.624（XMEAS_19 / XMV_9 / XMEAS_18）——方差倍增而均值不动；蒸汽均值仅 -0.76%、塔温均值 -0.30%（66.011→65.811 °C，`05_review/optimizer_preflight.md` P1）。物理含义：供汽未失、扰动为波动性而非断供性——温控回路在对抗一个热平衡扰动；同时把 H1 的子类约束为「热负荷波动型」，排除「供汽中断型」。
- **漂移形态**：XMEAS_18 半窗 z -0.585→-1.065 单调下漂（monotone_drift=true）、XMV_9 -0.065→-0.775、XMEAS_19 +0.073→-0.718——渐进退化（drift）而非一次性操作点改变（step），与波动性热平衡失调一致。
- **对照组（排除证据的统计底座）**：反应器块 XMEAS_9 z=+0.032 / var 0.976 / rolling onset null，XMEAS_21 异常段 0 次越限、XMV_10 var 1.007；冷却执行器 XMV_11 var 1.047 / onset null；四路进料 |z|≤0.306（XMEAS_3 +0.306 最大，首越限 @177 晚于主位点）。
- **传播场（非源）**：塔压/反应器压力/分离器压力（XMEAS_16/7/13）于样本 161-162 同步小阶跃（≤0.94σ），压力链 r=0.970-0.998（lag0）——单一扰动经循环气路库存传播的投影（气相物料平衡分钟级均衡），幅度弱、无方差结构，不是主异常。

### 4.2 相关结构与滞后补偿分析

- XMV_9~XMEAS_19 r=0.988（lag0）——阀门流量方程执行链的结构相关，只证链路通畅，不作故障证据。
- XMEAS_19~XMEAS_18 r=0.941；分层 Pearson（基线/异常/异常前半/异常后半）= 0.858/0.950/0.972/0.929，方向全一致；Spearman 全记录 0.928；physics_discrepancy_count=0（`02_processed/time_lag_analysis.json`）。
- **滞后补偿 CCF（±20 样本）**：best-lag +1 样本（3 min）ccf=0.9409 vs lag0 r=0.9408，**Δ=0.0001——统计上不可分辨**。按管线脚本 `lag_ccf` 符号约定（lag>0 ⇒ y 领先 x），+1 对应温度先行；但 Δ=0.0001 不足以在闭环中分辨先行者。
- **时间序判定（round-1 修复后口径，judge round-2 独立重算复核）**：首 ≥3σ 越限排序 XMEAS_18@169 → XMV_9@170 → XMEAS_19@171（温度最先；基线 1-160 参照 z，ddof=0/1 两口径一致）。滚动 20 均值起始 162/166/168 仅作均值场量级证据、不作方向判据（judge 以 thr=1.0 复核得 167/169/171——任何单一口径下塔温均最早或并列最早）。
- **时间序结论**：主位点三通道起始近同步（≤4 样本 = 12 分钟内），属温控**闭环热补偿签名**；lead-lag 方向在本数据**不可分辨（UNRESOLVABLE）**，轻度偏向 H6，不构成因果方向的独立证据——本诊断不以时序在 H1/H6 之间作方向判定。
- **流量通道无判别力**：XMEAS_2~XMEAS_18 full r=-0.014（best-lag ccf 0.132；分层 -0.030/-0.021/-0.187/+0.100）——本体预测的中等反相关不可观测；正确解读是「判别缺口而非机制反证」：D 进料流量恒定（z=-0.114），H6 的热状态只能经未测温度/焓通道作用。
- **防伪相关纪律的正面执行**：XMEAS_2~XMEAS_21 r=-0.48 统计显著但因无本体机制（四反臆测条件之物理机制不满足）被剔除出因果引用；CCF 仅对结论引用的 8 对执行（52×51 全扫描因循环耦合伪相关风险被纪律性跳过——本体 confounders[0]）。

### 4.3 对齐图判读（视觉-统计交叉验证）

**[口径披露]** 本环境为非 VLM 环境：`03_figures/visual_analysis.json` observation_mode=metadata_backed_inference，3 张 PNG 均未被图像模型读取（chart_inventory read_status=READ_FAILED，原因 NON_VLM_ENVIRONMENT）。以下判读为数据侧元数据口径：视觉证据按 L4 降级使用，不作为像素级视觉证据引用；全部数字溯源至统计工件（避免证据双重计数）。视觉-统计一致性：一致（图形由统计工件数值渲染，元数据同源）。

![汽提蒸汽回路位点结构主视图（全52通道z归一化时序叠加，±3σ红线）](03_figures/fig_vlm_temporal_overlay_single_product.png)

三段式解读：① 图示——样本 161 后 XMEAS_19/XMV_9/XMEAS_18 进入持续大幅波动，反应器组（XMEAS_9/XMEAS_21/XMV_10）全程平直；② 统计——位点三通道 ≥3σ 越限 223/196/122 次 vs 基线 0 次、最长 ≥2σ 游程 3.4-3.8 h、标准差×2.5-2.7（对应方差×4.3-7.4）；③ 物理——蒸汽热负荷波动注入塔能量平衡（Q=ṁ_steam·λ_steam），温控闭环持续对抗扰动，产生「方差爆炸 + 塔温单调下漂」的补偿签名。

![参数同步热图（回路结构块与独立块核对）](03_figures/fig_vlm_synchronization.png)

三段式解读：① 图示——同步组 SG1 蒸汽执行链（XMEAS_19,XMV_9 r=0.988 lag0）、SG2 蒸汽→塔温（r=0.941）、SG3 气路压力链（r=0.970-0.998）；独立参数组=反应器温度块；② 统计——同步组基据为 lag-compensated CCF 与分层 Pearson（数据侧），非像素判读；③ 物理——SG1/SG3 为回路结构相关（只证链路通畅），SG2 为机制链耦合（方向不可分辨，见 4.2）。该结构支撑 H1/H6 共通道不可判别与 H3 排除。

![全局时序叠加（向后兼容视图，与单产品主视图同数据）](03_figures/fig_vlm_temporal_overlay.png)

判读同主视图；此图为向后兼容的全局叠加（plot_manifest：同数据生成），保留用于完整性核对。

### 4.4 稳健性核验（抗伪相关门）

- anti_spurious：0 fatal / 0 serious / 0 moderate；outlier_driven=0、trend_confounded=0、Simpson=0、Spearman 发散=0；overall_validity=「ROBUST」（`02_processed/validate_report.json`）。
- 留一杠杆：4 对引用相关 max_shift ≤0.0062——无单点杠杆效应（含闭环反馈结构对 XMEAS_9~XMV_10 r=0.643）。
- 离群敏感性：7 对核验 clean_r 变化 ≤14.5%、outlier_driven=false——0.92σ 量级的弱签名场偏移不是离群点伪象。
- 多重检验：100 次检验 29 个名义显著 vs 期望假阳性 5.0；Bonferroni 阈值下 12 个——本诊断引用的相关对均额外通过稳态窗分层 + 滞后补偿双核验，不以名义显著性为据。
- 计量自洽：FLOW_QUADRATIC_PLAUSIBLE（P/F² CV=1.87%，`02_processed/physics_check.json`）——支持 H5 伪象排除与流路无故障。

## 5. 假设检验：竞争假设对比与排除逻辑

### 5.1 竞争假设总表

| 假说 | 内容 | 判定 | 置信度 / 排除置信度 | 置信帽 |
|---|---|---|---|---|
| H1 | 汽提蒸汽侧热扰动（header 压力/品质波动或阀位波动放大） | CS1 竞争成员 | 55 | 65 |
| H6 | 汽提塔进料热状态变化（D/E 进料温度或 stream-10 热焓波动，通道未测量） | CS1 竞争成员 | 50 | 65 |
| H2 | 冷凝/分离器冷却侧扰动（冷却水入口温度未测量） | 残余弱候选 [WEAK_EXCLUSION]，不入 CS1 | 40 | — |
| H3 | 反应器侧一次因（动力学 / 反应器冷却） | 排除（STATISTICAL） | 95 | — |
| H4 | 进料流量 / 负荷漂移 | 排除（STATISTICAL） | 95 | — |
| H5 | 传感器 / 数据质量伪象 | 排除（COMBINED） | 93 | — |

另评估 H7（循环压缩机/气路阻力）与 H8（放空/惰性组分累积慢漂移）：相关通道全平稳（z≈0、var≈1.0-1.2），并入 H3 类排除逻辑，未单列（`04_diagnostics/reasoning_chain.json` R4 alternatives）。

### 5.2 CS1={H1,H6}：为何不可判别（INDISTINGUISHABLE，帽 65）

- **同通道同形**：两假说经同一热平衡方程 Q_steam=Q_vap+ΣF_i·cp·(T_feed−T_bubble) 在相同已测通道（XMEAS_18/XMEAS_19/XMV_9）上产生同号、同量级、同滞后（+1 样本）的响应——塔温单调下漂 + 蒸汽回路方差倍增在两个机制下完全同形。
- **判别量未测量**：蒸汽 header 压力/干度（判 H1）、D/E 进料温度、stream-10 温度/焓（判 H6）均不存在于 52 列数据集；流量通道判别力已被否定（r=-0.014，D 进料流量恒定）。
- **时间序不给方向**：温度先行的闭环补偿签名轻度偏向 H6，但 Δ=0.0001 的 CCF 与近同步起始（≤4 样本）不足以分辨先行者——对未判别分叉强制 DETERMINED 是协议红线，本诊断不犯。
- **独立收敛**：`02_processed/time_lag_analysis.json` key_recommendations 与 `02_processed/data_analysis_conclusion.json` expert_review_summary 独立得出同一结论。
- **55/50 的依据（judge round-2 认可可辩护）**：H6 的流量介导版本被 r=-0.014 + 四路进料恒定否定，且进料侧首越限（@177/@289/@844）全部晚于主位点（@169）——H1 保留 5 分边际；同时如实披露闭环签名轻度偏向 H6。
- **H1 置信度规范路径**：五因子基线 75（统计 18 + 物理 20 + 时序 13 + 混淆控制 16 + 症状完备 8，`04_diagnostics/confidence.json`）−15（INDISTINGUISHABLE 帽）−5（根环节 DATA_LINK_MISSING 保守折减）= 55。注：confidence.json adjustment_log 第三条（-5）为 round-1 修复增量记录（非加性项），不重复扣减——judge warning 已注明，引用以规范路径 75-15-5=55 为准。

### 5.3 排除集（排除置信度 ≥90）

- **H3 反应器侧（95）**：反应器扰动必经移热链留痕（Q_rxn=ṁ_cw·cp·ΔT+Arrhenius 不可绕过）——XMEAS_9 settled z=-0.001 / rolling onset null；XMEAS_21 异常段 0 次越限 / var 0.988；XMV_10 var 1.007；XMEAS_7 仅 +0.75σ 且与压力链（r=0.970-0.998）共动、可由气路传播解释。复活条件：反应器组出现先于样本 166 的持续（≥20 样本）越限或 rolling onset。
- **H4 进料流量/负荷漂移（95）**：负荷漂移必等比缩放全流程流量并破坏节点平衡 F6≈F1+F4+F8——四路进料 |z|≤0.306、进料阀 var ≤1.204、产品/下游流量平稳（XMEAS_17 -0.032σ var 1.044；XMEAS_14 +0.181σ var 1.162）；节点平衡成立（`02_processed/physics_check.json` 质量/流量自洽）。复活条件：任一进料阀/流量出现先导性阶跃（≥1σ 且早于样本 166）。
- **H5 传感器/数据伪象（93）**：主位点越限为持续多样本游程（最长 76 样本 = 3.8 h）而非孤立 1 点；方差增大过 Levene（p<1e-4）且基线段 0 越限；阀/流量/温度三独立传感器同构失效概率极低；计量自洽（FLOW_QUADRATIC_PLAUSIBLE）。全记录确有 406 起孤立 1 样本尖峰，判为噪声、与主信号分离，不改变排除结论。复活条件：单通道独占持续游程且同回路无伴随结构，或 DCS 标定记录显示传感器同期故障。

### 5.4 残余候选 H2（40，[WEAK_EXCLUSION]）

两个可观测判据均反对 H2：① XMV_11 全程无补偿动作（var 1.047、rolling onset null）——若冷凝负荷被扰动，闭环执行器必留痕；② 冷却侧首越限（XMEAS_11@173、XMEAS_22@231）晚于主位点（@168-171）——时间先序反向。但冷却水入口温度未测量（本体 confounders[1]），达不到 ≥90 排除门槛，按纪律保留为残余候选、不入 eliminated。复活条件：补测入口温度显示平稳（则升级为 ≥90 排除）或出现 XMV_11 先导补偿动作（则复活为主候选）。

### 5.5 质量门与修复记录（本轮诊断的可审计性）

- Step 5b 预审计（`05_review/optimizer_preflight.md`）：PREFLIGHT VERDICT=NO_FATAL（0 FATAL / 1 MAJOR / 2 MINOR）。MAJOR-1（H1 时间先序证据为混合口径构造 + CCF 符号误读）已在 round-1 定向修复中关闭；MINOR-1（var_ratio 误标）以本报告的标准差口径表述落实；MINOR-2（lag_match 降级）已在 diagnosis.json 落实为 UNTESTED/SUPPORTIVE。
- judge round-1：score=75、2 项 blocking（时间方向、H1 置信重加权）→ 定向修复（CS1 结构、帽 65、排除集 95/95/93 不变）。
- judge round-2（`05_review/judge_feedback.json`）：score=90、verdict=pass、零 blocking；7 项 spot-check 全部从 `00_input/data.csv` 精确复现（首越限 169/170/171、ccf 0.9409/lag0 0.9408、五因子和 75、六假说演化算术、标准差比口径）。
- 修复后规范口径（本报告全文采用）：CS1={H1=55, H6=50}（帽 65 内近并列）、总置信度（overall）=55/MEDIUM。

## 6. 根因结论

### 6.1 诊断结论

**COMPETING_SET（诚实三态），总置信度 55/MEDIUM，帽 65。** 结论为两层结构：

1. **位点层（DETERMINED 级证据）**：扰动主位点 = 汽提塔蒸汽热回路（XMV_9 / XMEAS_19 / XMEAS_18）——方差（标准差×2.5-2.7（对应方差×4.3-7.4））、持续游程（3.4-3.8 h）、闭环时间结构三重定量锚定，三个竞争类原因（反应器 / 进料流量 / 传感器伪象）以 95/95/93 排除。
2. **一次因层（不可判别）**：H1 蒸汽侧热扰动 vs H6 汽提塔进料热状态变化——经同一热平衡通道表达、判别量未测量，INDISTINGUISHABLE；CS1={H1=55, H6=50} 近并列。
3. 残余：H2 [WEAK_EXCLUSION]（40）。run_summary.json 的 primary_finding 与 `04_diagnostics/diagnosis.json` 的 primary_finding 逐字一致。

### 6.2 因果推理过程与物理机制

**共享因果链（H1 与 H6 的已测表达通道）**：
未测一次因（H1：header 压力/品质 或 H6：进料温度/焓）→ 塔热平衡失衡（Q_steam=Q_vap+ΣF_i·cp·ΔT）→ 塔温偏离泡点平衡并单调下漂（XMEAS_18 半窗 z -0.585σ→-1.065σ）→ 温控执行器（XMV_9）持续补偿 → 蒸汽流量波动放大（XMEAS_19）→ 回路方差倍增。

- **链内已验证链接**：XMV_9→XMEAS_19（阀门流量方程 F=Cv·f(x)·sqrt(ΔP·ρ)，r=0.988 lag0，ALL_LINKS_VALIDATED）；XMEAS_19→XMEAS_18（Q=ṁ_steam·λ_steam→VLE 泡点响应，r=0.941，本体先验时滞「分钟级（塔板水力学滞后）」与 +1 样本量级相容——方向不可分辨，仅作量级相容性参考）。
- **根环节缺口（DATA_LINK_MISSING，已披露非静默删除）**：H1 链根（header 状态→回路波动）与 H6 链根（进料温度→塔温）的通道均不在 52 列数据集——这是本诊断保持 COMPETING_SET 而非 DETERMINED 的直接原因（`04_diagnostics/diagnosis.json` inference_gaps）。
- **量级自洽**：-0.76% 蒸汽负荷对应分数 ℃ 级泡点响应，与观测 -0.2 °C 同数量级（preflight P7）；蒸汽通道标准差比 2.725 传导至塔温通道标准差比 2.068，同数量级衰减方向物理自洽。
- **[PHYSICS_UNVERIFIED] 项**：H6 的量级（焓平衡各热项权重）UNTESTED；温控回路结构文档（XMEAS_18→XMV_9 串级与增益标定）未提供——补偿方向推理为推断级。

### 6.3 推理链（R1-R8）与置信演化

R1 数据刻画（弱签名场景 → 位点结构+排除法策略）→ R2 统计发现（主位点 + 传播场 + 负发现入账）→ R3 验证过滤（ROBUST + 四反臆测门；r=-0.48 无机制剔除）→ R4 假说生成与链验证（6+2 假说；CORRELATION_ABSENT 修正解读而非删除）→ R5 逐对判别（CS1 INDISTINGUISHABLE → 帽 65）→ R6 排除文档化（95/95/93 + 复活条件）→ R7 结论与可证伪性 → R8 不确定度定界与补测排序（`04_diagnostics/reasoning_chain.json`）。

hypothesis_evolution 全部可复算（judge round-2 逐项验证）：H1 30+25+20-15-5=55；H6 30+10-8+18=50；H2 25+15+0=40；H3 25-25=0；H4 20-20=0；H5 15-15=0。

### 6.4 可证伪条件（升级 / 降级路径）

1. 补测蒸汽 header 压力/干度：若与回路活动同步波动 → H1 升 DETERMINED 候选、H6 证伪；若全程平稳 → H1 一次因证伪。
2. 补测 D/E 进料温度或 stream-10 焓：若出现先导波动且经焓平衡定量相容 → H6 升 DETERMINED 候选、H1 降级；若全程平稳 → H6 证伪。
3. 两个判别量同时平稳 → 现有两成员同时受压，需寻找共同上游第三假说。
4. 蒸汽阀手动阶跃试验：塔温响应增益与基线标定一致且扰动残差消失 → 扰动源不在蒸汽侧本体。
5. 补测冷却水入口温度平稳 → H2 升级为 ≥90 排除（残余不确定性关闭）。

## 7. 证据附录

### 7.1 证据全景清单

证据结构（`04_diagnostics/evidence.json` evidence_inventory）：视觉证据 3 项（rank 4，METADATA-BACKED 口径、L4 降级）、数值证据 10 项（rank 3 为主）、物理证据 4 项（rank 5：本体关系 ×3 + physics_check）、验证证据 7 项（validate_report / time_lag / anomaly_report）。视觉证据均与统计证据同源披露，未重复计数。

### 7.2 关键工件索引（含关键数字）

| 工件 | 关键内容与数字 |
|---|---|
| `04_diagnostics/diagnosis.json` | primary_finding；CS1={H1,H6} INDISTINGUISHABLE 帽 65；排除 95/95/93；12 对 discriminability_matrix；repair_history（round-1 定向修复记录） |
| `04_diagnostics/confidence.json` | H1=55（五因子 18/20/13/16/8=75；规范路径 75-15-5）、H6=50、H2=40、overall=55/MEDIUM；H1/H6 双帽 65 |
| `04_diagnostics/evidence.json` | 证据清单 3/10/4/7；CCF 0.9409 vs lag0 0.9408；首 ≥3σ 越限 169/170/171 |
| `04_diagnostics/reasoning_chain.json` | R1-R8 完整链；hypothesis_evolution 六假说全复算；uncertainty_summary 帽 65 |
| `06_scripts/semantic_analysis_results.json` | 标准差比 2.544/2.725/2.068（Levene p<1e-4）；越限 223/196/122 vs 基线 0；游程 76/67/71 样本；406 起孤立尖峰 |
| `02_processed/time_lag_analysis.json` | best-lag +1 样本 ccf=0.9409 vs lag0 0.9408（Δ=0.0001）；分层 r 0.858/0.950/0.972/0.929；Spearman 0.928；XMEAS_2~XMEAS_18 r=-0.014 |
| `02_processed/validate_report.json` | anti_spurious 0/0/0、ROBUST；leave-one-out ≤0.0062；离群敏感性 ≤14.5%；多重检验 29/5.0/12；Time-sorted |
| `02_processed/physics_check.json` | FLOW_QUADRATIC_PLAUSIBLE（P/F² CV=1.87%） |
| `02_processed/data_analysis_conclusion.json` | hypothesis_verdicts：H1 supported、H2/H6 indeterminate、H3/H4/H5 refuted；process_only 视图与 dual_drive not_applicable 记录 |
| `01_ontology/ontology.json` | 7 设备/4 工段；XMV_9→XMEAS_19→XMEAS_18 与 XMEAS_2→XMEAS_18 关系（governing law）；5 confounders |
| `03_figures/visual_analysis.json` | observation_mode=metadata_backed_inference；3 图 READ_FAILED 披露与「不得作为像素证据」警告 |
| `05_review/judge_feedback.json` | round-2 score=90、pass、零 blocking；7 项 spot-check 复现；报告引用绑定清单 |
| `05_review/optimizer_preflight.md` | NO_FATAL；MAJOR-1（已修复）/ MINOR-1、MINOR-2（已落实）；P1-P8 物理验证表 |

### 7.3 图表证据

本报告嵌入全部 4 张已渲染图（`03_figures/plot_manifest.json`）：fig_temporal_overview.png（§2）、fig_vlm_temporal_overlay_single_product.png（§4.3 主视图）、fig_vlm_synchronization.png（§4.3）、fig_vlm_temporal_overlay.png（§4.3 兼容视图）。全部为元数据口径（非 VLM 环境），判读三段式与视觉-统计一致性声明见 §4.3。

## 8. 建议与后续（行动方案）

### 8.1 P0 —— 判别补测（最小代价关闭 CS1 分叉）

1. **加装蒸汽 header 压力/干度在线测量**（判 H1 供热侧）。验证方法：其波动是否与 XMEAS_19 去除阀位趋势后的残差同步。预期效果：1-2 周数据即可升级或证伪 H1。
2. **加装 D/E 进料预热器出口温度（或 stream-10 温度/焓）测量**（判 H6 进料侧）。验证方法：波动是否先于/同步于回路方差放大，且经焓平衡折算与塔温漂移幅度（约 -0.9σ，settled -0.624σ）相容。

### 8.2 P1 —— 主动判别与制度核查

3. **蒸汽阀手动阶跃试验**（塔温响应增益对标定值的偏离可指认扰动侧）——需工艺侧批准短时试验窗口；属主动判别，成本最低、证据力最强。
4. **调取温控回路结构文档**（XMEAS_18→XMV_9 是否串级、增益标定）——把补偿方向推理从推断级升级为文档级。
5. **过渡期监控**：XMV_9/XMEAS_19/XMEAS_18 的方差与 ≥3σ 越限游程、塔温下漂速率（半窗 -0.585→-1.065σ）；在判别量到位前，任何干预按 H1/H6 中性预案执行（如保障蒸汽压力上限裕度），避免依据未证实的方向假设改动操作点。

### 8.3 P2 —— 关闭残余不确定性

6. 补测**冷却水入口温度** → H2 升级为 ≥90 排除或复活为主候选。
7. 补充**产品实验室分析/质量列** → 打通过程→质量双驱动闭环（当前 process_only 视图下质量影响评估不可做，已记录为证据缺口）。
8. 核查 **DCS 标定/维护记录** → 加固 H5 排除（排除置信度 93 → 可进一步加固）。

## 9. 方法论说明与局限

**方法**：竞争假说协议（假说 → 逐对判别力评估 → 排除 → 三态结论）；四反臆测条件（时间先序 + 统计显著 + 物理机制 + 无矛盾）作为每条引用证据的准入门；证据等级 L1-L7（本结论以 L3 统计证据 + L5 物理机理为底座，视觉证据 L4 元数据口径降级、不独立加分）；置信帽规则（INDISTINGUISHABLE ≤65）；分层 / 滞后补偿 CCF / 留一 / 离群 / 多重检验稳健性核验。时间粒度：180 s 采样下 1 样本 = 3 分钟；滚动 20 样本起始点法的分辨力约 ±12 分钟（preflight INFO-2）——温度约 4 样本的先导属弱时序证据，本报告未将其升格为方向判定。

**局限（aleatory，不可约）**：180 s 采样对高频蒸汽扰动混叠；基线段仅 160 样本（8 h），基线 σ 与游程阈值的抽样误差有限；406 起孤立 1 样本尖峰构成的噪声场；960 样本对数天尺度慢漂移截断。

**局限（epistemic，补测即可消除）**：蒸汽 header 状态、D/E 进料温度/焓、冷却水入口温度三个通道未测量——CS1 分叉与 H2 残余的全部来源；温控回路结构文档未提供；进料配比（confounders[2]）未测量。

**局限（model）**：焓平衡线性化近似；CCF 线性相关度量对非线性汽提 VLE 的适用性；弱签名下方差效应量的稳健性依赖 Levene 检验假设。

**诚实声明**：本报告不含任何像素级视觉主张；所有数字可溯源至 §7.2 所列工件；在判别量补测完成前，H1 与 H6 之间不作方向性结论——这是弱签名数据下可辩护的最强诚实陈述，也是 COMPETING_SET 三态协议的要求。
