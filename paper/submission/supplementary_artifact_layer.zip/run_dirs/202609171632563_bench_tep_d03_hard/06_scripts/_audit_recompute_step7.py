# Step 7 FINAL audit - independent recomputation from 00_input/data.csv (Auditor Sun)
import csv, math

path = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171632563_bench_tep_d03_hard/00_input/data.csv"
with open(path, newline='', encoding='utf-8') as f:
    rows = list(csv.reader(f))
header = rows[0]
data = rows[1:]
n = len(data)
print("rows:", n, "cols:", len(header))

def col(name):
    j = header.index(name)
    return [float(r[j]) for r in data]

def mean(x): return sum(x)/len(x)
def var(x, ddof=0):
    m = mean(x); return sum((v-m)**2 for v in x)/(len(x)-ddof)
def sd(x, ddof=0): return math.sqrt(var(x, ddof))
def corr(a, b):
    ma, mb = mean(a), mean(b)
    num = sum((x-ma)*(y-mb) for x, y in zip(a, b))
    den = math.sqrt(var(a)*var(b)) * len(a) if False else math.sqrt(sum((x-ma)**2 for x in a)*sum((y-mb)**2 for y in b))
    return num/den

B = slice(0, 160)        # 1-based 1-160
P = slice(160, 960)      # 1-based 161-960

# --- 1. std ratios (baseline vs post), ddof=1 ---
for c in ["XMV_9", "XMEAS_19", "XMEAS_18"]:
    x = col(c)
    sb, sp = sd(x[B], 1), sd(x[P], 1)
    print(f"{c}: std {sb:.4f} -> {sp:.4f} ratio={sp/sb:.4f} var_ratio={(sp/sb)**2:.3f}")

# --- 2. mean shifts ---
x19 = col("XMEAS_19"); x18 = col("XMEAS_18")
m19b, m19p = mean(x19[B]), mean(x19[P])
m18b, m18p = mean(x18[B]), mean(x18[P])
print(f"XMEAS_19 mean {m19b:.2f} -> {m19p:.2f} ({(m19p/m19b-1)*100:.2f}%)")
print(f"XMEAS_18 mean {m18b:.3f} -> {m18p:.3f} ({(m18p/m18b-1)*100:.2f}%)")

# --- 3. >=3sigma excursions: baseline-referenced z, ddof=1 and ddof=0 ---
for c in ["XMV_9", "XMEAS_19", "XMEAS_18"]:
    x = col(c)
    for dd in (1, 0):
        mb, sb = mean(x[B]), sd(x[B], dd)
        post_exc = sum(1 for v in x[P] if abs((v-mb)/sb) >= 3)
        base_exc = sum(1 for v in x[B] if abs((v-mb)/sb) >= 3)
        first = next(i+1 for i, v in enumerate(x) if i >= 160 and abs((v-mb)/sb) >= 3)
        mx = max(abs((v-mb)/sb) for v in x[P])
        if dd == 1:
            print(f"{c}: exc_base={base_exc} exc_post={post_exc} first(1-based)={first} max|z|={mx:.2f} (ddof=1)")
        else:
            print(f"{c}:   ddof=0 first={first} max|z|={mx:.2f}")

# --- 4. correlation steam flow vs stripper temp ---
a, b = col("XMEAS_19"), col("XMEAS_18")
r0 = corr(a, b)
# pipeline lag_ccf convention: ccf(lag)=corr(xs[lag:], ys[:-lag]); lag>0 => y leads x
ccf_pos1 = corr(a[1:], b[:-1])   # lag +1
ccf_neg1 = corr(a[:-1], b[1:])   # lag -1
print(f"r_lag0={r0:.4f}  ccf(+1)={ccf_pos1:.4f}  ccf(-1)={ccf_neg1:.4f}  delta_best_vs_lag0={abs(ccf_pos1-r0):.4f}")

# --- 5. structure pair valve-flow ---
v9 = col("XMV_9")
print(f"r(XMEAS_19, XMV_9) lag0 = {corr(v9, x19):.4f}")

# --- 6. flow-channel discriminability ---
x2 = col("XMEAS_2")
print(f"r(XMEAS_2, XMEAS_18) lag0 = {corr(x2, x18):.4f}")

# --- 7. settled rolling-200 mean z (last window of each segment, baseline-referenced) ---
def roll_last_z(x, seg, mb, sb, w=200):
    lo, hi = seg
    seg = x[lo:hi]
    # last non-overlapping-ish rolling mean within segment
    vals = [mean(seg[max(0, i-w+1):i+1]) for i in range(w-1, len(seg))]
    z_last = (mean(seg[-w:]) - mb)/sb
    return z_last
for c in ["XMEAS_19", "XMV_9", "XMEAS_18"]:
    x = col(c)
    mb, sb = mean(x[B]), sd(x[B], 1)
    zb = (mean(x[B][-200:]) - mb)/sb
    zp = (mean(x[P][-200:]) - mb)/sb
    print(f"{c}: settled roll-200 mean z: baseline-last200={zb:+.3f} post-last200={zp:+.3f}")

# --- 8. half-window drift for XMEAS_18 ---
h1 = slice(160, 480); h2 = slice(480, 960)
mb, sb = mean(x18[B]), sd(x18[B], 1)
z1 = (mean(x18[h1])-mb)/sb; z2 = (mean(x18[h2])-mb)/sb
print(f"XMEAS_18 half-window z: {z1:+.3f} -> {z2:+.3f}")

# --- 9. feeds & reactor control group (exclusion basis) ---
for c in ["XMEAS_9", "XMEAS_21", "XMV_10", "XMV_11", "XMEAS_2", "XMEAS_3", "XMEAS_14", "XMEAS_17"]:
    x = col(c)
    mb, sb = mean(x[B]), sd(x[B], 1)
    zb = (mean(x[P])-mb)/sb
    vr = var(x[P], 1)/var(x[B], 1)
    print(f"{c}: mean-z(post vs base)={zb:+.3f} var(post/base)={vr:.3f}")

# --- 10. column inventory: judge-discerning channels absent? ---
print("header channels containing 'header/pressure' check: XMEAS_7 present:", "XMEAS_7" in header,
      "; total XMEAS:", sum(1 for h in header if h.startswith("XMEAS")),
      "; total XMV:", sum(1 for h in header if h.startswith("XMV")))
