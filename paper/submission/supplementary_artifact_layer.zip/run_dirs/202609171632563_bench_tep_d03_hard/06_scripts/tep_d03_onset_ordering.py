# -*- coding: utf-8 -*-
"""Rolling-window mean-shift onset (temporal precedence, anti-speculation condition 1).
For each column: baseline-referenced z of a trailing 20-sample (60 min) mean;
onset_idx = first index >= 160 where |z_roll| stays >= 0.5 for >= 10 consecutive samples.
Updates 06_scripts/semantic_analysis_results.json (key: rolling_onset)."""
import json, os
import numpy as np
import pandas as pd

RUN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
df = pd.read_csv(os.path.join(RUN_DIR, "00_input", "data.csv"))
B, P0, W, MINRUN = 160, 160, 20, 10

OUT = os.path.join(RUN_DIR, "06_scripts", "semantic_analysis_results.json")
res = json.load(open(OUT, encoding="utf-8"))

cols = ["XMEAS_18", "XMEAS_19", "XMV_9", "XMEAS_11", "XMEAS_22", "XMV_11",
        "XMEAS_16", "XMEAS_7", "XMEAS_13", "XMEAS_9", "XMV_10", "XMEAS_21",
        "XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_41",
        "XMEAS_3", "XMEAS_20", "XMEAS_9"]
onset = {}
for c in cols:
    b = df[c].astype(float).values[:B]
    mb, sb = b.mean(), b.std(ddof=1)
    roll = pd.Series(df[c].astype(float).values).rolling(W, min_periods=W).mean().values
    z = (roll - mb) / sb
    ok = np.zeros(len(z), dtype=bool)
    ok[P0:] = np.abs(z[P0:]) >= 0.5
    onset_idx, run = None, 0
    for i in range(P0, len(z)):
        run = run + 1 if ok[i] else 0
        if run >= MINRUN:
            onset_idx = i - MINRUN + 1
            break
    end_mean_z = round(float(np.nanmean(z[800:])), 3)
    onset[c] = {"rolling_onset_idx": onset_idx,
                "rolling_onset_sample_1based": (onset_idx + 1) if onset_idx is not None else None,
                "z_roll_mean_last200": end_mean_z}
res["rolling_onset"] = onset
json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(onset, indent=1))
