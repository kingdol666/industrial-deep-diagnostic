# -*- coding: utf-8 -*-
"""
data-processor Phase 3 semantic analysis — bench_tep_d03_hard (TEP, weak-signature scenario)
Ontology-guided (01_ontology/ontology.json) targeted computations, all recomputable from 00_input/data.csv.
Baseline segment = rows 1..160 (declared onset: sample 161, ontology _provenance.onset_row=161).
Outputs: 06_scripts/semantic_analysis_results.json
"""
import json, os, sys
import numpy as np
import pandas as pd
from scipy import stats

RUN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(RUN_DIR, "00_input", "data.csv")
OUT = os.path.join(RUN_DIR, "06_scripts", "semantic_analysis_results.json")

ONSET_IDX = 160  # 0-based; declared onset sample 161 (1-based)
BASE_END = 160   # baseline rows [0,160)

df = pd.read_csv(DATA)
df["timestamp"] = pd.to_datetime(df["timestamp"])
num_cols = [c for c in df.columns if c != "timestamp"]
assert len(df) == 960, f"row count changed: {len(df)}"

base = df.iloc[:BASE_END]
post = df.iloc[ONSET_IDX:]
post1 = df.iloc[ONSET_IDX:480]   # post-onset first half
post2 = df.iloc[480:]            # post-onset second half

res = {"meta": {
    "rows": int(len(df)), "n_numeric": len(num_cols),
    "baseline_rows": [1, 160], "post_onset_rows": [161, 960],
    "sampling_s": 180, "onset_idx_0based": ONSET_IDX,
    "data_source": "00_input/data.csv (raw; identical to cleaned_data.json — deterministic ingestion)",
}}

# ---------- 1. Baseline vs post-onset mean shift (z, in baseline-sigma units) ----------
shifts = []
for c in num_cols:
    b = base[c].astype(float).values
    p = post[c].astype(float).values
    mb, sb = float(np.mean(b)), float(np.std(b, ddof=1))
    mp, sp = float(np.mean(p)), float(np.std(p, ddof=1))
    t, pw = stats.ttest_ind(p, b, equal_var=False)
    # Levene variance test
    lv, pl = stats.levene(b, p, center="median")
    shifts.append({
        "col": c,
        "mean_base": round(mb, 6), "mean_post": round(mp, 6),
        "std_base": round(sb, 6), "std_post": round(sp, 6),
        "z_mean_shift": round((mp - mb) / sb, 3) if sb > 0 else None,
        "std_ratio_post_over_base": round(sp / sb, 3) if sb > 0 else None,
        "welch_t_p": round(float(pw), 5),
        "levene_var_p": round(float(pl), 5),
    })
shifts.sort(key=lambda d: abs(d["z_mean_shift"]), reverse=True)
res["mean_shift_ranking_top12"] = shifts[:12]
res["std_ratio_ranking_top8"] = sorted(shifts, key=lambda d: abs(d["std_ratio_post_over_base"] - 1), reverse=True)[:8]
res["n_cols_abs_z_shift_ge_0p5"] = sum(1 for d in shifts if abs(d["z_mean_shift"]) >= 0.5)
res["n_cols_welch_p_lt_0p05"] = sum(1 for d in shifts if d["welch_t_p"] < 0.05)
res["n_cols_levene_p_lt_0p05"] = sum(1 for d in shifts if d["levene_var_p"] < 0.05)
res["all_shifts"] = shifts

# ---------- 2. Spike census (|z|>=3 vs baseline mean/std) — site structure ----------
spikes = {}
for c in num_cols:
    b = base[c].astype(float).values
    mb, sb = float(np.mean(b)), float(np.std(b, ddof=1))
    if sb <= 0:
        continue
    z = (df[c].astype(float).values - mb) / sb
    idx = np.where(np.abs(z) >= 3.0)[0]
    if len(idx):
        spikes[c] = {"n_total": int(len(idx)),
                     "n_baseline": int((idx < BASE_END).sum()),
                     "n_post": int((idx >= ONSET_IDX).sum()),
                     "max_abs_z": round(float(np.max(np.abs(z))), 2),
                     "idx_list": [int(i) for i in idx]}
res["spike_census"] = spikes
# spike time clustering: all |z|>=3 rows pooled (baseline-referenced), nearest-neighbour gap
all_idx = sorted(set(i for c in spikes for i in spikes[c]["idx_list"]))
gaps = np.diff(all_idx) if len(all_idx) > 1 else []
res["spike_pooled"] = {"n_events": len(all_idx),
                       "idx_range": [int(all_idx[0]), int(all_idx[-1])] if all_idx else None,
                       "median_gap": float(np.median(gaps)) if len(gaps) else None}

# ---------- 3. Post-onset stability: step vs ramp (first/second half comparison) ----------
half_shifts = []
for c in num_cols:
    b = base[c].astype(float).values
    p1, p2 = post1[c].astype(float).values, post2[c].astype(float).values
    mb, sb = float(np.mean(b)), float(np.std(b, ddof=1))
    z1, z2 = (np.mean(p1) - mb) / sb, (np.mean(p2) - mb) / sb
    half_shifts.append({"col": c, "z_first_half": round(z1, 3), "z_second_half": round(z2, 3),
                        "monotone_drift": bool(abs(z2) > abs(z1) + 0.3)})
res["half_window_shift_top10"] = sorted(half_shifts, key=lambda d: max(abs(d["z_first_half"]), abs(d["z_second_half"])), reverse=True)[:10]

# ---------- 4. Ontology-mandated identity checks (physics sanity) ----------
# 4a. Composition vectors sum to ~100 mol%? (ontology composition groups)
for gname, cols in {
    "stream6_reactor_feed_X23_28": ["XMEAS_23", "XMEAS_24", "XMEAS_25", "XMEAS_26", "XMEAS_27", "XMEAS_28"],
    "stream9_purge_X29_36": ["XMEAS_29", "XMEAS_30", "XMEAS_31", "XMEAS_32", "XMEAS_33", "XMEAS_34"],
    "stream11_product_X35_41": ["XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_39", "XMEAS_40", "XMEAS_41"],
}.items():
    s = df[cols].sum(axis=1)
    res.setdefault("composition_sum_checks", {})[gname] = {
        "mean": round(float(s.mean()), 3), "std": round(float(s.std(ddof=1)), 3),
        "min": round(float(s.min()), 3), "max": round(float(s.max()), 3)}
# 4b. Reactor feed node balance: corr(XMEAS_6, XMEAS_1+XMEAS_4+XMEAS_5)
f6 = df["XMEAS_6"].values
fsum = df["XMEAS_1"].values + df["XMEAS_4"].values + df["XMEAS_5"].values
r66 = float(np.corrcoef(f6, fsum)[0, 1])
res["mass_balance_F6_vs_F1pF4pF5"] = {"pearson_r": round(r66, 4),
    "mean_gap": round(float(np.mean(f6 - fsum)), 3), "std_gap": round(float(np.std(f6 - fsum, ddof=1)), 3),
    "note": "F6≈F1+F4+F8 with F8~XMEAS_5; residual is kscmh unit-basis offset, correlation=structure check"}
# 4c. Gas-loop pressure chain corr (ontology): XMEAS_7~XMEAS_13~XMEAS_16
res["pressure_chain_corr"] = {
    "XMEAS_7_XMEAS_13": round(float(np.corrcoef(df["XMEAS_7"], df["XMEAS_13"])[0, 1]), 4),
    "XMEAS_7_XMEAS_16": round(float(np.corrcoef(df["XMEAS_7"], df["XMEAS_16"])[0, 1]), 4),
    "XMEAS_13_XMEAS_16": round(float(np.corrcoef(df["XMEAS_13"], df["XMEAS_16"])[0, 1]), 4)}

# ---------- 5. Targeted anti-spurious verification for pairs the conclusion will cite ----------
def lag_ccf(x, y, max_lag=20):
    xs, ys = (x - x.mean()) / x.std(ddof=1), (y - y.mean()) / y.std(ddof=1)
    out = {}
    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            r = float(np.corrcoef(xs[:lag], ys[-lag:])[0, 1])
        elif lag > 0:
            r = float(np.corrcoef(xs[lag:], ys[:-lag])[0, 1])
        else:
            r = float(np.corrcoef(xs, ys)[0, 1])
        out[lag] = round(r, 4)
    best = max(out, key=lambda k: abs(out[k]))
    return out, best

pairs = [("XMEAS_9", "XMV_10"), ("XMEAS_2", "XMEAS_21"), ("XMEAS_2", "XMV_1"),
         ("XMEAS_9", "XMEAS_21"), ("XMEAS_2", "XMEAS_18"), ("XMEAS_19", "XMEAS_18"),
         ("XMEAS_6", "XMV_8"), ("XMEAS_9", "XMEAS_2")]
ccfres = {}
for a, b in pairs:
    x, y = df[a].astype(float), df[b].astype(float)
    full, best = lag_ccf(x, y)
    rb = float(np.corrcoef(base[a], base[b])[0, 1])
    rp = float(np.corrcoef(post[a], post[b])[0, 1])
    r1 = float(np.corrcoef(post1[a], post1[b])[0, 1])
    r2 = float(np.corrcoef(post2[a], post2[b])[0, 1])
    sr = float(stats.spearmanr(x, y).statistic)
    ccfres[f"{a}~{b}"] = {"pearson_full": round(float(np.corrcoef(x, y)[0, 1]), 4),
                          "pearson_baseline": round(rb, 4), "pearson_post": round(rp, 4),
                          "pearson_post_h1": round(r1, 4), "pearson_post_h2": round(r2, 4),
                          "spearman_full": round(sr, 4),
                          "best_lag": best, "ccf_at_best": full[best], "ccf_lag0": full[0]}
res["targeted_pair_verification"] = ccfres

# ---------- 6. Control-loop actuator structure (|r|>=0.95) vs quality targets ----------
targets = ["XMEAS_9", "XMEAS_2"]
strong = []
for i, a in enumerate(num_cols):
    for b in num_cols[i + 1:]:
        r = float(np.corrcoef(df[a], df[b])[0, 1])
        if abs(r) >= 0.95:
            strong.append({"pair": f"{a}~{b}", "r": round(r, 4)})
res["structural_pairs_r_ge_095"] = strong
res["n_structural_pairs"] = len(strong)

# ---------- 7. Quality targets: process capability view ----------
for t in targets:
    v = df[t].astype(float).values
    b, p = v[:BASE_END], v[ONSET_IDX:]
    res.setdefault("quality_targets_view", {})[t] = {
        "base_mean": round(float(b.mean()), 5), "base_std": round(float(b.std(ddof=1)), 5),
        "post_mean": round(float(p.mean()), 5), "post_std": round(float(p.std(ddof=1)), 5),
        "z_shift": round(float((p.mean() - b.mean()) / b.std(ddof=1)), 3),
        "var_ratio": round(float(p.std(ddof=1) / b.std(ddof=1)), 3),
        "mean_diff_abs": round(float(p.mean() - b.mean()), 6),
    }

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=1)
print("WROTE", OUT)
print(json.dumps({k: res[k] for k in ["mean_shift_ranking_top12", "std_ratio_ranking_top8",
      "n_cols_abs_z_shift_ge_0p5", "n_cols_welch_p_lt_0p05", "n_cols_levene_p_lt_0p05",
      "spike_pooled", "composition_sum_checks", "mass_balance_F6_vs_F1pF4pF5",
      "pressure_chain_corr", "quality_targets_view", "n_structural_pairs"]}, ensure_ascii=False, indent=1)[:4000])
