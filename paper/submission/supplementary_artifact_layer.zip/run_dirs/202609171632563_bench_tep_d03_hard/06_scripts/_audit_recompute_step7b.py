import csv, math
path = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171632563_bench_tep_d03_hard/00_input/data.csv"
with open(path, newline='', encoding='utf-8') as f:
    rows = list(csv.reader(f))
header, data = rows[0], rows[1:]
def col(name):
    j = header.index(name); return [float(r[j]) for r in data]
def mean(x): return sum(x)/len(x)
def var(x, ddof=0):
    m = mean(x); return sum((v-m)**2 for v in x)/(len(x)-ddof)
def sd(x, ddof=0): return math.sqrt(var(x, ddof))
B = slice(0,160); P = slice(160,960)

# H4: feed valves XMV_1..4 + XMEAS_1/XMEAS_4 std-ratio & var-ratio
print("-- H4 feed valves/flows (std_ratio | var_ratio) --")
for c in ["XMV_1","XMV_2","XMV_3","XMV_4","XMEAS_1","XMEAS_4"]:
    x = col(c); sr = sd(x[P],1)/sd(x[B],1)
    print(f"{c}: std_ratio={sr:.3f} var_ratio={sr**2:.3f}")

# H2/H6 temporal: first >=3sigma excursion (baseline-ref z, ddof=1), 1-based
print("-- first >=3sigma excursion (1-based, ddof=1) --")
for c in ["XMEAS_11","XMEAS_22","XMEAS_3","XMEAS_14","XMEAS_2"]:
    x = col(c); mb, sb = mean(x[B]), sd(x[B],1)
    idx = next((i+1 for i in range(160,960) if abs((x[i]-mb)/sb)>=3), None)
    print(f"{c}: first={idx}")

# XMV_11 / XMEAS_9 rolling onset check: does any rolling-20 mean |z|>=1 occur in post?
def roll_onset(x, mb, sb, thr=1.0, w=20):
    for i in range(160+w, 960):
        m = mean(x[i-w:i])
        if abs((m-mb)/sb) >= thr:
            return i  # 1-based end index approx
    return None
for c in ["XMV_11","XMEAS_9","XMEAS_21","XMV_10"]:
    x = col(c); mb, sb = mean(x[B]), sd(x[B],1)
    print(f"{c}: rolling-20 onset @thr1.0 (end-idx approx) = {roll_onset(x,mb,sb)}; mean-z={(mean(x[P])-mb)/sb:+.3f} std_ratio={sd(x[P],1)/sd(x[B],1):.3f}")
