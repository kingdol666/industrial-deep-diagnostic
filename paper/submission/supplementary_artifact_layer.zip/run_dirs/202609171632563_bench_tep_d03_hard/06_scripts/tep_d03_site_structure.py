# -*- coding: utf-8 -*-
"""Follow-up: per-loop variance table, composition closure alt-grouping, first-excursion ordering.
Appends/updates 06_scripts/semantic_analysis_results.json (key: followup)."""
import json, os
import numpy as np
import pandas as pd

RUN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
df = pd.read_csv(os.path.join(RUN_DIR, "00_input", "data.csv"))
B, P0 = 160, 160
base, post = df.iloc[:B], df.iloc[P0:]

OUT = os.path.join(RUN_DIR, "06_scripts", "semantic_analysis_results.json")
res = json.load(open(OUT, encoding="utf-8"))

num_cols = [c for c in df.columns if c != "timestamp"]
rows = []
for c in num_cols:
    b = base[c].astype(float).values
    p = post[c].astype(float).values
    mb, sb = b.mean(), b.std(ddof=1)
    mp, sp = p.mean(), p.std(ddof=1)
    zb = np.abs((b - mb) / sb)
    zp = np.abs((p - mp) / sb)  # not used; baseline-referenced below
    zall = np.abs((df[c].astype(float).values - mb) / sb)
    idx3 = np.where(zall >= 3)[0]
    first_post = int(idx3[idx3 >= P0][0]) if len(idx3[idx3 >= P0]) else None
    rows.append({"col": c, "z_shift": round((mp - mb) / sb, 3),
                 "var_ratio": round(sp / sb, 3), "first_post_excursion_idx": first_post})
res["followup_loop_table"] = rows

# composition closure alternative grouping (data-implied vs ontology grouping)
alt = {}
for name, cols in {
    "alt_stream9_purge_29_36": [f"XMEAS_{i}" for i in range(29, 37)],
    "alt_stream11_product_37_41": [f"XMEAS_{i}" for i in range(37, 42)],
    "ontology_stream9_29_34": [f"XMEAS_{i}" for i in range(29, 35)],
    "ontology_stream11_35_41": [f"XMEAS_{i}" for i in range(35, 42)],
}.items():
    s = df[cols].sum(axis=1)
    alt[name] = {"mean": round(float(s.mean()), 3), "std": round(float(s.std(ddof=1)), 3),
                 "closure_to_100_ok": bool(abs(s.mean() - 100) < 2)}
res["composition_closure_alt_grouping"] = alt

# sustained-run length for the primary site columns (consecutive |z|>=2 runs, baseline-referenced)
runs = {}
for c in ["XMEAS_18", "XMEAS_19", "XMV_9", "XMEAS_38", "XMEAS_16", "XMEAS_11"]:
    b = base[c].astype(float).values
    mb, sb = b.mean(), b.std(ddof=1)
    z = np.abs((df[c].astype(float).values - mb) / sb)
    mask = z >= 2
    best, cur, start, best_start = 0, 0, 0, 0
    for i, m in enumerate(mask):
        if m:
            if cur == 0:
                start = i
            cur += 1
            if cur > best:
                best, best_start = cur, start
        else:
            cur = 0
    runs[c] = {"longest_run_len_ge2sigma": int(best), "run_start_idx": int(best_start) if best else None,
               "run_start_sample_1based": int(best_start + 1) if best else None}
res["sustained_runs"] = runs

json.dump(res, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
sel = [r for r in rows if r["col"] in
       ["XMEAS_9", "XMEAS_21", "XMV_10", "XMEAS_7", "XMEAS_8", "XMEAS_6",
        "XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4", "XMV_1", "XMV_2", "XMV_3", "XMV_4",
        "XMEAS_5", "XMEAS_10", "XMV_5", "XMV_6", "XMEAS_20",
        "XMEAS_11", "XMEAS_22", "XMV_11", "XMEAS_12", "XMEAS_13", "XMEAS_14", "XMV_7",
        "XMEAS_15", "XMEAS_16", "XMEAS_17", "XMEAS_18", "XMEAS_19", "XMV_9", "XMV_8",
        "XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_39", "XMEAS_40", "XMEAS_41"]]
print(json.dumps({"loop_table": sel, "closure": alt, "runs": runs}, ensure_ascii=False, indent=1))
