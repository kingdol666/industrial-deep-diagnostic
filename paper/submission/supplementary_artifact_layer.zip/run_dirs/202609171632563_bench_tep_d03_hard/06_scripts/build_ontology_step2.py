# -*- coding: utf-8 -*-
"""
Step 2+2.5 context-builder: build 01_ontology/ontology.json for the TE benchmark scenario.
Data truth mandate: every numeric range below is recomputed from RUN_DIR/00_input/data.csv
(baseline segment = samples 1..160, pre-onset per user_context.json; anomaly segment = 161..end).
Persona: Professor Wang — failure analysis. RAG engine unavailable -> parameter_to_physics.json
pattern library + standard TE (Downs & Vogel 1993) engineering semantics.
"""
import csv, json, statistics, shutil, os, math
from datetime import datetime, timedelta

RUN_DIR = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171632563_bench_tep_d03_hard"
DATA = os.path.join(RUN_DIR, "00_input", "data.csv")
OUT_DIR = os.path.join(RUN_DIR, "01_ontology")
ONSET_ROW = 160  # user_context: anomaly starts at sample 161 (1-indexed) -> rows 0..159 are baseline

os.makedirs(OUT_DIR, exist_ok=True)

# ---------------------------------------------------------------- load data
with open(DATA, "r", encoding="utf-8", newline="") as f:
    rdr = csv.reader(f)
    header = next(rdr)
    rows = [[float(x) for x in r[1:]] for r in rdr if r and r[0]]
cols = header[1:]
n = len(rows)
base = rows[:ONSET_ROW]
post = rows[ONSET_ROW:]

def seg_stats(seg, j):
    vals = [r[j] for r in seg]
    m = statistics.fmean(vals)
    s = statistics.pstdev(vals) if len(vals) > 1 else 0.0
    return m, s

stats = {}
for j, c in enumerate(cols):
    bm, bs = seg_stats(base, j)
    pm, ps = seg_stats(post, j)
    z = (pm - bm) / bs if bs > 1e-12 else 0.0
    stats[c] = {"base_mean": bm, "base_std": bs, "post_mean": pm, "post_std": ps, "z": z}

ts0 = "2020-01-01T00:00:00"  # first timestamp in data.csv
ts_end = (datetime(2020, 1, 1, 0, 0, 0) + timedelta(minutes=3 * (n - 1))).strftime("%Y-%m-%dT%H:%M:%S")

# ------------------------------------------------- TE semantics (Downs & Vogel 1993)
# inference_basis template
BASIS = "TE标准编号语义(Downs & Vogel 1993)+过程描述(反应器-冷凝器-分离器-汽提塔+循环压缩机)；normal_range=基线段(样本1-160)均值±3σ，可由00_input/data.csv重算"

def zm(z):
    d = "↑" if z >= 0 else "↓"
    return f"{d}{abs(z):.1f}σ"

def xmeas(idx, name_en, unit, meaning, equip, stage, law, expected):
    c = f"XMEAS_{idx}"
    st = stats[c]
    nr = [round(st["base_mean"] - 3 * st["base_std"], 4), round(st["base_mean"] + 3 * st["base_std"], 4)]
    z = st["z"]
    if abs(z) >= 3:
        bm_ = "CONTRADICTED"
        disc = f"异常段(样本161-960)均值较基线偏移{zm(z)}，超出基线±3σ带；记为待诊断偏离信号（弱签名场景，幅度需下游量化复核）"
    else:
        bm_ = "CONSISTENT"
        disc = None
    return {
        "name": name_en, "column": c, "unit": unit, "role": "predictor",
        "physical_meaning": meaning,
        "physical_meaning_confidence": "KNOWN",
        "auto_inferred": True,
        "inference_basis": BASIS,
        "normal_range": nr,
        "setpoint": round(st["base_mean"], 4),
        "equipment_ref": equip, "stage_ref": stage,
        "governing_law": law,
        "expected_data_behavior": expected,
        "observed_data_behavior": f"基线(1-160)均值={st['base_mean']:.4g}±{st['base_std']:.2g}；异常段(161-960)均值={st['post_mean']:.4g}，偏移{zm(z)}",
        "behavior_match": bm_,
        "discrepancy_signal": disc if disc is not None else "",
        "knowledge_source": "auto_inferred",
    }

def xmv(idx, name_en, meaning, equip, stage, law, expected):
    c = f"XMV_{idx}"
    st = stats[c]
    z = st["z"]
    bm_ = "CONTRADICTED" if abs(z) >= 3 else "CONSISTENT"
    disc = (f"操纵变量异常段均值偏移{zm(z)}（阀位/指令持续偏离基线设定：控制器对扰动的响应，或设定变更）" if bm_ == "CONTRADICTED" else None)
    return {
        "name": name_en, "column": c, "unit": "%", "role": "control",
        "physical_meaning": meaning,
        "physical_meaning_confidence": "KNOWN",
        "auto_inferred": True,
        "inference_basis": BASIS + "；数值域16.8-63.6，与归一化阀位(0-100%)量程一致（量纲标度推断）",
        "control_type": "output",
        "setpoint": round(st["base_mean"], 2),
        "equipment_ref": equip, "stage_ref": stage,
        "governing_law": law,
        "expected_data_behavior": expected,
        "observed_data_behavior": f"基线均值={st['base_mean']:.4g}±{st['base_std']:.2g}；异常段均值={st['post_mean']:.4g}，偏移{zm(z)}",
        "behavior_match": bm_,
        "discrepancy_signal": disc if disc is not None else "",
        "knowledge_source": "auto_inferred",
    }

XP = []
XP.append(xmeas(1, "A Feed (Stream 1)", "kscmh", "组分A新鲜进料流量（stream 1，主反应物）", "EQ_REACTOR", "ST_FEED_REACT", "阀门流量方程 F=Cv·f(x)·sqrt(ΔP/ρ)；标况体积计量", "闭环流量控制，围绕基线窄带波动"))
XP.append(xmeas(2, "D Feed (Stream 2)", "kg/h", "组分D新鲜进料流量（stream 2，经汽提塔进入系统，反应物兼溶剂）", "EQ_STRIPPER", "ST_STRIPPER", "质量流量计量", "流量控制环，均值稳定"))
XP.append(xmeas(3, "E Feed (Stream 3)", "kg/h", "组分E新鲜进料流量（stream 3，经汽提塔进入系统，反应物）", "EQ_STRIPPER", "ST_STRIPPER", "质量流量计量", "流量控制环，均值稳定"))
XP.append(xmeas(4, "A and C Feed (Stream 4)", "kscmh", "A+C混合新鲜进料流量（stream 4）", "EQ_REACTOR", "ST_FEED_REACT", "阀门流量方程", "流量控制环，均值稳定"))
XP.append(xmeas(5, "Recycle Flow (Stream 8)", "kscmh", "循环气流量（stream 8，分离器气相经压缩机返回反应器）", "EQ_COMPRESSOR", "ST_RECYCLE", "压缩机功能律与管路阻力特性", "随系统压力/压缩机工况波动"))
XP.append(xmeas(6, "Reactor Feed Rate (Stream 6)", "kscmh", "反应器总进料流量（stream 6，新鲜进料+循环气汇合）", "EQ_REACTOR", "ST_FEED_REACT", "节点物料平衡 F6=F1+F4+F8", "与进料和循环量强相关，均值稳定"))
XP.append(xmeas(7, "Reactor Pressure", "kPa gauge", "反应器压力", "EQ_REACTOR", "ST_FEED_REACT", "气相物料平衡 dN/dt=ΣF_in−ΣF_out + 理想气体 PV=nRT", "压力控制环（经压缩循环与放空）窄带波动"))
XP.append(xmeas(8, "Reactor Level", "%", "反应器液位（滞液量）", "EQ_REACTOR", "ST_FEED_REACT", "液体积分物料平衡 dV/dt=F_in−F_out", "液位控制环，窄带波动"))
XP.append(xmeas(9, "Reactor Temperature", "°C", "反应器温度（放热反应，由冷却水移热控制）", "EQ_REACTOR", "ST_FEED_REACT", "能量平衡 Q_rxn=ṁ_cw·cp·(T21−T_in)＋Arrhenius k=k0·exp(−E/RT)", "温度控制环（XMV_10）窄带波动"))
XP.append(xmeas(10, "Purge Rate (Stream 9)", "kscmh", "放空流量（stream 9，分离器气相放空，控制惰性/组分库存）", "EQ_SEPARATOR", "ST_RECYCLE", "阀门流量方程；气相总平衡", "放空阀控制，均值稳定"))
XP.append(xmeas(11, "Product Sep Temp", "°C", "产品分离器温度（冷凝后气液分离罐操作温度）", "EQ_SEPARATOR", "ST_SEPARATION", "部分冷凝焓平衡＋Raoult VLE", "由冷凝器冷却水（XMV_11）控制，窄带波动"))
XP.append(xmeas(12, "Product Sep Level", "%", "产品分离器液位", "EQ_SEPARATOR", "ST_SEPARATION", "液体积分物料平衡", "液位控制环（XMV_7）"))
XP.append(xmeas(13, "Prod Sep Pressure", "kPa gauge", "产品分离器压力", "EQ_SEPARATOR", "ST_SEPARATION", "气相物料平衡（与反应器经管路连通）", "跟随反应器压力，略低"))
XP.append(xmeas(14, "Prod Sep Underflow (Stream 10)", "m3/h", "分离器液相出料流量（stream 10，去汽提塔）", "EQ_SEPARATOR", "ST_SEPARATION", "阀门流量方程；液体物料平衡", "出料阀控制，均值稳定"))
XP.append(xmeas(15, "Stripper Level", "%", "汽提塔塔釜/液位", "EQ_STRIPPER", "ST_STRIPPER", "液体积分物料平衡", "液位控制环（XMV_8）"))
XP.append(xmeas(16, "Stripper Pressure", "kPa gauge", "汽提塔操作压力", "EQ_STRIPPER", "ST_STRIPPER", "气相物料平衡（塔顶气返回分离/冷凝系统）", "窄带波动"))
XP.append(xmeas(17, "Stripper Underflow (Stream 11)", "m3/h", "汽提塔釜液产品流量（stream 11，产品G/H输出）", "EQ_STRIPPER", "ST_STRIPPER", "阀门流量方程；总物料平衡", "釜液阀控制，均值稳定"))
XP.append(xmeas(18, "Stripper Temperature", "°C", "汽提塔温度（蒸汽汽提强度指标）", "EQ_STRIPPER", "ST_STRIPPER", "焓平衡 Q=ṁ_steam·λ；VLE 泡点关系", "随蒸汽量与进料变化，窄带波动"))
XP.append(xmeas(19, "Stripper Steam Flow", "kg/h", "汽提蒸汽流量", "EQ_STRIPPER", "ST_STRIPPER", "蒸汽阀流量方程", "蒸汽阀控制，均值稳定"))
XP.append(xmeas(20, "Compressor Work", "kW", "循环压缩机功耗", "EQ_COMPRESSOR", "ST_RECYCLE", "压缩功 W=ṁ·cp·T1·[(P2/P1)^((k−1)/k)−1]", "随循环量与压比波动"))
XP.append(xmeas(21, "Reactor Cooling Water Outlet Temp", "°C", "反应器冷却水出口温度（移热负荷指标）", "EQ_CW_REACTOR", "ST_FEED_REACT", "Q=ṁ_cw·cp·(T_out−T_in)", "随反应放热与冷却水量反向波动"))
XP.append(xmeas(22, "Separator Cooling Water Outlet Temp", "°C", "冷凝器/分离器冷却水出口温度（冷凝负荷指标）", "EQ_CW_COND", "ST_SEPARATION", "Q=ṁ_cw·cp·(T_out−T_in)", "随冷凝负荷与冷却水量反向波动"))

comp6 = ["A", "B", "C", "D", "E", "F"]
comp9 = ["A", "B", "C", "D", "E", "F"]
comp11 = ["B", "C", "D", "E", "F", "G", "H"]
for i in range(23, 29):
    sp = comp6[i - 23]
    XP.append(xmeas(i, f"Component {sp} in Stream 6", "mol %",
                    f"反应器进料（stream 6）气相色谱组成：组分{sp}摩尔分数",
                    "EQ_REACTOR", "ST_FEED_REACT",
                    "组分物料平衡＋反应化学计量（A+C+D→G；A+C+E→H；A+C→F；3D→2F）",
                    "由进料配比与循环组成决定，慢变量"))
for i in range(29, 35):
    sp = comp9[i - 29]
    XP.append(xmeas(i, f"Component {sp} in Stream 9", "mol %",
                    f"放空气（stream 9）组成：组分{sp}摩尔分数（惰性/轻组分累积的敏感指标）",
                    "EQ_SEPARATOR", "ST_RECYCLE",
                    "组分物料平衡＋放空选择率",
                    "随放空量与反应消耗慢变"))
for i in range(35, 42):
    sp = comp11[i - 35]
    XP.append(xmeas(i, f"Component {sp} in Stream 11", "mol %",
                    f"汽提塔产品（stream 11）组成：组分{sp}摩尔分数（产品质量指标）",
                    "EQ_STRIPPER", "ST_STRIPPER",
                    "汽提VLE＋反应化学计量（G、H为目标产物）",
                    "产品质量受进料/蒸汽/反应深度影响，慢变量"))

XC = []
XC.append(xmv(1, "D Feed Flow Valve (Stream 2)", "D进料流量操纵变量（控制stream 2流量）", "EQ_STRIPPER", "ST_STRIPPER", "阀门流量方程 F=Cv·f(x)·sqrt(ΔP/ρ)", "由进料控制环设定，缓慢调整"))
XC.append(xmv(2, "E Feed Flow Valve (Stream 3)", "E进料流量操纵变量（控制stream 3流量）", "EQ_STRIPPER", "ST_STRIPPER", "阀门流量方程", "由进料控制环设定，缓慢调整"))
XC.append(xmv(3, "A Feed Flow Valve (Stream 1)", "A进料流量操纵变量（控制stream 1流量）", "EQ_REACTOR", "ST_FEED_REACT", "阀门流量方程", "由A组分/产品目标控制，缓慢调整"))
XC.append(xmv(4, "A and C Feed Valve (Stream 4)", "A+C混合进料操纵变量（控制stream 4流量）", "EQ_REACTOR", "ST_FEED_REACT", "阀门流量方程", "由进料控制环设定，缓慢调整"))
XC.append(xmv(5, "Compressor Recycle Valve", "压缩机循环阀开度（调节循环气量/系统压力）", "EQ_COMPRESSOR", "ST_RECYCLE", "压缩机特性曲线＋管路平衡点", "压力控制执行器，围绕基线窄带波动"))
XC.append(xmv(6, "Purge Valve (Stream 9)", "放空阀开度（控制stream 9放空量与惰性组分库存）", "EQ_SEPARATOR", "ST_RECYCLE", "阀门流量方程", "放空控制执行器，窄带波动"))
XC.append(xmv(7, "Separator Pot Liquid Flow Valve (Stream 10)", "分离器液相出料阀（控制stream 10流量与分离器液位）", "EQ_SEPARATOR", "ST_SEPARATION", "阀门流量方程；液位积分平衡", "液位/流量控制执行器"))
XC.append(xmv(8, "Separator/Stripper Liquid Flow Valve (Stream 11)", "汽提塔釜液/产品流量阀（控制stream 11流量与汽提塔液位；原文表记 'Separator Storm Liquid Flow' 为文献沿用笔误）", "EQ_STRIPPER", "ST_STRIPPER", "阀门流量方程；液位积分平衡", "液位/产品流量控制执行器"))
XC.append(xmv(9, "Stripper Steam Valve", "汽提蒸汽阀开度（控制汽提蒸汽量）", "EQ_STRIPPER", "ST_STRIPPER", "蒸汽阀流量方程", "蒸汽量控制执行器"))
XC.append(xmv(10, "Reactor Cooling Water Flow Valve", "反应器冷却水流量阀（反应器温度控制执行器）", "EQ_CW_REACTOR", "ST_FEED_REACT", "Q=ṁ_cw·cp·ΔT；串级控温", "温度控制环输出，围绕基线波动"))
XC.append(xmv(11, "Condenser Cooling Water Flow Valve", "冷凝器冷却水流量阀（分离器温度控制执行器）", "EQ_CW_COND", "ST_SEPARATION", "冷凝焓平衡 Q=ṁ_cw·cp·ΔT", "温度控制环输出，围绕基线波动"))

META = [{"name": "timestamp", "column": "timestamp", "role": "timestamp",
         "description": "采样时间戳，3分钟间隔（2020-01-01T00:00:00起，共960行）"}]

# ---------------------------------------------------------------- ontology
ontology = {
    "scene": {
        "name": "bench_tep_d03_hard",
        "process_type": "连续化工过程（Tennessee Eastman 反应-分离-循环流程，RAG不可用，采用TE标准语义+数据自证）",
        "production_goal": "由A/C/D/E进料连续生产G与H两种产品（stream 11），维持压力/温度/液位约束与产品质量",
        "equipment": [
            {"id": "EQ_REACTOR", "name": "反应器", "type": "连续搅拌釜反应器（CSTR，气-液两相，放热）",
             "function": "气液反应：A+C+D→G、A+C+E→H（目的产物），副反应 A+C→F、3D→2F（均放热）",
             "location": "流程前端；进料stream 1/4/6，出料stream 6(气)"},
            {"id": "EQ_CONDENSER", "name": "产品冷凝器", "type": "管壳式水冷冷凝器",
             "function": "部分冷凝反应器出料气流，未凝气去分离器气相", "location": "反应器下游"},
            {"id": "EQ_SEPARATOR", "name": "气液分离器（产品分离罐）", "type": "卧式闪蒸罐",
             "function": "气液分离：气相→循环压缩/放空，液相（stream 10）→汽提塔", "location": "冷凝器下游"},
            {"id": "EQ_COMPRESSOR", "name": "循环压缩机", "type": "离心压缩机",
             "function": "将分离器气相（stream 7）升压循环回反应器（stream 8），维持系统压力", "location": "分离器与反应器之间"},
            {"id": "EQ_STRIPPER", "name": "汽提塔", "type": "蒸汽汽提塔（板式/填料）",
             "function": "用蒸汽汽提分离器液相中的轻组分（返回循环），塔釜输出产品G/H（stream 11）；D/E进料由此入系统", "location": "分离器下游"},
            {"id": "EQ_CW_REACTOR", "name": "反应器冷却水回路", "type": "循环水冷回路（XMV_10调节）",
             "function": "移出反应热，控温XMEAS_9/21", "location": "反应器夹套/盘管"},
            {"id": "EQ_CW_COND", "name": "冷凝器冷却水回路", "type": "循环水冷回路（XMV_11调节）",
             "function": "提供冷凝负荷，控温XMEAS_11/22", "location": "冷凝器壳程"},
        ],
        "stages": [
            {"id": "ST_FEED_REACT", "name": "进料与反应", "sequence": 0, "typical_duration": "连续",
             "key_physics": "四步反应（均放热）：1) A+C+D→G  2) A+C+E→H  3) A+C→F  4) 3D→2F；Arrhenius速率温度耦合；总/组分物料平衡；能量平衡 Q=ṁ_cw·cp·ΔT",
             "key_parameters": ["XMEAS_1", "XMEAS_4", "XMEAS_6", "XMEAS_7", "XMEAS_8", "XMEAS_9", "XMV_3", "XMV_4", "XMV_10"]},
            {"id": "ST_SEPARATION", "name": "冷凝与气液分离", "sequence": 1, "typical_duration": "连续",
             "key_physics": "部分冷凝（焓平衡+冷凝曲线）；Raoult/气液平衡；罐液位积分平衡 dV/dt=F_in−F_out",
             "key_parameters": ["XMEAS_11", "XMEAS_12", "XMEAS_13", "XMEAS_14", "XMV_7", "XMV_11"]},
            {"id": "ST_RECYCLE", "name": "循环压缩与放空", "sequence": 2, "typical_duration": "连续",
             "key_physics": "气体总物料平衡（压力=库存指标）；放空选择率控制组分库存/惰性累积；压缩机功能律与压缩功",
             "key_parameters": ["XMEAS_5", "XMEAS_10", "XMEAS_13", "XMEAS_20", "XMV_5", "XMV_6"]},
            {"id": "ST_STRIPPER", "name": "汽提与产品输出", "sequence": 3, "typical_duration": "连续",
             "key_physics": "蒸汽汽提VLE（轻组分脱除返回循环）；塔釜产品质量（G/H摩尔分数）；D/E经本工段进入反应系统",
             "key_parameters": ["XMEAS_15", "XMEAS_17", "XMEAS_18", "XMEAS_19", "XMEAS_35", "XMEAS_40", "XMEAS_41", "XMV_1", "XMV_2", "XMV_8", "XMV_9"]},
        ],
        "objectives": [
            "维持G/H产品质量与目标产量（stream 11组成与流量）",
            "保持反应器压力/温度/液位与分离器/汽提塔工况在约束内",
            "控制惰性/副产物F库存（放空策略），最小化放空原料损失与压缩/蒸汽能耗",
        ],
    },
    "signals": {
        "inspection_signals": [],
        "process_parameters": XP,
        "control_variables": XC,
        "events": [],
        "metadata_columns": META,
    },
    "parameter_groups": {
        "fresh_feed_flows": ["XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4"],
        "reactor_conditions": ["XMEAS_6", "XMEAS_7", "XMEAS_8", "XMEAS_9"],
        "separator_conditions": ["XMEAS_11", "XMEAS_12", "XMEAS_13", "XMEAS_14"],
        "stripper_conditions": ["XMEAS_15", "XMEAS_16", "XMEAS_17", "XMEAS_18", "XMEAS_19"],
        "recycle_compressor": ["XMEAS_5", "XMEAS_10", "XMEAS_20"],
        "cooling_water_circuit": ["XMEAS_21", "XMEAS_22", "XMV_10", "XMV_11"],
        "composition_stream6_reactor_feed": ["XMEAS_23", "XMEAS_24", "XMEAS_25", "XMEAS_26", "XMEAS_27", "XMEAS_28"],
        "composition_stream9_purge": ["XMEAS_29", "XMEAS_30", "XMEAS_31", "XMEAS_32", "XMEAS_33", "XMEAS_34"],
        "composition_stream11_product": ["XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_39", "XMEAS_40", "XMEAS_41"],
        "feed_valves": ["XMV_1", "XMV_2", "XMV_3", "XMV_4"],
        "gas_loop_valves": ["XMV_5", "XMV_6"],
        "liquid_flow_valves": ["XMV_7", "XMV_8", "XMV_9"],
    },
    "relationships": [
        {"from": "XMV_10", "to": "XMEAS_9", "type": "control", "strength": "strong",
         "mechanism": "反应器冷却水阀开度↑→冷却水流量↑→移热Q↑→反应器温度↓（控温回路执行器）",
         "governing_equation": "Q = ṁ_cw·cp·(T21−T_cw_in)；dT/dt = (Q_rxn − Q)/ (M·cp)",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "即时~数十秒（热容惯性）",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_10", "to": "XMEAS_21", "type": "control", "strength": "strong",
         "mechanism": "冷却水流量↑→同等移热负荷下出口温升↓（反相关）",
         "governing_equation": "T21 = T_cw_in + Q/(ṁ_cw·cp)",
         "predicted_functional_form": "inverse", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_11", "to": "XMEAS_11", "type": "control", "strength": "strong",
         "mechanism": "冷凝器冷却水阀↑→冷凝负荷↑→分离器温度↓",
         "governing_equation": "Q_cond = ṁ_cw·cp·(T22−T_cw_in)；焓平衡决定闪蒸温度",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "秒~分钟",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_11", "to": "XMEAS_22", "type": "control", "strength": "strong",
         "mechanism": "冷凝器冷却水流量↑→同等冷凝负荷下出口温升↓",
         "governing_equation": "T22 = T_cw_in + Q_cond/(ṁ_cw·cp)",
         "predicted_functional_form": "inverse", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_6", "to": "XMEAS_10", "type": "control", "strength": "strong",
         "mechanism": "放空阀开度↑→放空流量↑",
         "governing_equation": "F9 = Cv·f(x)·sqrt((P13−P_amb)·ρ9)",
         "predicted_functional_form": "monotonic", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_10", "to": "XMEAS_7", "type": "causal", "strength": "moderate",
         "mechanism": "放空↑→系统气相库存下降速率↑→反应器/分离器压力↓（放空是唯一物料出口）",
         "governing_equation": "dN/dt = F1+F4+F8 − F6_out... − F9；PV=nRT",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "分钟级（气体库存缓冲）",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_5", "to": "XMEAS_5", "type": "control", "strength": "strong",
         "mechanism": "压缩机循环阀开度↑→循环气流量↑",
         "governing_equation": "压缩机特性曲线与管路阻力平衡点",
         "predicted_functional_form": "monotonic", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_5", "to": "XMEAS_20", "type": "causal", "strength": "moderate",
         "mechanism": "循环量↑/压比↑→压缩机功耗↑",
         "governing_equation": "W = ṁ·cp·T1·[(P2/P1)^((k−1)/k) − 1]",
         "predicted_functional_form": "monotonic", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_9", "to": "XMEAS_7", "type": "physical", "strength": "strong",
         "mechanism": "反应温度↑→反应速率（Arrhenius）↑→气相生成/消耗加快＋理想气体膨胀→压力正耦合",
         "governing_equation": "k = k0·exp(−E/RT)；PV=nRT",
         "predicted_functional_form": "exponential", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_1", "to": "XMEAS_6", "type": "physical", "strength": "strong",
         "mechanism": "反应器总进料=新鲜A+C+循环气（节点汇合）",
         "governing_equation": "F6 ≈ F1 + F4 + F8（换算到同一标况基准）",
         "predicted_functional_form": "linear", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_7", "to": "XMEAS_14", "type": "control", "strength": "strong",
         "mechanism": "分离器液相出料阀↑→stream 10流量↑",
         "governing_equation": "F10 = Cv·f(x)·sqrt(ΔP·ρ)",
         "predicted_functional_form": "monotonic", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_7", "to": "XMEAS_12", "type": "control", "strength": "strong",
         "mechanism": "出料↑（入料不变）→分离器液位↓",
         "governing_equation": "dV/dt = F_cond_in − F10",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "分钟级（罐容积分）",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_8", "to": "XMEAS_17", "type": "control", "strength": "strong",
         "mechanism": "釜液阀↑→stream 11产品流量↑",
         "governing_equation": "F11 = Cv·f(x)·sqrt(ΔP·ρ)",
         "predicted_functional_form": "monotonic", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_8", "to": "XMEAS_15", "type": "control", "strength": "strong",
         "mechanism": "釜液采出↑（进料不变）→汽提塔液位↓",
         "governing_equation": "dV/dt = F10+F2+F3 − F11 − V_vap",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "分钟级",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMV_9", "to": "XMEAS_19", "type": "control", "strength": "strong",
         "mechanism": "蒸汽阀↑→汽提蒸汽流量↑",
         "governing_equation": "F_steam = Cv·f(x)·sqrt(ΔP·ρ_steam)",
         "predicted_functional_form": "monotonic", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_19", "to": "XMEAS_18", "type": "causal", "strength": "strong",
         "mechanism": "蒸汽量↑→汽提热负荷↑→塔温↑",
         "governing_equation": "Q = ṁ_steam·λ_steam",
         "predicted_functional_form": "monotonic", "inferred": True, "time_lag": "分钟级（塔板水力学滞后）",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_2", "to": "XMEAS_18", "type": "causal", "strength": "moderate",
         "mechanism": "D进料↑→汽提塔冷进料负荷↑→同等蒸汽量下塔温↓",
         "governing_equation": "焓平衡：Q_steam = Q_vap + ΣF_i·cp·ΔT",
         "predicted_functional_form": "inverse", "inferred": True, "time_lag": "分钟级",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_2", "to": "XMEAS_38", "type": "causal", "strength": "moderate",
         "mechanism": "D进料↑→未反应D随产品排出↑→产品中D摩尔分数↑（D为中间反应物，3D→2F消耗）",
         "governing_equation": "组分物料平衡＋化学计量",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "长滞后（经反应-循环全程）",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_6", "to": "XMEAS_12", "type": "causal", "strength": "moderate",
         "mechanism": "反应器进料↑→冷凝入罐流量↑→分离器液位（同等采出下）↑",
         "governing_equation": "dV/dt = F_cond_in − F10",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "分钟级（管路+冷凝）",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_9", "to": "XMEAS_21", "type": "physical", "strength": "strong",
         "mechanism": "反应温度↑→放热负荷↑→同等冷却水量下冷却水出口温度↑",
         "governing_equation": "Q_rxn(T) 随T指数增长；T21 = T_in + Q_rxn/(ṁ_cw·cp)",
         "predicted_functional_form": "exponential", "inferred": True, "time_lag": "即时",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_10", "to": "XMEAS_29", "type": "causal", "strength": "weak",
         "mechanism": "放空量与放空组成联合决定组分库存衰减速率；放空↑→轻组分被更快带出→循环组成缓降",
         "governing_equation": "d(x_i·N)/dt = 进料x_i·F_in − 反应消耗 − x_i·F9",
         "predicted_functional_form": "delayed_response", "inferred": True, "time_lag": "长滞后（库存积分）",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
        {"from": "XMEAS_19", "to": "XMEAS_35", "type": "causal", "strength": "weak",
         "mechanism": "蒸汽量↑→轻组分（B等）脱除更完全→产品中轻组分摩尔分数↓",
         "governing_equation": "汽提VLE：y_i = K_i(T,P)·x_i",
         "predicted_functional_form": "inverse", "inferred": True, "time_lag": "分钟级",
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only"},
    ],
    "confounders": [
        {"variable": "循环回路耦合（recycle loop）", "why": "闭环循环使反应器/分离器/汽提塔几乎所有变量互相关，任何单变量漂移都会传播到全回路，伪相关风险极高（需滞后补偿CCF与稳态过滤）", "controlled": False},
        {"variable": "冷却水入口温度（未测量）", "why": "同时影响XMEAS_9/11/21/22，是冷却回路的共同驱动因素", "controlled": False},
        {"variable": "进料配比波动（stream 4中A/C比，未测量）", "why": "同时影响G/H生成比与放空/产品组成", "controlled": False},
        {"variable": "控制系统交互作用", "why": "温度/压力/液位多个控制环耦合，操纵变量（XMV）变化可能是响应而非原因（观测方向≠因果方向）", "controlled": False},
        {"variable": "生产负荷/操作点漂移", "why": "全流程流量类变量共同缩放，主成分方向易被误判为故障方向", "controlled": False},
    ],
    "metadata": {
        "units": {c: ("timestamp" if c == "timestamp" else ("%" if c.startswith("XMV_") else ("mol %" if 23 <= int(c.split("_")[1]) <= 41 else {
            "XMEAS_1": "kscmh", "XMEAS_2": "kg/h", "XMEAS_3": "kg/h", "XMEAS_4": "kscmh", "XMEAS_5": "kscmh", "XMEAS_6": "kscmh",
            "XMEAS_7": "kPa gauge", "XMEAS_8": "%", "XMEAS_9": "°C", "XMEAS_10": "kscmh", "XMEAS_11": "°C", "XMEAS_12": "%",
            "XMEAS_13": "kPa gauge", "XMEAS_14": "m3/h", "XMEAS_15": "%", "XMEAS_16": "kPa gauge", "XMEAS_17": "m3/h",
            "XMEAS_18": "°C", "XMEAS_19": "kg/h", "XMEAS_20": "kW", "XMEAS_21": "°C", "XMEAS_22": "°C"}[c])))
                  for c in header},
        "sampling_rate": "180 s（3分钟，user_context.json）",
        "batch_id": None,
        "timezone": None,
        "start_time": ts0,
        "end_time": ts_end,
        "product_grades": [{"name": "G/H 共产物（连续牌号，未提供牌号切换信息）", "key_parameter_differences": {}}],
    },
    "_provenance": {
        "built_by": "context-builder (Professor Wang persona)",
        "rag_engine": "unavailable (localhost:8764 connection refused, probe 2026-09-17T16:4x) → fallback: resources/parameter_to_physics.json 模式库 + TE标准语义领域知识",
        "normal_range_method": "基线段=样本1..160（user_context声明异常自样本161起）；均值±3·总体标准差；全部可由00_input/data.csv重算",
        "observed_behavior_method": "异常段=样本161..960均值 vs 基线段；偏移量以基线σ为单位(z)；Stage-1预检级别，完整统计分析由data-processor执行",
        "onset_row": 161,
        "weak_signature_note": "user_context：文献公认统计弱签名场景，全列谱偏离幅度小，需位点结构与排除法判别",
    },
}

with open(os.path.join(OUT_DIR, "ontology.json"), "w", encoding="utf-8") as f:
    json.dump(ontology, f, ensure_ascii=False, indent=2)

shutil.copyfile(r"D:/codes/myskills/industrial-deep-diagnostic/.claude/skills/industrial-ontology-builder/schemas/ontology_schema.json",
                os.path.join(OUT_DIR, "schema.json"))

# ------------------------------------------------------- clarification gate (auto)
def amb(aid, subject, question, resolution, conf):
    return {"id": aid, "subject": subject, "question": question,
            "auto_resolution": resolution, "auto_inferred": True, "confidence": conf,
            "inference_basis": "physics_inference_framework L1-L5 + TE标准语义 + 数据自证（基线统计）"}

clarification = {
    "clarification_status": "AUTO_RESOLVED",
    "interaction_mode": "auto",
    "generated_by": "context-builder",
    "ambiguities": [
        amb("AMB-1", "目标变量(target)未指定",
            "数据中没有显式的故障标签列，诊断目标是什么？",
            "根因诊断型运行：全部XMEAS作为诊断信号(predictor)，XMV作为控制执行变量(control)，timestamp为元数据；用户目标=诊断本次异常根因（user_context.json）", "high"),
        amb("AMB-2", "XMV量纲",
            "XMV_1..11数值为16.8~63.6，是流量还是阀位？",
            "解释为归一化阀位/操纵变量指令(%)，角色=control；具体流量语义按TE标准XMV编号映射（如XMV_10=反应器冷却水阀）；此为量纲标度推断，已在inference_basis标注", "medium"),
        amb("AMB-3", "XMEAS_23..28所属物流",
            "stream 6的组成测点位于反应器进料侧（Downs & Vogel表4：Reactor Feed Rate (Stream 6)）",
            "按TE标准语义处理为stream 6（反应器进料气路）GC组成A-F；stream 9=放空气、stream 11=产品", "high"),
        amb("AMB-4", "异常起点与基线定义",
            "normal_range应以哪段数据为正常基准？",
            "user_context声明第161样本(8h)起进入异常工况→基线=样本1..160，normal_range=基线均值±3σ；异常段=161..960仅用于observed_data_behavior预检", "high"),
        amb("AMB-5", "单位体系确认",
            "XMEAS单位（kscmh/kg/h/kPa gauge/°C/mol %等）",
            "采用TE标准单位体系；与基线数值量级逐列核对一致（如XMEAS_2≈3631 kg/h、XMEAS_7≈2705 kPa gauge、产品G≈53.7/H≈43.8 mol%）", "high"),
    ],
}

with open(os.path.join(RUN_DIR, "00_input", "clarification_needed.json"), "w", encoding="utf-8") as f:
    json.dump(clarification, f, ensure_ascii=False, indent=2)

# ------------------------------------------------- rag_deep_understanding (fallback record)
rag = {
    "status": "RAG_ENGINE_UNAVAILABLE_FALLBACK",
    "probed_url": "http://localhost:8764/health",
    "probe_result": "connection refused (curl exit 7, 3s timeout, probed once)",
    "fallback_used": [
        "resources/parameter_to_physics.json（模式库：物理量→控制方程→因果链→竞争假设）",
        "TE标准编号语义（Downs & Vogel 1993）工程领域知识（过程描述明确为Tennessee Eastman流程）",
    ],
    "claims": [],
    "claim_validations": [],
    "validation_queue": [],
    "gaps": [
        "无外部知识库佐证：所有物理关系基于第一性原理+TE文献语义（relationships.rag_validated=false），Stage 2统计验证由data-processor执行",
        "stream 6组分测点位置（进料侧）依据Downs & Vogel表4表记，未做独立交叉验证",
        "XMV量纲（%）为标度推断，未获文档确认",
    ],
}
with open(os.path.join(RUN_DIR, "00_input", "rag_deep_understanding.json"), "w", encoding="utf-8") as f:
    json.dump(rag, f, ensure_ascii=False, indent=2)

# ------------------------------------------------------------- summary print
contradicted = [s["column"] for grp in ("process_parameters", "control_variables")
                for s in ontology["signals"][grp] if s.get("behavior_match") == "CONTRADICTED"]
print("columns_covered:", len(XP) + len(XC) + len(META), "of", len(header))
print("ontology_bytes:", os.path.getsize(os.path.join(OUT_DIR, "ontology.json")))
print("contradicted_signals:", contradicted)
print("ts_end:", ts_end, "n_rows:", n)
