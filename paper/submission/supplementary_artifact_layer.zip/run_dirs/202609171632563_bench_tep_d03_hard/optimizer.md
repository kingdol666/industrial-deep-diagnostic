# optimizer.md — Step 7 FINAL 物理审计（FINAL_AUDIT）

- 运行目录: `D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171632563_bench_tep_d03_hard`
- 审计人: report-reviewer（审计员孙·物理审计），PRE_REPORT_AUDIT=false（FINAL 模式，报告发布前最后一道独立门）
- 审计对象: `report.md`（230 行 / 9 节 / 4 图）+ `run_summary.json`，对照 `04_diagnostics/diagnosis.json`、`04_diagnostics/confidence.json`、`04_diagnostics/evidence.json`、`04_diagnostics/reasoning_chain.json`（round-1 修复后）、`05_review/judge_feedback.json`（round-2, score=90, pass, 零 blocking）、`05_review/optimizer_preflight.md`（NO_FATAL，MAJOR-1 已修复）、`02_processed/*`
- 独立复算数据源: `00_input/data.csv`（960 行 × 52 数值通道 + timestamp，180 s 均匀单调、0 NaN）
- 复算工具: venv python（`D:/codes/myskills/industrial-deep-diagnostic/.claude/shared/scripts/.venv/Scripts/python.exe`）；复算脚本留存于 `06_scripts/_audit_recompute_step7.py`、`06_scripts/_audit_recompute_step7b.py`

---

## 一、审计总览（审计总览）

本报告为 round-1 定向修复（judge blocking#1 时间方向 / blocking#2 H1 置信重加权）后的 Step 6 产物。**审计员孙独立复核结论：报告如实反映了修复后的分叉——放行。**

1. **修复忠实性：通过**。全文 grep 扫描：`执行器先行` / `actuator leads` / `166→168→169`（混合口径构造）/ `overall 60`（reasoning_chain R7 残留短语）/ `方差×2.5-2.7`（var_ratio 误标口径）在 `report.md` 中**零命中**。judge round-2 四条绑定表述规则全部落实：
   - CS1 以近并列 {H1=55, H6=50} 表述（帽 65 内），总置信度 overall=55/MEDIUM（§1 / §5.2 / §6.1，§5.5 明示"修复后规范口径（本报告全文采用）"）——无 60-vs-50 残留；
   - 时间序改述为近同步闭环补偿签名：首 ≥3σ 越限 XMEAS_18@169 → XMV_9@170 → XMEAS_19@171（温度最先），lead-lag 方向**不可分辨**（best-lag +1 ccf=0.9409 vs lag0 0.9408，Δ=0.0001；并如实披露"轻度偏向 H6、不作方向判据"）（§4.2）；
   - 效应量统一表述"**标准差×2.5-2.7（对应方差×4.3-7.4）**"（§1/§4.1/§4.3/§6.1 共 4 处；§4.1 明示 var_ratio 字段实为标准差比、真方差比 6.47/7.43/4.28）；
   - 未引用任何 stale 表述；§5.5 如实记录 round-1 score=75 → round-2 score=90/pass/零 blocking 与修复范围。
2. **数值可溯源：通过**。20+ 个承重数值经我从 `00_input/data.csv` 直接重算，**全部与报告一致**（见第二节复算表；唯一次级索引存在已知的 1 样本普查偏移，judge round-2 已裁定 carried non-blocking、非承重）。
3. **run_summary.json 一致性：通过**。diagnosis_type=COMPETING_SET、judge 90/pass、overall 55/MEDIUM、CS1={55,50} 帽 65、排除 95/95/93、artifact_index 16 项与 figures 4 项逐一实存；其 primary_finding 与 `04_diagnostics/diagnosis.json` 的 primary_finding **逐字一致**（经比对确认，报告 §6.1 第 3 条所述属实）。
4. **发现 0 项 FATAL / 0 项 MAJOR / 3 项 MINOR 残留**（全部为上游工件措辞级残留、方向保守、不改变任何结论，详见第四节）。无证据链断裂、无 verdict-changing 缺陷。

**裁定：ENDORSED——报告可进入 Step 8（HTML 构建）。**

---

## 二、统计核验（统计核验，独立复算，源=`00_input/data.csv`，基线=样本 1-160，异常段=161-960）

| # | 报告主张（出处） | 报告值 | 独立重算值 | 判定 |
|---|---|---|---|---|
| T1 | 主位点标准差比（§4.1 表） | XMV_9 1.230→3.129（×2.544）；XMEAS_19 4.429→12.072（×2.725）；XMEAS_18 0.229→0.474（×2.068） | 1.2297→3.1288（×2.5443）；4.4294→12.0716（×2.7254）；0.2292→0.4740（×2.0682）；真方差比 6.474/7.428/4.277 | **精确一致**（"方差×4.3-7.4"口径正确） |
| T2 | 首次 ≥3σ 越限时间序（§4.2，round-1 修复核心） | XMEAS_18@169 → XMV_9@170 → XMEAS_19@171（温度最先，ddof=0/1 一致） | XMEAS_18@169、XMV_9@170、XMEAS_19@171；ddof=0 复核同为 169/170/171（max\|z\| 6.04/6.49/7.51 与 6.06/6.51/7.53） | **精确一致** |
| T3 | 滞后补偿 CCF（§4.2） | lag0 r=0.9408；best-lag +1 样本 ccf=0.9409；Δ=0.0001 不可分辨；+1=温度先行（脚本符号约定） | r_lag0=0.9408；ccf(+1)=0.9409；ccf(−1)=0.9400（蒸汽先行仅 0.9400）；Δ=0.0001 | **精确一致**（方向不可分辨成立） |
| T4 | 越限普查（§4.1/§7.2） | XMV_9 196 / XMEAS_19 223 / XMEAS_18 122 次，基线 0 次 | 196/223/122，基线 0（ddof=1） | **精确一致** |
| T5 | 均值场（§1/§4.1/§6.2） | 蒸汽 234.46→232.68 kg/h（−0.76%）；塔温 66.011→65.811 °C（−0.30%）；settled 滚动 z +0.067/−0.060/−0.624 | 234.46→232.68（−0.76%）✓；66.011→65.811（−0.30%）✓；XMEAS_18 末 200 简单均值 z=−0.728（preflight INFO-1 披露的另一估计量，同号同量级） | **一致**（估计量口径已在报告/Preflight 分别注明） |
| T6 | 半窗单调漂移（§1/§4.1） | XMEAS_18 −0.585σ→−1.065σ | −0.585→−1.065 | **精确一致** |
| T7 | 排除对照组平稳性（§4.1/§5.3） | XMEAS_9 z=+0.032、XMEAS_21 −0.096、XMV_10 +0.056、XMV_11 +0.079、XMEAS_2 −0.114、XMEAS_3 +0.306、XMEAS_14 +0.181、XMEAS_17 −0.032 | +0.032 / −0.096 / +0.056 / +0.079 / −0.114 / +0.306 / +0.181 / −0.032 | **全部精确一致** |
| T8 | 流量通道无判别力（§4.2/§5.2） | XMEAS_2~XMEAS_18 r=−0.014；D 进料恒定 z=−0.114；XMV_9~XMEAS_19 r=0.988 | −0.0138；−0.114；0.9880 | **精确一致** |
| T9 | H4 进料阀平稳（§5.3 "var ≤1.204"） | XMEAS_1 var 1.203、进料阀 ≤1.204 | XMEAS_1 std 比=1.203、XMV_3 std 比=1.204（真方差比 1.447/1.451——上游 var_ratio 字段实为 std 比，judge carried MINOR） | **数值一致**（标签残留，方向保守，见 M-1） |
| T10 | H2/H6 时序反向（§5.4/§5.2） | 冷却侧首越限 XMEAS_11@173、XMEAS_22@231；进料侧 XMEAS_3@177、XMEAS_14@289、XMEAS_2@844——全部晚于主位点 169-171 | XMEAS_11@174、XMEAS_22@232、XMEAS_3@178、XMEAS_14@290、XMEAS_2@845（均 +1，judge round-2 已裁定的 carried 1-sample census offset） | **排序结论一致**（偏移非承重，见 M-2） |
| T11 | XMV_11/XMEAS_9 执行器静止（§5.4 H2 反证、§5.3 H3） | rolling onset null、var 1.047/0.976 | 滚动 20 均值 thr=1.0 全程无起始（None）；std 比 1.047/0.976 精确复现 | **精确一致** |
| T12 | 置信算术（§5.2/§6.3） | H1 五因子 18+20+13+16+8=75；规范路径 75−15−5=55；evolution：H1 30+25+20−15−5=55、H6 30+10−8+18=50、H2 25+15+0=40、H3/H4/H5 归零；overall=55/MEDIUM；双帽 65 | 逐项手工复算全部重构成立；与 `04_diagnostics/confidence.json`（confidence_score 55/50/40、ceilings 65×2、overall 55）及 `04_diagnostics/reasoning_chain.json` hypothesis_evolution 逐字段一致 | **精确一致** |
| T13 | 沿用验证工件（§4.4） | anti_spurious 0/0/0 ROBUST；留一 ≤0.0062；离群 ≤14.5%；多重检验 29/5.0/12；`time_lag_analysis.json` 分层 0.858/0.950/0.972/0.929、Spearman 0.928、physics_discrepancy_count=0、r(2,18) 分层 −0.030/−0.021/−0.187/+0.100、best-lag ccf 0.132 | 与 `02_processed/validate_report.json`（judge round-1 逐条实存核验）、`02_processed/time_lag_analysis.json`（本轮直接读回）逐值相符 | **一致**（carried，round-1/round-2 双重复核） |

**复算匹配统计：13 组（含 20+ 分项数值）全部与报告一致；承重数值零偏差。**

---

## 三、物理核验（物理核验）

| # | 检查项 | 结果 |
|---|---|---|
| P1 | **修复后因果链的物理自洽**：共享链"未测一次因→塔热平衡失衡（Q_steam=Q_vap+ΣF_i·cp·ΔT）→塔温单调下漂→XMV_9 闭环补偿→蒸汽流量方差放大"——每个箭头对应本体 governing law（`01_ontology/ontology.json`：XMV_9→XMEAS_19 阀门方程即时、XMEAS_19→XMEAS_18 Q=ṁ·λ 分钟级、XMEAS_2→XMEAS_18 焓平衡 inverse）；链内已测链接 r=0.988/0.941 验证通过，根环节 DATA_LINK_MISSING 如实披露为 COMPETING_SET 的直接原因（§6.2）——**无物理不可能链环，无被撤回方向主张的残留引用** | 通过 |
| P2 | **热平衡方向与量级**：供汽未失（均值 −0.76%）而方差 ×2.7（std 比）+塔温 −0.30%（−0.2 °C 级）——波动型而非断供型，Q=ṁ·λ 下分数℃级响应与观测同数量级；H6 量级 UNTESTED 已如实标注（§6.2 [PHYSICS_UNVERIFIED] 项） | 通过 |
| P3 | **闭环签名 vs 方向判定的边界**：温度最先（T2）+Δ=0.0001（T3）⇒ 方向不可分辨、轻度偏向 H6——报告明确"不以时序在 H1/H6 之间作方向判定"（§4.2），对未判别分叉未强制 DETERMINED（协议红线未违反） | 通过 |
| P4 | **判别量缺失核实**：52 列=XMEAS_1..41+XMV_1..11（本轮重新枚举确认），无蒸汽 header 压力/干度、无 D/E 进料温度、无 stream-10 焓、无冷却水入口温度列——CS1 INDISTINGUISHABLE 帽 65 的物理前提成立 | 通过 |
| P5 | **排除集物理边界**：H3（反应器扰动必经移热链留痕——对照组合 T7/T11 全平稳）、H4（负荷漂移必等比缩放流量——T9 进料阀/流量 std 比 ≤1.204）、H5（持续游程 76 样本=3.8h + Levene + 计量自洽 FLOW_QUADRATIC_PLAUSIBLE）均附定量幅度与复活条件；H2 以 40 保留 [WEAK_EXCLUSION]、未达 ≥90 不入 eliminated——纪律执行正确 | 通过 |
| P6 | **置信帽纪律**：CS1 双成员帽 65、H1=55/H6=50 ≤65、overall 55/MEDIUM；adjustment_log 第三条（−5）为非加性修复增量记录、报告按规范路径 75−15−5=55 引用且 §5.2 明示不重复扣减——judge warning 的 reporter 侧处置正确 | 通过 |
| P7 | **证据等级与降级诚实性**：视觉证据 3 项全部 METADATA-BACKED（`03_figures/visual_analysis.json` observation_mode=metadata_backed_inference，3 图 READ_FAILED/NON_VLM_ENVIRONMENT），L4 降级、不独立加分、不重复计数；报告 §4.3 口径披露完整；引用的 4 张 PNG（fig_temporal_overview / fig_vlm_temporal_overlay_single_product / fig_vlm_synchronization / fig_vlm_temporal_overlay）实存于 `03_figures/` | 通过 |
| P8 | **可证伪性**：5 条升级/降级路径（§6.4）具体可执行（补测 header 状态、D/E 进料温度、双平稳→第三假说、阀阶跃试验、冷却入口温度）；与 diagnosis.json falsification_conditions 一致 | 通过 |

---

## 四、残留发现（全部 MINOR、非阻塞、方向保守，不构成阻塞项）

- **M-1（carried，工件标签残留）**：上游工件的 `var_ratio` 字段实为标准差比（judge round-1/round-2 均裁定 carried MINOR、保守方向）。报告正文对承重效应量已统一使用正确口径"标准差×2.5-2.7（对应方差×4.3-7.4）"；但 §4.1 对照组与 §5.3 沿引工件字段时保留了 "var 0.976/1.007/1.047/1.203/≤1.204" 写法（真方差比为 0.954/1.014/1.096/1.447/1.451）。偏离幅度均贴近 1.0，不改变排除结论。`run_summary.json`/`diagnosis.json` 的 primary_finding 逐字保留"方差×2.5-2.7"属 verbatim 一致性要求，报告 §6.1 已明示并做口径校正——不扣分。
- **M-2（carried，1 样本普查偏移）**：次级索引（XMEAS_11/22、XMEAS_3/14/2 首越限）比本轮 ddof=1 重算早 1 个样本（T10）；judge round-2 同测得该偏移并裁定 carried non-blocking。主位点 169/170/171 在 ddof=0/1 双口径下精确，所有时序方向结论不变。
- **M-3（上游措辞残留，报告未引用）**：`02_processed/time_lag_analysis.json` significant_lags_detail 仍含 "mechanism-consistent steam->temp delay" 旧表述（preflight MAJOR-1 定位之一）；`04_diagnostics/reasoning_chain.json` R7.uncertainty.aleatory 仍含 stale "overall 60"（judge round-2 警告，grep 确认 report.md 零引用）。二者为工件层将来 opportunistic 修复项，对报告层无影响。

**无 FATAL / 无 MAJOR**：未发现物理不可能结论、证据链断裂或 verdict-changing 缺陷；报告中所有承重数字可溯源至所引工件或由原始数据精确重构。

---

## 五、判定（判定）

位点层（DETERMINED 级证据）与一次因层（COMPETING_SET，CS1={H1=55, H6=50} 帽 65、overall 55/MEDIUM）表述与修复后诊断工件完全一致；judge round-2 绑定表述规则四条全部落实；20+ 承重数值独立重算零偏差；三项残留均为上游工件措辞级、方向保守、非承重。报告达到发布标准，可进入 Step 8 HTML 构建。

FINAL_AUDIT_VERDICT: **ENDORSED** — FATAL 0 / MAJOR 0 / MINOR 3（M-1 var 标签残留、M-2 次级索引 1 样本偏移、M-3 上工件 stale 措辞未入报告）；无阻塞项，无修复要求。
