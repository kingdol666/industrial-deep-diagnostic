# optimizer_preflight.md — PRE_REPORT 物理审计（Step 5b）

- 运行目录: `D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171632563_bench_tep_d03_hard`
- 审计人: report-reviewer（审计员孙·物理审计）, PRE_REPORT_AUDIT=true
- 审计时间: 2026-09-18（报告尚不存在，符合 pre-report 时序；本文件产出先于 Step 6）
- 审计对象: `04_diagnostics/diagnosis.json`、`04_diagnostics/evidence.json`、`04_diagnostics/confidence.json`、`04_diagnostics/reasoning_chain.json`、`01_ontology/ontology.json`、`02_processed/*`、`06_scripts/semantic_analysis_results.json`、`03_figures/visual_analysis.json`
- 独立复算数据源: `00_input/data.csv`（960 行 × 52 数值通道 + timestamp，180 s 均匀单调、0 NaN，已独立验证；`02_processed/cleaned_data.json` 与原始数据逐列全等 IDENTICAL）
- 复算工具: venv python（`D:/codes/myskills/industrial-deep-diagnostic/.claude/shared/scripts/.venv/Scripts/python.exe`，numpy/scipy）

---

## 一、审计总览（审计总览）

诊断结论为 **COMPETING_SET**：主位点定量定位于汽提塔蒸汽热回路（XMV_9/XMEAS_19/XMEAS_18），一次因在 H1（蒸汽侧热扰动）与 H6（汽提塔进料热状态变化）之间经同一热平衡通道表达、判别量未测量，INDISTINGUISHABLE 帽 65，H1=60 / H6=50 / H2 残余[WEAK_EXCLUSION]=40，H3/H4/H5 排除（95/95/93）。

**审计员孙独立复核结论：**
1. **主位点定位：认可（ENDORSED）**。方差/越限/游程/分层相关等全部核心统计量经我从原始数据独立重算，**逐项精确吻合**（见第二节复算表）。反应器/进料/冷却执行器侧排除证据同样精确复现。
2. **热平衡物理合理性：认可**。蒸汽均值仅 -0.76%（供汽未失）而离散度剧增、塔温 -0.30%，方向自洽、幅度亚 1%，与"弱签名波动型热平衡失调"一致，无物理不可能项。
3. **COMPETING_SET 三态判定与帽 65：认可**。判别量缺失论证经 52 列通道清单核实成立（无蒸汽 header 压力/干度、无 D/E 进料温度、无冷却水入口温度列）；对未判别分叉强制 DETERMINED 才是违规，本诊断未犯。
4. **发现 1 项 MAJOR 证据方向性缺陷**（不推翻结论但必须在报告前修正表述）：H1 因果链第 5 环声称"执行器先行、温度随后（首越限 XMV_9@166→XMEAS_19@168→XMEAS_18@169）"。经独立重算与管线自身工件核对，**该时间先序主张不成立**：按任一单一口径，塔温 XMEAS_18 均最早或并列最早（≥3σ 首越限 169→170→171；滚动 20 均值起始 162→166→168）；引用的 166/168 实为滚动起始样本而非越限样本，属**混合口径构造**。且 CCF best-lag +1（0.9409）按管线脚本 `lag_ccf` 的符号约定（lag>0 ⇒ y 领先 x）实为**塔温领先蒸汽 1 个样本**，"蒸汽→塔温 3 分钟传输滞后"是符号误读（best 与 lag0 差仅 0.0001，统计上本不可分辨）。真实签名是"近同步、温度边缘先行"的**闭环补偿形态**，对 H6 略为有利、对 H1 无支持力。
5. **发现 1 项 MINOR 系统性口径标注错误**：全部工件中的 "var_ratio/方差×2.5-2.7" 实为**标准差比**（2.544/2.725/2.068 = std_post/std_base）；真实方差比为 6.47/7.43/4.28（平方）。方向保守（低估效应），不影响结论。

**修复定位**：缺陷集中于证据措辞与单一链环方向判读，位点定位、排除集、CS1 结构全部稳固——**无需 D→J→R→R 全量重跑**，按第四节 repair_instruction 修正后即可放行 Reporter。

---

## 二、统计验证（独立复算，源=`00_input/data.csv`）

| # | 诊断主张（出处） | 管线值 | 独立重算值 | 判定 |
|---|---|---|---|---|
| S1 | 数据形状/时间列（R1） | 960×52、180 s 单调、0 NaN | 960×53(含ts)、unique dt=180.0、0 NaN | 一致 |
| S2 | 清洗等价性（time_lag_analysis data_source） | cleaned 与 raw 一致 | 52 列逐列 allclose IDENTICAL | 一致 |
| S3 | 均值场 z（semantic mean_shift） | XMEAS_16 +0.923 / XMEAS_18 −0.873 / XMEAS_11 −0.781 / XMEAS_19 −0.402 / XMV_9 −0.491 / XMEAS_2 −0.114 | +0.923 / −0.873 / −0.781 / −0.402 / −0.491 / −0.114 | 全部精确一致 |
| S4 | ≥3σ 越限普查（spike_census） | XMV_9 196 / XMEAS_19 223 / XMEAS_18 122，基线 0；XMEAS_9 全记录 5（基线2）；XMEAS_21 异常段 0；max\|z\| 6.49/7.51/6.04 | 196/223/122、基线 0；5（基线2）；0；6.49/7.51/6.04 | 精确一致 |
| S5 | 主位点 std（std_ratio_ranking） | XMV_9 1.2297→3.1288；XMEAS_19 4.4294→12.0716；XMEAS_18 0.2292→0.4740 | 1.2297→3.1288；4.4294→12.0716；0.2292→0.4740 | 精确一致 |
| S6 | Levene 方差检验 p<1e-4 | p≈0 | 1.0e-23 / 1.1e-25 / 1.9e-15 | 一致（更强） |
| S7 | 相关结构（time_lag_analysis） | r(19,18)=0.9408 lag0；分层 0.858/0.950/0.972/0.929；Spearman 0.928；r(19,XMV_9)=0.988；r(2,18)=−0.014；压力链 0.970–0.998 | 0.9408 / 0.858/0.950/0.972/0.929 / 0.928 / 0.988 / −0.0138 / 0.9705–0.9982 | 精确一致 |
| S8 | CCF best-lag（time_lag_analysis） | best lag "+1"、ccf 0.9409、解释为"蒸汽→塔温 3 min 延迟" | 脚本约定 lag>0 ⇒ y 领先 x ⇒ **XMEAS_18 塔温领先蒸汽 1 样本**（r=0.9409）；蒸汽领先 1 样本仅 0.9400；Δvs lag0=0.0001 不可分辨 | **方向误读（MAJOR-1）** |
| S9 | ≥2σ 持续游程（sustained_runs） | XMEAS_18 76 样本自 688（3.8 h）；XMEAS_19 67 自 684；XMV_9 71 自 683 | 76 @ 1-based 688（3.80 h）等 | 精确一致 |
| S10 | 半窗单调漂移（half_window） | XMEAS_18 −0.585→−1.065（true）；XMV_9 −0.065→−0.775；XMEAS_19 +0.073→−0.718 | −0.585→−1.065；−0.065→−0.775；+0.073→−0.718 | 精确一致 |
| S11 | 反应器/进料/冷却平稳（followup_loop_table） | XMEAS_9 +0.032/0.976、XMEAS_21 −0.096/0.988、XMV_10 +0.056/1.007、XMEAS_3 +0.306、XMEAS_14 +0.181、XMEAS_17 −0.032、XMV_11 +0.079/1.047 onset null | +0.032/0.954*、−0.096/0.975*、+0.056/1.014*、+0.306、+0.181、−0.032、+0.079/1.047* | z 全一致；*管线 var_ratio 实为 std 比（MINOR-1） |
| S12 | **首越限时间序（H1 链第 5 环）** | "XMV_9@166→XMEAS_19@168→XMEAS_18@169——执行器先行、温度随后" | 管线自身 spike_census idx_list(0基): 169/170/168 ⇒ 1 基 **169(XMEAS_18)→170(XMV_9)→171(XMEAS_19)**；滚动起始 1 基 **162(XMEAS_18)→166(XMV_9)→168(XMEAS_19)**。引用的 166/168 是滚动起始样本、169 是越限样本——混合口径；任何单一口径下塔温均最早 | **不成立（MAJOR-1）** |
| S13 | 验证工件引用（evidence.json validation_evidence） | leave_one_out 4 对 max_shift≤0.0062；outlier_sensitivity ≤14.5%；change_point XMEAS_9 过分割；多重检验 29/5/12；anti_spurious 0/0/0；Time-sorted | `02_processed/validate_report.json` 内全部实存且数值吻合（4 对 0.0034–0.0062、−14.5%、n_changes=82、29/5.0/12、0/0/0、time_sorted=true） | 一致 |
| S14 | 视觉证据口径（evidence.json） | METADATA-BACKED、非像素判读、L4 降级 | `03_figures/visual_analysis.json` observation_mode=metadata_backed_inference + 明确 WARNING"不得作为视觉证据" | 诚实降级，认可 |

---

## 三、物理验证（Physics Verification）

| # | 检查项 | 结果 | 严重度 |
|---|---|---|---|
| P1 | **热平衡方向自洽**：蒸汽平均 −0.76%（234.46→232.68 kg/h）、阀位 −1.24%、塔温 −0.30%（66.011→65.811 °C）——供热量微降与塔温微降同号，幅度亚 1%，无能量符号矛盾 | 通过 | INFO |
| P2 | **供汽未失（断供型排除）**：蒸汽均值位移 z=−0.402（settled +0.067），离散 ×2.7（std 比）——"方差爆炸而均值不动"，H1 子类被正确约束为热负荷波动型而非断供型 | 通过 | — |
| P3 | **计量/流路自洽**：`02_processed/physics_check.json` FLOW_QUADRATIC_PLAUSIBLE（P/F² CV=1.87%，XMEAS_2 流量 3553–3769 kg/h 对 XMEAS_7 压力 2686–2726 kPa）——支持 H5 伪象排除 | 通过 | — |
| P4 | **闭环补偿签名**：温度先动（S12）+ 执行器随后 + 回路内 r=0.988/0.941，是温控回路对抗热平衡扰动的标准闭环形态；该形态对 H1/H6 中性偏 H6，**不再构成执行链方向的独立证据** | 修正后通过 | MAJOR-1 |
| P5 | **判别量缺失核实**：52 列=XMEAS_1..41+XMV_1..11，无蒸汽 header 压力/干度、无 D/E 进料温度、无 stream-10 焓、无冷却水入口温度——CS1 INDISTINGUISHABLE 的物理前提成立 | 通过 | — |
| P6 | **本体一致性**：`01_ontology/ontology.json` 中 XMV_9→XMEAS_19（阀门方程，即时）、XMEAS_19→XMEAS_18（Q=ṁ·λ，分钟级）、XMEAS_2→XMEAS_18（焓平衡 inverse）、XMV_11→XMEAS_11/22 与 confounders[0..4] 均实存且与诊断引用一致 | 通过 | — |
| P7 | **量级先验**：Q=ṁ·λ 下 −0.76% 蒸汽负荷对应分数℃级泡点/塔温响应，与观测 −0.2 °C 同数量级；无超物理量级主张。H6 量级 UNTESTED 已如实标注 | 通过 | — |
| P8 | **诊断纪律**：COMPETING_SET+帽65、H2<90 不入 eliminated 标[WEAK_EXCLUSION]、CORRELATION_ABSENT 修正而非静默删除、r=−0.48 无机制剔除、406 起孤立尖峰与主信号分离、6+2 假说覆盖与 alternatives 记录、falsification_condition 具体可执行 | 通过 | — |

---

## 四、发现清单（含严重度与修复指令）

### MAJOR-1：H1 时间先序证据方向错误（证据完整性缺陷，可修复）
- **位置**：`04_diagnostics/diagnosis.json` H1.physical_logic_chain[4]（"首越限时间序……执行器先行、温度随后，符合执行链方向"，evidence_status=OBSERVED）、H1.predicted_observables[2]；`04_diagnostics/reasoning_chain.json` R2 outputs/R4 step_by_step；`04_diagnostics/evidence.json` rolling_onset 条目解读；`02_processed/time_lag_analysis.json` 的"steam→temp delay"叙述。
- **事实**：见 S8/S12。任何一致口径下塔温 XMEAS_18 先于执行器/流量（越限 169 vs 170/171；滚动 162 vs 166/168）；CCF "+1" 按脚本约定为温度领先蒸汽，且 Δr≈0.0001 不可分辨。
- **影响**：H1 失去其声称的时间方向支持；观测签名实为闭环补偿形态，对 CS1 内部权重略偏向 H6。**不改变**：主位点定位、COMPETING_SET 类型、帽 65、三项排除。
- **severity: MAJOR**
- **repair_instruction（Reporter 放行前置）**：
  1. 报告中**禁止**出现"执行器先行/蒸汽超前塔温 3 分钟传输滞后/首越限 166→168→169"作为 H1 方向证据。
  2. 统一改述为："主位点三通道起始近同步（≤4 样本 = 12 min 内）；一致口径下塔温最早或并列最早（滚动 20 均值起始 162/166/168，≥3σ 首越限 169/170/171）；CCF 在 ±1 样本内方向不可分辨（lag0 0.9408，best 0.9409）——属温控闭环补偿签名，不构成因果方向的独立证据。"
  3. `diagnosis.json` H1 链第 5 环 evidence_status 应由 OBSERVED 降为 CORRECTED/WEAKENED 并按上述改写；`confidence.json` H1.temporal_evidence（现 18/20）应下调至约 12–14/20，H1 总分 60→55–58 仍within帽 65；报告中将 H1/H6 表述为 CS1 内近乎均势成员（差距收窄）。
  4. 该修正不要求重跑 Step 4 全流程：位点、排除集、CS1 结构维持原样。

### MINOR-1：var_ratio 系统性误标（std 比被写作方差比）
- **位置**：`06_scripts/semantic_analysis_results.json`（字段 std_ratio_post_over_base 正确）→ `04_diagnostics/diagnosis.json`（"var_ratio 2.544/2.725/2.068、方差×2.5-2.7"）、`04_diagnostics/confidence.json`、`04_diagnostics/evidence.json`、`02_processed/data_analysis_conclusion.json`。
- **事实**：2.544/2.725/2.068 = std_post/std_base；真方差比 = 6.47/7.43/4.28。方向保守（低估），位点排序不变。
- **severity: MINOR**
- **repair_instruction**：报告统一表述为"标准差 ×2.5–2.7（即方差 ×4.3–7.4）"，或在引用 var_ratio 时改标 std_ratio。

### MINOR-2：H1 证明强度继承 MAJOR-1
- `diagnosis.json` H1.ontology_data_physics_proof.lag_match="MATCH" 与 STRONG_EVIDENCE 结论部分依赖被误读的滞后方向；修正后 lag_match 应改 PARTIAL/UNRESOLVABLE（近同步、方向不可分辨），链内链接验证（r=0.988 lag0、r=0.941）本身维持有效。
- **severity: MINOR**

### INFO-1：settled 口径差异：z_roll_mean_last200（XMEAS_18 −0.624）为滚动均值型估计量，普通末 200 样本均值 z 为 −0.728；两者同号同量级，报告引用时注明估计量即可。
### INFO-2：180 s 采样 + 20 样本滚动窗使起始点分辨力约 ±12 min；4 样本的温度先导属弱时序证据，报告不得将其升格为方向判定。
### INFO-3：XMEAS_9 两种口径（followup +0.032 vs settled −0.001）、XMEAS_11（−0.781 vs −0.872）为不同估计量，结论（平直/传播场）一致，无矛盾。

**无 FATAL 项**：未发现物理不可能结论、证据链断裂级缺陷或无出处的数字；所有被引用统计量均溯源至实存工件并经独立重算复核。

---

## 五、最终裁定

- 主位点（汽提蒸汽热回路）定位：**ENDORSED**（S1–S7、S9–S14、P1–P3、P5–P8 全部通过）
- 排除集 H3/H4/H5（95/95/93）：**ENDORSED**（定量幅度与物理边界充分）
- CS1={H1,H6} INDISTINGUISHABLE 帽 65：**ENDORSED**（判别量缺失经通道清单核实）
- H1 时间方向证据与置信分解：**NEEDS_REPAIR**（MAJOR-1/MINOR-2，修复指令见第四节）
- 数值口径标注：**NEEDS_REPAIR**（MINOR-1，措辞级）

**PREFLIGHT_NEEDS_REPAIR**（修复范围=证据措辞与 H1 时序/置信口径，非结论结构；按第四节 repair_instruction 修正后即可进入 Step 6 Reporter，无需全量重诊）

PREFLIGHT_VERDICT: NO_FATAL — FATAL 0 项；MAJOR 1 项（H1 时间先序/CCF 方向误读，报告前必须修正表述并微调 H1 时序置信）；MINOR 2 项（var_ratio 误标、lag_match 降级）。
