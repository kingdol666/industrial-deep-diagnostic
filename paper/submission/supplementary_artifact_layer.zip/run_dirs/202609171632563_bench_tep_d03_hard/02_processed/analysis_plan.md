# Analysis Plan — bench_tep_d03_hard (data-processor, Engineer Zhang)

RUN_DIR: `workspace/diagnostic-runs/202609171632563_bench_tep_d03_hard`
Data: `00_input/data.csv` (960 rows x 53 cols, 180 s sampling, 0 NaN, timestamps monotonic — verified by venv python)
Baseline segment: samples 1-160 (ontology `_provenance.onset_row=161`, user_context L2 declaration).
Post-onset segment: samples 161-960.

## Ontology-Guided Analysis Architecture

Ontology: `01_ontology/ontology.json` (context-builder, TE 标准语义, RAG 不可用回退).
Physical groups (ontology `parameter_groups`): fresh_feed_flows (XMEAS_1..4), reactor_conditions
(XMEAS_6..9), separator_conditions (XMEAS_11..14), stripper_conditions (XMEAS_15..19),
recycle_compressor (XMEAS_5/10/20), cooling_water_circuit (XMEAS_21/22, XMV_10/11),
compositions (XMEAS_23..41), feed_valves (XMV_1..4), gas_loop_valves (XMV_5/6),
liquid_flow_valves (XMV_7..9). Control relationships: 22 (see ontology `relationships`).
MUST-analyze pairs (from relationships + stage physics): XMEAS_19~XMEAS_18 (steam→temp),
XMEAS_19~XMV_9 (actuator), XMV_10→XMEAS_9/XMEAS_21 (reactor CW loop), XMV_11→XMEAS_11/XMEAS_22
(condenser CW loop), XMEAS_7~XMEAS_13~XMEAS_16 (gas-loop pressure chain).
PRUNED: none (52 numeric columns all carry physics; weak-signature scenario forbids discarding columns).

Ontology pre-check flagged ALL signals `CONSISTENT` (segment-mean level ≤ ~1σ). This is the declared
weak-signature scenario: discrimination must come from **site structure** (variance growth, excursion
runs, onset ordering) and **exclusion**, not from large mean shifts.

Key data-shape facts: no group/product column (single continuous grade), no inspection columns
(process_only view — matches `anomaly_report.dual_drive_analysis.data_view_mode`), real time column
(180 s uniform, monotonic), 11 manipulated variables in closed loops (loop-internal |r| up to 1.000).

## Data View Mode

`process_only` — 53 columns = 41 process measurements + 11 valves + timestamp; zero laboratory /
inspection columns (ontology `signals.inspection_signals = []`). Process-to-quality causal linkage
is therefore an **evidence gap**, carried into `data_analysis_conclusion.json`.

## Hypothesis-Method Map

See `02_processed/analysis_method_plan.json` (H1..H6, minimal discriminative method sets).
Methods actually executed (venv python, all recomputable from `00_input/data.csv`):

| Method | Tool | Purpose |
|---|---|---|
| M2 segment stats | `06_scripts/tep_d03_semantic_analysis.py` | baseline vs post mean/std, Welch t, Levene variance |
| M7 spike census + sustained runs | same + `06_scripts/tep_d03_site_structure.py` | baseline-referenced \|z\|≥3 census; ≥2σ run lengths; first-excursion ordering |
| M3 rolling onset | `06_scripts/tep_d03_onset_ordering.py` | rolling-20 mean z onset per column (temporal precedence) |
| M4 targeted lag CCF | `06_scripts/tep_d03_semantic_analysis.py` | ±20-sample CCF for the 8 cited pairs only |
| M5 stratified correlation | same | baseline / post / post-h1 / post-h2 correlation stability (steady-state window discipline) |
| Closure & physics sanity | same + `02_processed/physics_check.json` | composition vector closure, node-balance offset, pressure∝flow² check |

## Adaptive Decision Audit

| Question | Answer |
|---|---|
| Data view mode | process_only |
| Scenario | weak-signature continuous chemical process (TEP-class), step disturbance at declared sample 161 |
| Analysis NOT done | per-product split (no group col), Simpson-by-group (no group col; time-stratification used instead), full-pair lag sweep (recycle-loop spurious-correlation risk; 8 targeted pairs only), RAG validation (no queue; engine unavailable) |
| Custom scripts | 3 under `06_scripts/` (semantic analysis, site structure, onset ordering) — needed because full-record z-scores mask the weak-signature site (see findings) |
| Escape-valve additions | sustained-run analysis (M7), composition closure check — both back-filled into the method plan |

## Analysis Coverage Matrix (planned)

- pure_process_analysis: covered (validate_report + 06_scripts results)
- process_inspection_dual_drive: not_applicable (no inspection columns) — documented as evidence gap
- grouping_confounding: partial (time-stratified correlation; no product grouping possible)
- temporal_regime_event: covered (rolling onset ordering, sustained runs, baseline-referenced census)
- scenario_specific: covered (weak-signature protocol: baseline-referenced z + site structure + exclusion)

## What I will NOT do

- No full-correlation-matrix fishing beyond the prepared package; no causal labels from loop-internal
  correlations (XMV↔its own actuated variable are structure, not fault evidence); no filtering-out of
  the post-onset window (it carries the fault signature); no VLM image reading in this environment.

## Baseline Script Findings and Gaps (Phase 2.7)

Prepared package (`02_processed/validate_report.json`): 100 target-pair tests, 12 Bonferroni-significant;
anti-spurious battery clean (0 outlier-driven / trend-confounded / Simpson / Spearman-divergence;
leave-one-out max shift 0.0062). Gaps a human process engineer would still need:
1. Full-record z-scores (prepare digest) dilute weak-signature sites — the top listed columns
   (XMEAS_6/XMV_8/XMEAS_15/XMEAS_4/XMEAS_30/XMV_6) are NOT the primary site once baseline-referenced.
   → custom scripts filled this gap.
2. Change-point module over-segments noise on XMEAS_9 (83 micro-segments, no dominant break) —
   not usable as evidence here; rolling-mean onset used instead.
3. No regime filter artifact — steady-state discipline implemented as baseline-window stratification.
