# 工业诊断报告 — SKAB水循环试验台阀门异常诊断（valve1_1）

**场景**: SKAB水循环试验台阀门异常诊断（valve1_1） | **产品/批次**: 单产品单批次记录（batch applicable=false，`02_processed/validate_report.json` anti_spurious.batch） | **日期**: 2026-09-18 | **运行ID**: 202609171630389_bench_skab_valve1_1
**Judge 质量门**: 95/100 — pass（`05_review/judge_feedback.json`，7 项关键统计量经 venv python 独立复算全部精确一致）
**物理预检**: PREFLIGHT_PASS（NO_FATAL）— FATAL 0、MAJOR 0、MINOR 3、INFO 5（`05_review/optimizer_preflight.md`，本报告已按其报告层条件执行 3 项 MINOR 修正）

> **阅读指南**: 第 1 节是给厂长/总经理看的一页纸摘要（2 分钟读完）。第 2–4 节展示时序对齐图判读、数据质量与统计分析（给工艺工程师）。第 5–6 节是假设检验与根因结论（给技术主管）。第 7 节是证据附录（可审计）。第 8 节是行动方案。第 9 节是方法与局限。

> **实事求是声明**: 本报告所有结论均来源于运行目录内的实际工件（`00_input/`–`05_review/`），每个数字标注来源文件与数值，关键统计量经诊断代理与 Judge 双方用 venv python 从 `00_input/data.csv` 独立复算确认。视觉证据在非 VLM 环境下按 `metadata_backed_inference`（元数据支撑推断，未读像素）形态使用，等级封顶 L4。本报告未使用任何外部网络知识（[EXTERNAL KNOWLEDGE]: 无）。诊断结论为 **COMPETING_SET**（竞争假设集），本报告如实呈现两个不可分辨的生存假设，不升级为 DETERMINED。

---

## 1. 执行摘要

### 发生了什么？

闭环水循环试验台（水箱 + 离心泵 + 阀门）的一段 20 分钟记录（1145 行，1 Hz，2020-03-09 10:34:33–10:54:33）中，回路流量在 **rows 621–927（0-based，对应 2020-03-09 10:45:24–10:50:45，约 5.1 分钟）** 出现**平台式台阶下移**：中位数从 32.0 降至 30.9998 L/min（**-3.13%**），Mann-Whitney 窗对比 **p=5.73e-158**（n_in=307 / n_out=838；`02_processed/semantic_verification.json` flow_window_recomputed，已复算确认）。异常窗结束后流量自发恢复（窗后中位数 **31.9995 ≈ 32 L/min**，median 口径；预检 S17）。同窗内电机电流中位数同向下移 0.115 A（方向性，p=0.1016，不显著），双振动通道全程平坦，压力通道无电平迁移（量化盲）。

### 为什么会发生？

**根因判定（COMPETING_SET）**：本次异常由**水力流路阻力改变族（阀门/流道）的工况点迁移**引起——泵特性曲线 H=H0−kQ² 与管路阻力曲线 ΔP_sys=k(θ)·Q² 的交点移动导致流量平台式下移并可逆恢复。机制族层面证据充分（本体-数据-物理四要素验证 STRONG_EVIDENCE）；但**"下游节流（H1，置信 65）vs 上游供给受限（H2，置信 60）"的分叉不可分辨**：唯一物理判别量是泵后压力方向（H1 预言沿泵曲线上移、H2 预言下移），而压力通道量化步长 0.327 bar 为预期移动 ~0.025 bar 的 13 倍（`02_processed/physics_check.json` PH2，resolvable=false）——判别在**仪器层面**不可实现。竞争集 CS1={H1, H2} 判为 INDISTINGUISHABLE，置信天花板 65 生效。四类竞争机制（机械/气蚀劣化 H3、电侧扰动 H4、计量伪迹 H5、热漂移混杂 H6）分别以排除置信 93/92/90/96 量化排除。

### 影响有多大？

- 影响范围：单一回路流量通道下降 3.13%（约 1 L/min 量化台阶），持续约 5.1 分钟后自发恢复；电流、振动、压力、热通道均无伴随损伤特征。
- 严重程度：本记录为试验台过程数据（无产量/质量检验列，process_only 数据视图），无法折算产量损失；物理上属**可逆的工况点迁移**而非设备损伤事件——但若同一机制（阀门受限）在产线上持续或加深，将直接压缩产能并存在气蚀风险（H2 分支）。
- 结论可靠度：综合置信 60/100（MEDIUM），受 CS1 天花板 65 与"阀门开度未测量"（DATA_LINK_MISSING）结构性约束。

### 推荐行动（详见第 8 节）

| 优先级 | 行动 | 预期效果 | 时间 | 大约成本 |
|:------:|------|---------|------|:------:|
| **P0** | 以 ≤0.01 bar 分辨率同步复测泵前+泵后压力，复现异常工况 | 直接判别 H1/H2（压力方向），可将 COMPETING_SET 升级为 DETERMINED | 本周（需复现异常） | 低（高精度变送器租/校） |
| **P1** | 接入阀门开度反馈/执行器指令记录；核查流量计标定日志 | 确立（或推翻）根因链首环节；关闭 H5 残余缺口 | 本月 | 低–中 |
| P2 | VLM 重读 5 张诊断图（像素级形态）；振动通道频响标定 | 补齐 L4 视觉证据与 H3 排除的敏感性前提 | 条件成熟时 | 中 |

### 有多大把握？

**综合置信度: 60/100（MEDIUM）**（`04_diagnostics/confidence.json` overall_confidence）。用通俗的话说：机制族"流路阻力改变"这一层的判断接近确定（流量台阶 p=5.73e-158 无可辩驳、七通道方向链自洽、物理量级核算自洽）；但"动哪个阀"（泵前还是泵后）在本记录的仪器配置下无法判别——不是我们不想下结论，是压力传感器的 0.327 bar 量化步长把 0.025 bar 的判别信号完全掩盖了。综合置信取竞争集中较弱成员 H2 的 60，符合"结论受最弱环节约束"原则。

---

## 2. 诊断背景与时序对齐图分析（核心证据）

### 2.1 背景与用户问题

用户问题："诊断本次异常的根本原因"（`00_input/user_context.json`）。过程描述：水循环试验台，水箱（EQ-TANK）+ 离心泵（EQ-PUMP，驱动电机 EQ-MOTOR）+ 阀门（EQ-VALVE，开度未测量，泵前/泵后位置未指明）+ 管路（EQ-PIPE）闭环回路；1 Hz 采样，回路封闭循环；本记录含一段异常工况，起止时标不提供（truth_withheld=true）。本体（`01_ontology/ontology.json`）将流量定为唯一 behavior_match=CONTRADICTED 通道（稳态恒流预期被违背），并将"阀门位置（泵前/泵后）"显式列为根因判别的核心竞争分叉点。

数据视图：8 个数值通道（Accelerometer1RMS/Accelerometer2RMS/Current/Pressure/Temperature/Thermocouple/Voltage/Volume Flow RateRMS）全部为过程侧量，**无任何检测/质量测量列** → process_only（`02_processed/anomaly_report.json` dual_drive_analysis.data_view_mode），双驱动集成路径（View B）空转，纯过程路径（View A）承载全部判别（`04_diagnostics/diagnosis.json` integrated_dual_drive_analysis：not_applicable）。

### 2.2 全参数时序对齐图判读

![全参数z归一化时间对齐叠加图](03_figures/fig_vlm_temporal_overlay_single_product.png)

**图上看到了什么（METADATA-BACKED，非像素读取）**：该图绘制的 Volume Flow RateRMS 序列含 rows 621–927（2020-03-09 10:45:24–10:50:45，约 5.1 分钟）的平台式水平移——窗内量化电平 {30:125, 31:181, 32:1} vs 窗外 {32:643, 31:130, 33:65}（按最近整数电平舍入计数，np.round 口径；Judge warning #2），窗内外中位数 31 vs 32 L/min，p=5.73e-158，独立变点检测标记 row 621（`03_figures/visual_analysis.json` + `02_processed/semantic_verification.json`，observation_mode=metadata_backed_inference，诊断代理已用 venv python 从 `00_input/data.csv` 复算确认）。其余七通道在窗沿无对齐阶跃。

**统计怎么说**：同步组 G2_hydraulic_load_direction_chain（流量 + 电流同窗、方向一致）与 G1_vibration_pair（振动对 r=0.4677，属同源共变 colinear group，窗内保持沉默）编码于同步性热图（`03_figures/visual_analysis.json` cross_parameter_temporal_alignment.synchronous_groups）。视觉与统计一致：无 `[视觉与统计不一致]` 项、无 `[视觉证据过度声称]` 项（视觉条目均以统计交叉引用锚定）。

**物理上说得通吗**：说得通。工况点由泵曲线与管路阻力曲线交点决定（本体 relationships：EQ-VALVE→Flow causal/strong，governing ΔP_sys=k(θ)·Q²）；"节流→工况点迁移→流量平台式台阶移动且可逆"的本体预言与观测形态完全同型：台阶下移 3.13%、维持 5.1 分钟、窗后恢复至 32 L/min（`04_diagnostics/diagnosis.json` process_fluctuation_analysis.key_process_findings[0]）。

![窗口对比专图](03_figures/fig_window_contrast.png)

**该图告诉我们什么**（METADATA-BACKED）：红色阴影标示流量窗 rows 621–927；电流窗内/外中线导引 0.907 vs 1.022 A（夹距即 -0.115 A 同向下移）；Acc1/Acc2 迹线在窗内无抬升。单图通道方向链——流量平台（强）+ 电流同向（弱/方向性，p=0.1016 不得读作显著确认）+ 振动平坦——三者联合仅与水力流路阻力改变机制族相容（`03_figures/visual_analysis.json`，图源 `06_scripts/semantic_verification.py`，每点可溯源到 `02_processed/cleaned_data.csv` 具体行）。

![关键变量时序网格图](03_figures/fig_temporal_overview.png)

**该图告诉我们什么**：全变量基线形态与 ±3σ 越限分布（`03_figures/image_captions.json`）：Acc2 max|z|=13.56（超 3σ 占比 0.4%）、Pressure max|z|=4.02（0.3%）、Acc1 max|z|=3.45（0.3%）——越限均为孤立量化尖峰（压力 3σ 尖峰 rows 42/306/789，为量化电平交替副产物；row 789 虽落在窗内但为孤立单行相邻电平跳变，诊断未将其用作事件证据，`02_processed/anomaly_report.json`），非窗沿聚集事件。

![全局时间对齐叠加图](03_figures/fig_vlm_temporal_overlay.png)

**该图告诉我们什么**：全局冗余视图（visual_analysis.py 兼容视图，`03_figures/plot_manifest.json`），与单产品对齐图形态一致——流量平台下移为全记录唯一显著形态偏移，其余通道无对齐事件。

![参数同步性热图](03_figures/fig_vlm_synchronization.png)

**该图告诉我们什么**（METADATA-BACKED）：强共变仅存在于振动对（Acc1~Acc2 r=0.4677，稳态切片 0.5154、时间三分层 0.426–0.511 同号、留一 max_shift=0.043、lag-0 最优）；Current~Voltage 中等（r=0.2898，正号，确认为混杂链）；Pressure~Flow 量化盲（r=-0.0092）；Thermocouple~Flow 原始 r=0.337 为已证伪的趋势伪象。共变图中恰有一个独立机械证据源（振动对）且其在异常窗内保持沉默——无任何伪相关进入因果证据图（`03_figures/visual_analysis.json`，rank L4）。

### 2.3 对齐图分析总体结论

时序对齐判读的核心发现：**唯一被违背预期的通道是流量**（平台式下移并恢复），电流同窗同向（方向性），振动/压力/电压/热四类通道均为"非事件"——该七通道方向链把全部竞争假设约束到"能在 ~5.1 分钟内维持流量平台并随后释放"的可逆机制族。跨产品对比不适用（单产品单批次记录，batch applicable=false）。

---

## 3. 数据质量评估

| 维度 | 结论 | 来源与数值 |
|------|------|-----------|
| 完整性 | 1145 行 × 9 列，8 数值列零缺失 | `02_processed/feature_summary.json`（1145/列） |
| 时间轴 | datetime 已排序（time_sorted=true），1 Hz 标称；56 处 >1.5 s 短缺口（最大 2 s） | `02_processed/validate_report.json` sorting_validation；预检 S16 复算一致 |
| 流量量化 | 仅 {30,31,32,33} 四个整数电平（±0.002 抖动；计数按 np.round 舍入口径） | `01_ontology/ontology.json` data_quality_notes；Judge warning #2 |
| 压力量化 | 仅 7 个离散电平（步长≈0.327 bar，中位步长 0.32793 bar） | 预检 S9 复算一致（`05_review/optimizer_preflight.md`） |
| 清洗审计 | `02_processed/cleaned_data.csv` 与 `00_input/data.csv` 逐字节一致（1145×9），清洗未引入数值漂移 | 预检 INFO-4（raw.equals(cleaned)==True） |
| 生产状态/稳态 | 稳态切片 962 行（84.02%）；caveat：方差型融合将低流量平台 rows 621–868 的 246 行标为 "steady"——稳态过滤无法排除水平移窗，仅作相关稳健性切片使用 | `02_processed/production_regime_filter.json` |
| 批次完整性 | batch applicable=false（id_col=null）——Simpson/跨产品分层检验不适用 | `02_processed/validate_report.json` anti_spurious.batch |
| 孤立异常点 | 压力 3 个孤立 3σ 尖峰（rows 42/306/789）为量化电平交替统计副产物，无窗聚集，不作事件证据 | `02_processed/anomaly_report.json`；预检 INFO-2 |
| 歧义管理 | 7 项输入歧义全部 AUTO_RESOLVED（无 PARAM_AMBIGUITY 未决项，不触发 50 置信天花板）；阀门开度缺失→潜在变量（AMB-04） | `00_input/clarification_needed.json` |

---

## 4. 统计分析发现

> 本节为报告的强制正文（非附录）。所有判别统计量以**窗沿对比**（Mann-Whitney 中位数检验）为准——`02_processed/validate_report.json` 证实流量目标的全部 6 个预测子逐点去趋势相关均为 trend_confounded=true（attenuation −140.8%/−94.1%/345.2%/351.4%/110.0%/117.3%），逐点相关对本"双电平平台"信号不具判别力。

### 4.1 七通道窗对比方向链（窗口 = rows 621–927，0-based，2020-03-09 10:45:24–10:50:45）

| 通道 | 窗内/窗外中位数 | 移幅 | Mann-Whitney p | 判读 |
|------|:---:|:---:|:---:|------|
| Volume Flow RateRMS | 30.9998 / 32.0 L/min | **-3.13%** | **5.73e-158** | 首要异常：平台式台阶下移，统计上无可辩驳（窗内电平 {30:125,31:181,32:1} vs 窗外 {32:643,31:130,33:65}，舍入口径；滚动均值复算 w=60 阈值 31.2 与本体预检窗 match=true） |
| Current | 0.9072 / 1.0219 A | -0.1147 A（-11.2%） | 0.1016 | **方向性（弱）证据**：与负载减小类机制相容，但电压宽带方差支配电流通道（std=0.28 A），未过显著性——只按方向性采信（见 4.3） |
| Accelerometer1RMS | 0.0269 / 0.0269 g | -0.07% | 0.452 | 全程平坦——无机械/气蚀激励 signature（物理排除证据） |
| Accelerometer2RMS | 0.0401 / 0.0399 g | +0.63%（+0.0002 g ≈ 0.2σ） | 0.0027 | 统计可检出但物理可忽略，不得过度解读；与 Acc1 同源共变（r=0.4677）不重复计数 |
| Pressure | 电平分布相近（0.0547 bar 占 56.0% vs 58.8%） | 无窗沿迁移 | 0.778 | null 对 H1/H2 双向不采信：PH2 证明预期移动 ~0.025 bar ≪ 量化步长 0.327 bar，属假阴性风险而非"无耦合"证据 |
| Voltage | 230.88 / 231.369 V | -0.489 V（-0.21%） | 0.173 | 无窗沿对齐——电侧驱动假设（H4）时间 precedence 条件不满足 |
| Temperature / Thermocouple | 73.63 / 73.75 ℃；斜率 -0.002981 / -0.000148 ℃/行 | 无窗沿阶跃 | 去趋势后窗残差对比 p=2.0e-40（Temp，全程冷却曲率伪象）/ 0.602（TC） | 全程缓降漂移、非异常相关通道；引用一律采用**去趋势后**口径（预检 INFO-5） |

来源：`02_processed/semantic_verification.json` flow_window_recomputed + window_contrast；`02_processed/physics_check.json` PH1–PH3；`02_processed/validate_report.json`。上述 7 项关键统计量经 Judge 用 venv python 从 `00_input/data.csv` 独立复算全部精确一致（`05_review/judge_feedback.json` spot_check_findings：correlations_sampled=7, verified=7, questionable=0），物理预检 20/20 项重算一致（`05_review/optimizer_preflight.md` 第二节 S1–S20）。

### 4.2 反伪证核查结果（四重程序）

- **趋势伪象证伪**：唯一原始 |r|≥0.3 因果候选 Thermocouple~Flow（r=0.337，p=8.4e-32）经线性去趋势崩塌至 r=-0.0337（衰减 110%；x_time_trend_r=-0.46, y_time_trend_r=-0.774），时间三分层符号不一致 [0.080, 0.540, -0.230]，lag 最优漂至边界 lag=20 → 确认为时间趋势伪象（`02_processed/causal_evidence_map.json` validation_status=refuted；H6 排除主证据）。
- **Simpson 悖论**：simpson_paradox_findings=0（无分组列，not_applicable）。
- **离群点/杠杆点**：outlier_driven_correlations=0；留一 max_shift=0.0057（leveraged=false）；Thermocouple~Flow clean_r=0.3367（r_change -0.1%），证伪理由唯一且明确（趋势）。
- **互信息陷阱标注**：MI(Pressure, Volume Flow RateRMS)=8.339（normalized 1.0）为两通道共享量化电平结构产生的**伪信息**，其余通道对 MI_normalized ≤ 0.224——不得误读为强因果证据（`02_processed/validate_report.json`）。
- **滞后核查**：5 个被引用参数对的 CCF 均无显著滞后（significant_lags_found=0），与"水力/电磁传播 <1 s ≪ 1 Hz 采样"物理先验一致 → 统一 lag-0 口径（`02_processed/time_lag_analysis.json`）。

### 4.3 电流证据的严格定界（预检 MINOR-2 修正）

电流窗对比 -0.1147 A 的 p=0.1016（不显著）。按预检 MINOR-2 条件：**不得**将电流下移表述为"PH2 机制下的必然结果"——按 PH2 自身陡端泵曲线假设，轴功率变化约为 +2.9%（上升方向），"净下降"仅在平坦泵曲线（|dH/H| < ~3.1%）变体下成立；且观测移幅 -11.2% 超出 QH 耦合隐含的 0–3% 预测带——与其未过显著性（p=0.1016）"由噪声支配"的定性自洽。本报告表述为：**电流下移方向与负载减小类机制相容（平坦泵曲线变体），幅度偏大且不显著，仅方向性采信**。电压解耦（OLS，斜率 0.007471 A/V）后残差窗对比 -0.0688 A 同号（p=0.176），混杂不解释该方向链（`02_processed/semantic_verification.json` voltage_controlled_current_window_contrast）。

**上游数字缺陷拦截声明（预检 MINOR-3）**：`02_processed/causal_evidence_map.json` 边 "Volume Flow RateRMS → Current" 标注 "p<1e-60" 与可复算真值 **p=0.1016** 不一致（疑为对流量 p=5.7e-158 的误写）。诊断方已在 reasoning_chain R2 检出并纠正；**本报告与后续 HTML 可视化一律只引用 p=0.1016（方向性），严禁传播 p<1e-60**。

### 4.4 物理量级核算（PH1–PH3）

- **PH1 表观功率**：S=V·I 逐行计算（cos φ 未知，表观功率代理，derived）——窗内 220.9 vs 窗外 229.8 VA（-3.9%，p=0.062）：方向与负载减小一致、幅度与 3.13% 流量降幅同量级、未达显著。
- **PH2 压力不可分辨核算**：预期扬程移动上界 = H × |dH/H| ≈ 0.4 bar × 2 × 3.126% ≈ **0.025 bar**（**上界，最陡泵曲线假设**）≪ 量化步长 **0.327 bar**（13 倍差）→ resolvable=false。这是 CS1（H1/H2）不可分辨的定量根源。
- **PH3 振动物理排除**：机械/气蚀激励必然抬升宽带振动 RMS（a=ω²·d），实测窗内平坦（Acc1 -0.07% n.s.；Acc2 +0.63% ≈ 0.2σ 物理可忽略）→ 排除机械劣化族（H3），并构成对 H2（starving 伴生气蚀 signature）的轻度不利（-5 置信，不足以排除）。

来源：`02_processed/physics_check.json`；预检 P2/P3 独立复算成立。

---

## 5. 假设检验与竞争假设

### 5.1 六假设竞争集总表

| 假设 | 机制类 | 最终置信 | 状态 | 排除/判定依据（数字） |
|------|:---:|:---:|:---:|------|
| **H1 下游侧节流/流路受限**（泵后阀门开度减小或下游流道局部阻塞） | OPERATION | **65** | **生存（CS1）** | 流量平台 -3.13%（p=5.73e-158）+ 电流方向性同向 + 振动平坦 + 窗后恢复；本体 STRONG_EVIDENCE；受 CS1 天花板 65 封顶 |
| **H2 上游侧供给受限**（泵前节流/吸入侧受阻→入口 starving） | OPERATION | **60** | **生存（CS1）** | 与 H1 共享全部流量观测；starving 专有气蚀 signature 未观测（-5）、电压混杂（-3）；proof_strength=SUPPORTIVE |
| H3 泵机械劣化（不平衡/轴承/气蚀内损） | WEAR | 5 | 排除（COMBINED，排除置信 **93**） | 振动双通道平坦直接矛盾（a=ω²·d）；磨损不可逆 vs 窗后恢复+row 621 锐利变点矛盾 |
| H4 电压/电侧扰动 | ENVIRONMENT | 5 | 排除（STATISTICAL，排除置信 **92**） | 电压无窗沿对齐（-0.489 V，p=0.173）；Voltage~Flow r=-0.013 全程零响应；Current~Voltage 正号（r=0.2898）与恒功率先验相反→电压为噪声混杂 |
| H5 计量伪迹（流量计偏移+量化+缺口） | ENVIRONMENT | 8 | 排除（COMBINED，排除置信 **90**，压线诚实） | 恒定量化不能制造窗内分布迁移；2 s 缺口撑不起 5.1 分钟平台；物理路径独立的电流链方向性同向（双测量链交叉）；保留 8 分反映"标定史不可验证"残余缺口 |
| H6 热漂移混杂（Thermocouple~Flow 伪相关） | DRIFT | 3 | 排除（STATISTICAL，排除置信 **96**） | 去趋势衰减 110% + 三分层符号翻转 + 边界 lag + 形态量级矛盾（0.000148 ℃/行不可能制造 row 621 台阶，量级差 4 个数量级以上）；无现实复活路径 |

来源：`04_diagnostics/diagnosis.json` hypotheses + `04_diagnostics/confidence.json` confidence_breakdown / adjustment_log。

### 5.2 竞争集 CS1：H1 vs H2 为何不可分辨

- **唯一物理判别量**：泵后压力方向——H1（下游节流）预言沿泵曲线上移 ~0.025 bar；H2（上游受限）预言下移。二者方向相反、行动层互斥（动哪个阀完全不同）。
- **判别失效根源（仪器，非证据缺席）**：PH2 核算预期移动 ~0.025 bar（上界）≪ 压力量化步长 0.327 bar → `discriminability_matrix` [H1,H2] = INDISTINGUISHABLE，discriminating_signal_available=false。`03_figures/visual_analysis.json` pipeline_warnings（CRITICAL）同判："upstream/downstream throttling is indistinguishable on this instrumentation"。
- **组内唯一不对称**：H2 的 starving 专有气蚀振动 signature 未观测到——按检出阈论证（3% 量级轻度抽空可低于 0.2σ 检出阈）仅构成 -5 轻度偏置，远低于 90 排除阈，不足以改变 INDISTINGUISHABLE 分类。
- **置信天花板**：CS1 confidence_ceiling=65（INDISTINGUISHABLE_COMPETING_SET），显式应用于 H1 与 H2（`04_diagnostics/confidence.json` confidence_ceilings_applied）。
- **判别矩阵全景**：10 对假设两两判别——1 对 INDISTINGUISHABLE（H1,H2），9 对 ONE_SIDE_EXCLUDED（H3/H4/H5/H6 与 H1/H2 均被单侧排除；`04_diagnostics/diagnosis.json` discriminability_matrix）。

### 5.3 排除逻辑明细（量化论证 + 复活条件）

| 排除项 | 三渠道论证 | 复活条件 |
|--------|-----------|---------|
| H3（93） | 物理排除：机械缺陷必备宽带振动 signature 全程缺席（PH3）；时间形态排除：磨损不可逆 vs 窗后恢复 + 锐利变点起始 | 振动通道对气蚀高频不敏感的证明，或亚 RMS 阈的声发射/压力脉动数据 |
| H4（92） | 时间 precedence 失败（电压无对齐 p=0.173）+ 耦合量级矛盾（Voltage~Flow r=-0.013 从未驱动流量）+ 混杂链符号反证（P2 正号 vs 恒功率先验） | 与 rows 621–927 精确对齐的电压暂降记录或调速指令日志 |
| H5（90） | 量化逻辑（恒定量化不能制造窗内水平分布迁移，p=5.73e-158；56 处缺口最大 2 s 无法维持平台）+ 双测量链交叉（独立电流链方向性同向 -0.115 A，解耦残差同号）——刻意压线 90 以诚实反映标定史不可验证 | 与窗口精确对齐的流量计标定漂移/故障记录，且更大样本下电流方向链瓦解 |
| H6（96） | 四重反伪证正式证伪（去趋势 -0.0337 / 分层 [0.080, 0.540, -0.230] / 边界 lag=20 / 留一无杠杆）+ 形态量级矛盾 | 无现实路径（仅当采用完全不同趋势模型且通过全部分层一致性检验） |

排除数 4 ≥ 2，满足协议门槛；每条排除带可执行复活条件（`04_diagnostics/diagnosis.json` hypotheses.eliminated）。

---

## 6. 根因结论

### 6.1 诊断结论总结

- **诊断类型**：`COMPETING_SET`（竞争假设集，不升级为 DETERMINED）。
- **机制族判定（确定层）**：根因为**水力流路阻力改变族（阀门/流道）的泵-管路工况点迁移**——这是唯一与全部七通道方向链、量级核算（PH1/PH2）与时间形态（锐利变点 + 5.1 分钟平台 + 自发恢复）相容的机制族，本体-数据-物理四要素验证（函数形式 MATCH / 滞后 MATCH / 量级 PLAUSIBLE / 方向 MATCH）overall_proof_strength=STRONG_EVIDENCE。
- **分支判定（不可分辨层）**：CS1 = {H1 下游节流（65），H2 上游供给受限（60）}，INDISTINGUISHABLE，天花板 65。**综合置信 60/100（MEDIUM）**，取竞争集内较弱成员 H2（"结论受最弱证据等级约束"原则）。
- **链首环节缺口**：阀门开度/执行器指令无数据列（EQ-VALVE 未测量潜在变量，`00_input/clarification_needed.json` AMB-04）→ 链首环节仅能经下游通道间接推断（supported_indirect，`02_processed/causal_evidence_map.json`）——这是结论停留在 COMPETING_SET 的构成性缺口之一。
- **如果这个结论是错的，最可能因为**：≤0.01 bar 双端压力复测显示窗内两侧均无方向性移动 ≥0.02 bar（机制族动摇）；或发现与窗口精确对齐的计量故障记录（H5 复活，全族重审）。
- **要进一步提高把握，需要**：见第 8 节补测清单（按判别力排序，首选项单独立即可将 COMPETING_SET 升级为 DETERMINED）。

### 6.2 物理机制与推理过程

物理逻辑链（H1 侧，与 H2 在前两环共享）：

1. **泵后阀门开度 θ↓ 或下游流道阻力↑（未测量潜在变量 EQ-VALVE）→ 管路阻力曲线 ΔP_sys=k(θ)·Q² 变陡**（KNOWN_PHYSICS；流量降 3.13% 对应 k 增大约 6.5%——**平坦泵曲线一阶近似（H2≈H1）下的 derived 值**；若按 PH2 最陡端假设则 k2/k1≈1.133（+13.3%）。两端数字不可不加限定地并排引用（预检 MINOR-1）；无论哪端，压力移动均 ≪ 0.327 bar，CS1 判定稳健）。
2. **阻力曲线变陡 → 工况点沿泵曲线 H=H0−kQ² 迁移 → 回路流量平台式下移**（OBSERVED：rows 621–927 电平 {30:125,31:181,32:1} vs 窗外 {32:643,31:130,33:65}，中位数 30.9998 vs 32.0 L/min，p=5.73e-158；窗后恢复至 31.9995≈32 L/min，median 口径）。
3. **Q↓（主导）且 H 变化（平坦曲线变体下部分抵消）→ 轴功率趋降 → 电机电流随负载同向下移**（INFERRED，**方向性采信**：-0.1147 A，p=0.1016，解耦残差 -0.0688 A 同号；幅度偏大且不显著，见 4.3 定界）。
4. **沿泵曲线预期扬程移动 ~0.025 bar（上界）——低于压力通道量化步长，本记录内不可观测**（UNVERIFIED；PH2 resolvable=false）。

生活化类比：就像捏住花园水管的中段——捏得稍紧（下游节流，H1）水管出口水流变小但捏点上游压力略升；若是水塔供水不足（上游受限，H2）水流同样变小但捏点（泵后）压力会略降。两种捏法的"水流变小"一模一样，区别只在捏点压力的方向——而这块"压力表"的刻度粗到（0.327 bar）根本读不出这么小的变化（0.025 bar），所以我们只能诚实地给出两个分支。

推理过程摘要（完整八段见 `04_diagnostics/reasoning_chain.json` R1–R8）：R1 数据表征（process_only、量化定界、候选窗）→ R2 统计发现与复算（p=5.73e-158 复算确认；判别统计量方法论修正：窗沿对比取代逐点相关；拦截上游 p<1e-60 错误标注）→ R3 反伪证过滤（H6 趋势伪象证伪；onset 无先行通道/PRECURSOR 缺席）→ R4 假设生成（6 假设 + 1 项显式并入：异物短暂堵塞与 H1 物理同构，不制造伪竞争）→ R5 判别力评估（[H1,H2] INDISTINGUISHABLE，天花板 65 生效）→ R6 排除验证（4 项排除 93/92/90/96）→ R7 结论与可证伪性 → R8 不确定性定界与补测清单。

### 6.3 推理链摘要与置信分解

**置信分解（五因子，`04_diagnostics/confidence.json`）**：

| 因子（满分） | H1 下游节流 | H2 上游受限 | 说明 |
|------|:---:|:---:|------|
| 统计强度（25） | 15 | 15 | 流量窗对比无可辩驳，但链首环节为未测量潜在变量、电流佐证仅方向性 |
| 物理合理性（25） | 19 | 17 | H1 四要素 MATCH（STRONG_EVIDENCE）；H2 辅助预言未落定（SUPPORTIVE） |
| 时序证据（20） | 16 | 16 | 锐利变点+恢复形态清晰；无先行通道（PRECURSOR 缺席） |
| 无混淆（20） | 14 | 14 | 电压混杂经 OLS 解耦；热趋势排除；压力量化假阴性风险双向披露 |
| 症状完整性（10） | 7 | 6 | 五通道方向链自洽；H2 的 starving 伴生症状缺检（-1） |
| **五因子合计** | **71** | **68** | — |
| 调整 | 电压混杂 -3；CS1 天花板封顶至 65 | signature 缺失 -5；电压混杂 -3 | adjustment_log 12 条可完整重构 |
| **最终** | **65（MEDIUM，ceiling 65）** | **60（MEDIUM）** | overall = 60（最弱环节原则） |

**不确定性分解**：aleatory（不可约）——电压宽带波动 std=10.8 V 支配电流统计力、流量量化抖动 ±0.002 L/min、56 处采样缺口；epistemic（可补测消解）——阀门开度未知、泵后压力真实方向被量化掩盖、流量计标定史不可验证、振动通道频响未标定；model——一阶阻力曲线近似（k·Q²）与恒转速假设、starving-气蚀耦合未建模。

**推翻路径（what_would_change_conclusions）**：① ≤0.01 bar 泵前+泵后双端同步压力（窗内方向性移动 ≥0.02 bar 即判别分支；两侧均无 → 机制族动摇）；② 阀门开度反馈/执行器指令日志（直接确立或推翻机制族）；③ 与 rows 621–927 对齐的流量计故障记录 + 更大样本电流对比不显著（H5 复活）；④ 先行于 row 621 的振动抬升或气蚀声学证据（H3 复活）；⑤ 与窗口对齐的电压暂降/调速指令（H4 复活）。

---

## 7. 证据附录

### 7.1 证据等级总览（L1–L7）

| 等级 | 本运行中的实例（文件 + 关键数值） |
|:---:|------|
| **L1** 直接测量 | `00_input/data.csv`（1145 行 × 9 列，1 Hz）：流量窗电平计数 {30:125,31:181,32:1}/{32:643,31:130,33:65}、中位数 30.9998/32.0 L/min、MW p=5.7348e-158（n=307/838）；电流 0.9072/1.0219 A、p=0.101636——诊断代理与 Judge 双 venv python 复算精确一致 |
| **L2** 用户文档 | `00_input/user_context.json`：水循环试验台过程描述与列含义（truth_withheld=true，异常起止时标不提供） |
| **L3** 统计分析（含验证） | `02_processed/semantic_verification.json`（窗对比全通道 p 值；OLS 斜率 0.007471 A/V、残差 -0.0688 A）、`02_processed/validate_report.json`（time_sorted=true；Thermocouple~Flow r 0.337→-0.0337 衰减 110%；Simpson=0；fatal_issues=0；change_points=1）、`02_processed/physics_check.json`（PH1 -3.9% p=0.062；PH2 0.025 bar vs 0.327 bar；PH3 振动平坦）、`02_processed/time_lag_analysis.json`（5 对无显著滞后）、`02_processed/anomaly_report.json`（3σ 尖峰 rows 42/306/789 量化副产物；无 PRECURSOR） |
| **L4** 图表视觉证据（封顶，metadata_backed） | `03_figures/visual_analysis.json`（observation_mode=metadata_backed_inference，非 VLM 环境未读像素；同步组 G1/G2；pipeline_warnings CRITICAL 压力分辨率警告）+ 5 张 PNG（`03_figures/plot_manifest.json`：5/5 生成成功）——本报告所有图形引证均标 METADATA-BACKED，不得表述为"VLM 读图确认"（预检 INFO-3） |
| **L5** 领域知识/过程逻辑 | `01_ontology/ontology.json`：EQ-VALVE→Flow（causal/strong，ΔP_sys=k(θ)·Q²）；Flow→Current（causal/moderate，P_sh=ρgQH/η）；PUMP 机械状态→振动（causal/strong，a=ω²·d）；4 个声明混杂因素；阀门位置分叉点 |
| **L6** 外部网络参考 | 无（本运行未使用网络检索，[EXTERNAL KNOWLEDGE]: 无） |
| **L7** 无支撑假设 | 不存在——阀门开度等未知项均显式登记为 epistemic 缺口/潜在变量（`00_input/clarification_needed.json` AMB-04），未被虚构填充 |

证据结构统计（`04_diagnostics/diagnosis.json` evidence_summary）：视觉 3 项、数值 9 项、物理 5 项、验证 7 项。结论的最低证据等级约束：首要证据 L1+L3；分支判别缺口为 L7 级未知项（无数据支撑）。

### 7.2 证据全景与图表索引

| 编号 | 图表（相对 run 目录） | 一句话发现 | 支持结论 | 诊断含义 |
|:---:|------|----------|:---:|---------|
| F1 | `03_figures/fig_vlm_temporal_overlay_single_product.png` | 流量 rows 621–927 平台式下移 -3.13%（p=5.73e-158，变点 row 621） | 机制族判定 | 首要异常为真实水力工况点迁移而非噪声 |
| F2 | `03_figures/fig_window_contrast.png` | 电流导引线 0.907/1.022 A 同向下移（方向性）；振动迹线窗内无抬升 | H1/H2 生存 + H3 排除 | 方向链仅与流路阻力改变族相容 |
| F3 | `03_figures/fig_temporal_overview.png` | 全变量基线形态；3σ 越限均为孤立量化尖峰 | 无先行事件 | 异常无 PRECURSOR，置信受结构性压制 |
| F4 | `03_figures/fig_vlm_temporal_overlay.png` | 全局冗余视图与 F1 形态一致 | 机制族判定 | 平台下移为全记录唯一显著形态偏移 |
| F5 | `03_figures/fig_vlm_synchronization.png` | 强共变仅振动对（r=0.4677，窗内沉默）；Current~Voltage 混杂链确证 | H3 排除 + H4 排除 | 无伪相关进入因果证据图 |

关键工件交叉索引：`04_diagnostics/diagnosis.json`（COMPETING_SET；primary_finding；CS1 ceiling 65；4 项排除 93/92/90/96；10 对判别矩阵；3 条 inference_gaps；6 条 data_gaps）、`04_diagnostics/confidence.json`（overall 60 MEDIUM；五因子分解；12 条 adjustment_log；2 条 ceiling 应用）、`04_diagnostics/reasoning_chain.json`（R1–R8；6 条假设演化路径；3 条 reasoning_weaknesses 及缓解）、`05_review/judge_feedback.json`（95/100 pass；10 项准则 9–10 分；7/7 抽检复算一致；blocking_issues=[]）、`05_review/optimizer_preflight.md`（PREFLIGHT_PASS，S1–S20 复算一致；MINOR-1/2/3 已在本报告对应章节执行）。

---

## 8. 建议与后续

### 8.1 行动方案（P0/P1/P2）

| 优先级 | 行动 | 具体操作 | 预期效果 | 如何验证 | 时间 |
|:---:|------|---------|---------|---------|:---:|
| **P0** | 双端高分辨率压力复测 | 以 ≤0.01 bar 分辨率同步连续测量泵前+泵后压力，复现异常工况并覆盖 rows 621–927 同型窗口 | 直接判别 H1/H2：泵后压力上移 ≥0.02 bar → H1 确立；下移 → H2 确立；两侧均无 → 机制族动摇、全链重审 | 窗内压力方向性移动 ≥0.02 bar 的存在性与方向 | 本周（需复现异常） |
| **P0** | 阀门动作核查 | 检查试验台阀门执行器是否有开度反馈/指令日志（含 PLC/DCM 记录） | 直接确立（或推翻）根因链首环节，消解 DATA_LINK_MISSING | 日志时间与 row 621（10:45:24）对齐性 | 本周（零硬件成本） |
| P1 | 链路补测 | 接入泵入口真空度/压力测点（H2 starving 直接判据）；保留高频声发射通道选项 | 证实/证伪 H2；分辨气蚀性抽空 | 异常复现时入口压力是否下降 | 本月 |
| P1 | 计量链核查 | 调取流量计标定/故障日志；更大样本复核电流窗对比 | 关闭 H5 残余缺口（排除置信 90→可上调） | 无与窗口对齐的计量异常记录 | 本月 |
| P2 | 视觉与传感标定 | VLM 重读 5 张 PNG（像素级形态学证据）；加速度计频响/安装方位标定 | 视觉证据 L4 提质；H3 排除的敏感性前提显式化 | 像素级形态与统计窗结构一致 | 条件成熟时 |

### 8.2 运行监控建议

| 监控指标 | 当前基线 | 报警条件 | 依据 |
|---------|:---:|:---:|------|
| Volume Flow RateRMS（滚动中位数，w=60） | 32 L/min | 持续 >1 分钟的 ≥1 L/min 台阶下移（-3.13% 量级） | `02_processed/semantic_verification.json` flow_window_recomputed |
| Current（窗沿中位数对比） | ≈1.02 A | 同窗同向下移（方向性提示，不作独立确认） | 窗内 0.9072 vs 窗外 1.0219 A，p=0.1016 |
| Accelerometer1RMS | 0.0269 g（std 0.0003） | RMS 抬升数倍以上（机械/气蚀 signature） | PH3；`02_processed/physics_check.json` |
| 泵后/泵前压力（若加装高分辨率测点） | — | 窗沿方向性移动 ≥0.02 bar | PH2 判别阈值 |

### 8.3 后续诊断步骤

按判别力降序的补测清单（`04_diagnostics/reasoning_chain.json` R8）：① 双端高分辨率压力（单独立即可将 COMPETING_SET 升级为 DETERMINED）；② 阀门开度反馈/执行器指令；③ 泵入口真空度；④ 高频声发射/加速度谱；⑤ 流量计标定核查；⑥ VLM 重读 5 张 PNG。注意红线：不得在缺乏判别数据时单边执行 H1 处置（调下游阀）——动作错配风险已在 reasoning_weaknesses 显式登记。

---

## 9. 方法论说明与局限

### 9.1 方法说明

- **判别统计量选择**：对"双电平平台式水平移"信号采用窗沿中位数对比（Mann-Whitney），弃用逐点相关——流量目标 6/6 预测子逐点去趋势相关 trend_confounded=true（`02_processed/validate_report.json`），Q→Current 逐点 r=0.0042（p=0.886）对平台信号无判别力，已修正为窗对比口径（`04_diagnostics/diagnosis.json` chain_link_validation.correction_applied）。
- **反伪证四重程序**：Simpson 检验 / 线性去趋势 / 滞后 CCF / 留一杠杆，全部通过 `02_processed/validate_report.json` 留痕；稳态过滤对水平移窗的盲区（平台=低方差）已声明且未被用于"证明窗口正常"（循环论证规避）。
- **物理核算**：PH1 表观功率 / PH2 压力不可分辨 / PH3 振动排除（`02_processed/physics_check.json`）；量级核算均为 derived 标注值。
- **独立性保障**：Judge（10 准则 95 分）与物理预检（Step 5b）相互独立且均从 `00_input/data.csv` 直接复算；本报告（Step 6）在此双重验证之上撰写。

### 9.2 局限与报告层修正

| 类型 | 具体局限 | 对结论的影响 / 处理 |
|------|---------|:---:|
| 数据盲区 | 阀门开度/指令、泵入口压力、转速通道均缺失；压力量化 0.327 bar；非 VLM 环境（视觉证据 metadata_backed） | H1/H2 不可分辨的构成性缺口；COMPETING_SET + 天花板 65 |
| 方法局限 | 平台型信号判别依赖窗沿定位（受量化与 56 处缺口限制，±2 行量级）；线性去趋势的曲率残差伪象（已标注禁用） | 窗沿定位误差不改变结论方向 |
| 模型假设 | 一阶阻力曲线 k·Q² 近似、恒转速假设、starving-气蚀耦合未建模 | 已列入各假设 assumptions 与 model 不确定性 |
| **预检 MINOR-1（已执行）** | k 增大 +6.5% 与 PH2 压力上界采用不同泵曲线陡度端 | 本报告在 6.2 明确标注 +6.5% 为平坦泵曲线一阶近似、0.025 bar 为最陡端上界，不并排混引 |
| **预检 MINOR-2（已执行）** | "轴功率净下降"表述与陡端假设方向相抵 | 本报告在 4.3 按方向性采信口径表述电流证据 |
| **预检 MINOR-3（已执行）** | 上游 causal_evidence_map 电流 p<1e-60 错误标注 | 本报告全文只使用可复算的 p=0.1016，并声明禁止传播错误值 |
| Judge 报告层约束（已执行） | rows 621-927 为 0-based 闭区间（=1-based 622–928）；窗后恢复为 median 口径（31.9995）；电平计数按 np.round 舍入口径 | 本报告一律同时给出 0-based 行号与时间戳；恢复行为用 median 口径；引用电平计数注明舍入口径 |

### 9.3 结论

本次诊断以可复算的证据链将根因定位到**水力流路阻力改变族（阀门/流道）的工况点迁移**，并以 COMPETING_SET（CS1: H1 下游节流 65 / H2 上游供给受限 60，天花板 65，overall 60 MEDIUM）诚实呈现"因压力分辨率而不可分辨"的仪器层面限制。四类竞争机制以 90–96 排除置信量化排除并附复活条件。一套 ≤0.01 bar 的双端压力复测即可裁决剩余分叉——在拿到该数据之前，任何单一分支的"确定"表述都超出现有证据的支撑范围。

---

*报告生成：reporter（工程师周，技术报告）；工件溯源：`04_diagnostics/{diagnosis,evidence,confidence,reasoning_chain}.json`、`05_review/{judge_feedback.json, optimizer_preflight.md}`、`02_processed/*`、`01_ontology/ontology.json`、`03_figures/{plot_manifest.json, visual_analysis.json, image_captions.json}`、原始数据 `00_input/data.csv`。运行ID：202609171630389_bench_skab_valve1_1。*
