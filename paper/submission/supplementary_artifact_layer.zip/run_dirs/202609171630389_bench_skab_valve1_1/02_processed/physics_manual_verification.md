# Physics Manual Verification (L1-L5) — diagnostician Step 4

run_id: 202609171630389_bench_skab_valve1_1
author: diagnostician (Chief Engineer Liu)
reason: gate `diagnostic-quality-check.mjs` expects `checks_performed` while upstream `02_processed/physics_check.json` records its targeted checks under `checks_run: 3` (key-format mismatch). This document provides the required L1-L5 manual magnitude proofs for the quantities this diagnosis relies on. Every number is recomputable from `00_input/data.csv` (key flow/current statistics re-verified by the diagnostician via venv python: flow in/out medians 30.9998/32.0 L/min, p=5.7348e-158; current in/out medians 0.9072/1.0219 A, p=0.1016).

## L1 — physical quantities identified (from data self-description + ontology)

| Quantity | Column | Unit | Range observed | Note |
|---|---|---|---|---|
| Loop flow (RMS, quantized) | Volume Flow RateRMS | L/min | {30, 31, 32, 33} integer steps | operating-point flow coordinate |
| Pump-after pressure | Pressure | bar | 7 discrete levels, step 0.327 bar | operating-point head coordinate, quantization-blind |
| Motor current | Current | A | 0.376–1.596 (mean 0.979) | load-torque proxy, voltage-confounded |
| Supply voltage | Voltage | V | 203.7–254.5 (std 10.8) | confounder |
| Vibration RMS x2 | Accelerometer1/2RMS | g | 0.0258–0.0279 / 0.0376–0.0534 | mechanical condition channels |
| Temperatures | Temperature / Thermocouple | ℃ | 71.0–76.3 / 25.61–25.92 | thermal state, global cooling drift |

## L2 — governing laws selected

1. Operating point: pump curve H = H0 − kQ² intersected with system resistance ΔP_sys = k(θ)·Q² (01_ontology/ontology.json).
2. Shaft power / current: P_sh = ρgQH/η, P_el = V·I·cosφ, T_motor = k_T·I.
3. Vibration response: a = ω²·d; excitation energy rise → RMS rise (monotonic, ISO 10816-style logic).
4. Thermal: mCp·dT/dt = P_loss − hA(T − T_amb).

## L3 — causal chains (Δparam → mechanism → observable)

- Valve/flow-path resistance ↑ → system curve steepens → operating point slides along pump curve → flow plateau down (rows 621-927, −3.13%) with head change ~+0.025 bar (downstream case) or ~−0.025 bar (upstream case).
- Flow ↓ (dominant) with partial head compensation → net shaft power ↓ → motor current median ↓ (observed −0.115 A, directional).
- Mechanical/cavitation defect → broadband excitation → vibration RMS rise (multiple × baseline bandwidth) — predicted, NOT observed.

## L4 — magnitude checks (PLAUSIBLE / IMPLAUSIBLE)

1. PH2 reconciliation (02_processed/physics_check.json): for dQ/Q = −3.13%, expected head move dH ≈ 2·(dQ/Q)·H with H of order 0.4 bar → |dH| ≤ 0.025 bar. Sensor quantization step = 0.327 bar ≈ 13× larger → pressure null is a FALSE-NEGATIVE risk, never evidence of no coupling. Status: PLAUSIBLE and consistent.
2. Resistance-coefficient change implied by the plateau: k2/k1 ≈ (Q1/Q2)² ≈ (32/31)² ≈ 1.065 (~+6.5%, first order, derived) — a small throttle motion, order-plausible. Status: PLAUSIBLE.
3. Current response: observed median −0.115 A (−11.2%) vs flow −3.13%: sign consistent with net shaft-power decrease (Q dominates, H compensates only ~0.025/0.4 ≈ 6%); magnitude order-consistent given voltage-broadband variance (std 10.8 V drives current std 0.28 A). Status: PLAUSIBLE, weak (p=0.1016, directional only).
4. Thermal-drift mechanism (H6): drift slope 0.000148 ℃/row cannot generate a 3.13% flow step at row 621 released near row 927 — mechanism magnitude off by orders of magnitude. Status: IMPLAUSIBLE → H6 excluded (confidence 96).
5. Voltage mechanism (H4): full-record Voltage~Flow r = −0.013 (p=0.65): fluctuations of the observed scale (std 10.8 V) never drove any flow response anywhere in the record; a row-621-aligned voltage event is absent (in/out medians −0.489 V, p=0.173). Status: IMPLAUSIBLE as driver → H4 excluded (confidence 92).
6. Mechanical mechanism (H3): baseline bandwidths are 0.0003 g / 0.001 g; a defect-grade excitation predicts multi-× rises; observed in-window shifts −0.07% (p=0.45) and +0.63% (+0.0002 g ≈ 0.2σ). Status: IMPLAUSIBLE as flow-drop driver → H3 excluded (confidence 93).

## L5 — alternative mechanisms screened (anti-speculation)

common cause (thermal/voltage drift): excluded quantitatively (items 4-5). reverse causation (flow meter artifact driving readings): excluded by independent current chain + constant quantization logic (diagnosis H5, confidence 90). artifact (quantization/gaps): cannot manufacture a 5.1-min level redistribution (in-window 30/31 = 306/307 rows vs out-window 32 = 643/838). control-side: no actuator columns exist (AMB-04) — recorded as DATA_LINK_MISSING, kept as COMPETING_SET fork (H1 downstream vs H2 upstream), discriminated only by pressure direction which L4 item 1 proves unresolvable on this instrumentation.

## Bottom line

All magnitude proofs support: hydraulic flow-path resistance change (valve/flow-path) family; downstream-throttling vs upstream-restriction fork unresolvable (COMPETING_SET, ceiling 65). Automatic physics gate discrepancy is a key-format mismatch (`checks_run` vs `checks_performed`), with the three targeted checks (PH1 apparent-power −3.9% p=0.062; PH2 quantization bound; PH3 vibration flatness) fully honored above.
