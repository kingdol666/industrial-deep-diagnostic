# -*- coding: utf-8 -*-
"""Pre-report physical audit (Step 5b) — independent re-verification from 00_input/data.csv.
Auditor: report-reviewer (Auditor Sun). All numbers recomputed from RAW input, not pipeline summaries.
"""
import json
import numpy as np
import pandas as pd
from scipy import stats

RUN = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171630389_bench_skab_valve1_1"
df = pd.read_csv(RUN + "/00_input/data.csv")
res = {}

res["n_rows"] = int(len(df))
res["cols"] = list(df.columns)
t = pd.to_datetime(df["datetime"])
res["time_sorted"] = bool(t.is_monotonic_increasing)
res["t_start"] = str(t.iloc[0])
res["t_end"] = str(t.iloc[-1])
gaps = t.diff().dt.total_seconds().dropna()
res["n_gaps_gt_1p5s"] = int((gaps > 1.5).sum())
res["max_gap_s"] = float(gaps.max())

# Window definition under test: rows 621-927 (1-based data rows, header excluded)
W0, W1 = 621, 927  # 1-based inclusive
inw = df.iloc[W0 - 1: W1]           # 1-based inclusive -> iloc [620:927]
outw = df.drop(inw.index)
res["n_in"] = int(len(inw)); res["n_out"] = int(len(outw))
res["win_t_start"] = str(inw["datetime"].iloc[0])
res["win_t_end"] = str(inw["datetime"].iloc[-1])

F = "Volume Flow RateRMS"
fin = inw[F].round(0).astype(int).value_counts().sort_index()
fout = outw[F].round(0).astype(int).value_counts().sort_index()
res["flow_counts_in"] = {int(k): int(v) for k, v in fin.items()}
res["flow_counts_out"] = {int(k): int(v) for k, v in fout.items()}
res["flow_median_in"] = float(inw[F].median())
res["flow_median_out"] = float(outw[F].median())
res["flow_pct_shift"] = round((inw[F].median() - outw[F].median()) / outw[F].median() * 100, 2)
u, p = stats.mannwhitneyu(inw[F], outw[F], alternative="two-sided")
res["flow_mw_p"] = float(p)

# Post-window recovery check: rows 928-1145 flow levels
post = df.iloc[W1:]
res["post_window_flow_level_counts"] = {int(k): int(v) for k, v in post[F].round(0).astype(int).value_counts().sort_index().items()}
res["post_window_median"] = float(post[F].median())

# Independent window detection: longest contiguous run of flow < 31.5
low = (df[F] < 31.5).astype(int).values
runs, start, best = [], 0, (0, 0)
for i, v in enumerate(low):
    if v == 1 and (i == 0 or low[i - 1] == 0):
        start = i
    if v == 1 and (i == len(low) - 1 or low[i + 1] == 0):
        if i - start + 1 > best[1] - best[0]:
            best = (start, i)
res["indep_longest_low_run_1b"] = [best[0] + 1, best[1] + 1]
res["indep_longest_low_run_len"] = int(best[1] - best[0] + 1)

def wc(col):
    u, p = stats.mannwhitneyu(inw[col], outw[col], alternative="two-sided")
    return {
        "in_median": float(inw[col].median()), "out_median": float(outw[col].median()),
        "in_mean": float(inw[col].mean()), "out_mean": float(outw[col].mean()),
        "median_shift": float(inw[col].median() - outw[col].median()),
        "mw_p": float(p),
    }

for c in ["Current", "Accelerometer1RMS", "Accelerometer2RMS", "Pressure", "Voltage", "Temperature", "Thermocouple"]:
    res["wc_" + c] = wc(c)

# Pressure quantization
pl = np.sort(df["Pressure"].unique())
res["pressure_n_levels"] = int(len(pl))
res["pressure_levels"] = [float(x) for x in pl]
res["pressure_step_median"] = float(np.median(np.diff(pl))) if len(pl) > 1 else None

# Voltage global stats
res["voltage_mean"] = float(df["Voltage"].mean()); res["voltage_std"] = float(df["Voltage"].std())
res["current_std"] = float(df["Current"].std())
res["current_r_voltage"] = float(stats.pearsonr(df["Current"], df["Voltage"])[0])
res["current_r_voltage_p"] = float(stats.pearsonr(df["Current"], df["Voltage"])[1])
res["voltage_r_flow"] = float(stats.pearsonr(df["Voltage"], df[F])[0])

# Thermal slopes (per row)
for c in ["Temperature", "Thermocouple"]:
    sl = np.polyfit(np.arange(len(df)), df[c], 1)[0]
    res["slope_" + c] = float(sl)

# PH1 apparent power
S = df["Voltage"] * df["Current"]
res["S_in_mean"] = float(S.iloc[inw.index].mean()); res["S_out_mean"] = float(S.drop(inw.index).mean())
res["S_pct"] = round((S.iloc[inw.index].mean() - S.drop(inw.index).mean()) / S.drop(inw.index).mean() * 100, 2)
u, p = stats.mannwhitneyu(S.iloc[inw.index], S.drop(inw.index), alternative="two-sided")
res["S_mw_p"] = float(p)

# OLS current ~ voltage residual window contrast
b, a = np.polyfit(df["Voltage"], df["Current"], 1)
resid = df["Current"] - (a + b * df["Voltage"])
res["ols_slope_A_per_V"] = float(b)
u, p = stats.mannwhitneyu(resid.iloc[inw.index], resid.drop(inw.index), alternative="two-sided")
res["resid_in_median"] = float(resid.iloc[inw.index].median())
res["resid_out_median"] = float(resid.drop(inw.index).median())
res["resid_shift"] = float(resid.iloc[inw.index].median() - resid.drop(inw.index).median())
res["resid_mw_p"] = float(p)

# Physics arithmetic cross-checks (auditor's own, independent of pipeline PH2)
Q1, Q2 = res["flow_median_out"], res["flow_median_in"]
dq = (Q2 - Q1) / Q1
res["phys_dQ_over_Q_pct"] = round(dq * 100, 3)
res["phys_k2_over_k1_flatH"] = round((Q1 / Q2) ** 2, 4)          # assumes H unchanged
dH_over_H_steep = -2 * dq                                        # PH2 upper-bound assumption (pure dynamic head)
res["phys_dH_over_H_upper_pct"] = round(dH_over_H_steep * 100, 2)
res["phys_dH_upper_bar_H04"] = round(0.4 * dH_over_H_steep, 4)
# Net shaft-power fractional change under the PH2 upper-bound pump-curve assumption:
res["phys_dP_over_P_upperbound_pct"] = round(((1 + dq) * (1 + dH_over_H_steep) - 1) * 100, 2)
# Required dH/H for net power to fall by the observed apparent-power/current magnitude:
res["phys_dH_needed_for_Pminus3pct_pct"] = round((-0.031 - dq) * 100, 2)

print(json.dumps(res, indent=1, ensure_ascii=False))
