
import csv, json, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8")))
cfg = json.loads(sys.argv[2])
names = cfg["names"]
fig, axes = plt.subplots(len(names), 1, figsize=(11, 2.1 * len(names)), squeeze=False)
for ax, name in zip(axes[:, 0], names):
    vals = [float(r[name]) if r.get(name) not in (None, "", "NaN", "nan", "null") else None for r in rows]
    xs = [i for i, v in enumerate(vals) if v is not None]; ys = [v for v in vals if v is not None]
    mean = sum(ys) / len(ys); std = (sum((y - mean) ** 2 for y in ys) / len(ys)) ** 0.5 or 1e-12
    ax.plot(xs, ys, lw=0.7)
    ax.axhline(mean + 3 * std, color="r", ls="--", lw=0.6); ax.axhline(mean - 3 * std, color="r", ls="--", lw=0.6)
    ax.set_ylabel(name[:34], fontsize=7); ax.tick_params(labelsize=6)
fig.suptitle(cfg["title"], fontsize=9)
fig.tight_layout(); fig.savefig(sys.argv[3], dpi=110)
