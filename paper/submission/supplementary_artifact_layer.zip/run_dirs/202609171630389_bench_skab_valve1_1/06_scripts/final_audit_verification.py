# -*- coding: utf-8 -*-
"""Step 7 FINAL audit — independent recomputation of load-bearing statistics.

Auditor: report-reviewer (Auditor Sun), FINAL_AUDIT mode.
Data source: 00_input/data.csv (raw, never pipeline summaries).
All numbers recomputed here are compared against values cited in report.md /
04_diagnostics/*.json / 05_review/*.
"""
import json
import sys

import numpy as np
import pandas as pd
from scipy import stats

RUN = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171630389_bench_skab_valve1_1"
df = pd.read_csv(RUN + "/00_input/data.csv")
n_rows = len(df)
print(f"rows={n_rows} cols={list(df.columns)}")

flow = df["Volume Flow RateRMS"].to_numpy()
cur = df["Current"].to_numpy()
pres = df["Pressure"].to_numpy()
volt = df["Voltage"].to_numpy()

# Window: 0-based closed [621, 927] -> python slice [621:928)
w = slice(621, 928)
in_w, out_w = flow[w], np.concatenate([flow[:621], flow[928:]])
cur_in, cur_out = cur[w], np.concatenate([cur[:621], cur[928:]])

# 1. Flow level counts (np.round convention), medians, MW p
lvl_in = np.round(in_w).astype(int)
lvl_out = np.round(out_w).astype(int)
cnt_in = {int(k): int(v) for k, v in zip(*np.unique(lvl_in, return_counts=True))}
cnt_out = {int(k): int(v) for k, v in zip(*np.unique(lvl_out, return_counts=True))}
med_in, med_out = float(np.median(in_w)), float(np.median(out_w))
mw = stats.mannwhitneyu(in_w, out_w, alternative="two-sided")
print(f"F1 flow_levels_in={cnt_in} expect={{30:125,31:181,32:1}}")
print(f"F2 flow_levels_out={cnt_out} expect={{32:643,31:130,33:65}}")
print(f"F3 flow_median_in={med_in:.4f} out={med_out:.4f} expect 30.9998/32.0")
print(f"F4 flow_drop_pct={(med_in-med_out)/med_out*100:.2f} expect -3.13")
print(f"F5 flow_MW_p={mw.pvalue:.4e} n_in={len(in_w)} n_out={len(out_w)} expect 5.73e-158 307/838")

# 2. Current window contrast
ci, co = float(np.median(cur_in)), float(np.median(cur_out))
mwc = stats.mannwhitneyu(cur_in, cur_out, alternative="two-sided")
print(f"F6 current_median_in={ci:.4f} out={co:.4f} shift={ci-co:.4f} p={mwc.pvalue:.4f} expect 0.9072/1.0219/-0.1147/0.1016")

# 3. Pressure quantization: unique levels + median step
pl = np.unique(pres)
steps = np.diff(pl)
print(f"F7 pressure_levels={len(pl)} steps_median={np.median(steps):.5f} expect 7 / ~0.327")

# 4. Post-window recovery (median convention)
post = flow[928:]
print(f"F8 post_window_median={np.median(post):.4f} expect 31.9995 (~32)")

# 5. PH1 apparent power S=V*I
s_in = (volt[w] * cur[w])
idx_out = np.r_[:621, 928:n_rows]
s_out = volt[idx_out] * cur[idx_out]
mws = stats.mannwhitneyu(s_in, s_out, alternative="two-sided")
print(f"F9 PH1 S_in={np.median(s_in):.1f} S_out={np.median(s_out):.1f} pct={(np.median(s_in)-np.median(s_out))/np.median(s_out)*100:.1f} p={mws.pvalue:.3f} expect 220.9/229.8/-3.9%/0.062")

# 6. Vibration flatness
for col, exp in (("Accelerometer1RMS", "p=0.452"), ("Accelerometer2RMS", "p=0.0027")):
    a = df[col].to_numpy()
    ai, ao = np.median(a[w]), np.median(a[idx_out])
    mwa = stats.mannwhitneyu(a[w], a[idx_out], alternative="two-sided")
    print(f"F10 {col} in={ai:.4f} out={ao:.4f} pct={(ai-ao)/ao*100:+.2f}% p={mwa.pvalue:.4g} (expect flat, {exp})")

# 7. Report integrity: p<1e-60 must never be cited as evidence
with open(RUN + "/report.md", encoding="utf-8") as f:
    rep = f.read()
n_1e60 = rep.count("1e-60")
print(f"F11 report_mentions_of_1e-60={n_1e60} (allowed only inside interception statement)")
print(f"F12 report_states_COMPETING_SET={'COMPETING_SET' in rep}")
print(f"F13 report_no_DETERMINED_upgrade={'DETERMINED（竞争假设集，不升级' in rep or '不升级为 DETERMINED' in rep}")

print("FINAL_AUDIT_RECOMPUTE_DONE")
