# -*- coding: utf-8 -*-
"""Step 5b PRE-REPORT physical audit — independent quantitative re-verification.
Auditor Sun (report-reviewer). All numbers recomputed from 00_input/data.csv only.
Zero reliance on upstream artifacts for any quoted number.
"""
import csv, math, json

DATA = "00_input/data.csv"

rows = []
with open(DATA, newline="", encoding="utf-8") as f:
    r = csv.reader(f)
    header = next(r)
    for rec in r:
        rows.append(rec)

cols = {c: i for i, c in enumerate(header)}
n = len(rows)
print("rows =", n, "| channels =", len(header) - 1)

def series(name):
    j = cols[name]
    return [float(rec[j]) for rec in rows]

def mean(x):
    return sum(x) / len(x)

def std(x, ddof=1):
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - ddof))

def z_of(name, idx, b_mean, b_std):
    return (series(name)[idx] - b_mean) / b_std

BL = range(0, 160)          # baseline idx0-159
PS = range(220, 960)        # post-onset steady idx220-959

def welch_t(a, b):
    ma, mb = mean(a), mean(b)
    va, vb = std(a) ** 2, std(b) ** 2
    na, nb = len(a), len(b)
    t = (ma - mb) / math.sqrt(va / na + vb / nb)
    return t

# ---------------- CHECK 1: cooling-triad same-sample fingerprint at idx160 ----------------
print("\n== CHECK 1: cooling triad at idx160 (baseline idx0-159 mu/sigma) ==")
tri = {}
for c in ["XMEAS_9", "XMEAS_21", "XMV_10"]:
    s = series(c)
    b = [s[i] for i in BL]
    bm, bs = mean(b), std(b)
    z160 = (s[160] - bm) / bs
    z161 = (s[161] - bm) / bs
    ps = [s[i] for i in PS]
    shift = (mean(ps) - bm) / bs
    tri[c] = dict(baseline_mean=bm, baseline_std=bs, z_idx160=z160, z_idx161=z161,
                  post_steady_shift_sigma=shift)
    print(f"{c}: baseline {bm:.4f} +- {bs:.4f} | z@idx160={z160:+.2f} z@idx161={z161:+.2f} | post-steady shift {shift:+.3f} sigma")
    print(f"   raw idx159/160/161: {s[159]:.4f} -> {s[160]:.4f} -> {s[161]:.4f}")

# claim comparison
print("claims: XMEAS_9 z=+10.47, XMEAS_21 z=+2.01 (idx160) / -2.34 (idx161), XMV_10 z=+11.10, shifts +0.09/-0.07/+6.82")

# ---------------- CHECK 2: contradiction scan — which channels have |z|>=3 at idx160 ----------------
print("\n== CHECK 2: all-channel |z| >= 3 scan at idx160 and max-z channel over onset window 158-166 ==")
num_cols = [c for c in header if c != "timestamp"]
hits160 = []
for c in num_cols:
    s = series(c)
    b = [s[i] for i in BL]
    bm, bs = mean(b), std(b)
    z160 = (s[160] - bm) / bs
    if abs(z160) >= 3:
        hits160.append((c, z160))
hits160.sort(key=lambda t: -abs(t[1]))
print("channels with |z(idx160)| >= 3:", [(c, round(z, 2)) for c, z in hits160])

# onset-window local max per channel (first |z|>=3 after idx155)
onset_hits = []
for c in num_cols:
    s = series(c)
    b = [s[i] for i in BL]
    bm, bs = mean(b), std(b)
    best = None
    for i in range(158, 167):
        z = (s[i] - bm) / bs
        if abs(z) >= 3 and (best is None or abs(z) > abs(best[1])):
            best = (i, z)
    if best:
        onset_hits.append((c, best[0], best[1]))
onset_hits.sort(key=lambda t: -abs(t[2]))
print("channels with |z|>=3 anywhere in idx158-166:")
for c, i, z in onset_hits:
    print(f"   {c} @idx{i}: z={z:+.2f}")

# ---------------- CHECK 3: XMV_10 era shift + Welch + step-flat (non-ramp) ----------------
print("\n== CHECK 3: XMV_10 era shift, Welch t, 3h-window flatness ==")
s10 = series("XMV_10")
b = [s10[i] for i in BL]
ps = [s10[i] for i in PS]
bm, bs = mean(b), std(b)
pm = mean(ps)
t = welch_t(b, ps)
print(f"baseline {bm:.4f} +- {bs:.4f} | post-steady {pm:.4f} | shift {(pm-bm)/bs:+.3f} sigma | Welch t={t:.2f}")
ratio = pm / bm
print(f"flow proxy ratio = {ratio:.4f} (claim 1.0912)")
# 3h (60-sample) window z sequence over post-steady
seq = []
start = 220
while start + 60 <= 960:
    w = [s10[i] for i in range(start, start + 60)]
    seq.append((mean(w) - bm) / bs)
    start += 60
print("3h window z sequence:", [round(v, 2) for v in seq])
print(f"spread = {max(seq)-min(seq):.3f} sigma | first-vs-last = {seq[0]-seq[-1]:+.3f} sigma (claim -0.087)")
# end-of-data level
tail = [s10[i] for i in range(900, 960)]
print(f"last 60 samples mean = {mean(tail):.3f}% (z={ (mean(tail)-bm)/bs :+.2f}) — still elevated at data end")

# ---------------- CHECK 4: P2 energy-balance necessity argument ----------------
print("\n== CHECK 4: P2 energy balance (algebraic necessity) ==")
s21 = series("XMEAS_21")
b21 = [s21[i] for i in BL]
ps21 = [s21[i] for i in PS]
bm21, bs21 = mean(b21), std(b21)
delta21 = mean(ps21) - bm21
print(f"T21 baseline {bm21:.4f} +- {bs21:.4f} | post-steady mean {mean(ps21):.4f} | delta {delta21:+.4f} C = {(mean(ps21)-bm21)/bs21:+.3f} sigma")
print(f"If Tin unchanged & Q unchanged: T21_new = Tin + (T21_old - Tin)/k, k={ratio:.4f}")
print(f"predicted drop = (1 - 1/k) * (T21 - Tin)_old = {(1 - 1/ratio):.4f} * (T21 - Tin)_old (claim factor 0.0836)")
print(f"Self-consistency H1: k*(1-(1-1/k)) = {ratio * (1 - 1/ratio):.6f} == 1 -> Q conserved exactly under H1 (algebraic)")
print(f"H6 escape bound: for predicted drop <= 1 sigma (0.1229 C), requires (T21-Tin)_old <= {bs21/(1-1/ratio):.2f} C, i.e. Tin_old >= {bm21 - bs21/(1-1/ratio):.2f} C")

# ---------------- CHECK 5: cross-loop localization XMEAS_22 ----------------
print("\n== CHECK 5: XMEAS_22 (condenser loop) stays in baseline band ==")
s22 = series("XMEAS_22")
b22 = [s22[i] for i in BL]
ps22 = [s22[i] for i in PS]
bm22, bs22 = mean(b22), std(b22)
print(f"baseline {bm22:.4f} +- {bs22:.4f} | post-steady {mean(ps22):.4f} | shift {(mean(ps22)-bm22)/bs22:+.3f} sigma (claim -0.08)")

# ---------------- CHECK 6: pressure network 2-sigma first crossings ----------------
print("\n== CHECK 6: pressure network first 2-sigma crossing after idx150 ==")
for c in ["XMEAS_7", "XMEAS_13", "XMEAS_16"]:
    s = series(c)
    b = [s[i] for i in BL]
    bm, bs = mean(b), std(b)
    first = None
    for i in range(150, min(960, 300)):
        if abs((s[i] - bm) / bs) >= 2:
            first = i
            break
    z = None
    if first is not None:
        z = (s[first] - bm) / bs
    print(f"{c}: first |z|>=2 after idx150 at idx{first} (z={z:+.2f})" if first else f"{c}: none in 150-300")

# ---------------- CHECK 7: feed side era shifts (H2/H4 exclusion basis) ----------------
print("\n== CHECK 7: feed/composition era shifts ==")
for c in ["XMEAS_1", "XMEAS_2", "XMEAS_4", "XMV_1", "XMEAS_23", "XMEAS_29"]:
    s = series(c)
    b = [s[i] for i in BL]
    psx = [s[i] for i in PS]
    bm, bs = mean(b), std(b)
    t = welch_t(b, psx)
    # rough two-sided p via normal approx (large n)
    p = math.erfc(abs(t) / math.sqrt(2))
    print(f"{c}: shift {(mean(psx)-bm)/bs:+.3f} sigma | Welch t={t:+.2f} p~{p:.2f}")

# ---------------- CHECK 8: anomaly-era correlations lag0 ----------------
print("\n== CHECK 8: anomaly-era (idx160-959) lag0 Pearson correlations ==")
def pearson(x, y):
    n = len(x)
    mx, my = mean(x), mean(y)
    sx = math.sqrt(sum((a - mx) ** 2 for a in x))
    sy = math.sqrt(sum((a - my) ** 2 for a in y))
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / (sx * sy)

a_range = range(160, 960)
x9 = series("XMEAS_9"); x21 = series("XMEAS_21")
r_v10_m9 = pearson([s10[i] for i in a_range], [x9[i] for i in a_range])
r_v10_m21 = pearson([s10[i] for i in a_range], [x21[i] for i in a_range])
r_full_v10_m9 = pearson(s10, x9)
print(f"r(XMV_10,XMEAS_9) anomaly era lag0 = {r_v10_m9:.4f} (claim 0.5796); full-data = {r_full_v10_m9:.4f} (claim pooled 0.2315)")
print(f"r(XMV_10,XMEAS_21) anomaly era lag0 = {r_v10_m21:.4f} (claim -0.4904)")

# ---------------- CHECK 9: timestamp integrity ----------------
print("\n== CHECK 9: timestamp monotonic / interval ==")
ts = [rec[0] for rec in rows]
from datetime import datetime
tds = [datetime.strptime(t, "%Y-%m-%d %H:%M:%S") for t in ts]
gaps = set((tds[i + 1] - tds[i]).total_seconds() for i in range(len(tds) - 1))
print(f"unique intervals: {gaps} | monotonic: {all(tds[i+1] > tds[i] for i in range(len(tds)-1))}")
print(f"row160 (0-based) timestamp = {ts[160]} (expected 2020-01-01 08:00:00)")

# ---------------- CHECK 10: XMEAS_9 anomaly scan beyond idx160 ----------------
print("\n== CHECK 10: XMEAS_9 all |z|>=3 samples (spike-then-return shape) ==")
b9 = [x9[i] for i in BL]
bm9, bs9 = mean(b9), std(b9)
out = [(i, (x9[i] - bm9) / bs9) for i in range(960) if abs((x9[i] - bm9) / bs9) >= 3]
print("XMEAS_9 |z|>=3 at:", [(i, round(z, 2)) for i, z in out])
print(f"\nVERDICT-BASE NUMBERS: idx160 deviation XMEAS_9 = {x9[160]-bm9:.4f} C = {(x9[160]-bm9)/bs9:.2f} sigma")
