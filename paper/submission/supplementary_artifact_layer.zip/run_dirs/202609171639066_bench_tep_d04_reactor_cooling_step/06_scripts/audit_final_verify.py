# -*- coding: utf-8 -*-
"""Step 7 FINAL physical audit — independent recomputation from 00_input/data.csv only.

Auditor Sun (report-reviewer), FINAL mode. Numbers recomputed here are compared
against report.md / run_summary.json / 04_diagnostics claims.
"""
import csv, math, json

RUN = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171639066_bench_tep_d04_reactor_cooling_step"
DATA = RUN + r"/00_input/data.csv"

rows = []
with open(DATA, newline="", encoding="utf-8") as f:
    r = csv.reader(f)
    header = next(r)
    for rec in r:
        rows.append(rec)

cols = header[1:]  # drop timestamp
n = len(rows)
assert n == 960, n

def series(name):
    j = header.index(name)
    return [float(rec[j]) for rec in rows]

def mean(v):
    return sum(v) / len(v)

def std(v):
    m = mean(v)
    return math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1))

def welch_t(a, b):
    ma, mb = mean(a), mean(b)
    va, vb = std(a) ** 2, std(b) ** 2
    return (ma - mb) / math.sqrt(va / len(a) + vb / len(b))

out = {}
base = slice(0, 160)        # idx0-159
tran = slice(160, 220)      # idx160-219 (transient, excluded from steady stats)
anom = slice(220, 960)      # idx220-959

x9 = series("XMEAS_9"); x21 = series("XMEAS_21"); xmv10 = series("XMV_10"); x22 = series("XMEAS_22")

# --- 1. cooling trio co-onset z (baseline mu/sigma) ---
for nm, s in (("XMEAS_9", x9), ("XMEAS_21", x21), ("XMV_10", xmv10)):
    b = s[base]; mu, sd = mean(b), std(b)
    out["trio_%s_mu" % nm] = round(mu, 4)
    out["trio_%s_sd" % nm] = round(sd, 4)
    out["trio_%s_z160" % nm] = round((s[160] - mu) / sd, 2)
out["trio_XMEAS_21_z161"] = round((x21[161] - mean(x21[base])) / std(x21[base]), 2)

# post-steady-state shifts (sigma units)
for nm, s in (("XMEAS_9", x9), ("XMEAS_21", x21), ("XMV_10", xmv10), ("XMEAS_22", x22)):
    b = s[base]; mu, sd = mean(b), std(b)
    a = s[anom]
    out["post_%s_shift_sigma" % nm] = round((mean(a) - mu) / sd, 3)
out["post_XMEAS_21_delta_C"] = round(mean(x21[anom]) - mean(x21[base]), 4)

# --- 2. XMV_10 era shift, Welch t, flow ratio, last-60 check ---
b, a = xmv10[base], xmv10[anom]
out["xmv10_base_mean"] = round(mean(b), 4)
out["xmv10_anom_mean"] = round(mean(a), 4)
out["xmv10_shift_sigma"] = round((mean(a) - mean(b)) / std(b), 2)
out["xmv10_welch_t"] = round(welch_t(b, a), 1)
out["flow_ratio"] = round(mean(a) / mean(b), 4)
out["p2_coef"] = round(1.0 - 1.0 / (mean(a) / mean(b)), 4)
out["xmv10_last60_mean"] = round(mean(xmv10[-60:]), 3)
out["xmv10_last60_z"] = round((mean(xmv10[-60:]) - mean(b)) / std(b), 2)

# 3h-window z series (anchor idx160, 60-sample step, 13 windows)
mu, sd = mean(b), std(b)
wins = []
for k in range(13):
    s0 = 160 + 60 * k
    seg = xmv10[s0:s0 + 60]
    wins.append(round((mean(seg) - mu) / sd, 3))
out["win13"] = wins
out["win13_span"] = round(max(wins) - min(wins), 3)
# steady-state-only windows (idx220..959, 12 windows of 60)
wins2 = []
for k in range(12):
    s0 = 220 + 60 * k
    seg = xmv10[s0:s0 + 60]
    wins2.append(round((mean(seg) - mu) / sd, 3))
out["win12_first_vs_last"] = round(wins2[0] - wins2[-1], 3)
out["win13_first_vs_last"] = round(wins[0] - wins[-1], 3)

# --- 3. co-onset uniqueness scan idx158-166: channels with |z|>=3 anywhere in window ---
hits = set()
for c in cols:
    s = series(c)
    muC, sdC = mean(s[base]), std(s[base])
    for i in range(158, 167):
        if abs((s[i] - muC) / sdC) >= 3.0:
            hits.add(c)
out["co_onset_hits"] = sorted(hits)

# --- 4. H6 survival bound / T9-T21 process-side differential ---
sd21 = std(x21[base])
out["x21_base_sd"] = round(sd21, 4)
out["h6_bound_T21minusTin"] = round(sd21 / 0.0836, 2)      # claim <=1.47 C
out["x21_base_mean"] = round(mean(x21[base]), 4)
out["tin_old_min"] = round(mean(x21[base]) - sd21 / 0.0836, 1)  # claim >=93.1 C
out["T9_minus_T21"] = round(mean(x9[base]) - mean(x21[base]), 1)  # claim ~25.8 C

# --- 5. pressure network onset response ---
for nm, idx_claim in (("XMEAS_13", 161), ("XMEAS_16", 161), ("XMEAS_7", 162)):
    s = series(nm)
    muC, sdC = mean(s[base]), std(s[base])
    out["press_%s_z" % nm] = round((s[idx_claim] - muC) / sdC, 2)

# --- 6. confidence arithmetic (from confidence.json cited sums) ---
out["H1_raw"] = 18 + 22 + 16 + 14 + 9
out["H6_raw"] = 18 + 18 + 16 + 14 + 5
out["overall_le_ceiling"] = 63 <= 65
out["identity_10912x09164"] = round(1.0912 * 0.9164, 4)

print(json.dumps(out, indent=1, ensure_ascii=False))
