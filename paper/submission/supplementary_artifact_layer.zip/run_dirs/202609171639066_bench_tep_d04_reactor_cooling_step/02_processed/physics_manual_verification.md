# Physics Manual Verification — diagnostician (Step 4)

Run: 202609171639066_bench_tep_d04_reactor_cooling_step
Author: diagnostician (Chief Engineer Liu persona), executing agent-protocol Phase 1/1.5
Method: all quantities below independently recomputed from `00_input/data.csv` (960 rows, 3-min interval)
with the shared venv python; cross-checked against `02_processed/physics_check.json` (P1-P5),
`02_processed/semantic_analysis_results.json` and `02_processed/validate_report.json`.
Note: this file also serves as the manual physics-verification record for
`diagnostic-quality-check.mjs` (its automatic counter does not read `physics_check.json.checks[]`,
which contains 5 executed checks with verdicts).

## L1 — Direct measurement identification

| Quantity | Column | Baseline (idx0-159) | Onset sample (idx160) | Post-steady (idx220-959) |
|---|---|---|---|---|
| Reactor temperature | XMEAS_9 | 120.3993 ± 0.0192 °C | z = +10.47 (single sample) | 120.4009 (+0.09σ, held) |
| Reactor CW outlet temp | XMEAS_21 | 94.6003 ± 0.1229 °C | z = +2.01, then −2.34 @161 | 94.5916 (−0.07σ, held) |
| Reactor CW valve | XMV_10 | 41.1424 ± 0.5502 % | z = +11.10 | 44.8967 (+6.82σ sustained step) |
| Separator CW outlet temp | XMEAS_22 | 77.3097 ± 0.2302 °C | z = +1.86 (transient only) | 77.2910 (−0.08σ, flat) |
| D feed | XMEAS_2 | 3662.36 ± 35.19 kg/h | z = −0.48 | 3665.83 (+0.10σ, p=0.26) |

Recomputed exactly (no discrepancy with data-processor artifacts).

## L2 — Governing laws (ontology + chemical engineering first principles)

- Reactor energy balance: `mCp·dT9/dt = (−ΔH)·r(T9) − Q_cool`
- CW-loop heat removal: `Q = ṁcw·cp_water·(T21 − Tin)` (Tin unmeasured)
- CW outlet relation: `T21 = Tin + Q/(ṁcw·cp)`
- Exchanger duty: `Q = UA·LMTD`
- Reactor pressure: `PV = nRT` (constant volume) — masked by pressure control network (XMV_5/XMV_6)

## L3 — Causal chain and predicted functional forms (ontology cross-check)

Ontology-predicted cooling-side disturbance fingerprint (`01_ontology/ontology.json`, relationship
XMEAS_21→XMEAS_9): co-movement of XMEAS_9 spike + XMEAS_21 transient + XMV_10 opening at onset.
Observed: all three move in the SAME sample (idx160). Predicted inverse coupling XMV_10→XMEAS_21:
confirmed in anomaly era (lag-0 CCF r = −0.4904; ontology predicted inverse). Predicted immediate
XMEAS_9→XMEAS_7 pressure response: raw r = 0.0654 — masked by closed-loop pressure control
(expected, not a contradiction); the evidence is the co-timed response (2σ crossings idx161-162),
not r.

## L4 — Magnitude plausibility (recomputed)

1. Flow proxy: 44.8967/41.1424 = **1.0912 → +9.1 %** cooling-water flow (valve position as proxy).
2. P2 algebraic necessity: hold T21 constant with Q constant ⇒ `T21 − Tin` must shrink by factor
   1/1.0912 ⇒ `ΔTin = 0.0836 × (T21 − Tin)_old > 0`. T21 observed Δ = **−0.0087 °C** (held at
   baseline). With Tin unchanged, T21 would have to FALL; it did not ⇒ an inlet-temperature rise
   (or an equivalent sudden UA loss — the H1/H6 fork) is algebraically required.
3. Step-vs-ramp (H3 falsifier): XMV_10 3-h window z sequence over idx160-920 =
   [6.72, 6.63, 6.92, 6.75, 7.04, 6.98, 6.93, 6.84, 6.64, 6.68, 6.93, 6.63] — spread **0.408σ**,
   non-monotonic, first-vs-last window delta **−0.087σ** over 40 h. A gradual UA degradation would
   produce a monotonic ramp; observed is step-flat ⇒ H3 excluded, sudden-input step confirmed.
4. Multi-instrument independence (H5 falsifier): pressure network first |z|>2 crossings recomputed:
   XMEAS_13 z=+2.05 @161, XMEAS_16 z=+2.09 @161, XMEAS_7 z=+2.30 @162 — one to two samples after
   the idx160 cooling event. A single-sensor artifact on XMEAS_9 cannot drive the actuator signal,
   the pressure network, and the adjacent CW outlet temperature co-timedly.
5. Loop localization (P3): XMEAS_22 era shift −0.08σ ⇒ disturbance confined to the reactor cooling
   loop; a plant-wide cooling-water event is excluded.

Verdict: all magnitudes PLAUSIBLE (no observed/predicted ratio deviates >10×; Tin-side magnitudes
are not exactly computable because Tin is unmeasured — disclosed as the H1/H6 fork, ceiling 65).

## L5 — Alternative mechanisms screened

- Reaction-heat side (H2): feeds move ≤0.10σ (p≥0.26), compositions ≤0.49σ with 2σ crossings AFTER
  onset (XMEAS_23@172) — consequence, not driver. EXCLUDED.
- Gradual fouling ramp (H3): excluded by L4.3 (step-flat, not ramp).
- D-feed driver (H4): global r=0.3336 is era-stable background coupling (0.4128/0.3176) — Simpson-type
  misread. EXCLUDED.
- Sensor artifact (H5): excluded by L4.4.
- Controller setpoint change: would park XMEAS_9 at a NEW level; observed XMEAS_9 returns to 120.4 °C
  (+0.09σ) while XMV_10 holds a compensating step — inconsistent; recorded as a falsification
  condition to be checked against controller logs (no setpoint channel in dataset).
- Surviving fork: unmeasured CW inlet-temperature step (H1, rank 1) vs sudden UA step loss (H6,
  rank 2) — INDISTINGUISHABLE on this dataset (no Tin/UA channel), kept as COMPETING_SET per protocol.
