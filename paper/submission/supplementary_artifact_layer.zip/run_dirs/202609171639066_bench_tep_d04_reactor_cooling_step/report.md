# 工业诊断报告 — bench_tep_d04_reactor_cooling_step

**场景**：TE 过程反应器冷却阶跃扰动（Tennessee Eastman 连续化工过程：反应器-冷凝器-气液分离器-汽提塔+循环压缩机）
**运行目录**：`workspace/diagnostic-runs/202609171639066_bench_tep_d04_reactor_cooling_step`
**数据**：`00_input/data.csv`（960 行 × 52 数值通道 + timestamp，3min 等间隔，2020-01-01 00:00 起 48h）
**用户问题**：诊断本次异常的根本原因（声明异常起点：第 161 样本 / idx160 = 2020-01-01 08:00，truth_withheld=true）
**结论形态**：COMPETING_SET ｜ **总体置信**：63/100（MEDIUM，竞争集天花板 65）｜ **质量门**：Judge 97/pass（首轮，1/3）· 报告前物理审计 PREFLIGHT_PASS（FATAL 0 / MAJOR 0）
**报告人**：Engineer Zhou（技术报告）· 2026-09-18

---

## 1. 执行摘要

**一句话结论**：idx160（2020-01-01 08:00）反应器冷却回路发生**输入阶跃型移热能力损失**——冷却三联征同拍指纹与能量平衡代数约束共同把扰动锁定在冷却侧；但冷却侧内部的子机制（**H1 未测量冷却水入口温度阶跃升高**，rank 1，vs **H6 突发性 UA 阶跃下降**，rank 2）在现有 3min 采样、无入口水温/UA 观测通道的条件下不可判别，按诚实三态协议输出 **COMPETING_SET**，置信被天花板 65 截断，总体 63/100。

**关键事实**（全部可从 `00_input/data.csv` 复算，Judge 与物理审计独立复算 20/20 项一致）：

- **唯一大幅工况位移出现在操纵变量**：冷却水阀位 XMV_10 从 41.14% 阶跃至 44.90%（+6.82σ，Welch t=−79.4，p=4.75e-164，52 通道中唯一 >1.19σ 的时代位移），折合冷却水流量 +9.1%——控制器在补偿持续的移热缺口，且台阶维持至数据末端（末 60 样本均值 44.918%，z=+6.86）。
- **冷却三联征同拍指纹**：idx160 同一采样内 XMEAS_9（反应器温度）单样本尖峰 z=+10.47、XMEAS_21（冷却水出口温度）瞬变 +2.01σ（idx161 回摆 −2.34σ）、XMV_10 跳升 z=+11.10；其后 XMEAS_9 被控制拉回设定点（后稳态仅 +0.09σ，守住 120.4°C）。
- **能量平衡必然性**：流量 +9.1% 而冷却水出口温度 T21 守住基线（Δ=−0.0087°C）——若入口水温 Tin 不变，T21 应下降 0.0836×(T21−Tin)_old；守住基线在代数上强制 Tin 升高（ΔTin>0）。
- **回路定域**：冷凝器回路对应测点 XMEAS_22 全程基线带内（−0.08σ）——排除全厂冷却水/环境总管事件，扰动定域于反应器冷却回路。

**业务影响与行动**：装置目前被控制器稳住（温度守设定点），但 XMV_10 已垫高 3.76 个百分点且扰动未消除——若扰动持续恶化将逼近阀位余量上限。**P0**：在反应器冷却水入口加装温度测点（一项测量即可把竞争集判别为 DETERMINED）；**P1**：核对 2020-01-01 08:00 前后控制器设定值/整定变更记录、加装传热率（UA）监测；**P2**：停车时检查换热面结垢/堵塞痕迹。详见第 9 节。

---

## 2. 诊断背景与数据概览

- **过程**：TE 连续化工过程。XMEAS_1..41 过程测量 + XMV_1..11 操纵变量（Downs-Vogel 标准映射）。关键通道：XMEAS_9=反应器温度（120.4°C 设定，基线 std 仅 0.019°C 窄带受控）、XMEAS_21=反应器冷却水出口温度、XMV_10=反应器冷却水阀位、XMEAS_22=分离器/冷凝器冷却水出口温度（跨回路参照）。
- **数据形态**（`00_input/input_inspection.json` + `02_processed/validate_report.json`）：960 行、52 数值通道、无缺失（missing_pct=0）；timestamp 960 个唯一值、180s 等间隔、严格单调（time_sorted=true）——全部时序先后主张合法。
- **工况分区**（`02_processed/production_regime_filter.json`）：基线稳态 idx[0,159] / 过渡带 idx[160,219]（不用于稳态统计）/ 异常稳态 idx[220,959]。无产品/批次分组列（product_grades=[]，batch_id=null），无质检/化验列（inspection_signals=[]）——**双驱动（process→quality）路径已执行核查并诚实判 not_applicable**，本诊断为纯过程波动路径（View A）。
- **结构性约束**（`00_input/clarification_needed.json` + `01_ontology/ontology.json` confounders 首条）：冷却水入口温度 Tin **未测量**（AMB-05）、换热器 UA 无在线观测（AMB-07 RAG 不可达已按协议降级为 parameter_to_physics 推理，rag_validated=false）。这两个缺口是本诊断保持竞争集的根本原因，不是推理偷懒。

## 3. 数据质量评估

| 检查项 | 结果 | 来源 |
|---|---|---|
| 完整性 | 960 行 × 52 通道 0 缺失、0 行损 | `00_input/input_inspection.json` |
| 时间轴 | time_sorted=true，3min 等间隔，960 唯一时间戳 | `02_processed/validate_report.json` sorting_validation |
| 批次完整性 | applicable=false（无批次 ID 列）——诚实判不适用 | `02_processed/validate_report.json` batch |
| Simpson 反转 / 趋势混杂 | 均为空（0 findings） | `02_processed/validate_report.json` anti_spurious |
| 单点杠杆 | leave_one_out 5/5 全部 leveraged=false（最大 max_shift=0.0254） | 同上 |
| 离群敏感度 | **1 项 SERIOUS**：XMV_10~XMEAS_9 池化 r=0.2315 判 outlier_driven（剔除 189 过渡带点后 clean_r=0.5091，+119.9%）——经核查为过渡带瞬变稀释而非离群伪造，诊断弃用池化值、改用时代分层值并披露（overall_validity=MODERATE_CONCERNS，见第 10 节局限性） | 同上 outlier_sensitivity |
| 生产状态 | 单连续工况 48h；稳态过滤（5pt 滚动 std ≤60 分位）用于时代分层统计 | `02_processed/production_regime_filter.json` |
| 已知噪声 | 组分分析仪加性噪声（XMEAS_37 出现微小负值），痕量组成读数需容忍噪声带宽 | `01_ontology/ontology.json` confounders |

## 4. 统计分析发现

以下每条均为可复算数字，标注来源与计算口径。

1. **时代位移扫描（52 通道，基线 idx0-159 vs 后稳态 idx220-959，Welch t）**：唯一 >1.19σ 的位移是 **XMV_10 +6.82σ**（41.1424%→44.8967%，Welch t=−79.4，p=4.75e-164）。次级位移仅 XMEAS_18 −1.19σ、XMV_9 −1.07σ、XMEAS_19 −1.01σ（汽提工段慢漂，见 6.4 节）。来源：`02_processed/semantic_analysis_results.json` era_shift_ranking。**最强判别证据的不对称**：全数据集唯一的"动作"发生在操纵变量，而非任何被控/组成通道。
2. **冷却三联征同拍指纹（L1 直接复算，口径=基线 idx0-159 μ/σ 归一化）**：idx160 同一采样内 XMEAS_9 z=+10.47（120.399±0.019°C 基线带，120.370→120.600→120.400 单样本尖峰回位）、XMEAS_21 z=+2.01（idx161 回摆 −2.34）、XMV_10 z=+11.10（40.694→47.248→43.966）；后稳态位移依次 +0.09σ / −0.07σ / +6.82σ。idx158-166 全通道 |z|≥3 扫描仅 XMV_10 与 XMEAS_9 两通道（审计 P-01 复算），无第四个同拍通道。注：`02_processed/anomaly_report.json` 的 max_deviation_sigma=10.06 为全数据集归一化口径，本报告统一采用基线 μ/σ 复算口径 10.47（两值同源不矛盾）。
3. **时代分层相关 r(XMV_10~XMEAS_9)**：baseline 0.6374（p=1.28e-19）/ anomaly 0.5796（p=5.48e-73），Spearman 收敛（0.6335/0.5613）；**全样本池化 r=0.2315 被时代均值位移稀释**（validate_report 判 SERIOUS，clean_r=0.5091 同向佐证）——引用相关一律以分层值为准。
4. **滞后补偿 CCF（lag0..20，`02_processed/time_lag_analysis.json`）**：XMV_10→XMEAS_9 异常期 lag0 r=0.5796 为最优滞后（无跨期错位）；XMV_10→XMEAS_21 lag0 r=−0.4904 与本体 inverse 预测一致（physics_discrepancy_alerts 判 physics_consistent）；XMEAS_9→XMEAS_7 全样本 r=0.0654、异常期 0.0492——闭环压力控制的预期掩蔽，其 lag4 r=−0.075 与 PV=nRT 方向相反且幅值可忽略，**按告警判虚假相关剔除**，该配对证据改用 onset 响应时序。
5. **onset 时序排序**：进料/组成 2σ 首穿全部晚于 onset@160（XMEAS_23@172、XMEAS_2@174；XMEAS_28@136 属基线噪声单点）——组成是后果而非驱动；压力网络 XMEAS_13 z=+2.05@161、XMEAS_16 z=+2.09@161、XMEAS_7 z=+2.30@162——冷却事件后 1-2 个采样响应（L1 独立复算）。
6. **XMV_10 阶跃-平坦形态（P5 指纹）**：3h 窗口（60 样本，锚点 idx160）z 序列 13 值 [6.72, 6.63, 6.92, 6.75, 7.04, 6.98, 6.93, 6.84, 6.64, 6.68, 6.93, 6.63, 6.80]，跨度 0.41σ，非单调；13 窗口口径 first-vs-last=−0.087σ（末窗 6.80 已含，与此自洽）；若按纯稳态窗（idx220-959，12 窗）对齐，审计复算为 −0.17σ——两种口径下均非单调、无 ramp，40h 无渐进漂移（末 60 样本 z=+6.86）。**渐进退化（ramp 形态）被定量否证**。
7. **伪线索甄别（Simpson 型误用被拦截）**：XMEAS_2~XMEAS_9 全局 r=0.3336 为对 XMEAS_9 的最强相关，但时代分层后 baseline 0.4128 / anomaly 0.3176 **两期同在**——背景控制耦合而非故障特异；且 XMEAS_2 时代位移仅 +0.10σ（Welch p=0.26）、2σ 首穿 idx174 晚于 onset。进料侧四通道位移全部 ≤0.10σ（p≥0.26），组成通道最大 −0.49σ（XMEAS_29）。

## 5. 竞争假设与排除逻辑

### 5.1 竞争假设对比

| 假设 | 机制类 | 内容 | 五因素原始分 | 最终置信 | 排序 |
|---|---|---|---|---|---|
| **H1** | ENVIRONMENT | 冷却水入口温度 Tin 阶跃升高（未测量变量），XMV_10 闭环补偿 | 79（18+22+16+14+9） | 65（ceiling 截断 −14） | **rank 1** |
| **H6** | WEAR | 换热器突发性 UA 阶跃下降（突发结垢/堵塞），闭环指纹与 H1 完全相同 | 71（18+18+16+14+5） | 65（ceiling 截断 −6） | rank 2 |
| H2 | OPERATION | 反应热侧驱动（进料负荷/组成增大放热） | 18 | 8 | 排除（COMBINED，95） |
| H3 | WEAR | 冷却能力渐进退化（UA 缓慢下降，ramp） | 15 | 5 | 排除（STATISTICAL，95） |
| H4 | OPERATION | D 进料扰动驱动 | 15 | 5 | 排除（STATISTICAL，95） |
| H5 | — | XMEAS_9 传感器/仪表伪迹 | 10 | 3 | 排除（PHYSICAL，95） |

**竞争集 CS1 = {H1, H6}，判别力 = INDISTINGUISHABLE，置信天花板 65**。两成员共享完全相同的闭环观测指纹；唯一潜在判别器是 P2 能量平衡对 T21 守恒行为的方向性预测，但其幅值标定依赖未测量的 (T21−Tin)_old——现有数据无可执行判别统计量（`04_diagnostics/diagnosis.json` discriminability_matrix）。判别所需补测见第 9 节。

### 5.2 排除假设与排除逻辑（四项排除，置信均 95 ≥ 90，各附 revival_condition）

- **H2 排除（COMBINED）**：进料/组成无驱动性位移（≤0.49σ，进料侧 ≤0.10σ 且 p≥0.26）；组成 2σ 首穿（172/189）晚于 onset 160——时序倒置，组成是后果；物理矛盾：放热增大应使 T21 持续升高，实测 T21 回归基线（−0.07σ）。四 anti-speculation 条件中"时序在前"与"无矛盾"两项不满足。
- **H3 排除（STATISTICAL）**：ramp 形态被窗口 z 序列定量否证（见 4.6）。注意：仅排除**渐进**形态，突发 UA 阶跃（H6）作为独立子案保留在竞争集内——这正是增补 H6、避免"虚假 DETERMINED"的原因。
- **H4 排除（STATISTICAL）**：全局相关榜首经时代分层证伪为背景耦合（4.7）；进料无位移、首穿晚于 onset。
- **H5 排除（PHYSICAL）**：多仪表独立协调响应与单传感器伪迹不相容——执行器 XMV_10 真实机械动作（z=+11.10 瞬变 + +6.82σ 台阶）、压力网络 idx161-162 响应、XMEAS_21 同拍瞬变；且伪迹无法解释 40h 台阶维持（XMEAS_9 尖峰后严格回位而补偿不撤）。

### 5.3 核心证据与对齐图解读

**披露（视觉-统计对齐口径）**：本次运行为 non-VLM 环境，`03_figures/visual_analysis.json` 为 pre-VLM 骨架（observation_mode=skeleton_pre_vlm，chart_inventory 三图 read_status=READ_FAILED）。以下图表仅作**定位参照**嵌入；对齐图解读依据的是统计元数据（co-onset、CCF、时代位移），**不虚构任何像素级视觉观察**，视觉与统计不存在不一致项。

![关键过程变量时序总览（红线为 ±3σ 阈值）](03_figures/fig_temporal_overview.png)

- **图上可见**：52 通道中仅 XMV_10 在 idx160 后抬升至新台阶，XMEAS_9 出现单样本尖峰后回位，其余通道（含 XMEAS_22）平稳。**统计佐证**：时代位移唯一大幅通道即 XMV_10 +6.82σ；XMEAS_9 后稳态 +0.09σ。**物理核验**：P1/P5 一致——操纵变量台阶 + 被控变量守住设定点 = 持续性未测量外部输入阶跃的闭环指纹。

![全局 z 归一化时序叠加图](03_figures/fig_vlm_temporal_overlay.png)

- **图上可见（元数据级）**：异常起点红线标注于样本 161；三联征通道在同一时刻起跳。**统计佐证**：idx160 同拍 z=+10.47 / +2.01 / +11.10；CCF lag0 最优（无跨期错位）。**物理核验**：本体预言的冷却侧扰动特征指纹（三者同向联动）被数据精确复现（`01_ontology/ontology.json` relationship XMEAS_21→XMEAS_9）。

![参数同步性热图（滑窗相关）](03_figures/fig_vlm_synchronization.png)

- **图上可见（元数据级）**：XMV_10~XMEAS_9 与 XMV_10~XMEAS_21 构成同步群。**统计佐证**：异常期 lag0 r=0.5796（同向）与 −0.4904（inverse，流量稀释）。**物理核验**：Q=ṁcw·cp·(T21−Tin) 决定阀开大→T21 下降的反比方向，与观测一致。

![单工况全参数 z 归一化叠加图（onset=样本 161 红线）](03_figures/fig_vlm_temporal_overlay_single_product.png)

- **图上可见（元数据级）**：进料/组成通道的偏离晚于冷却三联征；压力网络紧随其后。**统计佐证**：2σ 首穿次序——三联征@160 → 压力网络@161-162 → 组成@172/进料@174。**物理核验**：因果方向自冷却回路指向下游，而非反向。

## 6. 根因结论

### 6.1 诊断结论

**diagnosis_type = COMPETING_SET**。`04_diagnostics/diagnosis.json` primary_finding 原文：

> 反应器冷却系统扰动（reactor cooling system disturbance）：idx160（2020-01-01 08:00）反应器冷却回路发生移热能力阶跃性损失——冷却三联征同拍指纹（XMEAS_9 单样本尖峰 z=+10.47、XMEAS_21 瞬变 +2.01/-2.34σ、XMV_10 阀位跳升 z=+11.10 后维持 +6.82σ 恒定台阶 41.14%→44.90%，无 ramp）与能量平衡代数约束共同锁定冷却侧输入阶跃，进料/组成/反应热侧与传感器伪迹均被定量排除；冷却侧子机制分叉（未测量冷却水入口温度阶跃升高 vs 突发性 UA 阶跃下降）在现有 3min 采样、无入口水温/UA 观测通道的条件下不可区分，按协议保持竞争集（置信上限 65）。

机理级判定（冷却侧输入阶跃 + XMV_10 闭环补偿）四 anti-speculation 条件全部独立验证：时序（三联征同拍 + 下游次序正确）、统计显著（+6.82σ，p=4.75e-164）、物理机制（五项物理校核零矛盾）、无矛盾（症状完备性满分命中）。

### 6.2 物理机理链与能量平衡必然性论证

**H1（rank 1）机理链**（每箭头挂接守恒式， governing laws 与 `01_ontology/ontology.json` relationships 一致）：

1. 冷却水入口温度 Tin 阶跃升高（未测量；INFERRED，由三联征同拍性 + P2 代数约束反推）——governing law：Q = ṁcw·cp·(T21 − Tin)。
2. 同等阀位下移热量骤降 → XMEAS_9 单采样冲高（OBSERVED：idx160 z=+10.47）。
3. 温度控制器持续开大 XMV_10 → 流量 +9.1% → 移热恢复、T9 回设定点（OBSERVED：+6.82σ 台阶；+0.09σ 守恒）。
4. T21 = Tin + Q/(ṁcw·cp)：入口温升与流量增加精确互锁 → T21 回归基线（OBSERVED：−0.07σ；异常期 r=−0.4904 inverse 验证）。
5. 扰动定域于反应器冷却回路（OBSERVED：XMEAS_22 −0.08σ；P3 reactor_loop_localized）。

**能量平衡必然性（necessity 论证，独立复算自 00_input/data.csv）**：流量代理比 44.8967/41.1424 = **1.0912**；Tin 不变、热负荷不变时，T21 预测降幅 = (1 − 1/1.0912)×(T21−Tin)_old = **0.0836×(T21−Tin)_old**（°C）。实测 T21 位移仅 −0.0087°C（−0.07σ，基线 std 0.1229°C）——守住基线在代数上**强制 ΔTin = 0.0836×(T21−Tin)_old > 0**。H1 自洽性精确成立：1.0912 × 0.9164 = **1.0000**（Q 守恒恒等式），即 +9.1% 流量与入口温升在能量平衡下精确互锁。

**单位精度说明（采纳 Judge warning 1 / 审计 R-2）**：`02_processed/physics_check.json` P2 原文将 Tin 不变假设下的预测降幅写作"~1.4 sigma"——该量纲不精确（实际预测式为 ΔT21=0.0836×(T21−Tin)_old，单位 °C，而 (T21−Tin)_old 未测量，sigma 数无法从数据标定，幅值应记 NOT_APPLICABLE: UNCALIBRATABLE）。本报告一律以 0.0836×(T21−Tin)_old 表达，不引用该 sigma 数；诊断工件（diagnosis/confidence）亦未传播该数字。

### 6.3 H6 存活域定量界（采纳审计 R-1/M-01 —— 锐化 H1 排序，不破坏竞争集）

报告前物理审计（`05_review/optimizer_preflight.md` M-01）独立复算给出一个定量界：H6（Tin 不变的突发 UA 阶跃）要与观测 T21 守恒（|Δ|≤1σ=0.1229°C）相容，必须 **(T21−Tin)_old ≤ 0.1229/0.0836 ≈ 1.47°C**，即 **Tin_old ≥ 93.1°C**——而过程侧温差 T9−T21 ≈ **25.8°C**，冷却水侧温升不足过程侧落差的 6%，意味着极端不物理的换热面配置。叠加 idx160 T21 上冲（+2.01σ）方向本身与"UA 骤降瞬间 T21 应回落"相反（单采样内动态不可辨，不作排除依据）。

**诚实边界**：该上界**仅强化 H1 的 rank-1 排序依据，不构成对 H6 的排除**——Tin 未测量、协议要求排除置信 ≥90，故 COMPETING_SET 结构、天花板 65 与总体 63 **维持不变**。这是审计建议的"一句定量界"式呈现，不改变结论形态。

### 6.4 置信结构、判别缺口与次级影响

- **置信**：H1 = H6 = 65（INDISTINGUISHABLE 竞争集天花板；原始五因素 79/71 分别被截断 −14/−6，`04_diagnostics/confidence.json` adjustment_log 完整可逆）；总体 63 = 天花板 65 − 2（两成员共享全部判别证据、无独立区分证据，留 2 分裕度，`04_diagnostics/confidence.json`）。
- **已披露推理缺口（`04_diagnostics/diagnosis.json` inference_gaps，未静默删除）**：① H1 链首 Tin→XMEAS_9 为 DATA_LINK_MISSING（变量无测量通道，以 P2 代数约束 + 三联征反推补偿，evidence_level=L5）；② XMEAS_9→XMEAS_7 为 CORRELATION_ABSENT（闭环掩蔽，证据基础改用 onset 时序响应）；③ H6 的 UA→T21 链出现弱 DIRECTION_MISMATCH（T21 应降而实测守恒）——正是 H1 排序优先的依据。
- **次级影响（采纳审计 R-3/I-04）**：era_shift_ranking 中汽提工段存在 ≤1.2σ 慢漂——XMEAS_18 −1.19σ、XMV_9 −1.07σ、XMEAS_19 −1.01σ。幅值小、与 idx160 非同拍、不触碰结论，判为下游涟漪级扰动而非根因，如实记录避免"除 XMV_10 外全静止"的过度简化表述。

## 7. 证据附录

### 7.1 证据全景

证据等级结构（L1-L7，结论受最弱证据级约束——链首 Tin 为 L5 机理推断，已披露）：`04_diagnostics/evidence.json` 登记 visual 3 条 / numerical 8 条 / physical 5 条 / validation 5 条。

| 等级 | 工件 | 关键数字/内容 |
|---|---|---|
| **L1 直接测量** | `00_input/data.csv` | 三联征 idx160 z=+10.47/+2.01/+11.10（基线 idx0-159 μ/σ 复算口径）；XMV_10 41.1424%→44.8967%、流量比 1.0912；压力网络 XMEAS_13 z=+2.05@161、XMEAS_16 z=+2.09@161、XMEAS_7 z=+2.30@162；窗口 z 序列 13 值跨度 0.41σ |
| **L3 统计分析** | `02_processed/semantic_analysis_results.json` | XMV_10 +6.82σ（Welch t=−79.4，p=4.75e-164）；分层 r 0.6374/0.5796；进料/组成位移 ≤0.49σ；onset_ordering |
| L3 | `02_processed/time_lag_analysis.json` | CCF lag0 r=0.5796 / −0.4904；XMEAS_9→XMEAS_7 lag4 −0.075 虚假相关剔除 |
| L3 | `02_processed/validate_report.json` | time_sorted=true；outlier_sensitivity 1 项 SERIOUS（池化 0.2315→clean 0.5091）；simpson=[]、trend=[]；leave_one_out 全部 false；overall_validity=MODERATE_CONCERNS |
| L3 | `02_processed/production_regime_filter.json` | 三段工况分区 160/60/740 行；batch 不适用 |
| L3 | `02_processed/anomaly_report.json` | threshold_crossing_index=160（critical）；quality_reset reset_found=false（NO_RESET） |
| L3 | `02_processed/causal_evidence_map.json` | 根因候选 rank1=Tin 阶跃（data_supported_primary）/ rank2=突发 UA（competing_within_cooling_side） |
| **L4 视觉（元数据级）** | `03_figures/visual_analysis.json` + `03_figures/plot_manifest.json` | non-VLM 环境如实降级：4 张 PNG（时序总览/两张叠加/同步热图）存在但未作像素级读取，仅引用 co-onset idx160、lag0 r=0.58 等元数据对齐事实，无视觉过度声称 |
| **L5 本体/机理** | `01_ontology/ontology.json` | relationship XMEAS_21→XMEAS_9 特征指纹预言被精确复现；XMV_10→XMEAS_21 inverse 预言经 r=−0.4904 验证；confounders 首条=冷却水入口温度（未测量） |
| L5 | `02_processed/physics_check.json` | P1 控制器补偿 / P2 能量平衡（consistent_with_cw_inlet_temp_rise）/ P3 回路定域 / P4 压力网络响应 / P5 闭环阶跃指纹——5 项校核无一矛盾 |
| **审计/质量门** | `05_review/judge_feedback.json` | 总分 97、verdict=pass（iteration 1/3）；8 项 spot-check 全部 verified、questionable=0；13+ 项载荷数字独立复算吻合 |
| 审计 | `05_review/optimizer_preflight.md` | 独立复算 20/20 项与诊断引用一致；8 项幻觉红线全部通过；PREFLIGHT_VERDICT: NO_FATAL — PREFLIGHT_PASS（MINOR 1 / INFO 5，R-1/R-2/R-3 已由本报告采纳） |

### 7.2 关键工件与数字对照（Judge/审计双重复算锚点）

| 主张 | 数值 | 复算 |
|---|---|---|
| XMEAS_9 idx160 尖峰 | z=+10.47（σ=0.0192，Δ=0.2007°C） | 审计+Judge 一致 |
| XMV_10 时代位移 | +6.82σ，Welch t=−79.4 | 一致 |
| 流量代理比 | 1.0912（+9.1%） | 一致 |
| P2 系数 | 0.0836（=1−1/1.0912，代数精确） | 一致 |
| T21 守恒 | −0.07σ（Δ=−0.0087°C） | 一致 |
| XMEAS_22 定域 | −0.080σ | 一致 |
| 分层相关 | 0.6374 / 0.5796 / 池化 0.2315 | 一致 |
| 置信加和 | H1 79=18+22+16+14+9；总体 63≤65 | 加和复算通过 |

## 8. 推理链与详细推导（Reasoning Chain）

`04_diagnostics/reasoning_chain.json` R1-R8 八段完整（各含 inputs/reasoning/outputs/alternatives/uncertainty/falsification），要点：

- **R1 数据表征**：真实时间轴 + 单连续工况 + 无质检列 → 时序因果排序 + 时代分层合法，双驱动 View B 判 not_applicable（confidence 98）。
- **R2 统计发现**：核心不对称——唯一大幅位移在操纵变量；三联征同拍独立复算成立（96）；XMEAS_2 全局榜首判为背景耦合伪线索（95）。
- **R3 验证过滤**：池化 r=0.2315 判 SERIOUS 的复核=过渡带稀释（clean_r=0.5091 三角验证），采用分层值并披露；XMEAS_9→XMEAS_7 任何 CCF 滞后解释剔除（94/95）。
- **R4 假设生成**：移交预案 H1-H5 之外**增补 H6**——排除 ramp 形态 ≠ 排除 UA 退化；缺失 H6 会把"子机制不可分"误呈现为 DETERMINED（92）。"控制器设定值阶跃"备择被指纹论证排除（设定值变更应使 T9 驻留新值，实测严格回位 120.4°C），列入 H1 falsification 运行记录核对项。
- **R5 判别力评估**：[H1,H6] 判别统计量不可计算 → INDISTINGUISHABLE → CS1 + ceiling 65（90）；以 P2 方向性信号强行排除 H6 或降级 NEEDS_DATA 两种不诚实形态均被论证否决。
- **R6 排除验证**：H2/H3/H4/H5 四项定量排除、置信均 95≥90、各附 revival_condition（95）。
- **R7 结论定案**：机理级本可 DETERMINED，子机制级不可分 → 诚实形态 COMPETING_SET（90）。
- **R8 不确定度界定**：认识论缺口（Tin/UA/设定值通道/视觉/RAG）主导天花板，属**可消除型**——补测后机理级与子机制级可一并升格（92/94）。

判别矩阵 9 对全覆盖（`04_diagnostics/diagnosis.json` discriminability_matrix）：[H1,H6]=INDISTINGUISHABLE，[H1,H3]/[H6,H3]=DISCRIMINABLE（形态判别），其余 6 对=ONE_SIDE_EXCLUDED。无未评估对。

## 9. 建议与后续

**P0（立即，判别性补测——一项测量即可消解竞争集）**

1. **在反应器冷却水入口加装温度在线测量**（判别力最高、改动最小）。判读：若 idx160 时刻 Tin 阶跃升高且幅值满足 ΔTin=0.0836×(T21−Tin)_old → H6 出局，升格 DETERMINED(H1)；若 Tin 恒定（|ΔTin| 低于仪表噪声带）而 XMV_10 台阶仍存在 → H1 被证伪，H6 成为唯一存活假设。
2. **持续监视 XMV_10 台阶**：当前 44.9%（z≈+6.8）维持即扰动未消除；若台阶之上叠加 >0.5σ/24h 缓慢爬升，则叠加性渐进结垢需重新纳入（H3 revival_condition）。

**P1（一周内）**

3. **调阅温度控制器（XMEAS_9 回路）设定值/整定参数变更记录**，核对 2020-01-01 08:00 前后是否有变更——若有，冷却侧扰动假设失效，改判 OPERATION 类（H1 falsification 条件之二）。
4. **加装换热器传热率/UA 在线监测**（旁路温差、双测点 LMTD 估算）：UA 恒定 → H6 直接证伪；UA 阶跃 → H1 证伪。同时检查全厂冷却水总管温度与其它回路阀位（XMV_9 等）是否同拍——若同拍则"回路定域"前提被推翻。
5. **核对 XMEAS_9 与 XMV_10 是否共用多点温度变送器/机柜通道**及该通道 2020-01-01 08:00 前后检修记录（H5 revival_condition）。

**P2（计划性）**

6. 停车时检查反应器冷却器换热面结垢/堵塞/泄漏痕迹——发现突发性物理证据则 H6 物理证实。
7. 过渡带（onset 后 1-2 采样）高采样率复采为辅助判别手段（信息增益不及直接加 Tin 测点，列为辅助）。
8. 在具备视觉能力的环境中由 vlm-visual-analyzer 补读 4 张 PNG（当前 non-VLM 缺位已披露，统计证据自足）。

**证伪条件汇总**（完整版见 `04_diagnostics/diagnosis.json` 各假设 falsification_conditions）：整个诊断的证伪条件是 timestamp 系统性错位或 XMV_10 通道语义映射错误——此时本体映射崩塌、全部假设重建。

## 10. 方法与局限性

**方法**：时代分层统计（基线/异常稳态两代对比，过渡带剔除）、滞后补偿 CCF（lag0..20）、稳态过滤、Spearman 分歧复核、leave-one-out 杠杆与离群敏感度检验、Simpson/趋势混杂扫描、P1-P5 物理约束校核、竞争假设协议（≥3 备择 + 每箭头链路验证 + 判别力矩阵 + 逐项 revival/falsification 条件）。

**局限性与方法论披露（含 Judge 三项 warning 的落实）**：

1. **池化相关稀释（Judge warning 3，`02_processed/validate_report.json` overall_validity=MODERATE_CONCERNS）**：serious_count=1，即 XMV_10~XMEAS_9 池化 r=0.2315 判 outlier_driven=SERIOUS（剔除 189 过渡带点后 clean_r=0.5091，+119.9%）——系过渡带瞬变稀释而非离群伪造；本报告全部相关引用以时代分层值 0.58-0.64 为准，池化值仅作披露。batch.applicable=false（无批次 ID 列），批级分析不适用。
2. **P2 单位精度（Judge warning 1）**：`02_processed/physics_check.json` P2 的"~1.4 sigma"表述量纲不精确；本报告统一改以 ΔT21=0.0836×(T21−Tin)_old（°C）表达且幅值标注不可标定（NOT_APPLICABLE: (T21−Tin)_old unmeasured）。建议后续运行在 P2 输出处直接标注 UNCALIBRATABLE。
3. **窗口序列口径（Judge warning 2 / 审计 I-01、I-02）**：本报告统一引用 13 窗口 3h z 序列（含末窗 6.80），与 first-vs-last=−0.087σ 自洽；纯稳态窗（idx220-959，12 窗）口径下为 −0.17σ——两口径均非单调，ramp 排除结论不变。physics_check P5 首窗（6.72）实际覆盖过渡带 idx160-219，属标注口径瑕疵，不影响 P5 结论。
4. **z 归一化口径（审计 I-03）**：anomaly_report 的 max_deviation_sigma=10.06 为全数据集归一化，与基线 μ/σ 复算口径的 +10.47 同源不矛盾；本报告统一采用基线复算口径。
5. **视觉证据缺位**：non-VLM 环境，4 张 PNG 未作像素级读取（visual_analysis.json read_status=READ_FAILED），时间同步性主张仅有统计证明——若后续 VLM 补读与统计矛盾，以 CCF 定量为准。
6. **认识论缺口**：Tin/UA/(T21−Tin)_old/控制器设定值通道均未测量（H1 与 H6 保持竞争集的直接原因）；RAG 知识引擎不可达（3s 探测超时，rag_validated=false），物理关系按 parameter_to_physics + 化工原理降级推理，无任何 CONTRADICTED 本体声明被用作证据。
7. **偶然极限**：3min 采样对 onset 亚采样动态混叠（XMEAS_9 尖峰仅单样本）；48h 窗口仅含 2 个昼夜周期，环境慢周期混杂检验力有限（阶跃形态与周期形态不符，残余风险低但非零）；onset 前 idx153 有 XMEAS_9 单样本 z=+3.17，属 160 样本高斯基线期望极值，与 +10.47 有量级差异。
8. **模型假设**：稳态能量平衡近似（适用于后稳态段）、XMV_10 阀位-流量线性（流量比 1.0912 为代理）、PI 控制器积分补偿语义。窄带受控工况下误差为二阶。

---

*报告基于工件：`04_diagnostics/{diagnosis,evidence,confidence,reasoning_chain}.json`、`05_review/{judge_feedback.json,optimizer_preflight.md}`、`02_processed/*`、`01_ontology/ontology.json`、`03_figures/{plot_manifest.json,visual_analysis.json}`。质量门：Judge 97/pass（首轮）；报告前物理审计 PREFLIGHT_PASS（FATAL 0 / MAJOR 0 / MINOR 1 / INFO 5），R-1/R-2/R-3 建议已全部采纳。*
