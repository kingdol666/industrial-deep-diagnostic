# optimizer.md — Step 7 FINAL 物理审计（FINAL_AUDIT）

- **审计人**：Auditor Sun（report-reviewer，物理审计）· 独立审计，非橡皮图章
- **运行目录**：`D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171639066_bench_tep_d04_reactor_cooling_step`
- **审计对象**：`report.md`（225 行 / 10 节）+ `run_summary.json`，交叉追溯 `04_diagnostics/{diagnosis,evidence,confidence,reasoning_chain}.json`、`05_review/judge_feedback.json`、`05_review/optimizer_preflight.md`、`02_processed/*`
- **独立复算**：`06_scripts/audit_final_verify.py`（venv python，输入仅 `00_input/data.csv`，960 行 × 52 通道），控制台留档 `06_scripts/audit_final_verify_console.txt`
- **场景**：TE 过程反应器冷却阶跃扰动（bench_tep_d04）；报告结论形态 **COMPETING_SET**（CS1：H1 入口水温阶跃 rank1 / H6 突发 UA 阶跃 rank2，INDISTINGUISHABLE，ceiling 65，总体 63）

---

## 一、审计总览

| 项 | 结果 |
|---|---|
| FATAL | **0** |
| MAJOR | **0** |
| MINOR | 0 |
| INFO | 2（口径级备注，见第五节） |
| 载荷数字独立复算 | **20/20 项与报告引用一致**（三联征 z、时代位移、Welch t、流量比、P2 系数、H6 存活域、窗口序列、压力网络、置信加和、次级慢漂） |
| 报告-工件一致性 | report.md 对 `04_diagnostics/*.json`、`05_review/*`、`02_processed/*` 的全部引述逐项核对无篡改；primary_finding 引文与 diagnosis.json 逐字一致 |
| 结论形态保真 | **COMPETING_SET 无静默升格**：报告标题/执行摘要/§5.1/§6.1 与 run_summary.json 一致保持 CS1 两成员结构、天花板 65、总体 63 |
| Preflight 建议落实 | R-1（H6 定量界，仅排序锐化）/ R-2（口径标注）/ R-3（次级慢漂披露）**全部采纳且未越界**（见第三节） |
| 质量门复核 | Judge 97/pass（首轮 1/3，blocking_issues=[]）与 optimizer_preflight.md PREFLIGHT_PASS（FATAL 0/MAJOR 0/MINOR 1/INFO 5）引述属实 |

**审计总览结论**：报告忠实承接了诊断工件的诚实三态输出——机理级判定（冷却侧输入阶跃 + XMV_10 闭环补偿）证据链完整，冷却侧子机制分叉（H1 vs H6）如实保持不可判别竞争集；全部载荷数字可从原始数据精确复现；无证据链断裂、无结论形态改变、无过度声称。**可发布。**

## 二、统计核验（独立复算汇总，输入仅 `00_input/data.csv`）

| # | 主张（报告位置） | 审计复算 | 判定 |
|---|---|---|---|
| 1 | XMEAS_9 idx160 尖峰 z=+10.47（基线 120.399±0.019，Δ=0.2007°C）（§1/§4.2/§7.2） | μ=120.3993，σ=0.0192，z=+10.47 | 一致 |
| 2 | XMEAS_21 idx160 +2.01 → idx161 −2.34（§4.2） | +2.01 / −2.34（基线 94.6003±0.1229） | 一致 |
| 3 | XMV_10 idx160 跳升 z=+11.10（40.694→47.248→43.966）（§1/§4.2） | +11.10 | 一致 |
| 4 | XMV_10 时代位移 41.1424%→44.8967%（+6.82σ，Welch t=−79.4）（§1/§4.1） | +6.823σ，t=−79.4 | 一致 |
| 5 | 流量代理比 1.0912（+9.1%）（§6.2） | 1.0912 | 一致 |
| 6 | P2 系数 0.0836 = 1−1/1.0912；恒等式 1.0912×0.9164=1.0000（§6.2） | 0.0836；恒等式成立 | 一致 |
| 7 | T21 守恒 −0.07σ（Δ=−0.0087°C）（§1/§6.2/§7.2） | −0.071σ（−0.0087°C） | 一致 |
| 8 | 后稳态位移 +0.09σ / −0.07σ / +6.82σ（三联征）（§4.2） | +0.085 / −0.071 / +6.823σ | 一致 |
| 9 | XMEAS_22 定域 −0.08σ（§1/§6.2） | −0.080σ | 一致 |
| 10 | 13 窗口 z 序列 [6.72,…,6.80] 跨度 0.41σ 非单调；first-vs-last −0.087σ；纯稳态 12 窗口径 −0.17σ（§4.6/§10.3） | 序列逐值吻合（6.716…6.804），跨度 0.408σ；−0.088σ / −0.173σ（末位舍入差 ≤0.001，见 INFO-1） | 一致（舍入容差内） |
| 11 | 末 60 样本均值 44.918%（z=+6.86）（§1/§4.6） | 44.918%，z=+6.86 | 一致 |
| 12 | co-onset 唯一性：idx158-166 |z|≥3 仅 XMV_10 与 XMEAS_9（§4.2 引审计 P-01） | 复算命中集 = {XMEAS_9, XMV_10}，无第四通道 | 一致 |
| 13 | 压力网络 XMEAS_13 +2.05@161 / XMEAS_16 +2.09@161 / XMEAS_7 +2.30@162（§4.5/§5.2-H5） | 逐位一致 | 一致 |
| 14 | H6 存活域：(T21−Tin)_old ≤ 1.47°C、Tin_old ≥ 93.1°C、T9−T21 ≈ 25.8°C（§6.3） | 0.1229/0.0836=1.47°C；94.6003−1.47=93.1°C；120.3993−94.6003=25.8°C | 一致 |
| 15 | 次级慢漂 XMEAS_18 −1.19σ / XMV_9 −1.07σ / XMEAS_19 −1.01σ（§4.1/§6.4，R-3 采纳） | −1.19 / −1.07 / −1.01σ | 一致 |
| 16 | onset 前基线极值 idx153 z=+3.17（§10.7） | +3.17 | 一致 |
| 17 | 置信加和：H1 79=18+22+16+14+9 → 65（ceiling −14）；H6 71=18+18+16+14+5 → 65（−6）；总体 63 ≤ 65（§5.1/§6.4/§7.2） | 加和复算通过；63 ≤ 65 合规 | 一致 |
| 18 | 排除置信：H2/H3/H4/H5 均 95 ≥ 90 且各附 revival_condition（§5.2） | 与 diagnosis.json eliminated[] 逐项一致 | 一致 |
| 19 | Judge 97/pass、8 项 spot-check 全 verified（§7.1） | 与 judge_feedback.json 一致 | 一致 |
| 20 | Preflight PREFLIGHT_PASS（FATAL 0/MAJOR 0/MINOR 1/INFO 5）（§7.1/尾注） | 与 optimizer_preflight.md 第七节一致 | 一致 |

**统计核验结论**：报告引用的全部载荷数字（含 run_summary.json key_findings 五项）均可从 `00_input/data.csv` 独立复现，零偏差（除第 10 项末位舍入差）；无数字孤儿、无证据等级虚标、无置信超限。

## 三、物理核验

**1. R-1 落实方式核验（本审计核心关注点）**：报告 §6.3「H6 存活域定量界（采纳审计 R-1/M-01 —— 锐化 H1 排序，不破坏竞争集）」逐句核对：

- 定量界本身复算精确成立（0.1229/0.0836=1.47°C ⇒ Tin_old ≥ 93.1°C，vs 过程侧 25.8°C）；
- 报告明文「该上界**仅强化 H1 的 rank-1 排序依据，不构成对 H6 的排除**——Tin 未测量、协议要求排除置信 ≥90，故 COMPETING_SET 结构、天花板 65 与总体 63 **维持不变**」——与 preflight R-1 的原始意图（"不据此排除 H6、不改 COMPETING_SET"）逐点吻合；
- H6 在 §5.1 对比表中以独立行保留（机制类 WEAR、rank 2、置信 65），§5.2 H3 排除条目明文「突发 UA 阶跃（H6）作为独立子案保留在竞争集内」；
- 判别力表述未升格：§6.4/§5.1 均保留 H1=H6=65（INDISTINGUISHABLE）而非 H1>H6 的置信差。

**裁定：R-1 被正确用作排序锐化，未破坏诚实分叉/天花板结构，无静默升格。** "physically implausible"（极端不物理的换热面配置）的措辞与"不作排除依据"的限定同句出现，不构成结论改变。

**2. 机理链守恒式追溯**：主链每箭头挂接守恒式（Q=ṁcw·cp·(T21−Tin)；mCp·dT9/dt=(−ΔH)r−Q_cool；Q=UA·LMTD；PV=nRT），与 `01_ontology/ontology.json` relationships 一致；无纯统计因果裸奔。幅值匹配：+9.1% 流量与 ΔTin=0.0836×(T21−Tin)_old 在 Q 守恒下精确互锁（恒等式复算成立），无 >10× 失配。时标匹配：单采样冲高→idx163 起台阶，与一阶热系统+PI 反馈阶跃响应形态一致。

**3. 单位精度处置（Judge warning 1 / R-2）**：报告 §6.2 明确弃用 physics_check P2 的 "~1.4 sigma" 量纲不精确表述，统一以 ΔT21=0.0836×(T21−Tin)_old（°C）表达并标注幅值 NOT_APPLICABLE: UNCALIBRATABLE；核查 diagnosis/confidence 工件确认该 sigma 数未被传播。处置正确。

**4. 证据等级与披露完整性**：链首 Tin 为 L5 机理推断（DATA_LINK_MISSING 已在 §6.4 披露）；XMEAS_9→XMEAS_7 CORRELATION_ABSENT 以 onset 时序替代（已披露）；H6 UA→T21 DIRECTION_MISMATCH 仅作排序依据（已披露）；non-VLM 视觉缺位如实降级为元数据级、无像素级虚构（§5.3/§10.5）；池化 r=0.2315 SERIOUS 判定以分层值消化并保留披露（§3/§4.3/§10.1）。inference_gaps 三项无静默删除。

**5. 证伪与可行动性**：P0（加装入口水温测点，附双向判读规则）/P1（设定值记录、UA 监测、共因通道核查）/P2（停车检查）与各假设 falsification_conditions/revival_condition 对应完整——optimizer 输出具备可直接执行的确认计划。

## 四、矛盾扫描

1. **报告 vs 诊断工件**：primary_finding 引文、判别矩阵（9 对全覆盖，[H1,H6]=INDISTINGUISHABLE）、排除置信、置信加和、adjustment_log——逐项一致，无篡改、无选择性省略。
2. **报告 vs run_summary.json**：diagnosis_type/confidence{overall 63, ceiling 65, H1 65, H6 65}/judge 97/pass/preflight PASS/key_findings 五项——全部一致。
3. **双口径数字**：max_deviation_sigma 10.06（全数据集归一）vs 10.47（基线复算）已在 §4.2 注明同源不矛盾；窗口序列 13 窗/12 窗两口径（−0.087 vs −0.17σ）已在 §4.6/§10.3 并列——均非矛盾，属口径披露。
4. **"唯一 >1.19σ"表述**：XMEAS_18 恰为 −1.19σ（未超过），表述精确；且 §4.1/§6.4 已点名三条 ≤1.2σ 慢漂，无"除 XMV_10 外全静止"的过度简化。
5. **INFO-1（不阻塞）**：13 窗口 first-vs-last 报告引 −0.087σ，审计按 3 位小数窗口值复算为 −0.088σ——末位舍入差，非单调/ramp 排除结论不受影响；建议后续运行统一保留 3 位小数原值。
6. **INFO-2（不阻塞）**：§1 "独立复算 20/20 项一致"指 Judge+preflight 双重复算锚点；本次 FINAL 审计再次独立复算 20 项亦全部一致，表述成立。
7. **未发现**：任何"报告数字与工件/原始数据不符""COMPETING_SET 被静默升格""排除置信不足 90 却写成排除""隐藏假设冒充事实""循环论证""不可证伪结论"。

## 五、判定

- 报告忠实反映 COMPETING_SET 判定（CS1：H1 rank1 / H6 rank2、ceiling 65、总体 63），无静默升格、无证据链断裂；
- 20/20 载荷数字独立复算一致（输入仅 `00_input/data.csv`）；
- preflight R-1 被正确落实为排序锐化（H6 存活域 ≤1.47°C / Tin_old ≥93.1°C vs 过程侧 25.8°C 复算成立），竞争集结构与天花板未被破坏；
- Judge 97/pass 与 PREFLIGHT_PASS 引述属实；R-2/R-3 已采纳；两条 INFO 均为口径级备注，不构成阻塞项；
- 无证据链断裂或结论形态改变缺陷，不触发 D→J→R→R 修复回路。

**FINAL_AUDIT_VERDICT: ENDORSED**（FATAL=0，MAJOR=0，MINOR=0，INFO=2）——报告可放行进入 Step 8（HTML 构建）。
