#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
dp_semantic_analysis.py — data-processor Phase 3 custom semantic verification (Engineer Zhang).

Ontology-guided discrepancy analysis for bench_tep_d07_header_pressure.
Ontology Stage-1 flagged (01_ontology/ontology.json _build_notes.stage1_signals):
  XMV_4 post-shift +25.1% with XMEAS_4 flow unchanged -> Stream-4 header supply signature (CONTRADICTED);
  XMV_9 / XMEAS_19 mild secondary shifts as confounder candidates.

This script verifies, from 00_input/data.csv only (all numbers recomputable):
  1. Era split at index 160 (user_context: sample 161 1-based) + per-signal era steady-state test.
  2. Valve-gain physics Q = Cv*f(x)*sqrt(dP/rho): era flow-per-%-valve gain and implied header dP ratio
     for XMV_4/XMEAS_4 (test) vs XMV_1..3/XMEAS_1..3, XMV_6/XMEAS_10, XMV_7/XMEAS_14, XMV_9/XMEAS_19 (controls).
  3. Era-stratified (production-state filtered) lag-compensated CCF for every pair cited
     (anti-spurious v6.4/v6.5: full-series CCF is contaminated by the common step at 160).
  4. Leave-one-out leverage for XMV_9~XMEAS_19 (the correlation cited as intact).
  5. XMV_9 valve saturation headroom check.
Outputs: 02_processed/semantic_verification.json (+ stdout digest).
"""
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

RUN_DIR = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
DATA = RUN_DIR / "00_input" / "data.csv"
OUT = RUN_DIR / "02_processed" / "semantic_verification.json"

ERA_SPLIT = 160  # 0-based index of first anomalous sample (user_context sample 161, 1-based)

df = pd.read_csv(DATA)
df["timestamp"] = pd.to_datetime(df["timestamp"])
ts = df["timestamp"]
interval_s = float(ts.diff().dropna().dt.total_seconds().median())

cols = [c for c in df.columns if c != "timestamp"]
pre = df.iloc[:ERA_SPLIT]
post = df.iloc[ERA_SPLIT:]
n_pre, n_post = len(pre), len(post)

# ---------- 1. per-signal era steady-state test ----------
signal_rows = {}
for c in cols:
    x_pre = pre[c].to_numpy(dtype=float)
    x_post = post[c].to_numpy(dtype=float)
    m_pre, s_pre = float(np.mean(x_pre)), float(np.std(x_pre, ddof=1))
    m_post, s_post = float(np.mean(x_post)), float(np.std(x_post, ddof=1))
    z = (m_post - m_pre) / s_pre if s_pre > 0 else float("nan")
    shift_pct = (m_post - m_pre) / abs(m_pre) * 100 if m_pre != 0 else float("nan")
    signal_rows[c] = {
        "pre_mean": round(m_pre, 4),
        "pre_std": round(s_pre, 4),
        "post_mean": round(m_post, 4),
        "post_std": round(s_post, 4),
        "rel_shift_pct": round(shift_pct, 2),
        "post_mean_z_vs_pre": round(z, 2),
        "steady_within_pre_3sigma": bool(abs(z) <= 3),
        "variance_ratio_post_over_pre": round(s_post / s_pre, 2) if s_pre > 0 else None,
    }

# ---------- 2. valve-gain physics (Q = Cv*f(x)*sqrt(dP/rho)) ----------
# gain = mean(flow)/mean(valve%) per era; at constant flow, x2/x1 = sqrt(dP1/dP2)
pairs = [
    ("XMV_4", "XMEAS_4", "stream4_AC_header"),
    ("XMV_1", "XMEAS_1", "stream1_A_feed"),
    ("XMV_2", "XMEAS_2", "stream2_D_feed"),
    ("XMV_3", "XMEAS_3", "stream3_E_feed"),
    ("XMV_6", "XMEAS_10", "purge_line"),
    ("XMV_7", "XMEAS_14", "separator_underflow"),
    ("XMV_9", "XMEAS_19", "steam_header"),
]
gain_rows = {}
for valve, flow, tag in pairs:
    g_pre = float(pre[flow].mean()) / float(pre[valve].mean())
    g_post = float(post[flow].mean()) / float(post[valve].mean())
    flow_pre, flow_post = float(pre[flow].mean()), float(post[flow].mean())
    valve_pre, valve_post = float(pre[valve].mean()), float(post[valve].mean())
    dp_ratio = (g_post / g_pre) ** 2  # derived: dP_post/dP_pre at Cv,f,rho constant
    gain_rows[f"{valve}~{flow}"] = {
        "role": tag,
        "flow_pre": round(flow_pre, 4),
        "flow_post": round(flow_post, 4),
        "flow_rel_shift_pct": round((flow_post - flow_pre) / abs(flow_pre) * 100, 2),
        "valve_pre": round(valve_pre, 4),
        "valve_post": round(valve_post, 4),
        "valve_rel_shift_pct": round((valve_post - valve_pre) / abs(valve_pre) * 100, 2),
        "gain_pre_flow_per_pct": round(g_pre, 6),
        "gain_post_flow_per_pct": round(g_post, 6),
        "gain_change_pct": round((g_post - g_pre) / abs(g_pre) * 100, 2),
        "implied_dP_ratio_post_over_pre": round(dp_ratio, 4),
        "derived": True,
    }

# ---------- 3. era-stratified lag-compensated CCF ----------
def ccf(x: np.ndarray, y: np.ndarray, max_lag: int = 10):
    """r(lag) = corr(x_t, y_{t+lag}); lag>0 => x (first arg) LEADS y by lag samples."""
    out = []
    for lag in range(-max_lag, max_lag + 1):
        if lag >= 0:
            a, b = x[: len(x) - lag], y[lag:]
        else:
            a, b = x[-lag:], y[: len(y) + lag]
        a = a - a.mean()
        b = b - b.mean()
        denom = math.sqrt(float((a * a).sum()) * float((b * b).sum()))
        r = float((a * b).sum() / denom) if denom > 0 else 0.0
        out.append({"lag": lag, "r": round(r, 4)})
    return out

def ccf_digest(x, y, max_lag=10):
    cc = ccf(x, y, max_lag)
    n = min(len(x), len(y))
    sig = 2.0 / math.sqrt(n)
    best = max(cc, key=lambda d: abs(d["r"]))
    r0 = next(d for d in cc if d["lag"] == 0)["r"]
    return {
        "r_at_lag0": r0,
        "best_lag": best["lag"],
        "best_r": best["r"],
        "significance_threshold_abs_r": round(sig, 4),
        "best_lag_significant": bool(abs(best["r"]) > sig),
        "lag0_vs_best_improvement_pct": round((abs(best["r"]) - abs(r0)) / max(abs(r0), 1e-9) * 100, 1),
        "ccf_curve": cc,
    }

ccf_pairs = [("XMV_4", "XMEAS_4"), ("XMV_9", "XMEAS_19"), ("XMV_1", "XMEAS_1"),
             ("XMV_6", "XMEAS_10"), ("XMV_3", "XMEAS_3")]
era_ccf = {}
for v, f in ccf_pairs:
    era_ccf[f"{v}~{f}"] = {
        "era1_idx0_159": ccf_digest(pre[v].to_numpy(dtype=float), pre[f].to_numpy(dtype=float)),
        "era2_idx160_959": ccf_digest(post[v].to_numpy(dtype=float), post[f].to_numpy(dtype=float)),
    }

# Pearson r era-stratified for the cited pairs (Simpson / stratification check)
def pearson(x, y):
    return round(float(np.corrcoef(x, y)[0, 1]), 4)

strat = {}
for v, f in [("XMV_4", "XMEAS_4"), ("XMV_9", "XMEAS_19")]:
    strat[f"{v}~{f}"] = {
        "pearson_full_series": pearson(df[v].to_numpy(dtype=float), df[f].to_numpy(dtype=float)),
        "pearson_era1": pearson(pre[v].to_numpy(dtype=float), pre[f].to_numpy(dtype=float)),
        "pearson_era2": pearson(post[v].to_numpy(dtype=float), post[f].to_numpy(dtype=float)),
    }

# ---------- 4. leave-one-out leverage for XMV_9~XMEAS_19 ----------
x = df["XMV_9"].to_numpy(dtype=float)
y = df["XMEAS_19"].to_numpy(dtype=float)
full_r = float(np.corrcoef(x, y)[0, 1])
max_shift = 0.0
for i in range(len(x)):
    mask = np.ones(len(x), dtype=bool)
    mask[i] = False
    r_i = float(np.corrcoef(x[mask], y[mask])[0, 1])
    max_shift = max(max_shift, abs(full_r - r_i))
loo = {"pair": "XMV_9~XMEAS_19", "full_r": round(full_r, 4),
       "max_abs_shift_on_single_point_removal": round(max_shift, 4),
       "leveraged": bool(max_shift > 0.05), "n": int(len(x))}

# ---------- 5. XMV_9 saturation headroom ----------
xmv9_post = post["XMV_9"].to_numpy(dtype=float)
sat = {
    "xmv9_max_post161": round(float(xmv9_post.max()), 2),
    "xmv9_min_post161": round(float(xmv9_post.min()), 2),
    "n_samples_post161_ge_99pct": int((xmv9_post >= 99).sum()),
    "pct_samples_post161_ge_99pct": round(float((xmv9_post >= 99).mean() * 100), 2),
    "xmv4_max_post161": round(float(post["XMV_4"].to_numpy(dtype=float).max()), 2),
    "xmv4_n_post161_ge_99pct": int((post["XMV_4"].to_numpy(dtype=float) >= 99).sum()),
}

# ---------- assemble ----------
result = {
    "generated_at": pd.Timestamp.utcnow().isoformat(),
    "author": "data-processor (Engineer Zhang persona) — 06_scripts/dp_semantic_analysis.py",
    "inputs": {"data": "00_input/data.csv", "rows": int(len(df)), "era_split_index": ERA_SPLIT,
               "sampling_interval_seconds": interval_s,
               "era1_rows": int(n_pre), "era2_rows": int(n_post)},
    "era_signal_stats": signal_rows,
    "valve_gain_physics": gain_rows,
    "era_stratified_ccf": era_ccf,
    "era_stratified_pearson": strat,
    "leave_one_out_leverage": loo,
    "valve_saturation": sat,
}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")

# stdout digest
print("== steady flags (|z|>3): ")
for c, r in signal_rows.items():
    if not r["steady_within_pre_3sigma"]:
        print(f"  {c}: shift {r['rel_shift_pct']}% z={r['post_mean_z_vs_pre']} var_ratio={r['variance_ratio_post_over_pre']}")
print("\n== valve gain / implied dP:")
for k, r in gain_rows.items():
    print(f"  {k} [{r['role']}]: valve {r['valve_rel_shift_pct']}% flow {r['flow_rel_shift_pct']}% gain {r['gain_change_pct']}% dP_ratio={r['implied_dP_ratio_post_over_pre']}")
print("\n== era CCF:")
for k, r in era_ccf.items():
    for era, d in r.items():
        print(f"  {k} {era}: r0={d['r_at_lag0']} best lag={d['best_lag']} r={d['best_r']} sig={d['best_lag_significant']}")
print("\n== stratified pearson:", json.dumps(strat))
print("== LOO:", json.dumps(loo))
print("== saturation:", json.dumps(sat))
print("\nwrote", OUT)
