#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""dp_decoupling_figure.py — targeted diagnostic figure (Engineer Zhang).
Question answered: does the XMV_4 valve/flow pair decouple at sample 161 (header supply
signature), while XMV_9/XMEAS_19 stay coupled? Every trace plots raw data rows verbatim.
Output: 03_figures/fig_valve_flow_decoupling.png
"""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

RUN_DIR = Path(__file__).resolve().parents[1]
df = pd.read_csv(RUN_DIR / "00_input" / "data.csv")
SPLIT = 160
x = np.arange(len(df))

fig, axes = plt.subplots(2, 2, figsize=(15, 9))
fig.suptitle("Stream-4 Header Valve/Flow Decoupling vs Steam Valve/Flow Control (TE process, 3-min sampling)", fontsize=14)

# (a) XMV_4 vs XMEAS_4 twin axis
ax = axes[0, 0]
ax.plot(x, df["XMV_4"], color="tab:red", lw=1.2, label="XMV_4 valve (%)")
ax.set_ylabel("XMV_4 (%)", color="tab:red", fontsize=12)
ax2 = ax.twinx()
ax2.plot(x, df["XMEAS_4"], color="tab:blue", lw=1.2, label="XMEAS_4 flow (kscmh)")
ax2.set_ylabel("XMEAS_4 (kscmh)", color="tab:blue", fontsize=12)
ax.axvline(SPLIT, color="k", ls="--", lw=1.5)
ax.text(SPLIT + 5, ax.get_ylim()[0] + 1, "sample 161 (8 h)", fontsize=11)
ax.set_title("(a) A/C feed valve opens +25.1% while flow held at setpoint", fontsize=12)

# (b) XMV_9 vs XMEAS_19 twin axis
ax = axes[0, 1]
ax.plot(x, df["XMV_9"], color="tab:red", lw=1.0, label="XMV_9 valve (%)")
ax.set_ylabel("XMV_9 (%)", color="tab:red", fontsize=12)
ax2 = ax.twinx()
ax2.plot(x, df["XMEAS_19"], color="tab:blue", lw=1.0, label="XMEAS_19 steam (kg/h)")
ax2.set_ylabel("XMEAS_19 (kg/h)", color="tab:blue", fontsize=12)
ax.axvline(SPLIT, color="k", ls="--", lw=1.5)
ax.set_title("(b) Steam valve/flow stay coupled (transient swings, mean +3.9%)", fontsize=12)

# (c) era-stratified scatter
ax = axes[1, 0]
ax.scatter(df["XMV_4"][:SPLIT], df["XMEAS_4"][:SPLIT], s=14, alpha=0.7, color="tab:green", label="era1 idx0-159")
ax.scatter(df["XMV_4"][SPLIT:], df["XMEAS_4"][SPLIT:], s=8, alpha=0.5, color="tab:purple", label="era2 idx160-959")
ax.set_xlabel("XMV_4 (%)", fontsize=12)
ax.set_ylabel("XMEAS_4 (kscmh)", fontsize=12)
ax.legend(fontsize=11)
ax.set_title("(c) Same flow, two valve regimes: r1=-0.24 vs r2=+0.80", fontsize=12)

# (d) rolling valve gain XMEAS_4/XMV_4 normalized to era1 mean
ax = axes[1, 1]
gain = (df["XMEAS_4"] / df["XMV_4"]).rolling(20, center=True).mean()
gain = gain / gain[:SPLIT].mean() * 100.0
ax.plot(x, gain, color="tab:orange", lw=1.4)
ax.axvline(SPLIT, color="k", ls="--", lw=1.5)
ax.axhline(100, color="gray", lw=0.8)
ax.set_xlabel("sample index", fontsize=12)
ax.set_ylabel("gain, % of era1 baseline", fontsize=12)
ax.set_title("(d) Flow-per-%-valve gain drops ~20% (implied dP ratio 0.638, derived)", fontsize=12)

for ax in axes.flat:
    ax.grid(alpha=0.3)
    ax.tick_params(labelsize=11)

plt.tight_layout(rect=(0, 0, 1, 0.96))
out = RUN_DIR / "03_figures" / "fig_valve_flow_decoupling.png"
plt.savefig(out, dpi=140)
plt.close()
print("wrote", out, out.stat().st_size, "bytes")
