# -*- coding: utf-8 -*-
"""context-builder Phase 4/5 — build 01_ontology/ontology.json (+ schema copy,
00_input/clarification_needed.json) for the TE header-pressure benchmark run.

Data-truth mandate: normal_range / observed_data_behavior / behavior_match are
computed from 06_scripts/context_builder_probe_stats.json (pre = rows 1-160,
post = rows 161-960 of 00_input/data.csv). TE process semantics come from the
standard Tennessee Eastman numbering (Downs & Vogel 1993) — engineering domain
knowledge — and are marked knowledge_source=auto_inferred / inferred=true where
not directly readable from the data.
"""
import json
import shutil

RUN_DIR = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171639214_bench_tep_d07_header_pressure"
SKILL = "D:/codes/myskills/industrial-deep-diagnostic/.claude/skills/industrial-ontology-builder"
STATS = RUN_DIR + "/06_scripts/context_builder_probe_stats.json"

with open(STATS, encoding="utf-8") as f:
    S = json.load(f)

COL = S["columns"]

def rng(col):
    e = COL[col]["pre"]
    return [e["min"], e["max"]]

def observed(col):
    p, q = COL[col]["pre"], COL[col]["post"]
    shift = COL[col]["mean_shift_pct"]
    outside = COL[col]["post_mean_outside_pre_3sigma"]
    verdict = "后段均值位于前段±3σ之外" if outside else "后段均值位于前段±3σ之内"
    return ("前160样本均值 %.4g±%.2g（范围 %.4g~%.4g）；后800样本均值 %.4g（相对偏移 %+.2f%%），%s。"
            % (p["mean"], p["std"], p["min"], p["max"], q["mean"], shift, verdict))

def sig(n, name_cn, name_en, unit, meaning, stage, equip, law, expect,
        conf="KNOWN", extra=None):
    col = "XMEAS_%d" % n
    d = {
        "name": "%s (XMEAS_%d, %s)" % (name_cn, n, name_en),
        "column": col,
        "unit": unit,
        "role": "predictor",
        "physical_meaning": meaning,
        "physical_meaning_confidence": conf,
        "auto_inferred": True,
        "inference_basis": "TE标准编号语义(Downs & Vogel 1993)+数据值域核对(前160样本min/max)+过程描述(user_context)",
        "control_type": "measurement",
        "normal_range": rng(col),
        "stage_ref": stage,
        "equipment_ref": equip,
        "governing_law": law,
        "expected_data_behavior": expect,
        "observed_data_behavior": observed(col),
        "behavior_match": "CONSISTENT",
        "knowledge_source": "auto_inferred",
    }
    if extra:
        d.update(extra)
    return d

CONT_LAW = "调节阀流量方程 Q = Cv·f(x)·√(ΔP/ρ)"
STEADY_NOTE = "流量/压力被闭环控制保持在设定值附近小幅波动；扰动下应观察到操纵量补偿"
COMP_LAW = "摩尔分数守恒：各流股组分摩尔分数由反应/分离/循环网络的质量平衡决定"
COMP_EXPECT = "组成分析仪每3个采样(9分钟)更新一次（数据验证的保持特性），围绕稳态摩尔分数小幅波动"

XMEAS_DEFS = [
    (1, "A组分新鲜进料流量", "A Feed, Stream 1", "kscmh",
     "流股1新鲜A组分体积(标准)流量——反应原料A的供给", "S1_feed", "EQ_HEADER_S4_INDIVIDUAL",
     CONT_LAW, STEADY_NOTE + "；A进料损失时应观察到阀位/流量的异常补偿"),
    (2, "D组分新鲜进料流量", "D Feed, Stream 2", "kscmh",
     "流股2新鲜D组分流量——反应原料D供给", "S1_feed", "EQ_FEED_PIPES", CONT_LAW, STEADY_NOTE),
    (3, "E组分新鲜进料流量", "E Feed, Stream 3", "kscmh",
     "流股3新鲜E组分流量——反应原料E供给", "S1_feed", "EQ_FEED_PIPES", CONT_LAW, STEADY_NOTE),
    (4, "A+C混合进料流量", "A and C Feed, Stream 4", "kscmh",
     "流股4(A与C混合进料汇管)总流量——A、C经同一汇管供给，是C组分进入系统的唯一通道",
     "S1_feed", "EQ_HEADER_S4", CONT_LAW,
     "流量被控制器保持在设定值附近；若汇管上游供给压力下降，阀XMV_4必须大幅开大才能维持同一流量（阀增益∝√ΔP）"),
    (5, "循环流量", "Recycle Flow, Stream 8", "10^2 kscmh (数据尺度)",
     "流股8气相循环流量（分离器→压缩机→反应器）——维持循环回路载气量", "S6_recycle", "EQ_COMPRESSOR",
     "压缩机特性 H=H0-kQ² 与回路物料平衡；本数据集该值约为TE标准稳态值(2690.5)的1/100（尺度推断）",
     STEADY_NOTE),
    (6, "反应器进料总量", "Reactor Feed Rate, Stream 6", "10^2 kscmh (数据尺度)",
     "流股6进入反应器的总进料流量（新鲜进料+循环+汽提塔回流气合并）", "S2_reactor", "EQ_REACTOR",
     "物料平衡：F6 = F1+F2+F3+F4 + F8(气相部分)；尺度推断同XMEAS_5", STEADY_NOTE),
    (7, "反应器压力", "Reactor Pressure", "kPa(g)",
     "反应器气相压力——由循环压缩机回流阀/弛放阀联合维持", "S2_reactor", "EQ_REACTOR",
     "气相物料平衡 dN/dt = F_in - F_out - r·V；PV=nRT", "受控在2705 kPa附近；弛放/循环阀动作时应缓慢恢复"),
    (8, "反应器液位", "Reactor Level", "%",
     "反应器持液量（液位%满量程）", "S2_reactor", "EQ_REACTOR",
     "液相质量平衡：A·dL/dt = F_liq,in - F_liq,out", "受控在75%附近小幅波动"),
    (9, "反应器温度", "Reactor Temperature", "°C",
     "反应器物料温度——放热反应(A+C→D, A+E→F)与冷却移热的平衡点", "S2_reactor", "EQ_REACTOR",
     "能量平衡：mCp·dT/dt = Σ(-ΔH_rxn)·r·V - U·A·(T-T_cw)", "温度控制器经XMV_10维持在120.4°C，标准差应很小"),
    (10, "弛放气流量", "Purge Rate, Stream 9", "kscmh",
     "流股9弛放(排放)流量——排走惰性组分F并维持回路压力", "S7_purge", "EQ_HEADER_PURGE",
     CONT_LAW, "受控小幅波动；弛放阀开度增大→流量增大→反应器压力缓慢下降"),
    (11, "产品分离器温度", "Product Sep Temperature", "°C",
     "气液分离器/冷凝器罐温度——冷凝深度决定气液相平衡分割", "S3_condense", "EQ_CONDENSER",
     "VLE(Raoult)+能量平衡：冷凝水量随冷却量增大而增大", "受控在80.1°C附近"),
    (12, "产品分离器液位", "Product Sep Level", "%",
     "分离器罐液位（凝液持液量）", "S4_separate", "EQ_SEPARATOR",
     "液相质量平衡", "受控在50%附近"),
    (13, "产品分离器压力", "Product Sep Pressure", "kPa(g)",
     "分离器气相压力——循环回路下游压力节点", "S4_separate", "EQ_SEPARATOR",
     "气相平衡：P=Σx_i·P_sat,i(T)（VLE）；与反应器压力经压缩机耦合", "受控在2634 kPa附近"),
    (14, "分离器底流量", "Product Sep Underflow, Stream 10", "m3/h",
     "流股10分离器罐底部液体抽出流量（去汽提塔）", "S4_separate", "EQ_SEPARATOR",
     CONT_LAW, "受控在25.2 m³/h附近"),
    (15, "汽提塔液位", "Stripper Level", "%",
     "汽提塔塔釜液位", "S5_strip", "EQ_STRIPPER", "液相质量平衡", "受控在50%附近"),
    (16, "汽提塔压力", "Stripper Pressure", "kPa(g)",
     "汽提塔操作压力（塔顶气相去冷凝器/分离器）", "S5_strip", "EQ_STRIPPER",
     "气相平衡：塔压随进料气量与塔温变化", "受控在3102 kPa附近"),
    (17, "汽提塔底出料流量", "Stripper Underflow, Stream 11", "m3/h",
     "流股11塔底产品流量——装置最终产品输出（产量代理指标）", "S5_strip", "EQ_STRIPPER",
     CONT_LAW, "受控在22.9 m³/h附近"),
    (18, "汽提塔温度", "Stripper Temperature", "°C",
     "汽提塔塔釜温度——直接反映汽提蒸汽供热与轻组分脱除程度", "S5_strip", "EQ_STRIPPER",
     "能量平衡+VLE：蒸汽量↑→塔温↑、轻组分残留↓", "受控在65.8°C附近；蒸汽流量变化应有同向滞后响应"),
    (19, "汽提蒸汽流量", "Stripper Steam Flow", "kg/h",
     "进入汽提塔的汽提蒸汽质量流量（来自厂区蒸汽汇管）", "S5_strip", "EQ_HEADER_STEAM",
     "蒸汽阀流量方程 Q = Cv·f(x)·√(ΔP_header/ρ_s)——流量同时受阀位与汇管压力影响",
     "受控在235 kg/h附近；注意汇管压力未测量，阀位与流量的增益可能漂移"),
    (20, "压缩机功耗", "Compressor Work", "kW",
     "循环压缩机轴功率", "S6_recycle", "EQ_COMPRESSOR",
     "离心压缩：W = ṁ·ΔH(多变过程)；近似 W ∝ 循环流量×压比", "跟随循环流量/压力小幅波动，约341 kW"),
    (21, "反应器冷却水出口温度", "Reactor CW Outlet Temp", "°C",
     "反应器冷却水回路出口温度——反映反应放热带走量", "S2_reactor", "EQ_CW_REACTOR",
     "热平衡：Q_rxn = ṁ_cw·Cp·(T_out - T_in)", "受控在94.6°C附近"),
    (22, "分离器冷却水出口温度", "Separator CW Outlet Temp", "°C",
     "冷凝器冷却水回路出口温度——反映冷凝负荷", "S3_condense", "EQ_CW_COND",
     "热平衡：Q_cond = ṁ_cw·Cp·(T_out - T_in)", "受控在77.3°C附近"),
]

def comp_sig(n, stream, stream_cn, note, conf):
    col = "XMEAS_%d" % n
    return {
        "name": "流股%d %s 组分摩尔分数 (XMEAS_%d)" % (stream, stream_cn, n),
        "column": col,
        "unit": "mol%",
        "role": "predictor",
        "physical_meaning": "流股%d(%s)在线分析仪第%d通道组分摩尔分数。%s" % (stream, stream_cn, n, note),
        "physical_meaning_confidence": conf,
        "auto_inferred": True,
        "inference_basis": "流股归属按TE标准编号(23-28→流股6反应器进料,29-34→流股9弛放气,35-41→流股11塔底产品)；单通道组分身份依据TE稳态值匹配推断(XMEAS_23=32.188精确匹配流股6组分A)，无法从数据唯一分辨的身份已在含义中注明",
        "control_type": "measurement",
        "normal_range": rng(col),
        "stage_ref": {"6": "S2_reactor", "9": "S7_purge", "11": "S5_strip"}[str(stream)],
        "equipment_ref": {"6": "EQ_REACTOR", "9": "EQ_HEADER_PURGE", "11": "EQ_STRIPPER"}[str(stream)],
        "governing_law": COMP_LAW,
        "expected_data_behavior": COMP_EXPECT,
        "observed_data_behavior": observed(col),
        "behavior_match": "CONSISTENT",
        "knowledge_source": "auto_inferred",
    }

XMEAS = []
for d in XMEAS_DEFS:
    XMEAS.append(sig(*d))

s6_notes = [
    ("组分A（32.188与TE流股6稳态值精确匹配）", "INFERRED"),
    ("组分身份待定（数值8.89匹配TE稳态值集合中D通道，推断为D）", "INFERRED"),
    ("组分身份待定（数值26.38匹配TE稳态值集合中E通道，推断为E）", "INFERRED"),
    ("组分身份待定（无精确稳态匹配）", "UNKNOWN"),
    ("组分身份待定（数值18.78≈TE流股6组分B稳态值18.76，推断为B）", "INFERRED"),
    ("组分身份待定（数值1.66，低含量组分，可能为F惰性组分）", "UNKNOWN"),
]
s9_notes = [
    ("组分身份待定（主组分之一~33%）", "UNKNOWN"),
    ("组分身份待定（~13.8%）", "UNKNOWN"),
    ("组分身份待定（主组分之一~24%）", "UNKNOWN"),
    ("组分身份待定（低含量~1.3%）", "UNKNOWN"),
    ("组分身份待定（~18.6%）", "UNKNOWN"),
    ("组分身份待定（低含量~2.3%）", "UNKNOWN"),
]
s11_notes = [
    ("轻组分残留之一（~4.8%）", "UNKNOWN"),
    ("轻组分残留之一（~2.3%）", "UNKNOWN"),
    ("痕量组分（~0.018%）", "UNKNOWN"),
    ("低含量组分（~0.84%）", "UNKNOWN"),
    ("痕量组分（~0.099%）", "UNKNOWN"),
    ("主产品组分（~53.7%，推断为G）", "INFERRED"),
    ("主产品组分（~43.8%，推断为H）", "INFERRED"),
]
for i in range(6):
    XMEAS.append(comp_sig(23 + i, 6, "反应器进料", s6_notes[i][0], s6_notes[i][1]))
for i in range(6):
    XMEAS.append(comp_sig(29 + i, 9, "弛放气", s9_notes[i][0], s9_notes[i][1]))
for i in range(7):
    d = comp_sig(35 + i, 11, "塔底产品", s11_notes[i][0], s11_notes[i][1])
    d["role"] = "predictor"
    XMEAS.append(d)

XMEAS_QUALITY = [d for d in XMEAS if d["column"].startswith(("XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_39", "XMEAS_40", "XMEAS_41"))]
XMEAS_PROCESS = [d for d in XMEAS if d not in XMEAS_QUALITY]

XMV_DEFS = [
    (1, "A进料阀", "A Feed Valve", "流股1 A组分进料调节阀——A进料流量控制器(XMEAS_1)的执行器"),
    (2, "D进料阀", "D Feed Valve", "流股2 D组分进料调节阀——D进料流量控制器(XMEAS_2)的执行器"),
    (3, "E进料阀", "E Feed Valve", "流股3 E组分进料调节阀——E进料流量控制器(XMEAS_3)的执行器"),
    (4, "A+C混合进料阀", "A and C Feed Valve", "流股4 A/C混合汇管进料调节阀——流量控制器(XMEAS_4)的执行器；其开度-流量增益∝√(汇管压力-系统压力)，是汇管供给压力异常的敏感指示器"),
    (5, "压缩机回流阀", "Compressor Recycle Valve", "压缩机进出口回流调节阀——开度增大→回流份额增大→净循环流量与反应器压力下降"),
    (6, "弛放阀", "Purge Valve", "弛放气调节阀——开度增大→弛放流量增大→惰性组分F排出加快、回路压力下降"),
    (7, "分离器底流阀", "Sep Underflow Valve", "流股10分离器底部液体抽出调节阀——分离器液位控制执行器"),
    (8, "汽提塔底出料阀", "Stripper Underflow Valve", "流股11塔底产品调节阀——汽提塔液位控制执行器"),
    (9, "汽提蒸汽阀", "Stripper Steam Valve", "汽提蒸汽调节阀——蒸汽流量控制器(XMEAS_19)执行器；流量增益∝√(蒸汽汇管压力-塔压)"),
    (10, "反应器冷却水阀", "Reactor Cooling Water Valve", "反应器冷却水流量调节阀——反应器温度控制器(XMEAS_9)执行器"),
    (11, "冷凝器冷却水阀", "Condenser Cooling Water Valve", "冷凝器冷却水流量调节阀——分离器温度控制器(XMEAS_11)执行器"),
]

XMV = []
for n, cn, en, meaning in XMV_DEFS:
    col = "XMV_%d" % n
    pair = {"1": "XMEAS_1", "2": "XMEAS_2", "3": "XMEAS_3", "4": "XMEAS_4",
            "7": "XMEAS_14", "8": "XMEAS_17", "9": "XMEAS_19"}.get(str(n))
    d = {
        "name": "%s (XMV_%d, %s)" % (cn, n, en),
        "column": col,
        "unit": "%",
        "role": "control",
        "physical_meaning": meaning + "。数据值为阀位百分比(0-100)。",
        "physical_meaning_confidence": "INFERRED",
        "auto_inferred": True,
        "inference_basis": "TE标准操纵变量编号语义(Downs & Vogel 1993)；单位%为数据推断（值域0-100且变化平滑，符合阀位%表示），编号-物理功能对应关系为领域知识",
        "control_type": "output",
        "controlled_by": "对应回路的流量/液位/温度/压力控制器（TE基础控制结构，推断配对" + (pair or "见relationships") + "）",
        "equipment_ref": {"1": "EQ_HEADER_S4_INDIVIDUAL", "2": "EQ_FEED_PIPES", "3": "EQ_FEED_PIPES",
                          "4": "EQ_HEADER_S4", "5": "EQ_COMPRESSOR", "6": "EQ_HEADER_PURGE",
                          "7": "EQ_SEPARATOR", "8": "EQ_STRIPPER", "9": "EQ_HEADER_STEAM",
                          "10": "EQ_CW_REACTOR", "11": "EQ_CW_COND"}[str(n)],
        "stage_ref": {"1": "S1_feed", "2": "S1_feed", "3": "S1_feed", "4": "S1_feed",
                      "5": "S6_recycle", "6": "S7_purge", "7": "S4_separate", "8": "S5_strip",
                      "9": "S5_strip", "10": "S2_reactor", "11": "S3_condense"}[str(n)],
        "governing_law": CONT_LAW,
        "expected_data_behavior": "闭环控制下围绕稳态阀位小幅波动（稳态阀位：XMV_1≈63%, XMV_2≈54%, XMV_3≈24.6%, XMV_4≈61%, XMV_5≈22%, XMV_6≈40%, XMV_7≈38%, XMV_8≈47%, XMV_9≈48.5%, XMV_10≈41%, XMV_11≈18%）",
        "observed_data_behavior": observed(col),
        "behavior_match": "CONSISTENT",
        "knowledge_source": "auto_inferred",
    }
    if n == 4:
        d["behavior_match"] = "CONTRADICTED"
        d["discrepancy_signal"] = ("样本161起阀位均值从61.2%升至76.6%(+25.1%)，而被控流量XMEAS_4保持不变(±0.03%)。"
                                   "由Q=Cv·f(x)·√(ΔP/ρ)，流量不变而阀位大幅上移意味着阀前后压差ΔP显著下降——"
                                   "指向流股4上游(A/C汇管)供给压力下降的特征签名；属操纵变量侧异常信号，供数据-processor/diagnostician深挖")
    XMV.append(d)

ontology = {
    "scene": {
        "name": "bench_tep_d07_header_pressure — Tennessee Eastman 连续化工过程（反应器-冷凝器-气液分离器-汽提塔+循环压缩机，蒸汽/进料汇管相关异常）",
        "process_type": "连续化工过程 (continuous chemical process, Tennessee Eastman)",
        "production_goal": "由A、C、D、E新鲜进料在反应器内经放热反应(A+C→D、A+E→F)生成产品G/H，经冷凝-分离-汽提得到合格流股11产品（G+H≈97 mol%），循环未反应物料，弛放惰性组分F",
        "equipment": [
            {"id": "EQ_REACTOR", "name": "反应器", "type": "连续搅拌釜反应器 (CSTR)",
             "function": "气液相放热反应：A+C→D、A+E→F；带冷却水盘管移热（XMV_10调节）"},
            {"id": "EQ_CONDENSER", "name": "冷凝器", "type": "水冷冷凝器",
             "function": "部分冷凝反应器出口气体，冷凝液与未凝气进入分离器（XMV_11调节冷水量）"},
            {"id": "EQ_SEPARATOR", "name": "气液分离器", "type": "闪蒸罐",
             "function": "气液相分离：液相经流股10去汽提塔，气相经流股8回压缩机循环"},
            {"id": "EQ_STRIPPER", "name": "汽提塔", "type": "蒸汽汽提塔",
             "function": "用蒸汽汽提凝液中的轻组分(A/B/C)，塔顶气返回循环回路，塔底流股11为产品"},
            {"id": "EQ_COMPRESSOR", "name": "循环压缩机", "type": "离心压缩机",
             "function": "将分离器气相增压后送回反应器；带回流阀(XMV_5)调节回路压力"},
            {"id": "EQ_HEADER_S4", "name": "流股4 A/C混合进料汇管", "type": "进料汇管（多流股共用母管）",
             "function": "向装置供给A+C混合原料；汇管压力未测量。推断节点（标准TE扰动场景中的汇管压力异常对象）",
             "manufacturer": "NOT_APPLICABLE"},
            {"id": "EQ_HEADER_S4_INDIVIDUAL", "name": "流股1-3独立进料管线", "type": "进料管线",
             "function": "A(流股1)、D(流股2)、E(流股3)独立新鲜进料", "manufacturer": "NOT_APPLICABLE"},
            {"id": "EQ_HEADER_STEAM", "name": "蒸汽汇管（母管）", "type": "公用工程蒸汽母管",
             "function": "向汽提塔供给汽提蒸汽（XMV_9调节）；汇管压力未测量。推断节点",
             "manufacturer": "NOT_APPLICABLE"},
            {"id": "EQ_HEADER_PURGE", "name": "弛放气管线", "type": "排放管线",
             "function": "排放循环回路惰性组分F，维持回路压力与组成", "manufacturer": "NOT_APPLICABLE"},
            {"id": "EQ_CW_REACTOR", "name": "反应器冷却水回路", "type": "冷却水系统",
             "function": "移除反应热（XMEAS_21为出口温度指示）", "manufacturer": "NOT_APPLICABLE"},
            {"id": "EQ_CW_COND", "name": "冷凝器冷却水回路", "type": "冷却水系统",
             "function": "提供冷凝负荷（XMEAS_22为出口温度指示）", "manufacturer": "NOT_APPLICABLE"},
            {"id": "EQ_FEED_PIPES", "name": "D/E进料管线", "type": "进料管线",
             "function": "D(流股2)、E(流股3)新鲜进料", "manufacturer": "NOT_APPLICABLE"},
        ],
        "stages": [
            {"id": "S1_feed", "name": "新鲜进料输送（流股1-4）", "sequence": 1,
             "typical_duration": "连续（稳态），阀-流量回路响应秒~分钟级",
             "key_physics": "调节阀流量方程 Q = Cv·f(x)·√(ΔP/ρ)：流量由阀位与阀前后压差共同决定；汇管供给压力下降时阀增益∝√ΔP下降",
             "key_parameters": ["XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4", "XMV_1", "XMV_2", "XMV_3", "XMV_4"]},
            {"id": "S2_reactor", "name": "放热反应（反应器）", "sequence": 2,
             "typical_duration": "连续；温度回路时间常数分钟级",
             "key_physics": "Arrhenius动力学 r=k0·exp(-Ea/RT)·C_A^a·C_E^e；能量平衡 mCp·dT/dt=Σ(-ΔH)·r·V-UA·LMTD；气相平衡 PV=nRT",
             "key_parameters": ["XMEAS_6", "XMEAS_7", "XMEAS_8", "XMEAS_9", "XMEAS_21", "XMV_10", "XMEAS_23", "XMEAS_24", "XMEAS_25", "XMEAS_26", "XMEAS_27", "XMEAS_28"]},
            {"id": "S3_condense", "name": "部分冷凝（冷凝器）", "sequence": 3,
             "typical_duration": "连续",
             "key_physics": "VLE(Raoult定律)：冷凝深度由温度/压力与冷却量决定；Q=ṁ_cw·Cp·ΔT",
             "key_parameters": ["XMEAS_11", "XMEAS_22", "XMV_11"]},
            {"id": "S4_separate", "name": "气液分离（分离器）", "sequence": 4,
             "typical_duration": "连续",
             "key_physics": "闪蒸平衡+液位物料平衡；分离器压力为循环回路下游压力节点",
             "key_parameters": ["XMEAS_12", "XMEAS_13", "XMEAS_14", "XMV_7"]},
            {"id": "S5_strip", "name": "蒸汽汽提（汽提塔）+产品输出", "sequence": 5,
             "typical_duration": "连续",
             "key_physics": "汽提蒸汽质量/热量平衡：蒸汽量↑→塔温↑→产品中轻组分残留↓；塔底液位由XMV_8控制；蒸汽流量增益∝√(蒸汽汇管压力-塔压)",
             "key_parameters": ["XMEAS_15", "XMEAS_16", "XMEAS_17", "XMEAS_18", "XMEAS_19", "XMV_8", "XMV_9", "XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_39", "XMEAS_40", "XMEAS_41"]},
            {"id": "S6_recycle", "name": "循环压缩（压缩机+循环回路）", "sequence": 6,
             "typical_duration": "连续",
             "key_physics": "离心压缩 W=ṁ·ΔH；回流阀开度决定回流份额与回路压力",
             "key_parameters": ["XMEAS_5", "XMEAS_20", "XMV_5"]},
            {"id": "S7_purge", "name": "弛放排放（惰性组分排出）", "sequence": 7,
             "typical_duration": "连续",
             "key_physics": "气相物料平衡：弛放流量决定惰性组分F积累速率与回路压力",
             "key_parameters": ["XMEAS_10", "XMV_6", "XMEAS_29", "XMEAS_30", "XMEAS_31", "XMEAS_32", "XMEAS_33", "XMEAS_34"]},
        ],
        "objectives": [
            "维持流股11产品质量（G+H为主，轻组分残留受控）与产量（XMEAS_17）",
            "维持反应器压力/温度/液位在设定值（2705 kPa / 120.4°C / 75%）",
            "维持循环回路组成（弛放惰性组分F）与循环经济性",
            "诊断目标：识别样本161起异常工况的根本原因（user_context：第161样本/8h起进入异常）",
        ],
    },
    "signals": {
        "inspection_signals": XMEAS_QUALITY,
        "process_parameters": XMEAS_PROCESS,
        "control_variables": XMV,
        "events": [],
        "metadata_columns": [
            {"name": "时间戳", "column": "timestamp", "role": "timestamp",
             "description": "3分钟等间隔采样，2020-01-01 00:00:00 至 2020-01-02 23:57:00，共960样本"}
        ],
    },
    "parameter_groups": {
        "新鲜进料流量（流股1-4）": ["XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4"],
        "进料调节阀": ["XMV_1", "XMV_2", "XMV_3", "XMV_4"],
        "反应器条件": ["XMEAS_7", "XMEAS_8", "XMEAS_9", "XMEAS_21"],
        "反应器进料组成（流股6）": ["XMEAS_23", "XMEAS_24", "XMEAS_25", "XMEAS_26", "XMEAS_27", "XMEAS_28"],
        "冷凝/分离器条件": ["XMEAS_11", "XMEAS_12", "XMEAS_13", "XMEAS_14", "XMEAS_22"],
        "汽提塔条件": ["XMEAS_15", "XMEAS_16", "XMEAS_17", "XMEAS_18", "XMEAS_19"],
        "汽提塔执行器": ["XMV_8", "XMV_9"],
        "塔底产品组成（流股11，质量信号）": ["XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_39", "XMEAS_40", "XMEAS_41"],
        "弛放气（流股9）": ["XMEAS_10", "XMEAS_29", "XMEAS_30", "XMEAS_31", "XMEAS_32", "XMEAS_33", "XMEAS_34", "XMV_6"],
        "循环/压缩": ["XMEAS_5", "XMEAS_20", "XMV_5"],
        "冷却水公用工程": ["XMV_10", "XMV_11", "XMEAS_21", "XMEAS_22"],
        "时间戳": ["timestamp"],
    },
    "relationships": [
        {"from": "XMV_1", "to": "XMEAS_1", "type": "control", "strength": "strong",
         "mechanism": "A进料阀开度增大→流股1流量增大（流量控制器闭环）",
         "governing_equation": "Q = Cv·f(x)·√(ΔP/ρ)", "predicted_functional_form": "monotonic",
         "time_lag": "<1采样(3min)", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_2", "to": "XMEAS_2", "type": "control", "strength": "strong",
         "mechanism": "D进料阀开度增大→流股2流量增大", "governing_equation": "Q = Cv·f(x)·√(ΔP/ρ)",
         "predicted_functional_form": "monotonic", "time_lag": "<1采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_3", "to": "XMEAS_3", "type": "control", "strength": "strong",
         "mechanism": "E进料阀开度增大→流股3流量增大", "governing_equation": "Q = Cv·f(x)·√(ΔP/ρ)",
         "predicted_functional_form": "monotonic", "time_lag": "<1采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_4", "to": "XMEAS_4", "type": "control", "strength": "strong",
         "mechanism": "A/C汇管进料阀开度增大→流股4流量增大；但阀增益∝√ΔP，ΔP=汇管压力-系统压力。"
                      "本数据观测：样本161起阀位+25.1%而流量不变→推断汇管供给压力显著下降（Stage-1信号）",
         "governing_equation": "Q = Cv·f(x)·√(ΔP_header/ρ)，流量恒定时 x↑⇔ΔP↓",
         "predicted_functional_form": "monotonic", "time_lag": "<1采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested",
         "lag_detection_method": "physics_prior_only", "lag_agreement": "no_physics_prior"},
        {"from": "XMV_4", "to": "XMEAS_23", "to_note": "经反应器进料组成", "type": "causal", "strength": "moderate",
         "mechanism": "汇管供给状况（压力/组成可得性）变化→同流量下A/C配比漂移→流股6反应器进料组成平移→弛放与产品组成依次响应",
         "predicted_functional_form": "delayed_response", "time_lag": "数采样~数十采样（经反应器滞留与循环回路，回路时间常数小时级）",
         "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_5", "to": "XMEAS_5", "type": "causal", "strength": "moderate",
         "mechanism": "压缩机回流阀开度增大→回流份额增大→净循环流量（流股8）下降",
         "governing_equation": "压缩机特性 H=H0-kQ² 与回流分流关系", "predicted_functional_form": "inverse",
         "time_lag": "1~数采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_5", "to": "XMEAS_7", "type": "causal", "strength": "moderate",
         "mechanism": "回流阀开度增大→净循环气量下降→反应器压力下降（回路压力控制手段之一）",
         "predicted_functional_form": "delayed_response", "time_lag": "数采样（回路气相容积时间常数）",
         "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_6", "to": "XMEAS_10", "type": "control", "strength": "strong",
         "mechanism": "弛放阀开度增大→弛放流量增大", "governing_equation": "Q = Cv·f(x)·√(ΔP/ρ)",
         "predicted_functional_form": "monotonic", "time_lag": "<1采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_6", "to": "XMEAS_7", "type": "causal", "strength": "moderate",
         "mechanism": "弛放流量增大→回路气体净排出增大→反应器压力缓慢下降",
         "predicted_functional_form": "delayed_response", "time_lag": "数~数十采样",
         "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_7", "to": "XMEAS_14", "type": "control", "strength": "strong",
         "mechanism": "分离器底流阀开度增大→流股10流量增大", "governing_equation": "Q = Cv·f(x)·√(ΔP/ρ)",
         "predicted_functional_form": "monotonic", "time_lag": "<1采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_7", "to": "XMEAS_12", "type": "causal", "strength": "strong",
         "mechanism": "底流量增大→分离器液位下降（液位控制回路）",
         "predicted_functional_form": "inverse", "time_lag": "1~数采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_8", "to": "XMEAS_17", "type": "control", "strength": "strong",
         "mechanism": "塔底出料阀开度增大→流股11产品流量增大", "governing_equation": "Q = Cv·f(x)·√(ΔP/ρ)",
         "predicted_functional_form": "monotonic", "time_lag": "<1采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_8", "to": "XMEAS_15", "type": "causal", "strength": "strong",
         "mechanism": "塔底出料增大→汽提塔液位下降（液位控制回路）",
         "predicted_functional_form": "inverse", "time_lag": "1~数采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_9", "to": "XMEAS_19", "type": "control", "strength": "strong",
         "mechanism": "蒸汽阀开度增大→汽提蒸汽流量增大；流量增益∝√(蒸汽汇管压力-塔压)，汇管压力未测量，"
                      "样本161后XMV_9均值+3.9%且XMEAS_19同步+1.7%（Stage-1观测，供下游核实增益漂移）",
         "governing_equation": "Q_s = Cv·f(x)·√(ΔP_header_steam/ρ_s)",
         "predicted_functional_form": "monotonic", "time_lag": "<1采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_19", "to": "XMEAS_18", "type": "causal", "strength": "strong",
         "mechanism": "汽提蒸汽量增大→供热与汽提强度增大→塔釜温度升高、产品轻组分残留下降",
         "governing_equation": "能量平衡 Q=m_s·λ_s；VLE轻组分脱除", "predicted_functional_form": "delayed_response",
         "time_lag": "1~数采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_19", "to": "XMEAS_36", "type": "causal", "strength": "moderate",
         "mechanism": "蒸汽量增大→塔底产品轻组分残留（XMEAS_35/36通道）下降",
         "predicted_functional_form": "inverse", "time_lag": "数采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_10", "to": "XMEAS_21", "type": "causal", "strength": "strong",
         "mechanism": "反应器冷却水阀开度增大→冷却水量增大→同传热量下出口温升减小",
         "governing_equation": "Q_rxn = ṁ_cw·Cp·(T_out-T_in)", "predicted_functional_form": "inverse",
         "time_lag": "<1采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_10", "to": "XMEAS_9", "type": "causal", "strength": "strong",
         "mechanism": "冷却水量增大→移热增大→反应器温度下降（温度控制回路主手段）",
         "governing_equation": "mCp·dT/dt = Σ(-ΔH)·r·V - U·A·LMTD", "predicted_functional_form": "delayed_response",
         "time_lag": "1~数采样（热时间常数分钟级）", "inferred": True, "rag_validated": False,
         "data_direction_validated": "untested"},
        {"from": "XMEAS_9", "to": "XMEAS_21", "type": "causal", "strength": "moderate",
         "mechanism": "反应温度升高→反应速率指数增大→放热增大→冷却水出口温度升高（Arrhenius耦合）",
         "governing_equation": "r ∝ exp(-Ea/RT)", "predicted_functional_form": "exponential",
         "time_lag": "<1采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_11", "to": "XMEAS_22", "type": "causal", "strength": "strong",
         "mechanism": "冷凝器冷却水阀开度增大→冷水量增大→同冷凝负荷下出口温升减小",
         "governing_equation": "Q_cond = ṁ_cw·Cp·(T_out-T_in)", "predicted_functional_form": "inverse",
         "time_lag": "<1采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMV_11", "to": "XMEAS_11", "type": "causal", "strength": "strong",
         "mechanism": "冷水量增大→冷凝负荷增大→分离器温度下降（温度控制回路）",
         "predicted_functional_form": "delayed_response", "time_lag": "1~数采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_11", "to": "XMEAS_13", "type": "physical", "strength": "moderate",
         "mechanism": "分离器温度下降→气相冷凝份额增大→罐压下降（VLE平衡）",
         "governing_equation": "P = Σ x_i·P_sat,i(T)（Raoult）", "predicted_functional_form": "monotonic",
         "time_lag": "1~数采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_13", "to": "XMEAS_7", "type": "causal", "strength": "moderate",
         "mechanism": "分离器（压缩机入口侧）压力变化经压缩机传递至反应器——循环回路压力联动",
         "predicted_functional_form": "delayed_response", "time_lag": "数采样", "inferred": True,
         "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_5", "to": "XMEAS_20", "type": "physical", "strength": "strong",
         "mechanism": "循环流量增大→压缩机质量流量增大→轴功率增大",
         "governing_equation": "W = ṁ·ΔH_pol(y·P比)", "predicted_functional_form": "linear",
         "time_lag": "<1采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_4", "to": "XMEAS_6", "type": "physical", "strength": "strong",
         "mechanism": "反应器进料总量=新鲜进料(流股1-4)+循环气+汽提塔回流气的物料平衡",
         "governing_equation": "F6 = F1+F2+F3+F4+F8+塔顶回流气", "predicted_functional_form": "linear",
         "time_lag": "<1采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_16", "to": "XMEAS_18", "type": "physical", "strength": "moderate",
         "mechanism": "汽提塔操作压力升高→塔釜沸点升高（汽压-汽温VLE耦合）",
         "governing_equation": "塔釜泡点 T_bub(P, x)", "predicted_functional_form": "monotonic",
         "time_lag": "1~数采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
        {"from": "XMEAS_7", "to": "XMEAS_10", "type": "physical", "strength": "weak",
         "mechanism": "给定弛放阀位下，弛放流量随反应器-下游压差增大而增大",
         "governing_equation": "Q = Cv·f(x)·√(ΔP/ρ)", "predicted_functional_form": "monotonic",
         "time_lag": "<1采样", "inferred": True, "rag_validated": False, "data_direction_validated": "untested"},
    ],
    "confounders": [
        {"variable": "stream4_header_pressure（流股4 A/C汇管压力，未测量）",
         "why": "调节阀流量方程Q=Cv·f(x)·√(ΔP/ρ)中ΔP取决于汇管压力；汇管压力下降会在被控流量完全不变的情况下迫使XMV_4阀位大幅上移——本数据样本161后XMV_4阀位+25.1%而XMEAS_4不变，正是该混杂机制的直接观测签名。该变量不可控制且未测量，下游需经阀位-流量增益间接推断",
         "controlled": False, "inferred": True},
        {"variable": "steam_header_pressure（蒸汽汇管压力，未测量）",
         "why": "XMV_9→XMEAS_19的流量增益∝√(汇管压力-塔压)；汇管压力波动会被误读为阀位/控制器问题",
         "controlled": False, "inferred": True},
        {"variable": "cw_inlet_temp（冷却水入口温度，未测量）",
         "why": "XMEAS_21/22为冷却水出口温度，入口温度波动会同时改变反应器与冷凝器移热能力，混淆XMV_10/XMV_11阀位效应",
         "controlled": False, "inferred": True},
        {"variable": "stream4_composition（流股4中A/C配比，未测量）",
         "why": "XMEAS_4仅测总流量；A/C配比漂移直接改变反应器进料组成与反应速率，是组成类异常的潜在共同原因",
         "controlled": False, "inferred": True},
        {"variable": "reaction_kinetics/catalyst_activity（反应动力学/催化剂活性，未测量）",
         "why": "反应速率常数漂移会同时改变反应器温度、压力、出口组成与冷却负荷，可能同时驱动多个测量",
         "controlled": False, "inferred": True},
    ],
    "metadata": {
        "units": {
            "XMEAS_1": "kscmh", "XMEAS_2": "kscmh", "XMEAS_3": "kscmh", "XMEAS_4": "kscmh",
            "XMEAS_5": "10^2 kscmh (数据尺度)", "XMEAS_6": "10^2 kscmh (数据尺度)",
            "XMEAS_7": "kPa(g)", "XMEAS_8": "%", "XMEAS_9": "°C", "XMEAS_10": "kscmh",
            "XMEAS_11": "°C", "XMEAS_12": "%", "XMEAS_13": "kPa(g)", "XMEAS_14": "m3/h",
            "XMEAS_15": "%", "XMEAS_16": "kPa(g)", "XMEAS_17": "m3/h", "XMEAS_18": "°C",
            "XMEAS_19": "kg/h", "XMEAS_20": "kW", "XMEAS_21": "°C", "XMEAS_22": "°C",
            "XMEAS_23": "mol%", "XMEAS_24": "mol%", "XMEAS_25": "mol%", "XMEAS_26": "mol%",
            "XMEAS_27": "mol%", "XMEAS_28": "mol%", "XMEAS_29": "mol%", "XMEAS_30": "mol%",
            "XMEAS_31": "mol%", "XMEAS_32": "mol%", "XMEAS_33": "mol%", "XMEAS_34": "mol%",
            "XMEAS_35": "mol%", "XMEAS_36": "mol%", "XMEAS_37": "mol%", "XMEAS_38": "mol%",
            "XMEAS_39": "mol%", "XMEAS_40": "mol%", "XMEAS_41": "mol%",
            "XMV_1": "%", "XMV_2": "%", "XMV_3": "%", "XMV_4": "%", "XMV_5": "%",
            "XMV_6": "%", "XMV_7": "%", "XMV_8": "%", "XMV_9": "%", "XMV_10": "%", "XMV_11": "%",
            "timestamp": "datetime",
        },
        "sampling_rate": "3 min (180 s)，960样本共48小时；组成分析变量(XMEAS_23-41)每3样本(9 min)更新一次（数据验证）",
        "batch_id": None,
        "timezone": None,
        "start_time": "2020-01-01T00:00:00",
        "end_time": "2020-01-02T23:57:00",
        "product_grades": [],
    },
}

# ---- data-truth annotations carried on the ontology root (extra keys allowed by schema) ----
ontology["_build_notes"] = {
    "built_by": "context-builder (Professor Wang persona), Step 2 ontology construction, ONTOLOGY_MODE=full",
    "rag_engine": "unreachable at localhost:8764 (probed once, 3s timeout, curl exit 7) — sanctioned fallback: resources/parameter_to_physics.json pattern library + TE domain knowledge (Downs & Vogel 1993 standard semantics)",
    "data_truth": "normal_range = 前160样本[min,max]；observed_data_behavior = 前160样本均值±σ vs 后800样本均值（见 06_scripts/context_builder_probe_stats.json，全部可由 00_input/data.csv 重算）",
    "anomaly_split": "user_context提供：样本161(8h)起进入异常工况；Stage-1仅做均值±3σ筛查，完整统计分析由data-processor执行",
    "stage1_signals": [
        "XMV_4阀位后段均值+25.1%(61.2→76.6)且XMEAS_4流量不变 — 流股4汇管供给压力下降特征签名（behavior_match=CONTRADICTED）",
        "XMV_9阀位+3.9%、XMEAS_19蒸汽流量+1.7%（均在3σ内，CONSISTENT，趋势供下游核实）",
        "其余受控测量均在设定值附近±3σ内 — 异常被控制回路补偿，操纵变量侧信号是主要线索",
    ],
    "inference_discipline": "所有TE编号语义、回路配对、汇管/公用工程节点均为领域知识推断，已标inferred/auto_inferred=true；组件身份无法唯一分辨的组成通道标为UNKNOWN",
}

with open(RUN_DIR + "/01_ontology/ontology.json", "w", encoding="utf-8") as f:
    json.dump(ontology, f, ensure_ascii=False, indent=1)

shutil.copyfile(SKILL + "/schemas/ontology_schema.json", RUN_DIR + "/01_ontology/schema.json")

clar = {
    "clarification_status": "AUTO_RESOLVED",
    "interaction_mode": "auto",
    "resolved_at": "2026-09-17T17:10:42Z",
    "resolved_by": "context-builder (auto mode, physics_inference_framework L1-L5)",
    "ambiguities": [
        {"id": "A1", "topic": "组成通道(XMEAS_23-41)的组分身份",
         "question": "各组成通道对应哪个化学组分？",
         "resolution": "流股归属按TE标准编号确定（23-28→流股6反应器进料、29-34→流股9弛放气、35-41→流股11塔底产品，置信度高）；单通道组分身份仅XMEAS_23(=32.188，与TE稳态A精确匹配)、XMEAS_24/25/27(与D/E/B稳态值匹配)、XMEAS_40/41(主产品G/H，合计≈97%)可推断，其余标UNKNOWN。下游按'流股组成块'整体使用，不依赖单组分身份",
         "basis_level": "L1(数据稳态值匹配)+L5(TE领域知识)", "auto_inferred": True, "confidence": "medium"},
        {"id": "A2", "topic": "XMEAS_5/XMEAS_6数值尺度",
         "question": "循环流量/反应器进料总量约为TE标准稳态值的1/100，单位是什么？",
         "resolution": "按数据原尺度记录，单位标注'10^2 kscmh (数据尺度)'；不影响相对/相关性分析，绝对质量平衡计算时需×100换算",
         "basis_level": "L1(与TE稳态值2690.5/4127.4对比)", "auto_inferred": True, "confidence": "medium"},
        {"id": "A3", "topic": "XMV_1-11单位与语义",
         "question": "XMV是阀位百分比还是工程单位流量设定值？",
         "resolution": "记录为阀位百分比(%)：值域0-100、变化平滑且与被控测量呈闭环补偿关系；TE操纵变量编号-物理功能对应关系采用标准语义(INFERRED)",
         "basis_level": "L1(值域统计特征)+L5(TE领域知识)", "auto_inferred": True, "confidence": "medium"},
        {"id": "A4", "topic": "控制回路配对（哪个XMV控制哪个XMEAS）",
         "question": "各操纵变量的控制对象？",
         "resolution": "按TE文献通用基础控制结构配对记录于relationships/controlled_by（XMV_10→XMEAS_9, XMV_11→XMEAS_11, XMV_7→XMEAS_12, XMV_8→XMEAS_15, XMV_9→XMEAS_19等），全部标inferred=true，供下游作先验假设而非既定事实",
         "basis_level": "L5(TE基础控制结构文献常识)", "auto_inferred": True, "confidence": "medium"},
        {"id": "A5", "topic": "RAG知识引擎不可用",
         "question": "RAG检索不可用时知识来源如何替代？",
         "resolution": "按协议降级路径执行：跳过Phase 3，采用parameter_to_physics.json模式库+TE过程机理推理（无web检索）；ontology中knowledge_source统一标auto_inferred",
         "basis_level": "协议认可的fallback路径", "auto_inferred": True, "confidence": "high"},
        {"id": "A6", "topic": "汇管压力未测量（流股4 A/C汇管、蒸汽汇管）",
         "question": "关键汇管压力无传感器，如何处理？",
         "resolution": "登记为未测混杂变量(confounders)；下游经'阀位-流量增益'间接证据推断（XMV_4阀位+25%而流量不变即为该类证据）",
         "basis_level": "L1(XMV_4观测)+L5(阀流量方程)", "auto_inferred": True, "confidence": "high"},
        {"id": "A7", "topic": "异常起始样本",
         "question": "异常从哪个样本开始？",
         "resolution": "采用user_context提供值：样本161(第8小时)起进入异常；用于Stage-1前后段划分（pre=1-160, post=161-960）",
         "basis_level": "L2(用户文档)", "auto_inferred": False, "user_provided": True, "confidence": "high"},
    ],
    "notes": "auto模式：未向用户提问；全部歧义按physics_inference_framework L1-L5自动消解并标记。如需人工复核，A1/A2/A4优先。",
}

with open(RUN_DIR + "/00_input/clarification_needed.json", "w", encoding="utf-8") as f:
    json.dump(clar, f, ensure_ascii=False, indent=1)

import os
print("ontology.json bytes:", os.path.getsize(RUN_DIR + "/01_ontology/ontology.json"))
print("signals: process=%d inspection=%d control=%d metadata=%d" % (
    len(ontology["signals"]["process_parameters"]), len(ontology["signals"]["inspection_signals"]),
    len(ontology["signals"]["control_variables"]), len(ontology["signals"]["metadata_columns"])))
print("relationships:", len(ontology["relationships"]), " confounders:", len(ontology["confounders"]))
print("clarification_needed.json bytes:", os.path.getsize(RUN_DIR + "/00_input/clarification_needed.json"))
