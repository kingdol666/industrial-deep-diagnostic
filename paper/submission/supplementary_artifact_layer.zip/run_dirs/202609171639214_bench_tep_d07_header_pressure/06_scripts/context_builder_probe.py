# -*- coding: utf-8 -*-
"""context-builder Stage-1 pre-check probe (Step 2, Phase 0/R2).

Computes per-column pre-change (samples 1-160) and post-change (samples 161+)
statistics from 00_input/data.csv. Mean-shift-only screening — full statistical
analysis is the data-processor's job. All numbers recomputable from raw data.
"""
import csv
import json
import math
import sys

RUN_DIR = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171639214_bench_tep_d07_header_pressure"
DATA = RUN_DIR + "/00_input/data.csv"
OUT = RUN_DIR + "/06_scripts/context_builder_probe_stats.json"
CHANGE_IDX = 161  # 1-based sample where abnormal regime starts (user_context)

cols = []
pre = {}
post = {}
n_rows = 0
first_ts = None
last_ts = None

with open(DATA, newline="", encoding="utf-8") as f:
    r = csv.reader(f)
    header = next(r)
    cols = header[1:]
    for c in cols:
        pre[c] = []
        post[c] = []
    for i, row in enumerate(r, start=1):
        n_rows += 1
        ts = row[0]
        if first_ts is None:
            first_ts = ts
        last_ts = ts
        bucket = pre if i < CHANGE_IDX else post
        for j, c in enumerate(cols, start=1):
            bucket[c].append(float(row[j]))

def stats(arr):
    n = len(arr)
    if n == 0:
        return None
    m = sum(arr) / n
    var = sum((x - m) ** 2 for x in arr) / n if n > 1 else 0.0
    return {
        "n": n,
        "mean": round(m, 6),
        "std": round(math.sqrt(var), 6),
        "min": round(min(arr), 6),
        "max": round(max(arr), 6),
    }

out = {"n_rows": n_rows, "change_idx": CHANGE_IDX, "first_ts": first_ts, "last_ts": last_ts, "columns": {}}
for c in cols:
    sp = stats(pre[c])
    sq = stats(post[c])
    lo, hi = sp["mean"] - 3 * sp["std"], sp["mean"] + 3 * sp["std"]
    shifted = (sq["mean"] < lo) or (sq["mean"] > hi)
    out["columns"][c] = {
        "pre": sp,
        "post": sq,
        "pre_mean_plus_3sigma": [round(lo, 6), round(hi, 6)],
        "post_mean_outside_pre_3sigma": shifted,
        "mean_shift_pct": round((sq["mean"] - sp["mean"]) / abs(sp["mean"]) * 100, 4) if sp["mean"] != 0 else None,
    }

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(out, f, indent=1, ensure_ascii=False)

# compact console summary
for c in cols:
    e = out["columns"][c]
    flag = "SHIFT" if e["post_mean_outside_pre_3sigma"] else "."
    print("%-10s pre=%.5g+-%.2g post=%.5g shift=%+.2f%% %s" % (
        c, e["pre"]["mean"], e["pre"]["std"], e["post"]["mean"],
        e["mean_shift_pct"] or 0.0, flag))
print("rows=%d %s .. %s" % (n_rows, first_ts, last_ts))
