# 工业诊断报告 — TEP流股4 A/C汇管供给能力阶跃下降

- 运行ID：`202609171639214_bench_tep_d07_header_pressure`
- 诊断类型：`DETERMINED`（判定成立，非竞争集）
- 总体置信：78/100（MEDIUM，认知封顶80）
- Judge 质量门：**pass，98/100**（`05_review/judge_feedback.json`，iteration 1/3）
- 报告人：工程师周（技术报告）｜Step 6｜报告语言：中文（枚举与信号名保留英文）

---

## 1. 执行摘要

**结论：自样本161（第8小时）起，流股4 A/C进料汇管的供给能力发生阶跃下降——最可能机制是汇管上游供给压力阶跃下降（阀前后压差降至原值的63.8%，ΔP比0.638，derived）；XMV_4 阀自身 Cv/行程流通能力阶跃损失在遥测上不可区分，作为并列候选一并呈现（见第5、6章）。** 流量控制器为维持 XMEAS_4 设定值（9.3483→9.3458 kscmh，仅-0.03%），被迫将执行阀 XMV_4 开大 **+25.13%（z=12.35，52个数值通道中唯一突破前era±3σ稳态包络的信号）**；阀-流量增益由0.152630降至0.121942（**-20.11%**），经调节阀方程 Q=Cv·f(x)·√(ΔP/ρ) 代数反演得隐含ΔP比0.638（derived）。

**异常烈度重要更正（物理审计 F1 项）**：进料扰动并非以"两次短暂暂态后回归"的轻量方式传导——以前era稳态基线（era1：XMEAS_7 均值2705.49 kPa、σ=3.997）衡量，era2 反应器压力在 **2595.3~2856.8 kPa** 间欠阻尼振荡（前era基准 **-27.6σ~+37.9σ**，摆幅261.5 kPa≈设定值的9.7%，标准差比8.97（对应方差比80.4）），持续至约 idx620 才基本收敛；era 均值不变（+0.01%）是对称振荡的相消伪象，不代表变量稳态。

置信78/100：五因素基础分85（统计22+物理23+时序17+混杂控制15+症状完整8），因根因物理量（汇管压力）无传感器、结论属间接推断而扣减7分。三个备择假设（H2 蒸汽侧/H3 A/C配比/H4 反应器本体）以90/90/95置信排除。**建议优先级：P0 在流股4汇管加装压力变送并现场检验 XMV_4 阀 Cv/行程特性（两者合计可一次性裁决根因）；P1 校验阀位/流量变送、核查上游调压段记录、监视 XMV_4 饱和裕度（当前最大84.59%）；P2 加装 A/C 在线组成分析、复查反应器压力回路振荡整定。**

## 2. 诊断背景与数据概况

- **用户问题**：「诊断本次异常的根本原因」（`00_input/user_context.json`）。
- **过程对象**：Tennessee Eastman（TE）化工过程——反应器-冷凝器-气液分离器-汽提塔+循环压缩机；XMEAS_1..41 过程测量 + XMV_1..11 操纵变量。
- **数据范围**：`00_input/data.csv`，960行×53列（52个数值通道+timestamp），3分钟（180s）中位采样，约48小时窗口；用户告知第161样本（8h）起进入异常工况（`truth_withheld=true`，盲诊模式）。
- **工况结构**：单一连续产品、闭环控制主导（被控变量均值稳态、操纵变量携带扰动签名）；无产品/批次分组列（`02_processed/production_regime_filter.json` per_product_anomaly_analysis.applicable=false），分层对比轴合法采用 **era 二分（idx160）**：era1=idx0-159（稳态基准），era2=idx160-959（异常工况）。era 分界有三重独立依据：user_context 样本161、`02_processed/validate_report.json` 变化点、XMV_4 物理阶跃。
- **数据视图**：`process_only`（`02_processed/data_analysis_conclusion.json` adaptive_decision_audit.data_view_mode）——无独立实验室/检验质量域列，跨域双驱动诊断记 NOT_APPLICABLE。

## 3. 数据质量评估

| 项目 | 结果 | 来源 |
|------|------|------|
| 完整性 | 960行×53列，零缺失、零重复 | `00_input/input_inspection.json` |
| 时间序有效性 | time_sorted=true（timestamp列，960行无重复） | `02_processed/validate_report.json` anti_spurious.sorting_validation |
| 稳态占比 | steady_state_ratio=**0.9031（总体口径**；era2分项稳态占比未单独计算，引用时保持该限定） | `02_processed/production_regime_filter.json` |
| 清洗审计 | raw→cleaned 逐格比对 **0个单元格被修改**（清洗为空操作，完整性未受影响）；`data_cleaning_provenance` 键存在但 cleaning_integrity 未记录（缺口已登记 data_gaps） | `02_processed/data_analysis_conclusion.json`、物理审计复核 |
| 离群敏感性 | XMEAS_4~XMEAS_21 相关 full_r=-0.8337→clean_r=-0.4044（去157点，r变化51.5%，SERIOUS）——**判定离群驱动，已降级，本诊断全程未引用** | `02_processed/validate_report.json` anti_spurious.outlier_sensitivity |
| 反虚假基线口径 | 工件顶层计数为 outlier_sensitivity=10、leave_one_out_leverage=54、spearman_divergence=24、time_trend_confounding=0、simpson_paradox=0、overall_validity=SERIOUS_CONCERNS；诊断工件引用的「outlier_driven_correlations=1、fatal_issues=0」为 **SERIOUS级子集口径**（物理审计 F4 项，此处按顶层键名一并披露） | `02_processed/validate_report.json` |
| 本体信号计数更正 | 52个信号条目=**51 CONSISTENT + 1 CONTRADICTED（XMV_4）**；timestamp 无 behavior_match 字段（此前「53个信号/44个CONSISTENT」的括注口径有误，物理审计 F3/Judge warning 已更正；44 为 process_parameters(34)+control_variables CONSISTENT(10) 的子集计数） | `01_ontology/ontology.json`（judge独立清点复核） |
| 测量口径提示 | XMV_9 最大阀位指示100.16%超物理上限——应表述为「位置指示≥99%（17样本，2.12%，max 100.16，饱和边缘）」，不作为精确物理行程引用（物理审计 F5 项） | `00_input/data.csv`（审计重算） |

## 4. 统计分析发现

本章为报告主体（非附录）。全部关键数值经 judge 以 venv python 对 `00_input/data.csv` 独立重算逐位复现（`05_review/judge_feedback.json` spot_check：12项采样全部验证通过），并经物理审计（`05_review/optimizer_preflight.md`）二次重算确认。

### 4.1 唯一执行器签名

era 分层稳态包络检验（52通道）：**XMV_4 是唯一 steady_within_pre_3sigma=false 的信号**——era1 均值61.2484±1.2463% → era2 均值76.6413%（**+25.13%，post_mean_z_vs_pre=12.35**；era2 全程76.64±2.43%，max 84.59%，无饱和样本）。其余51通道全部在±3σ内（|z|≤0.89）。扰动签名出现在**操纵变量**而非被控变量——这是闭环主导过程「上游供给能力受损」的教科书式入口（`02_processed/semantic_verification.json` era_signal_stats）。

### 4.2 恒流量与增益反演（判别核心）

- 被控流量恒定：XMEAS_4 era均值 9.3483→9.3458 kscmh（**-0.03%**，稳态包络内）。
- 阀-流量增益：0.152630→0.121942 kscmh/%（**-20.11%**）；由 g∝√ΔP 得隐含 **ΔP比0.6383**（derived，=(0.121942/0.152630)²），即阀前后压差降至原值约63.8%（损失约36%）。
- 物理含义：Q=Cv·f(x)·√(ΔP/ρ) 中 Q 恒定、Cv/ρ 不变时，阀位+25.13%在代数上必然对应ΔP下降——方向、量级（PLAUSIBLE）、时序三要素与本体预期逐字命中（`02_processed/semantic_verification.json` valve_gain_physics；`01_ontology/ontology.json`）。

### 4.3 对照组排他与蒸汽侧次要应力

7对阀-流量增益对照：XMV_1 +0.21%、XMV_2 +0.11%、XMV_3 -0.22%、XMV_6 +0.16%、XMV_7 +1.14%（≤±1.2%）——**排除全厂公用工程共性漂移与仪表链共模故障**。蒸汽对 XMV_9 增益-2.1%（隐含ΔP比0.9584）、XMV_9 +3.92%（z=0.89）、XMEAS_19 +1.74%（z=0.49）均在±3σ内——蒸汽侧存在**量级小一个数量级**的同向轻度应力（真实但为次要共存事件，非根因）。蒸汽耦合完整且非杠杆驱动：era分层CCF r=0.980/0.990（lag 0/1），留一检验最大偏移0.0001。

### 4.4 时序先后与 era 分层 CCF

- **PRECURSOR 时序**（`02_processed/physics_check.json` anomaly_onset_coincidence）：对 XMEAS_4 首段异常区间[160,166]，XMV_4 为 PRECURSOR（effect **4.988**，窗口均值61.79→68.63），XMEAS_4 自身 CONCURRENT（effect -14.512，9.40→8.42）；对 XMEAS_7 两个异常区间[168,175]/[205,230]，XMV_4 均为 PRECURSOR（effect 2.098 / -1.931），弛放阀 XMV_6 亦为 PRECURSOR（3.596，补偿动作）。
- **era 分层滞后补偿 CCF**（`02_processed/time_lag_analysis.json`）：XMV_4~XMEAS_4 由 era1 的稳态微调模式（r=-0.2429，lag0）切换为 era2 的对抗扰动模式（lag0 r=0.8036；lag1 补偿后 r=0.8481；审计重算 lag1=0.8498，差0.0017属对齐口径微差，不实质）——相关模式的 regime 切换本身即扰动开始的佐证。**全序列 r=0.28 及大滞后CCF峰（lag14/20）判为 idx160 阶跃混合伪迹，禁用**。
- 时间列前提成立：time_sorted=true、180s中位采样；采样分辨率内的阀-流先后（同在idx160越限）已在局限中声明。

### 4.5 阀-流对齐图核心证据

诊断专项图由 data-processor 以 `06_scripts/dp_decoupling_figure.py`（输入 cleaned_data.csv + ontology）构建，对照展示 XMV_4 阀位阶跃与 XMEAS_4 流量平坦的解耦，以及蒸汽对耦合保持的对照；含分层散点与20样本滚动阀增益曲线（增益降约20%，隐含ΔP比0.638，derived）。

![流股4汇管阀-流量解耦对照](03_figures/fig_valve_flow_decoupling.png)

![关键变量时序总览](03_figures/fig_temporal_overview.png)

![单产品全参数z-score时间对齐叠加](03_figures/fig_vlm_temporal_overlay_single_product.png)

![全局z-score归一叠加](03_figures/fig_vlm_temporal_overlay.png)

![跨参数同步性热图](03_figures/fig_vlm_synchronization.png)

**视觉证据披露（非VLM环境）**：`03_figures/visual_analysis.json` 记录 observation_mode=skeleton_pre_vlm，全部图表 read_status=READ_FAILED——本运行未进行任何图像级目视解读，上述图形证据为**元数据级**（图设计目的+生成脚本溯源+统计交叉引用），时序先后结论完全由统计链（4.4节）承载。若后续 VLM 可用，应优先回读 CRITICAL 级时序叠加图复核（Judge warning 移交事项）。

### 4.6 异常烈度更正：全序列 z 口径 vs 前era稳态基线（物理审计 F1 项，约束本报告叙事）

`02_processed/anomaly_report.json` 对 XMEAS_4/XMEAS_7 的 max_deviation_sigma 与异常区间采用**全序列（era1+era2混合）均值/标准差**作基线，系统性低估异常烈度3~9倍。物理审计以正确的前era稳态基线重算（`05_review/optimizer_preflight.md` S9/S10/F1），本报告一律采用前era口径并更正相关叙事：

| 信号 | 全序列混合口径（anomaly_report，弃用） | **前era稳态基线口径（本报告采用）** |
|------|------|------|
| XMEAS_7 反应器压力 | max\|z\|=4.61，仅[168,175]（3.38σ）与[205,230]两个暂态区间 | era2 压力在 **2595.3~2856.8 kPa** 间欠阻尼振荡（前era基准2705.49 kPa、σ=3.997下 **-27.6σ~+37.9σ**），摆幅261.5 kPa≈设定值9.7%；含[160,190]低位平台（均值≈2630 kPa）与[194,242]高位平台（均值≈2801 kPa），约40样本周期振荡衰减，**约 idx620 才基本收敛**；era2 标准差比 **8.97**（对应方差比 **80.4**）；era 均值2705.49→2705.87（+0.01%，z=0.09）为对称振荡的**相消伪象** |
| XMEAS_4 流量 | 11个越3σ区间、max\|z\|=4.19 | 前era基线下 **22个越3σ区间、max\|z\|=12.29**（流量短暂跌至8.33 kscmh ≈ **-10.9%**） |

据此更正三处叙事：(1) 「扰动以暂态形式传导至反应器压力后恢复」改为「扰动引发反应器压力持续大幅欠阻尼振荡，约420样本（21小时）后收敛，均值回归为相消伪象」；(2) 「反应器侧稳态」的说法弃用；(3) H4 排除理由中的「era均值稳态=无本体扰动签名」前提如所写不成立，改为「反应器侧无独立先行异常、era均值未漂移，但存在由供给能力受损后压力/弛放回路调压交互（XMV_6 低位段开大、高位段关小的相位滞后 hunting；[194,242]高位平台与 XMV_9 动作共时，区间内 XMV_9 均值33.8 vs 区间前54.7）产生的持续振荡，已计入症状残差」（见5.4）。该振荡时间上紧跟进料阶跃、方向与相位和 H1 的传导机制相容，**不构成对根因方向的矛盾**，但属于进料侧单因素未完全解释的残差动态，如实披露。

### 4.7 组成与质量链零签名

反应器进料组成 XMEAS_23-28 era2 post_mean_z_vs_pre=[0.11, -0.03, -0.34, -0.02, -0.07, 0.28]（max 0.34，相对偏移≤0.44%）；塔底产品组成 XMEAS_35-41 相对偏移-0.40%~+0.32%——全部位于前era±3σ内。纯供给能力损失不改变进入反应器的A/C总量与配比：流量闭环维持了组成稳定，本48h窗口内无产品质量后果（`02_processed/semantic_verification.json`）。

### 4.8 统计陷阱与降级记录

- Simpson悖论=0、趋势混淆=0、fatal=0（`02_processed/validate_report.json`；计数口径见第3章）。
- 弃用证据清单：全序列 XMV_4~XMEAS_4 r=0.28（阶跃伪迹）；全序列大滞后CCF峰（lag14/20）；XMEAS_4~XMEAS_21 强相关（离群驱动，SERIOUS）；XMV_1/XMV_3 滞后结构（低信噪比）。
- no quality reset：quality_reset_analysis reset_found=false——不支持「组件复位/修复」类机制。

## 5. 竞争假设检验与排除逻辑

竞争假设协议：生成→数据判别→排除/存续。判别矩阵6对全部 DISCRIMINABLE 且判别信号均已测量（`04_diagnostics/diagnosis.json` discriminability_matrix）。

### 5.1 竞争假设对比表

| 假设 | 内容 | 判别信号 | 裁决 |
|------|------|------|------|
| **H1 流股4 A/C汇管供给能力阶跃下降** | 汇管供给压力（或阀侧流通能力，见5.5）阶跃下降，控制器被迫开大XMV_4维持XMEAS_4 | XMV_4签名（+25.13%，z=12.35，唯一破包络）+恒流量+增益-20.11%+PRECURSOR时序 | **存续，置信78** |
| H2 蒸汽汇管压力轻度下降（主因候选） | XMV_9/XMEAS_19 mild shift同向机制 | 无法生成XMV_4签名；增益-2.1% vs -20.11%量级差一个数量级；两汇管设备独立（EQ_HEADER_S4 vs EQ_HEADER_STEAM） | 主因排除（90）；**次要共存应力保留披露** |
| H3 流股4 A/C配比漂移 | 配比变化应致XMEAS_23-28系统性漂移 | 实测 max\|z\|=0.34，窗口内不存在 | 窗口内排除（90，限本48h窗口；窗口外不可证伪已登记revival_condition） |
| H4 反应器本体独立扰动（动力学/冷却侧） | 应表现为与进料阀无关的反应器侧先行异常 | XMEAS_7暂态/振荡的先行变量均为进料/弛放侧执行器（XMV_4/XMV_6 PRECURSOR）；反应器侧无先行异常 | 排除（95；排除理由已按F1改写，见5.4） |
| H5' XMV_4 阀 Cv/行程能力阶跃损失（**物理审计F2项新增，遥测不可区分备择**） | 阀内件/流通能力损失与汇管压力下降在 Q=Cv·f(x)·√(ΔP/ρ) 中产生**完全相同签名**（恒流量+阀位大移+增益-20.11%） | 数据内不存在判别量（流股4汇管无独立并联用户阀可交叉对照） | 列为并列候选：按先验（48h无检修窗口内阶跃式Cv损失概率低）暂列H1之后；现场阀检验为裁决手段（见第8章 P0） |

### 5.2 H2 排除要点（主因角色；其应力存在性诚实分离）

蒸汽侧漂移统计真实（XMV_9 +3.92%、XMEAS_19 +1.74%、位置指示≥99%饱和边缘17样本/max 100.16）但仅能解释自身mild shift；无因果路径生成 XMV_4 的 z=12.35 签名；蒸汽汇管与流股4汇管物理独立，蒸汽压降不能反向作用于进料阀压差。复活条件：XMV_4签名消失而蒸汽侧签名增至两位数量级，或证实两汇管存在ontology未记载的共享调压设施。

### 5.3 H3 排除要点

组成链（XMEAS_23-28）与产品质量链（XMEAS_35-41）窗口内零签名；注意组成分析仪每3采样（9分钟）更新，高频配比波动存在欠采样风险（已在置信扣分体现）。复活条件：更长窗口出现与XMV_4签名同步的组成漂移，或加装A/C在线组成分析后实测配比变化。

### 5.4 H4 排除要点（按物理审计 F1 项改写后的表述）

**改写后的排除依据**：(1) 反应器侧无独立先行异常——era均值未漂移（XMEAS_7 +0.01%、XMEAS_21/22冷却侧稳态），但era均值稳态是±130~151 kPa对称振荡的相消伪象，**不作为「无扰动」证据引用**；era2的持续欠阻尼振荡（2595~2857 kPa）已计入症状残差并与调压回路交互解释相容。(2) 时序方向——两次压力异常区间的先行变量均为进料/弛放侧执行器（XMV_4 PRECURSOR 2.098/-1.931；XMV_6 3.596），扰动自进料侧传入而非反应器自发。(3) 物理——气相物料平衡 dN/dt=F_in-F_out-r·V 下，进料短暂跌落（前era基准下最低8.33 kscmh）方向与量级足以触发压力振荡；简化律优先。复活条件：发现与进料阀状态无关的反应器侧先行异常（如冷却水入口温度——未测混杂——阶跃，或催化剂活性漂移的独立指示）。

### 5.5 H5'（新增）不可区分性声明

汇管压力下降与XMV_4阀自身Cv损失共享同一观测签名集，遥测内无判别量；二者不属于「排除」关系而属于「并列机制、现场裁决」关系。诊断此前以78置信断言「供给压力下降」，本报告按审计要求将根因措辞放宽为「**供给能力（压力/Cv流通能力）阶跃下降**」，并将阀检验列为P0建议。该不确定性已由置信-7扣减与80认知封顶部分承载。

## 6. 根因结论

### 6.1 诊断结论

> **`DETERMINED`：样本161起，流股4 A/C进料汇管供给能力（压力/Cv流通能力）阶跃下降——最可能机制为汇管上游供给压力阶跃下降（隐含ΔP比0.638，derived），XMV_4 阀侧 Cv/行程能力阶跃损失为遥测不可区分的并列候选。流量闭环以 XMV_4 +25.13% 的补偿维持 XMEAS_4 恒定（-0.03%），扰动传导为反应器压力持续欠阻尼振荡（2595~2857 kPa，约idx620收敛）后稳定；蒸汽汇管存在量级小一个数量级的同向轻度应力（次要共存，非根因）。置信78/100（认知封顶80）。**

（注：`04_diagnostics/diagnosis.json` 原文措辞为「汇管供给压力阶跃下降」；本报告按 `05_review/optimizer_preflight.md` F2 项要求放宽为上述「供给能力」表述，`run_summary.json` 的 primary_finding 字段则按要求逐字保留 diagnosis.json 原文以便机器比对。）

### 6.2 结论详细推导（物理逻辑链）

| # | 链节 | 证据状态 | 量化 |
|---|------|------|------|
| 1 | 汇管供给能力阶跃下降（未测量节点）→ 阀前后ΔP下降 | INFERRED | ΔP比0.638（derived，=(0.121942/0.152630)²） |
| 2 | ΔP下降+流量控制器积分作用 → XMV_4被迫大幅开大 | OBSERVED | 61.2484%→76.6413%（+25.13%，z=12.35，唯一破包络；对`00_input/data.csv`独立重算复现） |
| 3 | 阀位增益损失+控制恢复 → 流量短暂跌落与暂态 | OBSERVED | 流量era均值-0.03%；前era基准下22个越3σ区间、max\|z\|=12.29、最低8.33 kscmh（≈-10.9%） |
| 4 | 进料扰动 → 反应器气相物料平衡扰动 → 压力持续欠阻尼振荡后收敛 | OBSERVED（烈度按F1更正） | 2595.3~2856.8 kPa（-27.6σ~+37.9σ）、标准差比8.97（对应方差比80.4）、约idx620收敛；[160,190]低位≈2630 / [194,242]高位≈2801 kPa平台与XMV_6/XMV_9调压交互共时 |

链路验证：XMV_4→XMEAS_4（era2 r=0.8036/lag1补偿0.8481）、XMV_4→XMEAS_7（PRECURSOR）、XMV_6→XMEAS_10（r=0.935/0.946，弛放为补偿方）全部 ALL_LINKS_VALIDATED；根节点无传感器，以 governing law 代数反演+6对对照排他（≤±1.2%）作间接验证，证据状态显式标 INFERRED（`04_diagnostics/diagnosis.json` chain_link_validation）。

### 6.3 推理链摘要（R1-R8）

完整八段推理链见 `04_diagnostics/reasoning_chain.json`（每步含 inputs/reasoning/outputs/alternatives/uncertainty/falsification）：R1 数据特征化与era二分 → R2 统计发现与证据融合（唯一签名+对照排他） → R3 验证过滤（两条禁用证据隔离） → R4 竞争假设生成（本体confounder驱动） → R5 可区分性评估（6对全DISCRIMINABLE，拒绝强行COMPETING_SET） → R6 排除执行（H2/H3/H4=90/90/95，附复活条件） → R7 结论与可证伪性（DETERMINED，78） → R8 不确定性定界（封顶80+五项按判别价值排序的建议测量）。

### 6.4 置信结构与可证伪条件

- **置信78 = 五因素85（统计22/25+物理23/25+时序17/20+混杂控制15/20+症状完整8/10）- 7（根因节点不可观测的认知扣减，溯源 `02_processed/causal_evidence_map.json` confidence_cap_note）**；自设80认知封顶（65/50协议封顶不适用——无INDISTINGUISHABLE对、歧义全部消解）。
- 症状完整性评分依据按 F1 项复核：振荡烈度更正后，「解释全部主要观测」的表述收敛为「解释全部主要观测的方向与时序；压力振荡幅值与调压交互残差已披露」。
- **可证伪条件**（任一成立即推翻或重构H1）：
  1. 流股4汇管加装压力变送后直测显示样本161前后无阶跃——H1直接证伪；
  2. XMV_4 阀位变送器校验显示+25%为仪表漂移——机制改判仪表故障；
  3. **XMV_4 阀解体检验/行程-Cv特性验证发现流通能力阶跃损失（物理审计F2新增）——根因改判阀侧机制，与汇管压力假设区分**；
  4. 流量控制器设定值变更记录与阀位阶跃同步——改判OPERATION类机制；
  5. XMEAS_4 流量计校验显示失效（实际流量下降而显示恒定）——重构为「流量计失效掩盖真实流量损失」。

## 7. 证据附录

### 7.1 证据全景与证据等级

证据分层遵循 L1-L7 体系，本结论的证据底线由其最低等级成员决定（L3统计+L5机理，间接推断）：

| 等级 | 证据 | 内容与关键数字 |
|------|------|------|
| L1 直接测量 | `00_input/data.csv`（960行） | XMV_4 61.2484±1.2463→76.6413（+25.13%，z=12.35）；XMEAS_4 9.3483→9.3458（-0.03%）；诊断与judge/审计三方独立重算复现 |
| L2 用户文档 | `00_input/user_context.json`、`00_input/clarification_needed.json` | 异常起点样本161（8h）；A3阀位百分比/A6汇管压力未测经增益推断/A7起点歧义全部AUTO_RESOLVED |
| L3 统计分析 | `02_processed/semantic_verification.json` | era分层52通道唯一破包络；7对增益对照（-20.11% vs ≤±1.2%，蒸汽-2.1%）；组成链max\|z\|=0.34 |
| L3 统计分析 | `02_processed/physics_check.json` | PRECURSOR effect 4.988/2.098/-1.931；窗口均值61.79→68.63等精确复现 |
| L3 统计分析 | `02_processed/time_lag_analysis.json` | era分层CCF（era1 -0.2429→era2 0.8036/0.8481）；全序列伪迹鉴别 |
| L3 统计分析 | `02_processed/validate_report.json` | time_sorted=true；simpson=0、trend=0；离群驱动对降级 |
| L3 统计分析 | `02_processed/causal_evidence_map.json` | stream4_header_pressure→XMV_4 边 validated；root_cause_candidates[0] strong |
| L4 图表视觉 | `03_figures/fig_valve_flow_decoupling.png` 等5图 | **元数据级（skeleton_pre_vlm，未目视）**；图设计目的与统计底稿一致 |
| L5 领域/机理 | `01_ontology/ontology.json` | Q=Cv·f(x)·√(ΔP/ρ)；confounders登记stream4_header_pressure机制原文；XMV_4唯一CONTRADICTED（51 CONSISTENT+1 CONTRADICTED，F3更正口径） |
| L5 量级检验 | `05_review/optimizer_preflight.md` | ΔP损失~36%属上游调压事件可实现量级（PLAUSIBLE）；F1前era基线重算（2595~2857 kPa、标准差比8.97（对应方差比80.4）、22/17个越限区间） |
| 审计/质量门 | `05_review/judge_feedback.json` | 98/100 pass；12项数值采样全部独立复现；2条非阻断warning已在第3、4.5节落实 |

### 7.2 关键工件索引

```
00_input/data.csv                              960行×53列原始遥测（全部数值的可复算源头）
01_ontology/ontology.json                      本体：信号分组/置信7-34-11-1
02_processed/semantic_verification.json         era分层包络+增益表+分层相关
02_processed/physics_check.json                 PRECURSOR时序与窗口均值
02_processed/time_lag_analysis.json             era分层滞后补偿CCF
02_processed/validate_report.json               反虚假基线（含计数口径说明见第3章）
02_processed/production_regime_filter.json      稳态占比0.9031（总体）
02_processed/anomaly_report.json                异常区间（全序列z口径，本报告已按F1更正引用方式）
02_processed/data_analysis_conclusion.json      data-processor专家交接（结论与本诊断独立一致）
03_figures/plot_manifest.json                   5图清单（全部已嵌入第4.5节）
04_diagnostics/diagnosis.json|evidence.json|confidence.json|reasoning_chain.json
05_review/judge_feedback.json                   98/pass
05_review/optimizer_preflight.md                物理审计（F1-F7；本报告落实F1/F2/F3/F4/F5）
```

## 8. 建议与后续

| 优先级 | 措施 | 具体操作 | 预期效果/验证方法 |
|--------|------|------|------|
| **P0** | 流股4汇管加装压力变送 | 在EQ_HEADER_S4汇管直测点安装压力变送，对照样本161前后阶跃与ΔP比0.638推断 | 判别价值最高：直测阶跃≈证实H1压力机制；无阶跃→转向阀侧机制（H5'）。直接证伪/确认根因 |
| **P0** | **XMV_4 阀现场检验（物理审计F2新增裁决项）** | 阀解体检修/行程-Cv特性验证：离线标定行程-Cv曲线，核对内件冲蚀/堵塞/阀芯磨损迹象 | 若发现流通能力阶跃损失→根因改判阀侧机制；若Cv完好→压力机制成立。同时排除falsification[2]仪表漂移（一并做阀位变送器校验） |
| P1 | XMV_4 阀位变送器与 XMEAS_4 流量计校验 | 按 falsification_conditions[1]/[3] 执行现场校验 | 排除仪表伪影类替代机制（遥测内无法排除） |
| P1 | 核查流股4上游调压段/阀门状态记录 | 调阅8小时前后上游调压设施/阀位/检修与操作日志 | 设备层归因（具体何种失效）超出遥测可判别范围，须现场闭环 |
| P1 | 监视 XMV_4 饱和裕度 | era2阀位76.64±2.43%、max 84.59%：若汇管能力进一步损失将逼近饱和 | 建议设置85%预警阈值；饱和前干预可避免流量失控 |
| P2 | 反应器压力回路振荡整定复查（F1衍生） | 针对[160,242]欠阻尼振荡段（约40样本周期）复查XMV_6弛放/XMV_9蒸汽调压回路交互整定 | 降低同类扰动下的压力振荡幅值与收敛时间（当前约21小时） |
| P2 | A/C在线组成分析 | 关闭H3窗口外不可证伪缺口 | 长周期配比漂移可判别 |
| P2 | 蒸汽侧监视 | XMV_9位置指示≥99%饱和边缘（17样本，max 100.16）持续跟踪 | 防止次要应力升级为独立事件 |

## 9. 方法论说明与局限

**方法**：本体引导的竞争假设诊断（hypothesis→discriminability→elimination）；era分层稳态包络检验；调节阀方程代数反演（Q=Cv·f(x)·√(ΔP/ρ)）；era分层滞后补偿CCF（lags -10..+10）；PRECURSOR效应量时序判别；留一杠杆/离群敏感性/Simpson-趋势混淆反虚假基线；四反虚假关联条件（时间先后/统计显著性/物理机理/无矛盾）全部经工件验证。反虚假纪律：主动弃用不利于结论的全序列r=0.28并给出era分层解释。

**局限与数据缺口**（`04_diagnostics/diagnosis.json` data_gaps 6项）：
1. 流股4汇管压力无传感器——根因物理量只能经阀-流量增益间接推断（本报告置信-7与封顶80的根本原因）；
2. 流股4内A/C配比无在线测量——H3窗口外不可证伪；
3. 蒸汽汇管压力未测量——H2量级只能间接推断；
4. process_only数据模式——无独立检验质量域，跨域双驱动不适用；
5. VLM图像级确认缺失（skeleton_pre_vlm）——时序先后仅统计链支持；
6. data_cleaning_provenance不完整——清洗审计链缺失（经审计重核raw→cleaned为0单元格修改的空操作，实质影响有限）。

**模型假设**：阀位百分比与流通面积近似线性（f(x)≈x；真实等百分比特性将使ΔP比0.638的数值偏移，但不改变「ΔP下降」的方向性结论）；Cv/ρ跨era不变（组成链max|z|=0.34支持）；稳态era均值对比假设era内准稳态（era2部分通道标准差增大至8.97倍（对应方差比80.4）已计入扣分与残差披露）。**不确定性三分解**：aleatory——180s采样内瞬态不可分辨、era1仅160样本的σ抽样误差（z=12.35量级下可忽略）；epistemic——根因节点不可观测、设备层归因超界、XMV_4阀Cv机制与压力机制遥测不可区分（5.5节）；model——阀特性线性化与稳态准设假设。

**边界声明**：本结论限定于「汇管供给能力阶跃下降」这一过程层机制与48h观测窗口，不越界断言具体设备层失效形式；残余的「能生成相同签名的未知机制」逻辑空间由80认知封顶承载，并由第8章P0两项现场措施闭环。

---

*报告生成：Step 6 reporter（工程师周）。输入工件：`04_diagnostics/{diagnosis,evidence,confidence,reasoning_chain}.json`、`05_review/{judge_feedback.json,optimizer_preflight.md}`、`02_processed/*`、`01_ontology/ontology.json`、`03_figures/plot_manifest.json`、`00_input/data.csv`。Judge门98/100 pass；物理审计2项MAJOR（F1暂态口径、F2不可区分备择）与F3/F4/F5已在本文相应章节落实；judge_feedback 2条非阻断warning已落实（第3章计数口径、第4.5节视觉披露）。*
