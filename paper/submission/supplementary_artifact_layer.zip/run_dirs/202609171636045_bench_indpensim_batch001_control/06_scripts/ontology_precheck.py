# -*- coding: utf-8 -*-
"""Ontology Stage-1 pre-checks (R2) for context-builder.
Data source: RUN_DIR/00_input/data.csv (raw, rows 1-1130, 0.2h sampling).
Pure-Python (csv + math) — no third-party deps required.
Every number printed is recomputable from the raw CSV.
"""
import csv, math

CSV = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171636045_bench_indpensim_batch001_control/00_input/data.csv"

def fnum(s):
    if s is None: return None
    s = s.strip()
    if s == "" or s.lower() == "nan": return None
    try:
        v = float(s)
        return v
    except ValueError:
        return None

rows = []
with open(CSV, newline="", encoding="utf-8") as fh:
    rdr = csv.reader(fh)
    header = next(rdr)
    for r in rdr:
        rows.append([fnum(x) for x in r])

idx = {c: i for i, c in enumerate(header)}
N = len(rows)
print("N_ROWS", N)
print("N_COLS", len(header))

def col(name):
    j = idx[name]
    return [r[j] for r in rows]

def pearson(a, b):
    pairs = [(x, y) for x, y in zip(a, b) if x is not None and y is not None and math.isfinite(x) and math.isfinite(y)]
    n = len(pairs)
    if n < 3: return None, n
    mx = sum(p[0] for p in pairs) / n
    my = sum(p[1] for p in pairs) / n
    sxy = sxx = syy = 0.0
    for x, y in pairs:
        sxy += (x - mx) * (y - my); sxx += (x - mx) ** 2; syy += (y - my) ** 2
    if sxx == 0 or syy == 0: return None, n
    return sxy / math.sqrt(sxx * syy), n

def steps(name):
    """unique levels and first time each level is seen"""
    c = col(name); t = col("Time (h)")
    seen = {}
    for tval, v in zip(t, c):
        if v is None: continue
        key = round(v, 4)
        if key not in seen:
            seen[key] = tval
    return sorted(seen.items(), key=lambda kv: kv[1])

def rng(name):
    c = [v for v in col(name) if v is not None]
    return (min(c), max(c), len(c))

print("\n== STEP LEVELS (level, first_time_h) ==")
for nm in ["Aeration rate(Fg:L/h)", "Sugar feed rate(Fs:L/h)", "PAA flow(Fpaa:PAA flow (L/h))",
           "Oil flow(Foil:L/hr)", "Water for injection/dilution(Fw:L/h)", "Air head pressure(pressure:bar)",
           "Agitator RPM(RPM:RPM)", "Fault reference(Fault_ref:Fault ref)", "Ammonia shots(NH3_shots:kgs)"]:
    lv = steps(nm)
    print(nm, "->", lv[:12], ("...%d levels" % len(lv)) if len(lv) > 12 else "")

print("\n== RANGES ==")
for nm in header:
    mn, mx, n = rng(nm)
    print("%s | min=%.6g max=%.6g n=%d" % (nm, mn, mx, n))

print("\n== PEARSON r (n used) ==")
pairs = [
    ("Oxygen Uptake Rate(OUR:(g min^{-1}))", "carbon dioxide percent in off-gas(CO2outgas:%)"),
    ("Carbon evolution rate(CER:g/h)", "carbon dioxide percent in off-gas(CO2outgas:%)"),
    ("Oxygen Uptake Rate(OUR:(g min^{-1}))", "Generated heat(Q:kJ)"),
    ("Dissolved oxygen concentration(DO2:mg/L)", "Oxygen Uptake Rate(OUR:(g min^{-1}))"),
    ("Substrate concentration(S:g/L)", "Sugar feed rate(Fs:L/h)"),
    ("pH(pH:pH)", "Base flow rate(Fb:L/h)"),
    ("pH(pH:pH)", "Acid flow rate(Fa:L/h)"),
    ("Temperature(T:K)", "Heating/cooling water flow rate(Fc:L/h)"),
    ("Temperature(T:K)", "Heating water flow rate(Fh:L/h)"),
    ("Penicillin concentration(P:g/L)", "Time (h)"),
    ("Vessel Volume(V:L)", "Time (h)"),
    ("Vessel Weight(Wt:Kg)", "Vessel Volume(V:L)"),
    ("Penicillin concentration(P:g/L)", "carbon dioxide percent in off-gas(CO2outgas:%)"),
    ("Oil flow(Foil:L/hr)", "Penicillin concentration(P:g/L)"),
    ("Generated heat(Q:kJ)", "Time (h)"),
]
for a, b in pairs:
    r, n = pearson(col(a), col(b))
    print("%s ~ %s : r=%s n=%d" % (a.split("(")[0], b.split("(")[0], ("%.4f" % r) if r is not None else "NA", n))

# P trajectory samples
print("\n== P / X / S TRAJECTORY (t, P, S) ==")
t = col("Time (h)"); P = col("Penicillin concentration(P:g/L)"); S = col("Substrate concentration(S:g/L)")
V = col("Vessel Volume(V:L)")
for tt in [1, 10, 20, 30, 40, 45, 50, 60, 80, 100, 150, 200, 225]:
    best = min(range(N), key=lambda i: abs(t[i] - tt))
    print("t=%.1f P=%.4g S=%.4g V=%.0f" % (t[best], P[best] or float("nan"), S[best] or float("nan"), V[best] or float("nan")))

# PAA_offline / NH3_offline / X_offline sample times
print("\n== OFFLINE SAMPLE TIMES (first 25) ==")
for nm in ["PAA concentration offline(PAA_offline:PAA (g L^{-1}))",
           "NH_3 concentration off-line(NH3_offline:NH3 (g L^{-1}))",
           "Offline Biomass concentratio(X_offline:X(g L^{-1}))",
           "Viscosity(Viscosity_offline:centPoise)"]:
    c = col(nm); ts = [tv for tv, v in zip(t, c) if v is not None]
    print(nm.split("(")[0], "->", ts[:25])

# Volume integral rough check: dV vs flows over a clean subinterval (100-102h)
print("\n== VOLUME BALANCE SNAPSHOT t=100h ==")
flows = ["Sugar feed rate(Fs:L/h)", "Acid flow rate(Fa:L/h)", "Base flow rate(Fb:L/h)",
         "Water for injection/dilution(Fw:L/h)", "Dumped broth flow(Fremoved:L/h)",
         "PAA flow(Fpaa:PAA flow (L/h))", "Oil flow(Foil:L/hr)", "Aeration rate(Fg:L/h)"]
best = min(range(N), key=lambda i: abs(t[i] - 100.0))
tot = 0.0
for f in flows:
    v = rows[best][idx[f]] or 0.0
    tot += v
    print(f, "=", v)
print("sum_incl_aeration(dump_neg) =", tot)
