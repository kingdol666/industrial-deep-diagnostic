// Build-time chart data injection for diagnostic-report.html (html-visualizer Step 8)
// Samples THIS run's 00_input/data.csv + 02_processed/validate_report.json and
// replaces the __CHART_DATA__ placeholder. Every number traceable to run artifacts.
'use strict';
const fs = require('fs');
const path = require('path');
const RUN = __dirname + '/..';
const lines = fs.readFileSync(path.join(RUN, '00_input/data.csv'), 'utf8').trim().split(/\r?\n/);
const hdr = lines[0].split(',').map(s => s.trim());
const idx = Object.fromEntries(hdr.map((h, i) => [h, i]));
const col = {
  t: 'Time (h)',
  S: 'Substrate concentration(S:g/L)',
  DO: 'Dissolved oxygen concentration(DO2:mg/L)',
  P: 'Penicillin concentration(P:g/L)',
  pH: 'pH(pH:pH)',
  T: 'Temperature(T:K)',
  Fpaa: 'PAA flow(Fpaa:PAA flow (L/h))'
};
const rows = [];
for (let i = 1; i < lines.length; i++) {
  const c = lines[i].split(',');
  if (c.length < hdr.length) continue;
  rows.push(c);
}
const num = (r, k) => parseFloat(r[idx[col[k]]]);
const p_all = [], do_all = [], t_all = [], ph_all = [];
for (let i = 0; i < rows.length; i += 4) {
  const r = rows[i];
  p_all.push([+num(r, 't').toFixed(1), +num(r, 'P').toFixed(4)]);
  do_all.push([+num(r, 't').toFixed(1), +num(r, 'DO').toFixed(3)]);
  t_all.push([+num(r, 't').toFixed(1), +num(r, 'T').toFixed(3)]);
  ph_all.push([+num(r, 't').toFixed(1), +num(r, 'pH').toFixed(4)]);
}
const last = rows[rows.length - 1];
const p_end = [+num(last, 't').toFixed(1), +num(last, 'P').toFixed(3)];
const s_stg2 = [];
for (let i = 0; i < rows.length; i += 4) {
  const r = rows[i];
  if (Math.abs(num(r, 'Fpaa') - 10) < 1e-9) s_stg2.push([+num(r, 't').toFixed(1), +num(r, 'S').toFixed(6)]);
}
const v = JSON.parse(fs.readFileSync(path.join(RUN, '02_processed/validate_report.json'), 'utf8'));
const shortNames = { Viscosity_offline: 'P~粘度', NH3_offline: 'P~NH3_offline', X_offline: 'P~X_offline', CER: 'P~CER', CO2outgas: 'P~CO2', Wt: 'P~Wt' };
const collapse = (v.anti_spurious.time_trend_confounding || [])
  .filter(d => d.target.indexOf('Penicillin') === 0)
  .map(d => {
    let pair = d.parameter.split('(')[0].trim();
    for (const k in shortNames) if (d.parameter.indexOf(k) >= 0) pair = shortNames[k];
    return { pair: pair, raw: d.raw_r, det: d.detrended_r };
  });
const data = { p_all: p_all, p_end: p_end, s_stg2: s_stg2, do_all: do_all, t_all: t_all, ph_all: ph_all, collapse: collapse };
console.error('p_end=' + JSON.stringify(p_end) + ' s_stg2_n=' + s_stg2.length + ' p_all_n=' + p_all.length + ' collapse_n=' + collapse.length);
console.error('s_stg2_max=' + Math.max.apply(null, s_stg2.map(d => d[1])).toFixed(6) +
  ' do_min=' + Math.min.apply(null, do_all.map(d => d[1])).toFixed(3) +
  ' p_max=' + Math.max.apply(null, p_all.map(d => d[1])).toFixed(4));
const hp = path.join(RUN, 'diagnostic-report.html');
const html = fs.readFileSync(hp, 'utf8');
if (html.indexOf('__CHART_DATA__') < 0) { console.error('PLACEHOLDER NOT FOUND'); process.exit(1); }
const out = html.replace('__CHART_DATA__', JSON.stringify(data));
fs.writeFileSync(hp, out);
console.error('injected, bytes=' + Buffer.byteLength(out));
