// Structural + syntax verification for diagnostic-report.html vs render_manifest.json (CP-8B input)
'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const os = require('os');
const RUN = __dirname + '/..';
const html = fs.readFileSync(path.join(RUN, 'diagnostic-report.html'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(RUN, 'render_manifest.json'), 'utf8'));

const count = (re) => (html.match(re) || []).length;
const checks = {};
checks.bytes = Buffer.byteLength(html);
checks.html_open_tag = count(/<html/gi);
checks.echarts_ref = count(/echarts/gi);
checks.placeholder_left = count(/__CHART_DATA__/g);
checks.chart_canvas_ids = count(/id="chart[1-5]"/g);
checks.chart_readings = count(/class="chart-reading"/g);
checks.hero_meta_items = count(/hero-meta-item">/g);
checks.key_cells = count(/class="key-cell"/g);
checks.evidence_articles = count(/<div class="evidence-article">/g);
checks.pc_steps = count(/class="pc-step"/g);
checks.evidence_scores = count(/class="evidence-score"/g);
checks.evidence_layers = count(/class="evidence-layer" id=/g);
checks.figure_full = count(/class="figure-full"/g);
checks.fig_imgs = count(/src="03_figures\//g);
checks.img_onerror = count(/img[^>]+onerror=/g);
checks.verdict_matrix_rows = count(/<tr><td>H1 vs /g);
checks.stat_table_rows = count(/<tr><td>P ~ /g);
checks.action_rows = count(/class="pri">P[012]<\/td>/g);
checks.nav_anchors = count(/href="#(hero|where|how|evidence)"/g);
checks.loader_dots = count(/class="ls-dot"/g);
checks.importmap = count(/type="importmap"/g);
checks.unpkg_fallback = count(/unpkg\.com/g);
checks.jsdelivr = count(/cdn\.jsdelivr\.net/g);
checks.footer = count(/<footer class="page-footer">/g);
checks.degraded_notice = count(/id="degradedNotice"/g);
checks.noscript = count(/<noscript>/g);
checks.diag_status = count(/__diagStatus/g);
checks.getInstanceByDom = count(/getInstanceByDom/g);

// syntax-check every inline script block
const blocks = [];
let re = /<script( type="module")?>([\s\S]*?)<\/script>/g, m;
while ((m = re.exec(html))) blocks.push({ module: !!m[1], code: m[2] });
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'diaghtml-'));
checks.script_blocks = blocks.length;
checks.syntax_ok = true;
blocks.forEach((b, i) => {
  const f = path.join(tmp, 'blk' + i + (b.module ? '.mjs' : '.js'));
  fs.writeFileSync(f, b.code);
  try { cp.execSync('node --check ' + JSON.stringify(f), { stdio: 'pipe' }); }
  catch (e) { checks.syntax_ok = false; checks['syntax_error_blk' + i] = String(e.stderr || e.message).slice(0, 400); }
});

// alignment vs manifest page_model
const pm = manifest.page_model;
checks.align = {
  sections_4: checks.nav_anchors === pm.sections.length,
  hero_meta: checks.hero_meta_items === pm.hero_elements.hero_meta_items,
  key_findings: checks.key_cells === pm.hero_elements.key_findings_cells,
  charts_5: checks.chart_canvas_ids === manifest.charts.length,
  chart_readings_9: checks.chart_readings === (pm.section_how.chart_readings + pm.section_evidence.layer1_echarts_rebuilds + pm.section_how.png_reading_trios + pm.section_evidence.png_reading_trios),
  stat_rows: checks.stat_table_rows === pm.section_how.stat_table_rows,
  physics_steps: checks.pc_steps === pm.section_evidence.physics_chain_steps,
  articles: checks.evidence_articles === pm.section_evidence.evidence_articles,
  scores: checks.evidence_scores === pm.section_evidence.evidence_scores,
  layers: checks.evidence_layers === pm.section_evidence.layers,
  verdict_rows: checks.verdict_matrix_rows === pm.section_evidence.verdict_matrix_rows,
  action_rows: checks.action_rows === pm.section_evidence.action_rows,
  png_embedded_4: checks.fig_imgs === manifest.embedded_png_count,
  nav_anchors: checks.nav_anchors === pm.sections.length,
  equipment_count_declared: manifest.process_flow.equipment_count
};
console.log(JSON.stringify(checks, null, 1));
