# 工业诊断报告 — IndPenSim 青霉素补料分批正常对照批（batch_001）

- 运行目录：`D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171636045_bench_indpensim_batch001_control`
- 判定类型：`DETERMINED`（唯一存活假设 H1，置信 93/100，等级 HIGH，上限 95）
- 质量门：Judge 评分 **94 / pass**（`05_review/judge_feedback.json`，第 1 轮）；物理预审计 **PREFLIGHT_PASS / NO_FATAL**（`05_review/optimizer_preflight.md`：0 FATAL、0 MAJOR、2 MINOR——M1/M2 两项表述修正已在本报告中采纳）
- 撰写人：工程师周（报告撰写，Step 6）；数据基准：`00_input/data.csv`（1130 行 × 32 列，t=0.2–226.0 h，采样 0.2 h）

---

## 1. 执行摘要

**结论先行：本批无故障。** 全部观测波动均可由合法配方工况切换、闭环控制特征与设计内生物动力学轨迹定量解释，不存在任何需要设备/材料/测量/生物故障解释的残余形态（`04_diagnostics/diagnosis.json` primary_finding，DETERMINED）。对工厂管理层的一句话版本：**这批青霉素发酵完全按配方走完了 226 小时，产量达标，各环节衡算闭合，不需要检修任何设备。**

无故障判定的六项承重证据（全部经物理审计独立复算，见 `05_review/optimizer_preflight.md` V1–V14）：

| # | 证据 | 数值 | 来源 |
|---|------|------|------|
| 1 | 配方三阶段精确执行 | Fpaa 台阶行 26/201/1001 ↔ t=5.2/40.2/200.2 h；Fg 六级台阶变点 8.2/20.2/40.2/90.2/200.2 h 逐一与数据对齐，0 个配方外突跳 | `02_processed/production_regime_filter.json` |
| 2 | 基质饥饿准稳态 | STG2 S=0.00142±0.00040 g/L，94.5% 行在设计带 0.001–0.01 g/L 内，窗内最大 0.0026 g/L | `02_processed/batch_phase_semantic_analysis.json` |
| 3 | 产物近线性积累 | STG2 r(P,t)=0.9976（n=800），逐差均值斜率 0.1658 g/L/h | `02_processed/batch_phase_semantic_analysis.json` |
| 4 | pH/T 双窄带保持 | 带内率 99.82% / 99.91%（最大 T 偏差 0.75 K） | `02_processed/physics_check.json` |
| 5 | 供氧裕度 | DO 最低 9.322 mg/L（t=151.2 h）= 临界氧 2 mg/L 的 4.66 倍 | `02_processed/physics_check.json` |
| 6 | 体积衡算闭合 | r(dV/dt, ΣF)=0.9996（n=1129）；Wt–V 冗余 r=0.9971（LOO 位移 0.0） | `02_processed/batch_phase_semantic_analysis.json` |

**业务影响**：批末青霉素浓度（按行基准注明，审计修正 F3）——末行（t=226.0 h）在线 29.373 g/L / 离线 HPLC 29.386 g/L（相对差 0.04%）；批内在线最大 29.409 g/L；本体生产目标记录本批 226 h 实测 29.39 g/L（`01_ontology/ontology.json` scene.production_goal），观测/预测比值 0.999。**产量无损失，无误报处置成本。**

**建议行动分级（详见 §8）**：P0=无需任何纠偏动作、维持现配方执行；P1=补充 CER/OUR 厂商单位元数据 + 重复批次（把置信度从 93 向上限 95 收紧）；P2=VLM 环境复检 7 张图、离线化验加密、体积记账口径核对。

---

## 2. 诊断背景

- **工艺对象**：IndPenSim 100,000 L 搅拌罐青霉素 G 补料分批发酵（`01_ontology/ontology.json` scene：`indpensim_100000L_penicillin_fedbatch_batch001`）。三阶段配方语义：STG1 间歇生长（0.2–40.0 h）→ STG2 补料生产（40.2–200.0 h，Fpaa=10 L/h 恰 800 行）→ STG3 末期降载（200.2–226.0 h，Fpaa=4 L/h）。生产目标=最大化批末 P。
- **用户问题**："诊断本次异常的根本原因"（`00_input/user_context.json`）——本诊断的回答是：**经全链路排除性检验，本次提交数据中不存在异常，"根因"即配方调度本身**。对正常对照场景，制造弱故障结论即误报（false alarm），属于诊断失败。
- **数据概览**：1130 行 × 32 列，0.2 h 均匀采样，时间列严格递增（`02_processed/validate_report.json` sorting_validation.time_sorted=true）；离线化验列（P_offline/X_offline/PAA_offline/NH3_offline/粘度）每列仅 20 点（12 h 栅格）；恒定列 Agitator RPM=100、NH3_shots=0、Fault_ref=0。
- **歧义消解**：8 项数据歧义全部 AUTO_RESOLVED 并登记于 `00_input/clarification_needed.json`（AMB-1 O2 按 0–1 体积分数解释、AMB-3 Fremoved 负号约定、AMB-6 NaN=未采样禁止插补、AMB-7 开车瞬态等）。**Fault_ref 全 0 按 AMB-5 仅作标签元数据，不进入物理证据链**——无故障结论完全由工艺证据独立得出。
- **前 5 h 开车段**：Fpaa=5 L/h 斜坡共 25 行，属 STG1 内启动细节（AMB-7：P 首行 1e-25 浮点下溢、OUR 微负 |·|<0.06 g/min、Q 机器零，均判定为数值瞬态而非过程异常）。

### 2.3 对齐图三段式解读（核心证据）

以阶段语义图 `03_figures/fig_batch_phase_semantics.png` 为例，按"图显示什么 → 统计说什么 → 物理是否成立"三段式解读：

![批阶段语义（STG1|STG2|STG3）— S/Fs, DO/OUR, P/CO2](03_figures/fig_batch_phase_semantics.png)

1. **图显示什么**：S/Fs、DO/OUR、P/CO2 三组曲线沿批龄叠加，阶段边界标注在 40.2 h 与 200.2 h，执行量台阶与被控量窄带同图可见。
2. **统计说什么**：Fpaa 台阶精确出现在行 26/201/1001（t=5.2/40.2/200.2 h）；STG2 窗内 r(P,t)=0.9976、S 带内率 94.5%；阶段边界与配方时钟逐行对齐（`02_processed/production_regime_filter.json` verification 块）。
3. **物理是否成立**：受限补料准稳态（V·dS/dt = Fs·C_in − (1/Y_XS)·μ(S)·X·V − m_S·X·V ≈ 0）预测 S 钉在饥饿带；非生长相关合成（dP/dt = k_syn·X·f(PAA) − k_deg·P − (F/V)·P）预测 P 近线性积累——功能形式、时序、方向、量级四要素全部 MATCH（`04_diagnostics/diagnosis.json` ontology_data_physics_proof，overall=PROVEN）。

**视觉–统计一致性声明（审计修正）**：本运行环境无 VLM，7 张 PNG 全部渲染成功（`03_figures/plot_manifest.json` png_count=7, status=rendered）但像素读取全部失败（`03_figures/visual_analysis.json` observation_mode=`metadata_backed_inference`，read_status=READ_FAILED）。本报告引用的全部"视觉"证据均为元数据级判读，并与 L1/L3 数值证据交叉一致；报告不声称做过任何像素级观察。SG1 同步组（P 与 Fg/Wt/CO2/X_offline/CER 等共移动）的诊断含义为**批龄共演化**，去趋势后塌陷（见 §4），非组件级因果。

---

## 3. 数据质量评估

| 维度 | 结论 | 依据 |
|------|------|------|
| 完整性 | 在线列无缺失；离线 5 列各 20 点为 12 h 化验设计（NaN=未采样，AMB-6 禁止插补） | `00_input/input_manifest.json`、`00_input/clarification_needed.json` |
| 时间有效性 | Time (h) 严格递增（1130 值），0.2 h 间隔 | `02_processed/validate_report.json` sorting_validation |
| 批完整性 | 单产品批，无 product/lot 分组列，per-product 分层不适用（duplicate_batches=[]） | `02_processed/batch_integrity.json` applicable=false |
| 生产状态 | 全批单工况轨迹（fed-batch），STG2 稳态生产窗 = Fpaa==10 的 800 行（rows 200–999） | `02_processed/production_regime_filter.json` |
| 统计陷阱披露 | pH/T 的 pct_beyond_3sigma（6.0%/10.2%）与 Fa/Fh 的 max_abs_z（16.2/10.9）为窄带控制与近零基线的统计伪影，分阶段复核无阶段外突跳 | `02_processed/anomaly_report.json`、`02_processed/batch_phase_semantic_analysis.json` flagged_column_phase_evaluation |
| 单位口径 | RQ 存储比值 0.0162（生理带 0.9–1.1 的约 1/62）全批稳定（p05–p95=0.0047–0.0211）→ 判定存储单位错配，绝对 RQ 记 NOT_APPLICABLE；方向级气体衡算不受影响 | `02_processed/physics_check.json` |

数据质量足以支撑诊断（fatal_issues=0，`02_processed/validate_report.json`）；tier_1 质量目标（P、DO2）的 anomaly_intervals 均为空、无阈值穿越、无 reset 事件。

---

## 4. 统计分析发现

本节为承重章节（非附录）。全部相关结论均通过反伪因果四道闸（去趋势混杂 / 离群杠杆 / Simpson / 滞后核验）后才被引用。

![全参数 z 归一化时序叠加](03_figures/fig_vlm_temporal_overlay.png)

1. **表观强相关全部为批龄混杂**：13 对趋势混杂相关去趋势后塌陷（例：P~X_offline 0.8704→0.1126、P~NH3_offline 0.9122→−0.2163、P~CO2 0.7865→−0.0603、P~粘度 0.9228→0.1712）；0 对离群驱动；Simpson 悖论空集；fatal_issues=0（`02_processed/validate_report.json` anti_spurious）。
2. **存留的 6 对相关均为方向级平凡结构**（`02_processed/causal_evidence_map.json`，root_cause_candidates=[]）：CER–CO2、OUR–O2、V–Wt 为同源衡算/冗余恒等；T–Fc 为控制需求签名；OUR–DO 为闭环弱耦合；Fs–S 为准稳态复合符号（r=−0.5113，已标 NOT_CAUSAL_AS_IS）。
3. **滞后核验**（±20 步=±4 h，STG2 窗 n=800，6 对，`02_processed/time_lag_analysis.json`）：唯一实质性对齐为 **T 偏差领先冷却动作 Fc 1 步（0.2 h，r 0.5084→0.7550）**——需求驱动控制签名，Fc 是 T 的结果而非原因；两处 +20 步搜索边界值按协议判为搜索伪影不予采信。
4. **变点证据（按审计修正 M1 的核实口径表述）**：`02_processed/validate_report.json` 的 change_point_detection 块对 **2 个分析目标**做了均值漂移分段——**DO2 列 28 个变点（29 段，段均值 9.44–15.24 mg/L 全部处于正常带）、CER 列 111 个变点**（10 行窗口敏感检测器在平滑批龄漂移上的正常输出，段均值 0.042→0.053→0.068→0.089… 单调演化）。分段边界与配方步（行 26/101/201/501/1001）及生理再调节窗吻合，段均值有界，无故障形态。注意：validate_report summary 字段 `change_points_detected: 2` 计的是分析目标列数而非变点事件数，上游诊断工件曾误读该语义（Judge 与物理审计均已核正，本报告采用核实口径）。
5. **Spearman 分歧（按 Judge 修正口径）**：明细共 9 项——**1 项 SERIOUS（P~Fw 0.2056→0.5321）+ 8 项 MODERATE**；重尾列（S/Fa/Fh/T/Fremoved）已按建议以方向级引用兜底，不影响结论（`02_processed/validate_report.json` spearman_divergence）。
6. **Granger/互信息备注（Judge 建议采纳）**：如 P~Fg Granger lag-1 显著（f=1782）源于配方调度的同源混杂，与 §4 条 1 的混杂拒绝同解，**不构成额外因果证据**。
7. **分层一致性**：气体衡算方向对三阶段恒定——r(CER,CO2)=0.994/0.902/1.000、r(OUR,O2)=−0.968/−0.892/−0.993（STG1/2/3；审计复算 STG1 为 0.993/−0.948，差异系开车窗过滤口径，见 `05_review/optimizer_preflight.md` F4，方向与结论不变）；留一法杠杆复核 5 对全部 non-leveraged（max_shift ≤0.0194）。

![分组时序叠加 g1](03_figures/fig_vlm_temporal_overlay_single_product_g1.png)

![分组时序叠加 g2](03_figures/fig_vlm_temporal_overlay_single_product_g2.png)

![分组时序叠加 g3](03_figures/fig_vlm_temporal_overlay_single_product_g3.png)

![滚动相关同步性热图](03_figures/fig_vlm_synchronization.png)

**小结**：不存在任何需要故障解释的残余统计结构——"正常批"图景在进入假设检验前已由数据自证。

---

## 5. 竞争假设检验与诊断结论排除逻辑

按竞争假设协议，故障侧与"正常"侧对称开放生成 6 个假设（`04_diagnostics/diagnosis.json` hypotheses）：

| 假设 | 内容 | 判定 | 排除置信 | 关键定量判据 | 复活条件（摘要） |
|------|------|------|:---:|------|------|
| H1 | 配方驱动的正常补料分批运行（无故障） | **存活** | 93/100（HIGH，上限 95） | 六环物理链全部定量验证（§6） | 见 §8 证伪条件 |
| H2 | 供氧不足/通气系统退化 | 排除（PHYSICAL） | 96 | DO min 9.322 mg/L = 4.66× 临界氧，量级上不可能；O2 分数 18.5%–20.6% 无塌陷 | DO<5 mg/L 持续窗、尾气 O2 塌陷 |
| H3 | pH/T 控制回路失效 | 排除（COMBINED） | 95 | 带内 99.82%/99.91% + 执行器全跨度（Fb 0-225/Fc 0-445.62/Fh 0-339.37 L/h）+ T→Fc 需求签名 + 无 reset | 持续带外漂移、滞后签名反转 |
| H4 | 前体（PAA）供给故障/产物积累异常 | 排除（COMBINED） | 95 | r(P,t)=0.9976、斜率拐点仅在 200.2 h 配方边界、批末在线/离线互证 0.04% | 互证偏差 >5%、recipe 外斜率断裂 |
| H5 | 传感器/测量系统漂移 | 排除（COMBINED） | 92 | Wt–V r=0.9971（LOO 0.0）、气体衡算分阶段自洽、RQ 错配恒定不随时间增长 | 冗余通道间偏差随时间单调增长 |
| H6 | 染菌/代谢 regime 漂移 | 排除（COMBINED） | 90 | 染菌签名清单（OUR/CER 解耦、pH 酸化、S 溢出、衡算破坏）逐项缺席；RQ 窄带稳定 | 未来批出现任一签名 |

**判别力矩阵**：H1 vs H2/H3/H4/H5/H6 五对全部 `ONE_SIDE_EXCLUDED`，判别信号可用且已测量（物理阈值/带内率/斜率-配方耦合/冗余交叉/签名清单），**无 INDISTINGUISHABLE 对**——不触发 COMPETING_SET 降级与 ≤65 置信压顶。

**诚实披露的推理修正**（`04_diagnostics/diagnosis.json` inference_gaps，非静默删除）：朴素物理直觉预期"补料脉冲 Fs 立即抬高 S（正相关）"，但观测 r(Fs,S)=−0.5113 且无可信滞后（CORRELATION_ABSENT）。按受限补料准稳态约束修正机制表述：S 被消耗钉在饥饿带，负号是配方时间轨迹与准稳态的复合符号；判据改为"S 是否带内"（94.5% 带内即补料-消耗平衡成立的直接证据）。该环不承重，修正不降级 DETERMINED 判定（物理审计 P4 复核通过）。

---

## 6. 根因结论

**根因（唯一存活假设 H1）**：本批为配方驱动的正常（无故障）补料分批运行——观测波动的"根"是**配方时钟（隐变量）对执行器的台阶调度**：Fpaa 0/10/4 L/h 定义 STG1/STG2/STG3，Fg 六级台阶（30→42→55→60→75→65 L/h @ 8.2/20.2/40.2/90.2/200.2 h），Fs 18 级台阶（8–150 L/h）；执行量变化全部由配方合法驱动，被控量在闭环下保持窄带。

### 6.1 物理逻辑链（六环，`04_diagnostics/diagnosis.json` physical_logic_chain）

1. 配方时钟调度执行器 → 阶段边界与变点精确重合（OBSERVED：Fpaa 行 26/201/1001 ↔ t=5.2/40.2/200.2 h）；
2. 受限补料维持 S 饥饿准稳态（KNOWN_PHYSICS：STG2 S=0.00142±0.00040 g/L，94.5% 带内）；
3. S 饥饿 + X 平台 + 前体充足 → P 近线性积累（KNOWN_PHYSICS：r=0.9976，斜率见下）；
4. 供氧通道 kLa·(C*−CL) 平衡 OUR，DO 远离临界（OBSERVED：min 9.322 mg/L = 4.66× 临界）；
5. pH/T 双窄带由脉冲执行器维持，需求驱动（OBSERVED：T→Fc 1 步 r 0.51→0.755）；
6. 全部衡算闭合（OBSERVED：体积 0.9996、Wt–V 0.9971、P 互证 0.04%）。

**产物斜率与估计量口径（审计修正 F5）**：STG2 平均斜率 0.1658 g/L/h 为**逐差均值**（诊断人 venv python 独立复算 0.165805，与 `02_processed/batch_phase_semantic_analysis.json` 一致）；同一窗 OLS 估计为 0.1716 g/L/h（STG3：逐差 0.0331 / OLS 0.0367）。两估计量皆合法，复算时请勿因口径不同误判不一致。

**DO 物理自洽说明（审计修正 F6）**：DO 全程 9.322–15.872 mg/L **高于 1 atm 空气饱和值**——由罐顶加压（0.6→1.1 bar，亨利定律抬升 C*，`01_ontology/ontology.json` EQ-AIR）解释，属加压发酵罐的预期行为，而非量程伪影。

**体积衡算归因（审计修正 M2，覆盖上游表述）**：体积衡算**结构性闭合 r=0.9996**（n=1129，`02_processed/batch_phase_semantic_analysis.json` volume_balance_check：斜率 0.8776、截距 −17.33 L/h）。**单一比例因子 0.878 不能归因于"1 步积分时序"**——审计滞后检验（dV/dt vs ΣF(t−1)：r=0.8995、斜率 0.7898，劣于同时对齐的 r=0.9996/斜率 0.8776）已否定时序错位假设（`05_review/optimizer_preflight.md` 四、物理验证#2）。正确表述：0.878 因子与约 −17 L/h 截距对应**一个近似恒定的未记录净损失项（约 17–26 L/h 量级，全批累计 ≈4.5×10³ L ≈ 峰值体积 83,270 L 的 5%）**，损失序列有界、无随时间漂移，其物理分解（采样/蒸发/仿真体积记账）无法由本数据单独证明。恒定不增长的损失不是漂移型故障形态，衡算闭合本身无恙。

**本体-数据-物理证明**：功能形式 MATCH、滞后 MATCH、方向 MATCH、量级 PLAUSIBLE（批末 P 观测/预测比值 0.999）→ overall_proof_strength=**PROVEN**；支撑物理检查 9 项全 PASS（`02_processed/physics_check.json`）。

### 6.2 推理过程（R1–R8 概览，`04_diagnostics/reasoning_chain.json`）

| 段 | 问题 | 输出（置信） |
|----|------|------|
| R1 | 数据表征与场景判定 | 配方驱动青霉素 fed-batch 正常对照批；三阶段语义成立（97） |
| R2 | 统计发现与多源融合 | 表观强相关簇=批龄公共驱动；设计内轨迹清晰（93） |
| R3 | 验证过滤与异常复核 | 全部 3σ 异常候选消解为合法机制；无未解释变点（95/93） |
| R4 | 竞争假设生成 | 6 假设全部携带治理方程与可证伪条件；H1 链 5/6 环直接验证（92） |
| R5 | 判别力评估 | 五对全部 ONE_SIDE_EXCLUDED，无 INDISTINGUISHABLE（94） |
| R6 | 排除验证 | H2–H6 全部排除（96/95/95/92/90，各带复活条件）（93） |
| R7 | 结论与可证伪性 | DETERMINED；置信 93；五条证伪条件登记（93） |
| R8 | 不确定性定界 | 上限 95；四项 epistemic 缺口 + 三项 aleatory 极限 + 建议测量清单（95/90） |

置信度 93 可由三条独立路径重构（Judge 已核）：70+15+12−4（hypothesis_evolution）= 24+24+18+18+9（五因素）= 70+23（diagnosis confidence_adjustments）。

---

## 7. 证据附录（证据全景）

证据清单计数与 `04_diagnostics/evidence.json` 逐一对应：视觉 3 / 数值 7 / 物理 4 / 验证 4。承重数字全部为 L1 直接测量（经诊断人与物理审计双重复算）或 L3 验证统计；视觉证据诚实标注 L4 且仅为元数据级。

### 7.1 关键工件索引（含承重数字）

| 工件 | 承重内容 |
|------|------|
| `00_input/data.csv` | 1130 行 × 32 列；Fault_ref 全 0（σ=0，仅标签元数据 AMB-5）；Fpaa==10 恰 800 行；P 斜率 0.165805 g/L/h；DO min 9.322 @t=151.2 h；pH/T 带内 99.82%/99.91% |
| `02_processed/batch_phase_semantic_analysis.json` | 阶段语义切分、S 准稳态（94.5% 带内）、P 线性（0.1658 g/L/h, r=0.9976）、滞后补偿 CCF、分层相关、LOO 杠杆、体积衡算（r=0.9996）、verdict_hint：recipe-driven normal fed-batch |
| `02_processed/validate_report.json` | anti_spurious：13 对混杂塌陷、0 离群、Simpson 空、fatal=0、变点分析 2 目标（DO2 28 / CER 111）、Spearman 1 SERIOUS + 8 MODERATE |
| `02_processed/physics_check.json` | 9 项物理检查全 PASS（体积衡算、RQ 方向、Wt–V 冗余、临界 DO 裕度、pH/T 带、S 准稳态、在线/离线 P 互证、开车瞬态） |
| `02_processed/time_lag_analysis.json` | T→Fc 1 步需求签名（r 0.5084→0.7550）；其余 5 对 lag-0；±20 步边界值不采信 |
| `02_processed/anomaly_report.json` | P/DO2 anomaly_intervals 空、无阈值穿越、quality_reset_found=false |
| `02_processed/causal_evidence_map.json` | root_cause_candidates=[]；保留 6 条方向级边、13 条混杂边显式拒绝 |
| `02_processed/data_analysis_conclusion.json` | data-processor（工程师张）H1–H5 全 supported；双驱动 View B 因离线 20 点稀疏降级为定性互证（process_only） |
| `01_ontology/ontology.json` | 21 条治理方程 + 8 条 confounders（批龄/X_offline/配方调度等）；scene.production_goal 29.39 g/L |
| `03_figures/visual_analysis.json` | metadata_backed_inference：无元数据级故障签名；SG1=批龄共演化 |
| `04_diagnostics/diagnosis.json` / `confidence.json` / `evidence.json` / `reasoning_chain.json` | DETERMINED / 93 分五因素分解 / 证据清单 3-7-4-4 / R1–R8 全备 |
| `05_review/judge_feedback.json` | 94/pass；独立复算 9 项承重数值逐位吻合 |
| `05_review/optimizer_preflight.md` | PREFLIGHT_PASS；V1–V14 复算一致；M1/M2 修正指令（本报告已采纳） |

### 7.2 推理链与置信度

- H1 存活路径：R2 结构初判 → R3 异常候选清空 → R4 链验证 → R5 判别 → R6 存活 → R7 DETERMINED（`04_diagnostics/reasoning_chain.json` hypothesis_evolution）。
- 置信 93 的四项扣分来源（已披露，不可在本批数据内消除）：单批不可重复（−2）、批初开车瞬态 AMB-7（−2）、RQ 绝对单位不可裁决、非 VLM 视觉证据（后两项计入五因素缺口）。
- 反向证据三条均定量消解（`04_diagnostics/diagnosis.json` contradicting_evidence）：强相关簇（去趋势塌陷）、3σ 突出（窄带/近零基线伪影）、RQ 单位（恒定错配非代谢转变）。

### 7.3 全局时序图

![关键过程变量时序网格（±3σ 阈值线）](03_figures/fig_temporal_overview.png)

---

## 8. 建议与后续

**P0（必须，0 成本）**
- 无需任何纠偏、检修或工艺干预——本批各项判据裕度充足（DO 4.66×、互证 0.04%、衡算 0.9996）。维持现行配方与控制参数继续执行后续批次。

**P1（1–2 周内，收紧结论用）**
1. **补充 CER/OUR 厂商单位元数据**：闭合 RQ 绝对值 NOT_APPLICABLE 缺口（现存储比值 0.0162≈1/62 稳定错配），一并复核 AMB-1 O2 刻度。验证方式：元数据到位后重算 RQ 落入 0.9–1.1 生理带即闭合。
2. **重复批次**：以同一配方执行第 2/3 批并复用本管线，估计批间变异、检验 H1 的批间外推。预期效果：置信度 93 → 上限 95。
3. **离线化验加密**：现 20 点（12 h 栅格）仅够定性互证；加密后可恢复窗口级 process↔inspection 双驱动联动统计。

**P2（条件触发/机会性）**
- **VLM 复检**：在具备视觉模型的环境重读 7 张 PNG，验证元数据判读（预期一致；`03_figures/visual_analysis.json` pipeline_warnings 已登记）。
- **体积记账核对**：向数据提供方确认 ≈17–26 L/h 恒定未记录净损失的口径（采样/蒸发/仿真体积记账），以完成 0.878 因子的归因闭环（M2 指出其分解不可由本数据单独证明）。
- **供氧监测增强（仅当工艺侧怀疑供氧时）**：加装 DO 冗余探针或将采样提升至分钟级以分辨 kLa 动态。

**证伪条件（任一触发即重启诊断，`04_diagnostics/diagnosis.json` falsification_conditions）**
1. 任一阶段内部出现配方外持续水平偏移（执行量未变而被控量/状态量持续偏离带或轨迹）；
2. P 线性段出现 recipe 外斜率断裂，或在线/离线 P 互证偏差 >5%；
3. DO 跌破 ~2–5 mg/L 或尾气 O2 分数塌陷；
4. Wt–V 冗余或气体衡算方向对在任一阶段持续发散；
5. 去趋势后任一强相关（|r|≥0.5）指向非衡算、非冗余过程对。

---

## 9. 方法学说明与局限

- **方法**：本体引导的竞争假设协议（假设→判别力评估→定量排除→结论三态输出）；反伪因果四道闸（去趋势混杂、留一法离群杠杆、Simpson 分层、滞后补偿 CCF）；阶段语义先行（跨阶段水平差不计异常，故障假设全部在阶段内部评估）；本体-数据-物理四要素证明（功能形式/滞后/量级/方向）；Data Truth Mandate 双重复算（诊断人 + 物理审计，`05_review/optimizer_preflight.md` V1–V14）。
- **局限（不可在本批数据内消除）**：单批运行无重复，批间变异不可估计，结论显式限定于本批；0.2 h 采样无法分辨亚小时滞后结构（如 kLa 快动态）；非 VLM 环境，视觉证据仅为元数据级（未伪造任何像素观察）；离线化验 20 点稀疏，双驱动 View B 降级为定性互证；临界氧 2.0 mg/L 取文献口径（保守取 5 mg/L 裕度仍 1.86×，判别方向不变，`04_diagnostics/confidence.json` assumptions）；阶段边界过渡带（±1–2 采样步）未做非线性建模。
- **表述修正记录**：本报告已按 `05_review/optimizer_preflight.md` 采纳 M1（validate_report 的变点 summary 字段计的是分析目标列数——本报告一律按"2 个分析目标、DO2 28 个变点、CER 111 个变点"的事件数口径表述）与 M2（0.878 因子归因为恒定未记录净损失、时序错位假设已被滞后检验否定），并按 `05_review/judge_feedback.json` 三条非阻断建议采用核实口径（变点、Spearman 分歧、Granger 备注）与 F3/F5/F6 表述规范（批末浓度行基准、P 斜率估计量、DO 加压自洽）。
- **下一步管线**：Step 7 物理终审（report-reviewer）→ Step 8/8.5/9 HTML 可视化与收尾。本报告为 Step 6 输出，供终审与 HTML 构建消费。
