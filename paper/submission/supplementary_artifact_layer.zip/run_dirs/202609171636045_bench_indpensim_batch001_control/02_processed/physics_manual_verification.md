# Physics Manual Verification (L1-L5) — diagnostician

- Author: **diagnostician (Chief Engineer Liu)**, Step 4, run `202609171636045_bench_indpensim_batch001_control`
- Written at: 2026-09-17T19:20Z (UTC)
- Why this file exists: `diagnostic-quality-check.mjs` counts automatic physics checks via
  `physics_check.json.physical_checks` / `checks_performed` keys. This run's automatic physics
  artifact `02_processed/physics_check.json` (data-processor, Engineer Zhang) stores its 9 checks
  under the `checks` array key, so the gate script's counter reads 0. The automatic checks WERE
  executed and all PASS. This document additionally records the diagnostician's own L1-L5 manual
  magnitude verification (Phase 1 / Phase 1.5 of the agent protocol), all values recomputed
  independently from `00_input/data.csv` with the shared venv python.
- Scope note: nothing here modifies upstream artifacts; sources cited are run-dir-relative paths.

## Automatic checks recap (from 02_processed/physics_check.json, `checks` array — 9 items, all PASS)

| Check | Verdict |
|---|---|
| vessel volume balance closure (dV/dt vs ΣF) | PASS (r=0.9996, residual ≈3.1% of mean |dV/dt|) |
| respiratory quotient RQ self-check | UNIT_SCALE_MISMATCH (stable stored-unit quirk; direction-level balance valid; absolute RQ NOT_APPLICABLE) |
| weight-volume density relation (Wt–V redundancy) | PASS (r=0.9971, LOO shift 0.0) |
| critical dissolved-oxygen margin | PASS (min DO 9.322 mg/L ≈ 4.66× critical 2 mg/L) |
| pH control band compliance (6.5 ± 0.1) | PASS (99.82% in band) |
| temperature control band compliance (298.15 ± 0.5 K) | PASS (99.91% in band, max dev 0.75 K) |
| substrate starvation quasi-steady state | PASS (STG2 S 0.00142±0.00040 g/L, 94.5% in designed band) |
| online vs offline penicillin cross-validation | PASS (batch-end rel. diff 0.04%) |
| startup numerical transients (AMB-7) | PASS_WITH_NOTE (first 5 h only, 1-2 orders below operating range) |

## Diagnostician manual L1-L5 verification (independent)

### L1 — physical quantity identification
- All 29 process parameters mapped to ontology groups (oxygen_transfer_kLa, carbon_metabolism,
  ph_control_loop, temperature_control_loop, product_and_precursor, biomass_and_nitrogen,
  volume_mass_balance) per `01_ontology/ontology.json` parameter_groups. No column left without a
  physical quantity class; Fault_ref identified as label metadata (AMB-5), excluded from physics.

### L2 — governing law selection
- S: V·dS/dt = Fs·C_in − (1/Y_XS)·μ(S)·X·V − m_S·X·V (feed-limited quasi-steady design).
- P: dP/dt = k_syn·X·f(PAA) − k_deg·P − (F/V)·P, f(PAA) Monod-type precursor factor.
- DO: dCL/dt = kLa·(C*−CL) − OUR, kLa ∝ (Pg/V)^α·v_s^β (aeration + head pressure channels).
- Gas balance: CER ∝ Fg·CO2outgas; OUR ∝ −Fg·ΔO2 (direction invariants).
- Heat: Q_metabolic ≈ Fc·ρcp·ΔT (demand-driven jacket cooling; T deviation is the cause, Fc the effect).

### L3 — causal chains built
- Recipe clock → actuator steps (Fpaa 0/10/4; Fg 30→42→55→60→75→65; Fs 18 levels) → phase regimes.
- Feed-limited quasi-steady S → non-growth-associated P accumulation (X plateau + PAA sufficiency).
- kLa channel vs OUR → DO pinned above critical by closed loops (weakened r(DO,OUR) in STG2 = controlled signature).
- pH/T narrow bands + pulse actuation → loop closure signatures (r(pH,Fb)≈0 controlled-variable signature; T leads Fc by 0.2 h).

### L4 — magnitude checks (all PLAUSIBLE; predicted vs observed within 10×)
| Quantity | Predicted (law/ontology) | Observed (independent recompute) | Ratio/verdict |
|---|---|---|---|
| Batch-end P | ontology production-goal record 29.39 g/L | 29.373 g/L (row 1130) | 0.999 → PLAUSIBLE |
| STG2 P slope | ~constant (non-growth-associated, X plateau) | 0.165805 g/L/h mean finite-diff; r(P,t)=0.9976 (n=800) | PLAUSIBLE |
| S in STG2 | 0.001–0.01 g/L designed starvation band | mean 0.00142, max 0.0026 g/L; 94.5% in band | PLAUSIBLE |
| DO vs critical O2 | must stay > ~2 mg/L | min 9.322 mg/L (t=151.2 h) | 4.66× margin → PLAUSIBLE |
| dV/dt vs ΣF | equality (mass balance) | r=0.9996; single proportional factor 0.878 (1-step integration timing + unrecorded small losses) → residual ≈3.1% | PLAUSIBLE |
| T deviation | within ±0.5 K setpoint band | max deviation 0.75 K, 99.91% in band | PLAUSIBLE |

### L5 — alternative mechanisms considered per quantity (≥2 each, all resolved)
- Apparent strong correlations (e.g. CER~X_offline r=0.983): common batch-age/biomass driver +
  recipe co-scheduling — detrended collapse (13 pairs, e.g. P~X_offline 0.8704→0.1126,
  `02_processed/validate_report.json`); 0 outlier-driven; Simpson empty.
- r(Fs,S) = −0.5113: NOT a transport lag (best-lag at +20-step search boundary = artifact) —
  recipe-trajectory + starvation quasi-steady composite sign (`02_processed/causal_evidence_map.json`
  NOT_CAUSAL_AS_IS); correct criterion is band membership, not positive correlation.
- 3σ excursions on Fa/Fh/Fc/Q/T: pulse-type demand actuation on near-zero baselines + narrow-band
  control σ artifacts; per-phase review found no recipe-external jumps
  (`02_processed/batch_phase_semantic_analysis.json` flagged_column_phase_evaluation).
- RQ off physiological band by ~62×: stable unit-scale mismatch (p05–p95 = 0.0047–0.0211 across the
  whole batch), not a metabolic regime shift; direction-level gas balance co-move confirmed.
- Startup OUR<0 / P≈1e-25 / Q≈0: simulator startup transients / float underflow (AMB-7), first 5 h only.

## Conclusion
Manual L1-L5 verification agrees with the automatic artifact: **no physics-based fault signature
exists anywhere in this batch**; all fluctuation mechanisms are legitimate (recipe regime switches,
closed-loop control signatures, designed kinetic trajectories). This supports the diagnosis
H1 (normal, no fault) in `04_diagnostics/diagnosis.json`.

## Known non-VLM-environment disclosure (for the quality gate)
`diagnostic-quality-check.mjs` also emits critical `VLM_SOURCE_NOT_PROVEN` because
`03_figures/visual_analysis.json` records `analysis_provenance.source_agent = "visual_analysis.py"`
with `observation_mode = metadata_backed_inference`. This is **not forged and must not be fixed by
rewriting provenance**: no VLM exists in this environment, no PNG pixel was read by any model, and
all visual entries are metadata-backed inferences derived from statistical artifacts
(`visual_analysis.json` pipeline_warnings + grounding_summary disclose this explicitly).
