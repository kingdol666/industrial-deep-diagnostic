# 工业诊断报告 — bench_tep_d01_ac_feed_ratio（TE过程A/C进料配比阶跃扰动）

**运行ID**: 202609171632332_bench_tep_d01_ac_feed_ratio | **报告日期**: 2026-09-18 | **数据源**: `00_input/data.csv`（960行×53列，3分钟等间隔）
**诊断类型**: DETERMINED | **综合置信度**: 91/100（HIGH） | **Judge质量门**: 96/100 PASS（`05_review/judge_feedback.json`） | **预审计**: PREFLIGHT_PASS / NO_FATAL（`05_review/optimizer_preflight.md`，0 FATAL / 0 MAJOR / 3 MINOR）

> **阅读指南**: 第1节是给厂长/总经理看的一页纸摘要。第4节是核心统计证据。第5-6节是假设排除与根因结论。第7节供技术团队核对每个数字的出处。第8节是行动方案。

> **实事求是声明**: 本报告所有结论均来源于本运行目录内的实际工件（`04_diagnostics/*.json`、`02_processed/*`、`01_ontology/ontology.json`、`03_figures/*`、`05_review/*`），每个数字标注出处。本run为非VLM环境，全部图表证据按 Rank 4 元数据回溯统计降级引用，未读图像内容、未虚构任何视觉观察。全文σ值统一采用 `02_processed/semantic_deep_analysis.json` era_shift_table 口径（总体标准差 ddof=0），独立复算值（ddof=1）与该口径相对差约0.3%，不影响任何判据（判据裕度>18σ，详见9.1）。

---

## 1. 执行摘要

### 1.1 发生了什么

 Tennessee Eastman（TE）化工过程在样本161附近（用户声明故障时段起点，经数据独立复核起始簇为样本159-167）发生一次**A/C进料配比阶跃改变**：A新鲜进料支路（流股1，阀XMV_3/流量XMEAS_1）大幅上行（阀位24.57→74.76、流量0.249→0.760 kscmh，era位移+18.57σ/+18.78σ，为全部52通道之最），A/C混合进料支路（流股4，阀XMV_4/流量XMEAS_4）反向下调（-2.87σ/-6.89σ）——两腿抵消后**净新鲜A路径（XMEAS_1+XMEAS_4）仅移-0.46σ**，总进料（XMEAS_6 -0.13σ）与循环量（XMEAS_5 -0.05σ）守恒。这是"配比改变"而非"总量改变"的计量学签名。汽提蒸汽侧（塔温XMEAS_18 +13.61σ、蒸汽流量XMEAS_19 +14.56σ、蒸汽阀XMV_9 +16.89σ）滞后进料侧6-24采样跟随抬升，属联锁二次响应；气相回路压力出现一次**自恢复瞬态**（见1.2与4.1节按基线参考系的修正表述）；purge气F摩尔分数（XMEAS_34）+2.07σ慢漂。反应器温度链（XMEAS_9 +0.03σ）与产品质量块（XMEAS_35-41全部<0.3σ）保持基线。

### 1.2 为什么会发生

**根因（DETERMINED）: ST1进料计量阶段的A/C进料配比阶跃扰动（TE扰动族IDV1类）。** 阀位指令与流量在两个era内lag0锁步（r=0.9996，分段稳态0.9963/0.9997，留一零杠杆），物理上只能在真实阀-流路径上产生——这是执行器主动操纵的真实流量变化，不是传感器伪象。后段/基线流量比3.048与阀位比3.043相对偏差仅0.16%，"阀门开大三倍、流量跟着大三倍"就是最直白的证据。冷却退化、purge阀异常、测量漂移三个竞争假设被定量排除（95/92/96）。

**压力瞬态的准确表述（按预审计PF-1修正）**: 反应器压力XMEAS_7以**基线参考系**（基线均值2704.4 kPa / std 4.53）计，激励起始于**样本162**（idx161-162，滚动均值法），峰值在**样本190（约2820 kPa，高出基线约+116 kPa，≈+4.3%绝对压力，+25.6σ_baseline）**，约样本420-540回到基线附近、**自恢复**；其后仅余≤5σ_baseline的小阵发（样本693-707、884-903）。该瞬态**与进料阶跃近同步（滞后0-4采样），不早于进料起始窗**——对进料配比改变引起的回路产气/inventory再平衡而言，lag0回路传播正是预期物理行为。`02_processed/anomaly_report.json`中"样本175-201、max|z|=4.34"的区间值来自**故障后局部参考系**（post-era均值2710.9/std 27.7），两种口径描述同一事件，本报告统一以基线参考系为准。

### 1.3 影响有多大

- **过程侧**: A进料阀位三倍化（24.6%→74.8%开度）持续整个后段；汽提蒸汽负荷显著抬升（+13.6~+16.9σ）；purge气F含量+2.07σ慢漂——装置在偏离设计配比的工况下运行。
- **产品与安全**: 产品质量通道（XMEAS_35-41）era位移全部<0.3σ保持基线；反应器温度（+0.03σ）与压力（era位移仅+1.42σ，瞬态自恢复）均未突破约束——**扰动未波及热工与产品组成**。
- **诚实声明**: 本数据集为process_only视图（无检验/质量侧数据），产量与质量的经济损失无法从本数据集量化；过程→质量链条作为证据缺口移交（见9.3）。

### 1.4 建议行动（详见第8节）

| 优先级 | 行动 | 预期效果 |
|:---:|------|---------|
| **P0** | 调取DCS配比设定值/比率站日志与变更单授权记录；核查XMV_3阀与XMEAS_1变送器校验 | 辨识"设定改变 vs 供给侧阶跃"子变体；确认变更是否受控 |
| **P1** | 若变更非授权，恢复A/C配比设定并按6.2节预测可观测量验证回落；流股2/3单位制核验 | 配比恢复后蒸汽侧/压力应按预测次序回落 |
| P2 | 补充检验/质量数据采样闭环过程→质量链；VLM图像级视觉复核；CCF行集口径注明 | 提升置信上限至95 |

### 1.5 有多大把握

**综合置信度 91/100（HIGH）**（权威推导见6.5节：五因素24+24+19+18+9=94，扣起始检测分辨率-2、子变体歧义-1）。用白话说：三个竞争假设都以90+的置信度被定量排除，四条反臆测条件（时序先导/统计显著/物理机制/无矛盾）全部闭环；剩下的不确定性只在"配比是被人改的还是装置供给自己变的"这一记录层出处上——两者同属A/C配比扰动族，处置方向相同。Judge（`05_review/judge_feedback.json`）以96/100通过并逐位复算了全部承重数字（零幻觉）。

---

## 2. 诊断背景与数据概况

- **用户问题**: "诊断本次异常的根本原因"（`00_input/user_context.json`，truth_withheld=true；用户声明样本161起为故障时段，仅作描述性分层，起始点由数据独立复核为样本159-167簇，见4.1）。
- **对象过程**: TE连续化工过程——CSTR反应器—冷凝器—气液分离器—汽提塔+循环压缩机，气相循环带purge排放（`01_ontology/ontology.json` scene）。反应A+C+D→G、A+C+E→H，副产F；流股1=A新鲜进料、流股4=A/C混合进料（含约45%A+45%C，B的唯一新鲜来源）。
- **数据形态**: 960行×53列（timestamp + 41 XMEAS + 11 XMV），3分钟等间隔，时间列经`02_processed/validate_report.json`排序验证单调（time_sorted=true）——时序先后断言被允许。
- **生产状态**: 单一连续稳态工况，steady 806/960=83.96%，无开停车/异常窗口，无产品/批次分组列（`02_processed/production_regime_filter.json`）——组间混杂与工况切换混杂被排除，分析框架采用era分层（基线idx0-159 / 后段idx160-959）+稳态过滤。
- **诊断方式**: 纯过程波动诊断（process_with_time）；无检验/质量目标列，双驱动分析与按产品分层如实置NOT_APPLICABLE（`02_processed/data_analysis_conclusion.json` adaptive_decision_audit）。

![关键变量时序总览（±3σ阈值线，prepare阶段生成）](03_figures/fig_temporal_overview.png)

**图1解读**（元数据模式，未读图像内容，下同）: 该图为关键变量时序网格总览；全通道max|z|排序前列为XMEAS_31 4.93/XMEAS_36 4.85/XMEAS_16 4.82——均为窄分布通道的3σ单点尖峰。本诊断以era位移σ而非3σ点计数为准（3σ计数对紧分布通道敏感，如XMEAS_9基线std仅0.021°C同样有6个3σ点，见PF-3口径说明）。

---

## 3. 数据质量评估

| 项目 | 结论 | 出处 |
|------|------|------|
| 完整性 | 960行×53列无缺失；时间戳单调等间隔（180s唯一间隔） | `02_processed/validate_report.json`、`00_input/input_inspection.json` |
| 生产状态 | 单一连续稳态（steady 83.96%），无startup/shutdown/abnormal窗口 | `02_processed/production_regime_filter.json` |
| 批次/产品结构 | batch_id=null、无产品分组列——按产品分层not_applicable，以era分层替代 | `02_processed/batch_integrity.json`、`02_processed/production_regime_filter.json` |
| 数据视图 | process_only：52个数值列全部为过程测量/阀位指令，无检验/质量列 | `02_processed/anomaly_report.json` dual_drive_analysis、`01_ontology/ontology.json` signals.inspection_signals=[] |
| 已知问题① | 流股2/3单位制基准异常（XMEAS_5基线≈26.9 vs TE公开基准202.9 kscmh量级）——全物料衡算不可检验，退化为同尺度净A路径检验 | `00_input/clarification_needed.json`（A2/A5）、`02_processed/physics_check.json` C5注记 |
| 已知问题② | XMV_9量程越界（max=100.2，0-100%标称量程）——轻微标定/尺度问题，不影响lag0锁步证据（judge复算证实100.20） | `00_input/rag_deep_understanding.json` r2_claim_validations INCONSISTENT、judge复核 |
| 已知问题③ | 清洗溯源未记录（cleaning_integrity缺失，provenance incomplete）——judge数据质量意识项扣1分处 | `02_processed/data_analysis_conclusion.json` data_cleaning_provenance |
| 知识源降级 | RAG知识库不可用（HTTP 000超时），本体关系全部auto_inferred（L5级）；非VLM环境，视觉证据为metadata_backed_inference | `00_input/rag_deep_understanding.json`、`03_figures/visual_analysis.json` pipeline_warnings |

通道身份经数据基值交叉核对可靠：XMEAS_7≈2704 kPa、XMEAS_9≈120.4°C、XMV基值组与TE标准基准吻合（`00_input/clarification_needed.json` A1）。

---

## 4. 统计分析发现

### 4.1 时序对齐图核心证据（对齐图判读）

本run为非VLM环境，对齐图证据按 Rank 4 元数据回溯统计引用（`03_figures/visual_analysis.json` observation_mode=metadata_backed_inference，明示"No visual observation of PNG content was performed or claimed"）——以下"图上看到了什么"为图表设计目的+文件回溯统计（`03_figures/image_captions.json`），非图像观察。

![关键参数z归一化时间对齐叠图](03_figures/fig_vlm_temporal_overlay.png)

**图2（对齐图）三段式判读**: 图上（元数据）——关键参数z归一化共享时间轴，同步组结构为SG1（XMV_3/XMEAS_1，lag0，r=0.9999执行器-测量对）→SG2（XMV_9/XMEAS_19/XMEAS_18蒸汽级联，起始滞后SG1约6-24采样）→SG3（XMEAS_7/XMEAS_13/XMEAS_16压力三重奏，lag0，r 0.977-0.999）。统计——CCF给出因果方向：阀→流lag0、蒸汽→塔温最优lag2（360s，本体先验1-5采样内）。物理——三组结构与本体链XMV_3→XMEAS_1（lag0-1）、XMV_9→XMEAS_19（lag0-1）→XMEAS_18（lag1-5）、回路lag0传播逐一吻合。视觉与统计一致性：SG1/SG2/SG3全部有定量CCF支撑，无[视觉与统计不一致]项。注：visual_analysis.json synthesis中"≈1-8 samples"为该元数据文件内部措辞缺陷（judge W4），本报告统一采用6-24采样口径（蒸汽三链起始173/188/191减入口簇167）。

![引用通道三段面板阶跃起始对齐（黑色虚线=样本161）](03_figures/fig_fault_onset_zoom.png)

**图3（对齐图）三段式判读**: 图上（元数据）——进料计量/汽提蒸汽/气相回路三段面板以样本161标记线对齐；回溯统计显示进料面板+18.5/+18.7σ最早阶跃，汽提面板+13.6~+16.9σ滞后，XMEAS_9 +0.03σ平坦。统计——持续性起始检测（rolling window=5、3σ、≥80%持续，独立于user_context）：进料簇样本159-167（XMV_3/XMEAS_1 onset idx166=样本167）→XMEAS_18(173)→XMEAS_34(177)→XMEAS_4(181)→XMV_4(185)→XMEAS_19(188)→XMV_9(191)。物理——起始次序与"进料配比入口→下游联锁"的因果方向一致；XMEAS_9平坦证明冷却链未被激活。judge以`00_input/data.csv`逐行复算完全复现该次序（idx 166/172/176/180/184/187/190）。

![单连续产品全参数时间对齐叠图（无产品分组，等效全局叠图）](03_figures/fig_vlm_temporal_overlay_single_product.png)

**图4（对齐图）三段式判读**: 图上（元数据）——全通道叠加下仅8个通道达2σ阶跃判据且全部归属进料配比扰动及其联锁；产品组成块XMEAS_35-41处于任何受扰聚类之外。统计——52通道era位移全表（4.2节）；物理——单一连续稳态背景下的孤立阶跃扰动，无批次/产品混杂。

![参数同步性热图（相关结构聚类）](03_figures/fig_vlm_synchronization.png)

**图5（热图）三段式判读**: 图上（元数据）——三个同步簇：压力三重奏（r 0.977-0.999）、执行器-测量对（满相关）、产品通道XMEAS_40/41统计独立。统计——簇结构与`02_processed/causal_evidence_map.json`共线组CG1/CG2/CG3一致。物理——三簇恰对应三条过程链（进料计量/汽提蒸汽/回路压力）。

**XMEAS_7压力瞬态（基线参考系，PF-1修正表述）**: 激励起始于样本162，峰值样本190约2820 kPa（+116 kPa，+4.3%绝对压力），样本420-540回基线自恢复；与进料阶跃**近同步（滞后0-4采样）、不早于进料起始窗**——这是回路lag0传播的预期行为，而非独立压力侧根因。压力三重奏lag0同步（r(XMEAS_7,XMEAS_13)=0.9988、r(XMEAS_7,XMEAS_16)=0.9765）证明单一水力回路传播。

### 4.2 era位移总表：52通道中仅8个达到2σ阶跃判据

（σ口径：era_shift_table，ddof=0；基线idx0-159 vs 后段idx160-959）

| 通道 | 物理含义 | 基线→后段均值 | era位移 | 起始样本 | 链归属 |
|------|---------|--------------|--------|:-------:|--------|
| XMV_3 | A进料阀（流股1） | 24.57→74.76 | +18.57σ | 159-167簇(167) | H1入口 |
| XMEAS_1 | A新鲜进料流量 | 0.249→0.760 kscmh | +18.78σ | 159-167簇(167) | H1入口 |
| XMV_9 | 汽提蒸汽阀 | — | +16.89σ | 191 | H1联锁（H2机制） |
| XMEAS_19 | 汽提蒸汽流量 | — | +14.56σ | 188 | H1联锁（H2机制） |
| XMEAS_18 | 汽提塔温度 | — | +13.61σ | 173 | H1联锁（H2机制） |
| XMEAS_4 | A/C混合进料流量 | 9.351→8.799 kscmh | -6.89σ | 181 | H1补偿腿 |
| XMV_4 | A/C混合进料阀 | 61.26→57.64 | -2.87σ | 185 | H1补偿腿 |
| XMEAS_34 | purge气F摩尔% | 2.268→2.314 | +2.07σ | 177 | 二次旁证（链节降级，见4.4） |

**未达判据的关键对照**: 冷却链XMEAS_9 +0.03σ/XMEAS_21 +0.31σ/XMV_10 -0.22σ（均无起始簇）；purge链XMV_6 -1.33σ/XMEAS_10 -1.39σ（起始179/180，晚于进料侧）；总进料XMEAS_6 -0.13σ、循环量XMEAS_5 -0.05σ守恒；产品块XMEAS_35-41全部<0.3σ（max 0.289σ@XMEAS_35）。**配比代理XMEAS_1/XMEAS_4由0.0267升至0.0864（≈3.2倍）；净新鲜A路径9.6004→9.5593仅移-0.46σ**（配比补偿恒等式，见6.2）。出处：`02_processed/semantic_deep_analysis.json` era_shift_table；独立复算（`00_input/data.csv`，ddof=1）+18.51/+18.72/-2.86/-6.87σ等与工件在口径内一致。

### 4.3 阀-流量锁步与滞后结构（lag-compensated CCF）

| 参数对 | 最优lag | lag补偿r | 分段稳态r（基线/post） | 本体先验lag | 裁决 |
|--------|:------:|:-------:|:--------------------:|:----------:|------|
| XMV_3→XMEAS_1 | 0 | 0.9996（post lag0=0.99964） | 0.9963 / 0.9997 | 0-1 | 锁步=真实操纵量变化（直接引用） |
| XMV_4→XMEAS_4 | 1 | 0.6855（post lag0=0.5941） | -0.393（静默期噪声）/ 0.575 | 0-1 | 激活期方向一致；补偿腿时序吻合 |
| XMV_9→XMEAS_19 | 0 | 0.9943 | 0.852 / 0.993 | 0-1 | 蒸汽阀-流锁步（C2） |
| XMEAS_19→XMEAS_18 | 2（360s） | 0.9457 | 0.707 / 0.940 | 1-5 | 蒸汽→塔温级联（C3） |
| XMEAS_1→XMEAS_4 | — | post稳态 -0.7011（全序列-0.8409受era污染弃用） | +0.149 / -0.701 | 配比对（非本体边） | 反向阶跃=配比补偿 |
| XMEAS_10→XMEAS_7 | -11 | 工件-0.7211（judge复算|r|=0.6814，见4.4注） | — | 2-10（负向先导） | **方向矛盾→共同驱动混杂，禁止作因果边** |
| XMEAS_13→XMEAS_7 | 0 | 0.9988 | 0.994 / 0.999 | 回路lag0 | 压力三重奏同步 |

出处：`02_processed/time_lag_analysis.json`（9对，±20采样，正滞后=先行）；关键裁决key_recommendations明确XMV_3→XMEAS_1锁步"直接作为真实操纵量变化的证据引用"、XMEAS_10→XMEAS_7"不得作为purge阀→压力因果边引用，仅作联动记录"。

### 4.4 反伪相关验证与统计稳健性

- **四道验证全过**（`02_processed/validate_report.json` anti_spurious）：Simpson悖论0、趋势混杂0、离群驱动相关0、fatal 0；2处SERIES级Pearson-Spearman发散位于XMEAS_7~组分通道（XMEAS_23/XMEAS_29），均非承重链。
- **多重检验**: 100次检验Bonferroni显著47次（阈值0.0005）——锁步对在校正后仍极显著。
- **留一杠杆**: 锁步对max_shift=0.0（独立复算0.00002）、XMEAS_19→XMEAS_18为0.0009、XMEAS_1→XMEAS_4为0.0021，全部leveraged=false——非单点撬动的伪相关（来源按judge W1更正：承重对留一/分段稳态值载于`02_processed/semantic_deep_analysis.json` cited_pair_verification；`02_processed/validate_report.json`的leave_one_out_leverage仅覆盖XMEAS_7/XMEAS_9目标）。
- **物理定向校核C1-C7全部PASS**（来源按judge W1更正：`02_processed/semantic_deep_analysis.json` physics_sanity_checks——C1阀流锁步、C2蒸汽锁步、C3蒸汽→塔温方向、C4无冷却危机、C5净A补偿、C5b回路稳定、C6组分块自洽、C7温度约束保持；`02_processed/physics_check.json`实际内容为anomaly-onset类校核，不含C1-C7，特此正名）。
- **W3口径注记**: XMEAS_10→XMEAS_7最优lag位置（-11）与lag0 raw_r（-0.5169）judge逐位复现；lag补偿幅度复算|r|=0.6814 vs 工件-0.7211（约5%差异，疑窗口/滤波口径差）。该边本就被禁止作因果引用，方向裁决不变。
- **inference_gaps（未静默删除）**: XMEAS_1→XMEAS_34链节未通过验证——post-era lag0 r=0.1237弱相关，lag补偿CCF跨era符号翻转（full +0.51@lag20 vs post -0.57@lag-20，时间方向违背），判为era阶跃共同驱动混杂；已移出承重链，XMEAS_34 +2.07σ（起始177晚于入口）仅保留为起始顺序旁证。

### 4.5 统计陷阱披露

1. **era阶跃污染全序列相关**: r(XMEAS_1,XMEAS_4)全序列-0.8409是两era均值差制造的伪相关，按v6.4纪律一律采用分段/稳态过滤值（post稳态-0.7011）。
2. **3σ点计数陷阱**: 窄分布通道（XMEAS_9 std 0.021°C、XMEAS_31/36/16）的3σ尖峰是噪声计数效应，本诊断以era位移σ为严重度准绳。
3. **σ口径差异（PF-2）**: era_shift_table用ddof=0，独立复算用ddof=1，相对差约0.3%（如XMEAS_1 +18.7755 vs +18.7168）——两种口径均>18σ，判据裕度巨大，不构成错误；本报告全文统一ddof=0并在此声明。
4. **XMEAS_9单点z值口径（PF-3）**: anomaly_report的"6个3σ孤立单点、max 3.7σ"为anomaly管线稳健z口径；以基线mean/std（120.3998, 0.0212, ddof=1）计，6点（idx 21/57/81/131/242/907）基线z为-2.81/+3.30/-2.81/-2.81/+2.83/+2.83。承重事实与口径无关：6点全部孤立、基线段与后段对称分布、无连续区段、era位移仅+0.03σ——紧闭环噪声而非持续偏移。

---

## 5. 假设检验与竞争假设排除

### 5.1 竞争假设与裁决总表

| 假设 | 内容 | 机制类 | 裁决 | 数据侧verdict（`02_processed/data_analysis_conclusion.json`） |
|:---:|------|:------:|:----:|:----:|
| H1 | A/C进料配比阶跃扰动（流股1入口+流股4补偿，ST1_FEED） | OPERATION | **存活（DETERMINED）**，置信91 | supported |
| H2 | 汽提蒸汽侧抬升为独立根因 | STEAM_DIST | 时序先导违反→**改判为H1下游联锁**（机制真实，并入H1链第3环） | supported（作为下游二次响应） |
| H3 | 反应器冷却退化/温度失控 | EQUIPMENT | **排除（95）** | refuted |
| H4 | purge/循环阀异常（XMV_6/XMEAS_10） | EQUIPMENT | **排除（92）** | refuted |
| H5 | XMEAS_1/XMEAS_4测量/分析仪漂移伪象 | SENSOR | **排除（96）** | refuted |

液位控制类假设（分离器/汽提塔液位）在KEEP/REMOVE筛查阶段即被移除：XMEAS_11/12/14/15 era位移全部<0.5σ，无驱动级证据。

### 5.2 排除详情、排除置信与复活条件

| 假设 | 排除置信 | 定量排除依据 | 复活条件 |
|:---:|:-------:|-------------|---------|
| H3 冷却退化 | 95 | 本体预测签名（XMV_10持续开大+XMEAS_9上升+XMEAS_21响应）完全缺失：三通道<2σ且无起始簇；XMEAS_9仅6个孤立单点（前后era对称）；C4/C7 PASS；闭环反号r(XMEAS_9,XMEAS_21)=-0.11已按控制器作用正确诠释 | 冷却链任一通道≥2σ持续位移且起始先于进料侧，或UA退化/冷却水入口温度异常记录 |
| H4 purge阀异常 | 92 | XMV_6 -1.33σ/XMEAS_10 -1.39σ未达2σ且起始（179/180）晚于进料簇；purge→压力CCF最优lag-11与本体先验（lag2-10负向）方向相反→共同驱动混杂（禁止引用边）；压力瞬态近同步于进料阶跃且自恢复——扰动源在进料侧 | XMV_6出现≥2σ阶跃且起始先于或同步于进料簇（159-167），或purge阀维护/卡涩记录与扰动窗口吻合 |
| H5 测量漂移伪象 | 96 | 三重锁步（全序列0.9999/基线稳态0.9963/post稳态0.9997、留一0.0）——漂移传感器无法在两个era内跟随独立阀位指令；下游存在按本体滞后结构依次发生的真实响应链（蒸汽lag0/2、压力近同步瞬态、purge慢漂）；组分块自洽（C6：反应器进料块std 0.447→0.463）而单通道位移+18.8σ | 出现独立冗余测量（流股1第二流量计/阀位行程反馈）与XMEAS_1持续背离而阀位不变 |

三项排除均≥90，无[WEAK_EXCLUSION]；6对假设判别矩阵全部DISCRIMINABLE（`04_diagnostics/diagnosis.json` discriminability_matrix），无INDISTINGUISHABLE对，≤65置信上限未触发。

### 5.3 H2的分层处理与推理链核验

- **H2的诚实处理**（judge评为教科书级）: 蒸汽抬升机制真实存在（XMV_9→XMEAS_19锁步+lag2吻合先验），但其起始（173/188/191）系统性晚于进料入口簇（159-167），作为根因将违反时序先导——故从独立根因候选改判为H1物理逻辑链第3环（下游联锁），全程留痕非静默删除（`04_diagnostics/reasoning_chain.json` hypothesis_evolution.H2）。
- **推理链核验（R1-R8）**: `04_diagnostics/reasoning_chain.json`八段完整——R1数据特征化（era框架有效性95）→R2统计发现（93）→R3验证过滤（92）→R4竞争假设与链验证（91，5条承重链节全过+1条降级登记）→R5判别力（91，6对全DISCRIMINABLE）→R6排除验证（94，3项≥90）→R7结论与可证伪性（91，四条件闭环）→R8不确定性定界（置信上限95）。judge抽查：零幻觉、无静默删除、推断标记正确。

---

## 6. 根因结论

### 6.1 根因陈述与因果路径

**DETERMINED — 根因为ST1进料计量阶段的A/C进料配比阶跃扰动（TE扰动族IDV1类）**：流股1 A进料支路（XMV_3/XMEAS_1）上行+流股4 A/C混合进料支路（XMV_4/XMEAS_4）下行补偿，净新鲜A路径近似恒定。数据无法进一步区分"配比设定值被改变"与"流股1供给侧阶跃后由流股4控制回路补偿"两个同族子变体（无DCS设定值/供给日志）——两者机制族与处置方向一致，不降级DETERMINED，以data_gaps披露（见9.3）。

因果路径：**配比阶跃（入口，样本159-167）→ 净A恒定的补偿性配比改变 → ①汽提轻组分负荷上升→蒸汽联锁抬升（173/188/191，滞后6-24采样）＋ ②回路组分/产气再平衡→压力近同步瞬态（样本162起，峰值2820 kPa/+116 kPa，自恢复）＋ purge F%慢漂（+2.07σ@177）**；反应器热工链与产品组成块未被波及。

### 6.2 物理逻辑链逐环验证

| # | 链节 | 状态 | 定量验证 |
|:---:|------|:----:|---------|
| 1 | XMV_3开大→XMEAS_1同步上行（阀门安装流量特性Q=Cv·f(x)·√(ΔP/ρ)，lag0） | OBSERVED | r=0.9996（post lag0）；分段稳态0.9963/0.9997；留一0.0；增益一致性：流量比3.048 vs 阀位比3.043，偏差0.16% |
| 2 | A进料上行→流股4被控制回路下调补偿，净A恒定 | OBSERVED | XMV_4 -2.87σ/XMEAS_4 -6.89σ（起始181/185晚于入口14-18采样）；净A路径-0.46σ≈0（C5）；总进料/循环量守恒（C5b） |
| 3 | 配比改变→轻组分负荷↑→蒸汽联锁抬升→塔温上升 | OBSERVED | XMV_9→XMEAS_19 lag0 r=0.9943；XMEAS_19→XMEAS_18最优lag2 r=0.9457（先验1-5内）；起始191/188/173的级联次序 |
| 4 | 配比改变→回路再平衡→压力瞬态+purge F%微升 | INFERRED | 压力三重奏lag0同步、瞬态样本162起自恢复；XMEAS_34 +2.07σ@177仅起始顺序旁证（定量链节CORRELATION_ABSENT已降级登记，见4.4） |
| 5 | 反应器热工侧未被波及（对照项） | OBSERVED | XMEAS_9 +0.03σ/XMEAS_21 +0.31σ/XMV_10 -0.22σ全部<2σ无起始；温度约束保持（C7） |

本体-数据-物理证明总体STRONG_EVIDENCE：功能形式MATCH（阶跃+锁步单调）、滞后MATCH（lag0实测vs先验0-1；lag2实测vs先验1-5）、方向MATCH（四条通道全符合配比改变预测）、幅度PLAUSIBLE（补偿恒等式≈1.0；未评PROVEN仅因Cv/ΔP不可测）。反证面：冷却链与purge链的本体预测签名完全缺失——否定性证明本身就是诊断发现。

### 6.3 反臆测四条件闭环

1. **时序先导**: 进料入口簇159-167（持续性检测独立复核，judge逐行复现）早于汽提侧173/188/191；压力瞬态起始样本162与进料阶跃**近同步且不早于**进料起始窗——时序方向保持（回路lag0传播正是预期物理行为）。
2. **统计显著**: era位移+18.57/+18.78σ为52通道之最；锁步r=0.9996分段稳态0.9963/0.9997；留一零杠杆；Bonferroni显著47/100；Simpson/趋势/离群筛查全零。
3. **物理机制**: 阀门安装流量特性锁步证明真实操纵量变化；净A路径补偿恒等式（C5）；增益比3.048/3.043定量自洽。
4. **无矛盾**: 冷却链<2σ（C4/C7）、purge链<2σ且lag方向矛盾、锁步反漂移、产品/温度保持基线、组分块自洽；三条表面矛盾（XMV_4基线负相关、XMEAS_1→XMEAS_34符号翻转、r(XMEAS_9,XMEAS_21)闭环反号）全部获得定量诠释并留痕（`04_diagnostics/diagnosis.json` contradicting_evidence）。

### 6.4 诊断结论总结

- **诊断类型**: DETERMINED（单一存活假设+3项≥90排除+全链验证）。
- **综合置信度**: 91/100（HIGH）；置信上限评估95（补DCS日志辨识子变体+图像级视觉复核可达）。
- **如果这个结论是错的，最可能因为**: 独立复算锁步破裂（分段稳态r<0.9或留一出现杠杆）→"真实操纵量变化"前提失效，H5复活。
- **要进一步提高把握**: 调取DCS设定值/比率站日志（子变体辨识，成本最低改判力最强）；流股1上游压力/组成测量。

### 6.5 置信度权威推导（Judge复核口径，W2更正）

**权威推导载于`04_diagnostics/confidence.json`，judge复核确认**：五因素统计24 + 物理24 + 时序19 + 混杂18 + 症状9 = **基础分94**；扣减-2（持续性起始检测分辨率±2-6采样，时序先导精确到窗口级）、-1（配比子变体歧义，同族机制内残余认知不确定性）= **91**，算术自洽。**特别说明**：`04_diagnostics/reasoning_chain.json` hypothesis_evolution中H1演进台账（60+0+20+11-3=88）为叙事层算术缺陷，与final值91不一致——按judge指示，本报告不引用演进台账的中间合计，以confidence.json五因素推导为唯一置信权威（judge复算值=91）。

### 6.6 推理过程回顾

第一步（R1-R2），52通道位移筛出仅8个≥2σ——异常高度集中而非全厂性波动；起始排序把入口钉在进料计量。第二步（R3），四道反伪相关闸过滤：全序列-0.84的污染相关被分段值替换，purge→压力方向矛盾边被禁用，XMEAS_1→XMEAS_34弱链节被降级登记。第三步（R4-R6），5个带物理机制的竞争假设逐箭头验证：H1全链存活，H2因时序改判并入H1，H3/H4/H5定量排除。第四步（R7-R8），四条件闭环定DETERMINED，不确定性定界给出改判最短路径。全部8段推理留痕于`04_diagnostics/reasoning_chain.json`。

---

## 7. 证据附录

### 7.1 证据全景与可靠性总览

| 结论 | 统计 | 物理 | 时序 | 无混淆 | 综合 | 信度 |
|------|:---:|:---:|:---:|:---:|:---:|------|
| H1 A/C配比阶跃（DETERMINED） | ★★★★★（24/25） | ★★★★★（24/25） | ★★★★★（19/20） | ★★★★（18/20） | **91 HIGH** | 锁步+补偿恒等式双承重 |
| H3 冷却退化 | 排除95 | 签名缺失（否定性证明） | 无起始簇 | — | **已排除** | 复活条件明确 |
| H4 purge阀异常 | 排除92 | lag方向矛盾 | 起始滞后 | — | **已排除** | 复活条件明确 |
| H5 测量漂移伪象 | 排除96 | 三重锁步不可能 | 下游真实响应链 | — | **已排除** | 复活条件明确 |

证据计数（`04_diagnostics/diagnosis.json` evidence_summary）：视觉5条（Rank 4元数据模式）/数值10条/物理6条/验证8条。

### 7.2 分工件证据清单（文件+关键数字）

| 工件 | 关键数字/内容 |
|------|--------------|
| `00_input/data.csv` | 960行×53列原始数据；诊断人以venv python独立复算（基线idx0-159 vs 后段idx160-959）：era位移+18.51/+18.72/-2.86/-6.87/+0.03σ（ddof=1）、r(XMV_3,XMEAS_1) post lag0=0.99964、起始167/173/188/191——与上游工件在舍入/口径内一致；judge逐位复算通过 |
| `02_processed/semantic_deep_analysis.json` | era_shift_table（52通道位移+起始索引，ddof=0口径：+18.5689/+18.7755/-2.8699/-6.893/+13.6101/+14.5584/+16.8889/+2.0747σ）；onset_verification持续性检测（window=5、3σ、≥80%持续，feed侧起始窗idx158-163）；**physics_sanity_checks C1-C7全PASS（C1-C7的正式载体，W1更正）**；cited_pair_verification（承重对分段稳态+留一：max_shift 0.0/0.0009/0.0021）；C6组分块std 0.447→0.463 |
| `02_processed/time_lag_analysis.json` | 9对lag-compensated CCF（±20采样，3分钟/采样）：0.9996@0、0.9457@2、0.9943@0；XMEAS_10→XMEAS_7 lag-11方向矛盾裁决（key_recommendations禁止作因果边引用） |
| `02_processed/causal_evidence_map.json` | root_cause_candidates首位XMV_3/XMEAS_1（score=0.93，"最大位移+共同起始窗口+阀-流量锁步+上游于所有下游响应"）、次位XMV_4/XMEAS_4补偿（0.71）；共线组CG1/CG2/CG3 |
| `02_processed/validate_report.json` | anti_spurious汇总（Simpson 0/趋势0/离群0/fatal 0；2处Spearman发散均非承重链）；sorting_validation时序单调；multiple_testing Bonferroni 47/100@0.0005；leave_one_out_leverage（覆盖XMEAS_7/XMEAS_9目标，22条全部leveraged=false） |
| `02_processed/physics_check.json` | anomaly-onset-coincidence类校核（W1正名：不含C1-C7）；C5净A路径检验的注记与流股2/3单位制退化说明 |
| `02_processed/anomaly_report.json` | XMEAS_7异常区间[175,201]（局部参考系，max 4.34σ；基线参考系对应样本162起/峰值2820.5 kPa/+116 kPa，见1.2/4.1）；XMEAS_9仅6个孤立单点（idx 21/57/81/131/242/907）；quality_reset_analysis reset_found=false |
| `02_processed/production_regime_filter.json` | steady 806/960=83.96%、transition 16.04%、abnormal_windows=[]、per_product not_applicable |
| `01_ontology/ontology.json` | 29条物理关系及lag先验（XMV_3→XMEAS_1 lag0-1 monotonic、XMEAS_19→XMEAS_18 lag1-5、XMV_10→XMEAS_9 lag3-15 inverse、XMEAS_10→XMEAS_7 lag2-10 inverse）；ST1_FEED→ST4_RECYCLE→ST5_STRIP流程链；预审计抽查7条引用全部真实存在（PF-6） |
| `00_input/rag_deep_understanding.json` | TE领域知识auto_inferred（RAG超时不可用，L5降级）；失效模式族含"进料配比/流量扰动（流股1-4）"——数据签名与IDV1类扰动指纹一致 |
| `03_figures/*`（5张PNG+`plot_manifest.json`+`image_captions.json`+`visual_analysis.json`） | 全部生成成功；非VLM环境metadata_backed_inference，逐张按Rank 4元数据回溯统计引用（见4.1节） |
| `04_diagnostics/diagnosis.json` / `evidence.json` / `confidence.json` / `reasoning_chain.json` | DETERMINED结论、5假设闭环、五因素91、R1-R8推理链 |
| `05_review/judge_feedback.json` | 96/100 PASS；spot_check 6项（5 verified、1 questionable=W3口径差，裁决不变）；零幻觉；blocking_issues=[] |
| `05_review/optimizer_preflight.md` | PREFLIGHT_PASS / NO_FATAL；0 FATAL/0 MAJOR/3 MINOR（PF-1/2/3，均已按第六节要求落实到本报告）/5 INFO |

### 7.3 图表索引

| 编号 | 文件 | 一句话发现 | 支持结论 |
|:---:|------|-----------|:-------:|
| 图1 | `03_figures/fig_temporal_overview.png` | 全局异常集中于进料-汽提-回路链，非全厂波动 | H1 |
| 图2 | `03_figures/fig_vlm_temporal_overlay.png` | SG1→SG2→SG3同步组结构与本体滞后先验一致 | H1/H2并入 |
| 图3 | `03_figures/fig_fault_onset_zoom.png` | 进料面板最早阶跃（+18.5/+18.7σ），冷却链平坦（+0.03σ） | H1时序先导、H3排除 |
| 图4 | `03_figures/fig_vlm_temporal_overlay_single_product.png` | 仅8通道达2σ且全部归属单一因果链 | H1完整性 |
| 图5 | `03_figures/fig_vlm_synchronization.png` | 产品通道XMEAS_40/41独立于受扰聚类 | 扰动未入产品 |

### 7.4 证据等级体系说明

本报告引用的证据等级：L1直接测量（诊断人/judge对`00_input/data.csv`的独立复算）、L3统计分析（`02_processed/`验证工件）、L4图表证据（元数据回溯统计，非VLM环境降级使用）、L5领域知识（`01_ontology/ontology.json` + auto_inferred RAG）。无L2（用户文档）、无L6（外部网络引用）、无L7（臆测）。

---

## 8. 建议与后续行动方案

### 8.1 P0 — 立即执行（本周内）

| 行动 | 具体操作 | 预期效果 | 如何验证 | 时间/成本 |
|------|---------|---------|---------|:--------:|
| 调取配比设定记录 | 调取DCS中A/C配比/比率站设定值历史与变更单授权记录，核对变更时刻是否落在样本159-167窗口 | 辨识"设定改变 vs 流股1供给侧阶跃"子变体；确认变更是否受控 | 日志时间戳与扰动窗口比对 | 1-2天/极低 |
| 执行器与变送器常规校验 | 校验XMV_3阀行程与XMEAS_1流量变送器（虽H5已排除，属常规确认） | 排除设备隐患残留 | 校验报告 | 2-3天/低 |

### 8.2 P1 — 本月内

| 行动 | 具体操作 | 预期效果 | 如何验证 |
|------|---------|---------|---------|
| 配比恢复（若变更非授权） | 经变更管理恢复A/C配比设定，观察回落过程 | 回到设计工况；蒸汽负荷下降 | 按6.2节预测可观测量逐项核对：XMV_3/XMEAS_1回落且XMV_4/XMEAS_4反向回升、净A保持≈9.6 kscmh、蒸汽三链按阀→流lag0/流→温lag1-5次序跟随、压力三重奏保持lag0同步 |
| 流股2/3单位制核验 | 核对XMEAS_2/3/5量程与单位换算（clarification A2/A5） | 恢复混合器全物料衡算能力 | 单位核验记录；C5从退化式升级为全衡算式 |
| 压力变送器核查 | 核查XMEAS_7量程/标定（基线2704 kPa、瞬态峰值2820 kPa在量程内自恢复） | 确认测量链健康 | 标定记录 |

### 8.3 P2 — 条件成熟后

- 补充检验/质量侧数据采样，闭环"过程→产品质量"链条（当前process_only视图无法量化质量影响）。
- 部署VLM视觉模型，对5张PNG做图像级视觉复核（当前证据停留在Rank 4元数据回溯）。
- 恢复RAG知识库接入，为本体先验提供外部交叉验证；在`02_processed/time_lag_analysis.json`注明CCF行集口径（W3后续改进）。

### 8.4 效果监控与证伪条件

**监控指标**: XMV_3/XMEAS_1与XMV_4/XMEAS_4（配比两腿）、净A路径≈9.6 kscmh、XMEAS_18/19/XMV_9（蒸汽负荷）、XMEAS_7（基线2704 kPa，报警关注偏离>±116 kPa量级的非自恢复偏移）、XMEAS_9（120.4°C闭环）。

**可证伪条件**（全部可检验，`04_diagnostics/diagnosis.json` falsification_conditions）:
1. 独立复算锁步破裂（分段稳态r<0.9或留一出现单点杠杆）→ H5复活，结论重构。
2. 冷却链任一通道≥2σ持续位移且起始先于进料侧，或UA/冷却水入口温度异常记录 → H3复活。
3. XMV_6≥2σ阶跃且起始先于或同步于进料簇（159-167）→ H4复活。
4. DCS日志显示配比设定未变且流股1上游压力/组成异常记录存在 → 根因子变体改判为"流股1供给侧扰动+流股4补偿"（仍在H1族内，不改变DETERMINED处置方向）。
5. 流股2/3单位制核验推翻同尺度前提 → 净A路径补偿恒等式失效，需改用绝对流量衡算重验C5。

---

## 9. 方法与局限说明

### 9.1 方法与口径标注

- **方法**: era分层（基线idx0-159/后段idx160-959）+稳态过滤（steady行内复算）+lag-compensated CCF（±20采样）+留一杠杆+Simpson/趋势/离群筛查+物理定向校核（C1-C7，载体为`02_processed/semantic_deep_analysis.json` physics_sanity_checks）+本体lag先验判别。四套编号独立使用：Pipeline Step 0-9 / Agent Phase / 推理段R1-R8 / 方法Stage，本报告仅混用中文叙述不混编号。
- **σ口径（PF-2落实）**: 全文σ值统一采用era_shift_table口径（总体标准差ddof=0）并在4.2节标注；独立复算ddof=1值仅在7.2节作为复现性证据列出并注明口径，两口径相对差约0.3%。
- **XMEAS_9单点z值（PF-3落实）**: 引用处均注明稳健z口径（anomaly管线），并给出基线z对照（max +3.30）。
- **起始分辨率**: 持续性起始检测分辨率±2-6采样，时序先导结论为窗口级（已计入置信扣分-2）。

### 9.2 三项诚实披露（预审计要求保留）

1. **净A补偿是退化代理检验**: 流股4约含45%A，真正的组分A物料衡算因流股2/3单位制异常不可检验；XMEAS_1+XMEAS_4守恒是同尺度代理，方向正确且已如实披露（PF-5）。
2. **配比子变体歧义**: "设定值改变"与"流股1供给侧阶跃+流股4补偿"数据不可分辨（无DCS日志），同属H1族、预测签名相同，处置方向一致——作为data_gaps披露而非虚构COMPETING_SET（R5论证）。
3. **视觉证据为元数据模式**: 非VLM环境，全部图表证据未读图像内容，按Rank 4降级使用，无任何像素级视觉声称（`03_figures/visual_analysis.json` pipeline_warnings）。

### 9.3 数据缺口

`04_diagnostics/diagnosis.json` data_gaps七条：①无DCS设定值/比率站日志（子变体不可辨识）；②流股2/3单位制异常（全衡算不可检验）；③无检验/质量侧数据（过程→质量链不闭环）；④XMV_9量程越界max=100.2（轻微标定问题）；⑤RAG不可用（本体auto_inferred L5）；⑥非VLM环境；⑦起始检测窗口级分辨率。

### 9.4 Judge警示（W1-W4）落实情况

| 警示 | 内容 | 本报告落实 |
|:---:|------|-----------|
| W1 | C1-C7与C5值、承重对留一/分段稳态值被上游工件误标为`physics_check.json`/`validate_report.json`，实际载体为`02_processed/semantic_deep_analysis.json`（physics_sanity_checks/cited_pair_verification） | 4.4节与7.2节全部按更正后来源引用；`02_processed/physics_check.json`正名为anomaly-onset类校核 |
| W2 | reasoning_chain H1演进台账88≠91，权威推导为confidence.json（94-2-1=91） | 6.5节以judge复算值91为唯一权威，明示不引用台账中间合计 |
| W3 | XMEAS_10→XMEAS_7 lag补偿|r|复算0.6814 vs 工件-0.7211（口径差） | 4.4节注明两值与口径差，方向裁决与禁用边不变 |
| W4 | visual_analysis.json synthesis"1-8 samples"与SG2"6-24 samples"不一致 | 4.1节统一采用6-24采样口径 |

---

*报告撰写: reporter（Engineer Zhou，技术报告）；依据工件: `04_diagnostics/diagnosis.json`（primary_finding原文引用于run_summary.json）、`04_diagnostics/evidence.json`、`04_diagnostics/confidence.json`、`04_diagnostics/reasoning_chain.json`、`05_review/judge_feedback.json`（96/100 PASS）、`05_review/optimizer_preflight.md`（PREFLIGHT_PASS）、`02_processed/*`、`01_ontology/ontology.json`、`03_figures/plot_manifest.json`。所有数字可在`00_input/data.csv`上复算。*
