# -*- coding: utf-8 -*-
"""
Step 2+2.5 context-builder: TE process ontology construction (ONTOLOGY_MODE=full, INTERACTION_MODE=auto).
RAG engine unavailable -> sanctioned fallback: parameter_to_physics.json pattern structure + standard
Tennessee-Eastman domain semantics (Downs & Vogel 1993 / Rieth et al. 2017 TEP dataset variable ordering),
cross-checked against the data's own base-case values. All derived numbers are recomputable from data.csv.
Outputs: 01_ontology/ontology.json, 01_ontology/schema.json, 00_input/clarification_needed.json,
         00_input/rag_deep_understanding.json
"""
import csv, json, math, os, shutil, statistics, datetime

RUN_DIR = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171632332_bench_tep_d01_ac_feed_ratio"
SKILL_SCHEMA = r"D:/codes/myskills/industrial-deep-diagnostic/.claude/skills/industrial-ontology-builder/schemas/ontology_schema.json"
DATA = os.path.join(RUN_DIR, "00_input", "data.csv")
FAULT_START_ROW = 161  # user_context.json: 故障时段自第161样本（8h）起 — used ONLY for segmentation, not as diagnostic evidence
BASE_N = FAULT_START_ROW - 1

# ---------- load data ----------
with open(DATA, "r", encoding="utf-8") as f:
    rdr = csv.reader(f)
    header = next(rdr)
    rows = [[float(v) if i > 0 else v for i, v in enumerate(r)] for r in rdr]
idx = {c: i for i, c in enumerate(header)}
n = len(rows)
ts = [datetime.datetime.strptime(r[0], "%Y-%m-%d %H:%M:%S") for r in rows]
dt_set = {(ts[i + 1] - ts[i]).total_seconds() for i in range(n - 1)}
SAMPLING_S = int(sorted(dt_set)[0]) if len(dt_set) == 1 else 180

def colstats(c):
    i = idx[c]
    base = [r[i] for r in rows[:BASE_N]]
    post = [r[i] for r in rows[BASE_N:]]
    allv = base + post
    sd = statistics.stdev(base) if len(base) > 1 else 0.0
    return {
        "b_mean": statistics.mean(base), "b_std": sd,
        "b_min": min(base), "b_max": max(base),
        "p_mean": statistics.mean(post),
        "a_min": min(allv), "a_max": max(allv),
    }

def r4(x):
    if x == 0 or not math.isfinite(x):
        return 0.0
    return round(x, -int(math.floor(math.log10(abs(x)))) + 3)

S = {c: colstats(c) for c in header if c != "timestamp"}

def behavior(col):
    s = S[col]
    dm = s["p_mean"] - s["b_mean"]
    sig = abs(dm) / s["b_std"] if s["b_std"] > 0 else 0.0
    tail = ("未见显著偏移（<2σ）；Stage-2统计验证由data-processor完成"
            if sig < 2 else
            "后段相对基线显著%s（%.1fσ）；Stage-2统计验证由data-processor完成" % ("上升" if dm > 0 else "下降", sig))
    return ("样本1-160基线均值=%s，样本161-960均值=%s（Δ=%+s，%.1fσ）→ %s"
            % (r4(s["b_mean"]), r4(s["p_mean"]), r4(dm), sig, tail))

def norm_range(col):
    s = S[col]
    if s["b_std"] > 0:
        lo, hi = s["b_mean"] - 3 * s["b_std"], s["b_mean"] + 3 * s["b_std"]
        lo, hi = max(lo, s["b_min"]), min(hi, s["b_max"])
    else:
        lo, hi = s["b_min"], s["b_max"]
    return [r4(lo), r4(hi)]

KS = "auto_inferred"
SRC = "标准TE过程变量语义（Downs & Vogel 1993 / Rieth et al. 2017 TEP数据集通道次序）+ 数据基值交叉核对；RAG引擎不可用（localhost:8764探测失败），回退路径按协议执行"

# ---------- variable definitions ----------
# (col, name, unit, physical_meaning, governing_law, expected_behavior, equipment, stage, group)
XMEAS_DEFS = [
    ("XMEAS_1", "A Feed (Stream 1) A进料流量", "kscmh", "组分A新鲜进料流量（流股1，经阀门XMV_3计量进入反应器进料混合器）", "阀门安装流量特性 Q=Cv·f(x)·√(ΔP/ρ)", "随XMV_3开度同向变化；基线近似恒定（流量控制回路）", "EQT_MIXER", "ST1_FEED", "feed_flows"),
    ("XMEAS_2", "D Feed (Stream 2) D进料流量", "kscmh", "组分D新鲜进料流量（流股2，反应物，参与生成G的反应A+C+D→G）", "阀门安装流量特性 Q=Cv·f(x)·√(ΔP/ρ)", "随XMV_1开度同向变化；基线近似恒定（流量控制回路）", "EQT_MIXER", "ST1_FEED", "feed_flows"),
    ("XMEAS_3", "E Feed (Stream 3) E进料流量", "kscmh", "组分E新鲜进料流量（流股3，反应物，参与生成H的反应A+C+E→H）", "阀门安装流量特性 Q=Cv·f(x)·√(ΔP/ρ)", "随XMV_2开度同向变化；基线近似恒定（流量控制回路）", "EQT_MIXER", "ST1_FEED", "feed_flows"),
    ("XMEAS_4", "A and C Feed (Stream 4) A/C混合进料流量", "kscmh", "A与C混合进料流量（流股4，含约45%A、45%C及少量B/D/E/F杂质）", "阀门安装流量特性 Q=Cv·f(x)·√(ΔP/ρ)", "随XMV_4开度同向变化；基线近似恒定（流量控制回路）", "EQT_MIXER", "ST1_FEED", "feed_flows"),
    ("XMEAS_5", "Recycle Flow (Stream 8) 循环气流量", "kscmh", "循环压缩机出口循环气流量（流股8，气相回路主体流量）", "回路压力平衡与压缩机特性曲线（转速/回流阀定泵功点）", "与XMV_5开度及回路压降相关；基线近似恒定", "EQT_COMPRESSOR", "ST4_RECYCLE", "gas_loop_flows"),
    ("XMEAS_6", "Reactor Feed Rate (Stream 6) 反应器进料总量", "kscmh", "反应器总进料流量（流股6=新鲜进料1-4+循环气8经混合器汇合）", "质量守恒：F6=ΣF_fresh(1-4)+F_recycle(8)", "等于各新鲜进料与循环气之和；进料阶跃时一阶响应", "EQT_REACTOR", "ST2_REACT", "gas_loop_flows"),
    ("XMEAS_7", "Reactor Pressure 反应器压力", "kPa", "反应器操作压力（气相回路背压，TE基准≈2705 kPa）", "气相理想气体定律 PV=nRT + 反应化学计量与purge/冷凝汇", "受进料量、反应速率、purge阀与冷凝负荷共同决定；安全上限约束", "EQT_REACTOR", "ST2_REACT", "pressures"),
    ("XMEAS_8", "Reactor Level 反应器液位", "%", "反应器液相料位（%量程，控制持液量/停留时间）", "反应器总物料衡算 A_vessel·dh/dt=F_in,liq−F_out,liq", "由出料（溢流/液位控制）保持；基线≈75%", "EQT_REACTOR", "ST2_REACT", "levels"),
    ("XMEAS_9", "Reactor Temperature 反应器温度", "degC", "反应器操作温度（TE基准≈120.4°C；强放热反应，温度控制关键被控变量）", "CSTR能量衡算 ρCp·V·dT/dt=ΣF_i·Cp(T_i−T)+Σ(−ΔH_r)r_r−UA(T−T_cw)", "由反应器冷却水阀XMV_10调控；与冷却负荷负相关平衡", "EQT_REACTOR", "ST2_REACT", "process_temperatures"),
    ("XMEAS_10", "Purge Rate (Stream 9) 排放流量", "kscmh", "循环气回路purge排放流量（流股9，排出轻组分/惰性物维持组分平衡）", "purge分流 F_purge=x_v·F_recycle（阀权分配）", "随XMV_6开度同向变化；基线≈0.337 kscmh", "EQT_RECYCLE", "ST4_RECYCLE", "gas_loop_flows"),
    ("XMEAS_11", "Product Separator Temperature 分离器温度", "degC", "气液分离器操作温度（冷凝器后闪蒸罐温度，TE基准≈80°C）", "闪蒸/VLE相平衡（Raoult定律）+ 冷凝器能量衡算", "受冷凝器冷却水阀XMV_11调控；影响气液分配与循环组成", "EQT_SEPARATOR", "ST3_SEPARATE", "process_temperatures"),
    ("XMEAS_12", "Product Separator Level 分离器液位", "%", "气液分离器液位（%量程，缓冲罐持液）", "分离器物料衡算 A·dh/dt=F_vap_in_cond−F_vap_out−F_underflow", "由底流阀XMV_7液位控制回路维持；基线≈50%", "EQT_SEPARATOR", "ST3_SEPARATE", "levels"),
    ("XMEAS_13", "Product Separator Pressure 分离器压力", "kPa", "气液分离器压力（TE基准≈2634 kPa，低于反应器压力）", "气相回路压降分布+冷凝后的气体体积收缩", "与反应器压力、压缩机压比联动；基线近似恒定", "EQT_SEPARATOR", "ST3_SEPARATE", "pressures"),
    ("XMEAS_14", "Product Separator Underflow (Stream 10) 分离器底流流量", "m3/h", "分离器底流液体流量（流股10，去汽提塔，TE基准≈25 m³/h）", "液位控制回路：阀门特性 Q=Cv·f(x)·√(ΔP/ρ)", "随XMV_7（液位控制器输出）反向于液位偏差动作；基线近似恒定", "EQT_SEPARATOR", "ST3_SEPARATE", "liquid_flows"),
    ("XMEAS_15", "Stripper Level 汽提塔液位", "%", "汽提塔塔釜液位（%量程）", "塔釜物料衡算 A·dh/dt=F_stream10+F_steam_cond−F_stream11", "由塔底采出阀XMV_8液位控制回路维持；基线≈51%", "EQT_STRIPPER", "ST5_STRIP", "levels"),
    ("XMEAS_16", "Stripper Pressure 汽提塔压力", "kPa", "汽提塔操作压力（TE基准≈3102 kPa）", "塔压由气相脱出量与下游管网压降决定", "随蒸汽量与塔内气速缓变；基线近似恒定", "EQT_STRIPPER", "ST5_STRIP", "pressures"),
    ("XMEAS_17", "Stripper Underflow (Stream 11) 塔底产品采出流量", "m3/h", "汽提塔底产品流量（流股11，最终产品G/H，TE基准≈23 m³/h）", "液位控制回路：阀门特性 Q=Cv·f(x)·√(ΔP/ρ)", "随XMV_8（液位控制器输出）动作；基线近似恒定", "EQT_STRIPPER", "ST5_STRIP", "liquid_flows"),
    ("XMEAS_18", "Stripper Temperature 汽提塔温度", "degC", "汽提塔温度（TE基准≈65.7°C，表征汽提蒸汽负荷与轻组分脱除）", "塔板能量衡算+汽提传质（Henry/Raoult平衡驱动）", "随蒸汽流量XMV_9/XMEAS_19同向变化；滞后1-5个采样", "EQT_STRIPPER", "ST5_STRIP", "process_temperatures"),
    ("XMEAS_19", "Stripper Steam Flow 汽提蒸汽流量", "kg/h", "进入汽提塔的蒸汽流量（TE基准≈230 kg/h，汽提能量来源）", "蒸汽阀门流量特性 Q=Cv·f(x)·√(ΔP/ρ)（可压缩修正）", "随XMV_9开度同向变化；基线近似恒定", "EQT_STRIPPER", "ST5_STRIP", "liquid_flows"),
    ("XMEAS_20", "Compressor Work 压缩机功耗", "kW", "循环压缩机轴功率（TE基准≈341 kW）", "压缩机功率 P∝ṁ·w_s，等熵功 w_s∝T_in[(P_out/P_in)^((γ-1)/γ)−1]", "随循环气量（XMV_5）与压比（回路压力分布）变化", "EQT_COMPRESSOR", "ST4_RECYCLE", "utility"),
    ("XMEAS_21", "Reactor Cooling Water Outlet Temp 反应器冷却水出口温度", "degC", "反应器冷却水回路出口温度（TE基准≈94.6°C，直接表征反应器取热负荷）", "换热器热量衡算 Q=ṁ_cw·Cp·(T_out−T_in)=UA·LMTD", "与反应温度/反应放热同向、与冷却水流量反向", "EQT_CW_RX", "ST2_REACT", "cooling_water_outlet_temps"),
    ("XMEAS_22", "Separator Cooling Water Outlet Temp 冷凝器冷却水出口温度", "degC", "冷凝器冷却水回路出口温度（TE基准≈77.3°C，表征冷凝负荷）", "换热器热量衡算 Q=ṁ_cw·Cp·(T_out−T_in)=UA·LMTD", "与分离器温度/冷凝负荷同向、与冷却水流量反向", "EQT_CW_COND", "ST3_SEPARATE", "cooling_water_outlet_temps"),
]
# composition blocks (mole %)
COMP_DEFS = []
STREAM6 = [("A", 23), ("B", 24), ("C", 25), ("D", 26), ("E", 27), ("F", 28)]
STREAM9 = [("A", 29), ("B", 30), ("C", 31), ("D", 32), ("E", 33), ("F", 34)]
STREAM11 = [("A", 35), ("B", 36), ("C", 37), ("D", 38), ("E", 39), ("G", 40), ("H", 41)]
for comp, i in STREAM6:
    COMP_DEFS.append(("XMEAS_%d" % i, "Reactor Feed Component %s (Stream 6) 反应器进料%s组分" % (comp, comp), "mole%",
        "反应器进料（流股6）中组分%s的摩尔分数。反应器进料=新鲜进料+循环气，组分由进料配比与回路组分平衡决定" % comp,
        "反应器物料衡算+循环组分平衡：dC_j/dt=(F_in·C_j,in−F_out·C_j_out−Σν_jr·r_r)/V", "随对应进料流量与purge量缓变；回路时间常数大（数个采样至数十采样）", "EQT_REACTOR", "ST2_REACT", "reactor_feed_composition"))
for comp, i in STREAM9:
    COMP_DEFS.append(("XMEAS_%d" % i, "Purge Component %s (Stream 9) 排放气%s组分" % (comp, comp), "mole%",
        "purge排放气（流股9）中组分%s的摩尔分数。purge位于循环气路上，其组成近似表征循环回路/反应器出口气相组成" % comp,
        "回路组分平衡：轻组分经purge排出，B/D/E/F在回路中富集程度由反应消耗与purge速率共同决定", "对进料配比与purge阀开度敏感，响应滞后（回路循环时间常数）", "EQT_RECYCLE", "ST4_RECYCLE", "purge_composition"))
for comp, i in STREAM11:
    COMP_DEFS.append(("XMEAS_%d" % i, "Product Component %s (Stream 11) 产品%s组分" % (comp, comp), "mole%",
        "塔底产品（流股11）中组分%s的摩尔分数。G/H为主产物（基准≈53.7%%/43.8%%），轻组分A/B/C/E为未脱净残留，D为未反应残留" % comp,
        "汽提塔级间平衡+反应化学计量（A+C+D→G，A+C+E→H）：产品G/H比由D/E进料比与反应选择性决定", "G/H为产品质量指标；对D/E进料配比与反应温度敏感，响应滞后大（全流程时间常数）", "EQT_STRIPPER", "ST5_STRIP", "product_composition"))

XMV_DEFS = [
    ("XMV_1", "D Feed Valve (Stream 2) D进料阀", "D进料流量控制回路的执行阀（操纵D进料流量XMEAS_2）", "EQT_MIXER", "ST1_FEED"),
    ("XMV_2", "E Feed Valve (Stream 3) E进料阀", "E进料流量控制回路的执行阀（操纵E进料流量XMEAS_3）", "EQT_MIXER", "ST1_FEED"),
    ("XMV_3", "A Feed Valve (Stream 1) A进料阀", "A进料流量控制回路的执行阀（操纵A进料流量XMEAS_1）", "EQT_MIXER", "ST1_FEED"),
    ("XMV_4", "A and C Feed Valve (Stream 4) A/C混合进料阀", "A+C混合进料流量控制回路的执行阀（操纵XMEAS_4）", "EQT_MIXER", "ST1_FEED"),
    ("XMV_5", "Compressor Recycle Valve 压缩机循环阀", "压缩机出口回流阀（调节循环气量/回路压力，影响XMEAS_5、XMEAS_20）", "EQT_COMPRESSOR", "ST4_RECYCLE"),
    ("XMV_6", "Purge Valve (Stream 9) 排放阀", "purge排放阀（操纵排放流量XMEAS_10，参与回路压力/组分控制）", "EQT_RECYCLE", "ST4_RECYCLE"),
    ("XMV_7", "Separator Underflow Valve (Stream 10) 分离器底流阀", "分离器液位控制回路的执行阀（操纵底流XMEAS_14）", "EQT_SEPARATOR", "ST3_SEPARATE"),
    ("XMV_8", "Stripper Underflow Valve (Stream 11) 塔底采出阀", "汽提塔液位控制回路的执行阀（操纵产品采出XMEAS_17）", "EQT_STRIPPER", "ST5_STRIP"),
    ("XMV_9", "Stripper Steam Valve 汽提蒸汽阀", "汽提蒸汽流量控制回路的执行阀（操纵蒸汽流量XMEAS_19）", "EQT_STRIPPER", "ST5_STRIP"),
    ("XMV_10", "Reactor Cooling Water Valve 反应器冷却水阀", "反应器温度控制回路的执行阀（操纵冷却水量，直接影响XMEAS_9/XMEAS_21）", "EQT_CW_RX", "ST2_REACT"),
    ("XMV_11", "Condenser Cooling Water Valve 冷凝器冷却水阀", "冷凝器冷却水阀（操纵冷凝负荷，影响XMEAS_11/XMEAS_22）", "EQT_CW_COND", "ST3_SEPARATE"),
]

def xmeas_signal(d):
    col, name, unit, mean_, law, expect, eq, st, grp = d
    s = S[col]
    return {
        "name": name, "column": col, "unit": unit, "role": "predictor",
        "physical_meaning": mean_, "physical_meaning_confidence": "INFERRED",
        "auto_inferred": True, "inference_basis": SRC,
        "normal_range": norm_range(col),
        "governing_law": law, "expected_data_behavior": expect,
        "observed_data_behavior": behavior(col), "behavior_match": "UNVERIFIED",
        "knowledge_source": KS, "equipment_ref": eq, "stage_ref": st,
    }

def xmv_signal(d):
    col, name, mean_, eq, st = d
    s = S[col]
    return {
        "name": name, "column": col, "unit": "%", "role": "control",
        "physical_meaning": mean_ + "。取值为阀门开度指令（0-100%）",
        "physical_meaning_confidence": "INFERRED",
        "auto_inferred": True, "inference_basis": SRC,
        "control_type": "output", "setpoint": r4(s["b_mean"]),
        "controlled_by": "过程控制系统（TE基准控制结构对应回路）",
        "governing_law": "阀门安装流量特性 Q=Cv·f(x)·√(ΔP/ρ)",
        "expected_data_behavior": "基线近似恒定于基准开度；控制回路重新整定或强扰动时呈阶跃/斜坡",
        "observed_data_behavior": behavior(col), "behavior_match": "UNVERIFIED",
        "knowledge_source": KS, "equipment_ref": eq, "stage_ref": st,
    }

process_parameters = [xmeas_signal(d) for d in XMEAS_DEFS] + [xmeas_signal(d) for d in COMP_DEFS]
control_variables = [xmv_signal(d) for d in XMV_DEFS]

ontology = {
    "scene": {
        "name": "bench_tep_d01_ac_feed_ratio",
        "process_type": "连续化工过程（Tennessee Eastman 挑战过程）：CSTR反应器—冷凝器—气液分离器—汽提塔+循环压缩机，气相循环带purge排放",
        "production_goal": "以A、C、D、E为主要原料（B为流股4带入的杂质）经反应 A+C+D→G、A+C+E→H（副反应 A+B→F、3D→2F）连续生产G/H，产品经汽提塔底（流股11）采出；通过purge（流股9）排出轻组分维持回路稳定，并保证反应器温度/压力在安全约束内",
        "equipment": [
            {"id": "EQT_MIXER", "name": "进料混合器", "type": "static_mixer", "function": "汇合新鲜进料（流股1-4）与循环气（流股8）形成反应器进料（流股6）"},
            {"id": "EQT_REACTOR", "name": "反应器（CSTR）", "type": "continuous_stirred_tank_reactor", "function": "气液两相强放热反应生成产物G/H（副产F），带搅拌与冷却水夹套取热，压力/液位/温度为关键被控变量"},
            {"id": "EQT_CONDENSER", "name": "冷凝器", "type": "water_cooled_condenser", "function": "冷却反应器出口气相，冷凝产物G/H及可凝组分，供气液分离（冷却水阀XMV_11）"},
            {"id": "EQT_SEPARATOR", "name": "气液分离器（闪蒸罐）", "type": "flash_separator", "function": "将冷凝后物料分为气相（去压缩机循环）与液相（底流流股10去汽提塔）"},
            {"id": "EQT_COMPRESSOR", "name": "循环压缩机", "type": "centrifugal_compressor", "function": "将分离器气相增压返回反应器，维持气相循环（功耗XMEAS_20，回流阀XMV_5）"},
            {"id": "EQT_RECYCLE", "name": "循环气路与purge管线", "type": "gas_recycle_loop", "function": "循环气回路；经purge阀XMV_6排放流股9以排出轻/惰性组分，维持回路组分与压力平衡"},
            {"id": "EQT_STRIPPER", "name": "汽提塔", "type": "steam_stripping_column", "function": "以蒸汽（XMV_9）汽提分离器底流中的轻组分（A/B/C/E等）返回气相回路，塔底采出产品G/H（流股11）"},
            {"id": "EQT_CW_RX", "name": "反应器冷却水回路", "type": "cooling_water_circuit", "function": "带走反应器反应热（出口温度XMEAS_21表征取热负荷）"},
            {"id": "EQT_CW_COND", "name": "冷凝器冷却水回路", "type": "cooling_water_circuit", "function": "为冷凝器提供冷量（出口温度XMEAS_22表征冷凝负荷）"},
        ],
        "stages": [
            {"id": "ST1_FEED", "name": "进料计量与混合", "sequence": 1, "typical_duration": "连续", "key_physics": "阀门安装流量特性 Q=Cv·f(x)·√(ΔP/ρ)；混合器质量守恒 F6=ΣF_fresh+F_recycle", "key_parameters": ["XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4", "XMV_1", "XMV_2", "XMV_3", "XMV_4"]},
            {"id": "ST2_REACT", "name": "反应（CSTR）", "sequence": 2, "typical_duration": "连续（停留时间由液位与出料决定）", "key_physics": "Arrhenius动力学 r=k0·exp(−E/RT)·ΠC_j；CSTR质量/能量衡算；反应 A+C+D→G、A+C+E→H、A+B→F、3D→2F 均为放热反应", "key_parameters": ["XMEAS_6", "XMEAS_7", "XMEAS_8", "XMEAS_9", "XMEAS_21", "XMV_10", "XMEAS_23", "XMEAS_24", "XMEAS_25", "XMEAS_26", "XMEAS_27", "XMEAS_28"]},
            {"id": "ST3_SEPARATE", "name": "冷凝与气液分离", "sequence": 3, "typical_duration": "连续", "key_physics": "VLE相平衡（Raoult定律）与闪蒸物料/能量衡算；冷凝器换热 Q=UA·LMTD=ṁ_cw·Cp·ΔT", "key_parameters": ["XMEAS_11", "XMEAS_12", "XMEAS_13", "XMEAS_14", "XMEAS_22", "XMV_7", "XMV_11"]},
            {"id": "ST4_RECYCLE", "name": "气相循环与purge排放", "sequence": 4, "typical_duration": "连续", "key_physics": "压缩机等熵功 w_s∝T_in[(P_out/P_in)^((γ-1)/γ)−1]；回路压力平衡；组分平衡由purge速率决定（轻组分排放、反应物/杂质在回路富集）", "key_parameters": ["XMEAS_5", "XMEAS_10", "XMEAS_20", "XMV_5", "XMV_6", "XMEAS_29", "XMEAS_30", "XMEAS_31", "XMEAS_32", "XMEAS_33", "XMEAS_34"]},
            {"id": "ST5_STRIP", "name": "汽提与产品采出", "sequence": 5, "typical_duration": "连续", "key_physics": "蒸汽汽提传质（Henry/Raoult平衡驱动）；塔釜物料/能量衡算；产品G/H比反映D/E进料配比与反应选择性", "key_parameters": ["XMEAS_15", "XMEAS_16", "XMEAS_17", "XMEAS_18", "XMEAS_19", "XMV_8", "XMV_9", "XMEAS_35", "XMEAS_36", "XMEAS_37", "XMEAS_38", "XMEAS_39", "XMEAS_40", "XMEAS_41"]},
        ],
        "objectives": [
            "诊断本次运行异常时段（自样本161起）的根本原因",
            "维持反应器温度（XMEAS_9）与压力（XMEAS_7）在安全约束内",
            "维持产品流量与质量（XMEAS_17、产品G/H组成XMEAS_40/41）稳定",
        ],
    },
    "signals": {
        "inspection_signals": [],
        "process_parameters": process_parameters,
        "control_variables": control_variables,
        "events": [],
        "metadata_columns": [
            {"name": "时间戳", "column": "timestamp", "role": "timestamp", "description": "3分钟等间隔采样时间戳（%Y-%m-%d %H:%M:%S），共960个样本"}
        ],
    },
    "parameter_groups": {
        "feed_flows": ["XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4"],
        "gas_loop_flows": ["XMEAS_5", "XMEAS_6", "XMEAS_10"],
        "pressures": ["XMEAS_7", "XMEAS_13", "XMEAS_16"],
        "levels": ["XMEAS_8", "XMEAS_12", "XMEAS_15"],
        "process_temperatures": ["XMEAS_9", "XMEAS_11", "XMEAS_18"],
        "cooling_water_outlet_temps": ["XMEAS_21", "XMEAS_22"],
        "liquid_flows": ["XMEAS_14", "XMEAS_17", "XMEAS_19"],
        "utility": ["XMEAS_20"],
        "reactor_feed_composition": ["XMEAS_%d" % i for _, i in STREAM6],
        "reactor_feed_composition_topology": ["order=A,B,C,D,E,F", "topology=same stream 6 parallel analyzer channels, not spatial zones"],
        "purge_composition": ["XMEAS_%d" % i for _, i in STREAM9],
        "product_composition": ["XMEAS_%d" % i for _, i in STREAM11],
        "feed_valves": ["XMV_1", "XMV_2", "XMV_3", "XMV_4"],
        "gas_loop_valves": ["XMV_5", "XMV_6"],
        "liquid_valves": ["XMV_7", "XMV_8"],
        "utility_valves": ["XMV_9", "XMV_10", "XMV_11"],
    },
    "relationships": [],
    "confounders": [
        {"variable": "冷却水入口温度（未测量）", "why": "同时影响反应器/冷凝器冷却能力、XMV_10/XMV_11阀位与XMEAS_21/XMEAS_22出口温度，是冷却相关通道的公共混杂因素", "controlled": False},
        {"variable": "换热器结垢/传热系数UA退化（未测量）", "why": "同时推高反应器温度与冷却水阀开度、改变冷凝负荷分配，可伪装成进料/反应侧异常", "controlled": False},
        {"variable": "催化剂活性/动力学参数漂移（未测量，TE仿真中通常恒定）", "why": "同时改变反应放热、转化率与产品组成", "controlled": False},
        {"variable": "环境/大气条件（未测量）", "why": "影响冷却水系统与空冷效率的缓变共同因素", "controlled": False},
    ],
    "metadata": {
        "units": {"timestamp": "YYYY-MM-DD HH:MM:SS"},
        "sampling_rate": "%d s（3分钟等间隔）" % SAMPLING_S,
        "batch_id": None,
        "timezone": None,
        "start_time": ts[0].strftime("%Y-%m-%dT%H:%M:%S"),
        "end_time": ts[-1].strftime("%Y-%m-%dT%H:%M:%S"),
        "product_grades": [],
    },
}
ontology["metadata"]["units"].update({c: u for c, u in
    [(d[0], d[2]) for d in XMEAS_DEFS] + [(d[0], "mole%") for d in COMP_DEFS] + [(d[0], "%") for d in XMV_DEFS]})

# ---------- relationships (physics-based; no RAG available) ----------
def rel(frm, to, typ, strength, mechanism, lag, eq, form):
    return {
        "from": frm, "to": to, "type": typ, "strength": strength,
        "mechanism": mechanism, "time_lag": lag, "inferred": True,
        "governing_equation": eq, "predicted_functional_form": form,
        "rag_validated": False, "data_direction_validated": "untested",
        "lag_detection_method": "physics_prior_only", "lag_agreement": "not_tested",
    }
ontology["relationships"] = [
    rel("XMV_3", "XMEAS_1", "causal", "strong", "阀门开度→A进料流量（安装流量特性）", "≈0-1个采样（0-3min）", "Q=Cv·f(x)·√(ΔP/ρ)", "monotonic"),
    rel("XMV_1", "XMEAS_2", "causal", "strong", "阀门开度→D进料流量", "≈0-1个采样（0-3min）", "Q=Cv·f(x)·√(ΔP/ρ)", "monotonic"),
    rel("XMV_2", "XMEAS_3", "causal", "strong", "阀门开度→E进料流量", "≈0-1个采样（0-3min）", "Q=Cv·f(x)·√(ΔP/ρ)", "monotonic"),
    rel("XMV_4", "XMEAS_4", "causal", "strong", "阀门开度→A/C混合进料流量", "≈0-1个采样（0-3min）", "Q=Cv·f(x)·√(ΔP/ρ)", "monotonic"),
    rel("XMV_6", "XMEAS_10", "causal", "strong", "purge阀开度→排放流量", "≈0-1个采样（0-3min）", "F_purge=x_v·F_recycle", "monotonic"),
    rel("XMV_5", "XMEAS_5", "causal", "moderate", "压缩机回流阀开度→有效循环气量", "≈0-3个采样", "压缩机特性曲线+回路压力平衡", "monotonic"),
    rel("XMV_5", "XMEAS_20", "causal", "moderate", "回流阀开度改变压缩机工况点→轴功率变化", "≈0-3个采样", "P=ṁ·w_s，w_s∝T_in[(P_r)^((γ-1)/γ)−1]", "monotonic"),
    rel("XMV_7", "XMEAS_14", "causal", "strong", "分离器底流阀开度→底流流量（液位控制回路输出）", "≈0-1个采样", "Q=Cv·f(x)·√(ΔP/ρ)", "monotonic"),
    rel("XMV_8", "XMEAS_17", "causal", "strong", "塔底采出阀开度→产品流量（液位控制回路输出）", "≈0-1个采样", "Q=Cv·f(x)·√(ΔP/ρ)", "monotonic"),
    rel("XMV_9", "XMEAS_19", "causal", "strong", "蒸汽阀开度→汽提蒸汽流量", "≈0-1个采样", "Q=Cv·f(x)·√(ΔP/ρ)（可压缩修正）", "monotonic"),
    rel("XMV_10", "XMEAS_9", "causal", "strong", "冷却水阀开度↑→反应器取热↑→反应器温度↓（负向）", "≈3-15个采样（热容惯性）", "ρCp·V·dT/dt=ΣQ_react−UA(T−T_cw)", "inverse"),
    rel("XMV_10", "XMEAS_21", "causal", "moderate", "冷却水量↑→同等热负荷下出口水温↓（负向）", "≈1-3个采样", "Q=ṁ_cw·Cp·(T_out−T_in)", "inverse"),
    rel("XMEAS_9", "XMEAS_21", "causal", "moderate", "反应温度↑→反应放热与器壁温差↑→冷却水出口温度↑", "≈1-3个采样", "Q=UA·LMTD=ṁ_cw·Cp·ΔT", "monotonic"),
    rel("XMV_11", "XMEAS_11", "causal", "moderate", "冷凝器冷却水阀开度↑→冷凝负荷↑→分离器温度↓（负向）", "≈3-10个采样", "Q=UA·LMTD；闪蒸VLE平衡", "inverse"),
    rel("XMV_11", "XMEAS_22", "causal", "moderate", "冷却水量↑→同等冷凝负荷下出口水温↓（负向）", "≈1-3个采样", "Q=ṁ_cw·Cp·(T_out−T_in)", "inverse"),
    rel("XMEAS_11", "XMEAS_22", "causal", "moderate", "分离器温度↑→冷凝器热负荷↑→冷却水出口温度↑", "≈1-3个采样", "Q=UA·LMTD=ṁ_cw·Cp·ΔT", "monotonic"),
    rel("XMEAS_19", "XMEAS_18", "causal", "strong", "蒸汽流量↑→塔内汽提强度↑→塔温↑", "≈1-5个采样", "塔板能量衡算+汽提传质速率∝蒸汽量", "monotonic"),
    rel("XMEAS_5", "XMEAS_6", "physical", "strong", "质量守恒：反应器进料=新鲜进料（流股1-4）+循环气（流股8）", "≈0-1个采样", "F6=F1+F2+F3+F4+F8", "linear"),
    rel("XMEAS_10", "XMEAS_7", "causal", "moderate", "purge量↑→回路气相 inventory↓→反应器压力↓（负向）", "≈2-10个采样", "PV=nRT（气相空间）+回路物料衡算", "inverse"),
    rel("XMEAS_9", "XMEAS_7", "causal", "moderate", "反应温度↑→反应速率（Arrhenius）↑→气相摩尔生成与膨胀↑→压力↑；同时理想气体效应", "≈1-5个采样", "PV=nRT；r=k0·exp(−E/RT)·ΠC_j", "exponential"),
    rel("XMEAS_6", "XMEAS_7", "causal", "moderate", "进料量↑→气相持存与反应产气↑→压力↑", "≈2-10个采样", "回路物料衡算+PV=nRT", "monotonic"),
    rel("XMEAS_2", "XMEAS_26", "causal", "moderate", "D进料↑→反应器进料中D摩尔分数↑", "≈5-30个采样（回路混合）", "组分衡算 C_D=F2/(F1+F2+F3+F4+F8)（摩尔基准）", "monotonic"),
    rel("XMEAS_3", "XMEAS_27", "causal", "moderate", "E进料↑→反应器进料中E摩尔分数↑", "≈5-30个采样", "组分衡算（同上）", "monotonic"),
    rel("XMEAS_4", "XMEAS_30", "causal", "moderate", "流股4是B的唯一新鲜来源→其流量/组成决定回路B富集与purge中B分数", "≈10-40个采样（回路循环时间常数）", "回路B衡算：B_in(流股4)=B_purge+B_product+r3消耗", "monotonic"),
    rel("XMV_6", "XMEAS_30", "causal", "moderate", "purge阀开度↑→B排出↑→回路B富集↓→purge气中B摩尔分数↓（负向）", "≈10-40个采样", "回路B衡算（同上）", "inverse"),
    rel("XMEAS_2", "XMEAS_40", "physical", "moderate", "D是产物G的反应物（A+C+D→G）→D进料比决定产品G分数", "≈20-100个采样（全流程）", "化学计量 A+C+D→G（转化率×进料比）", "monotonic"),
    rel("XMEAS_3", "XMEAS_41", "physical", "moderate", "E是产物H的反应物（A+C+E→H）→E进料比决定产品H分数", "≈20-100个采样（全流程）", "化学计量 A+C+E→H", "monotonic"),
    rel("XMEAS_13", "XMEAS_20", "correlative", "moderate", "分离器压力（压缩机入口侧）与压比共同决定压缩机功耗", "≈0-3个采样", "P=ṁ·w_s，压比P_out/P_in", "monotonic"),
    rel("XMEAS_11", "XMEAS_12", "causal", "weak", "分离器温度↑→气化加剧→液相减少→液位承压（液位控制回路会反向补偿，净效应弱）", "≈1-5个采样", "闪蒸VLE+液位物料衡算", "inverse"),
]

# ---------- R2 stage-1 pre-checks (basic validation only) ----------
comp6_sum = sum(S["XMEAS_%d" % i]["b_mean"] for _, i in STREAM6)
comp9_sum = sum(S["XMEAS_%d" % i]["b_mean"] for _, i in STREAM9)
comp11_sum = sum(S["XMEAS_%d" % i]["b_mean"] for _, i in STREAM11)
xmv_out_of_range = [c for d in XMV_DEFS for c in [d[0]] if S[c]["a_min"] < 0 or S[c]["a_max"] > 100]

rag_doc = {
    "rag_engine": {
        "endpoint": "http://localhost:8764",
        "status": "unavailable",
        "probe": "GET /health 3s超时 → HTTP 000（连接失败），按协议仅探测一次",
        "probed_at": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
    },
    "fallback_path": "resources/parameter_to_physics.json 模式库（物理量→控制方程→因果链结构）+ 标准TE过程领域知识（Downs & Vogel 1993 / Rieth et al. 2017通道次序），并经数据基值交叉核对；未进行web检索（按任务约束）",
    "r1_semantic_comprehension": {
        "process_type": "Tennessee Eastman 连续化工过程（反应器-冷凝器-分离器-汽提塔+循环压缩机）",
        "reactions": ["A + C + D → G（主产物G）", "A + C + E → H（主产物H）", "A + B → F（副产物，B随流股4进入）", "3D → 2F（副反应）"],
        "domain_constraints": [
            "反应器温度/压力存在安全上限，强放热反应需持续冷却（XMV_10/XMV_11）",
            "气相回路必须维持purge以排出轻组分、防止惰性物积累",
            "产品G/H比由D/E进料配比与反应选择性决定",
            "组分通道（XMEAS 23-41）为在线分析仪，回路循环导致大时间常数",
        ],
        "failure_mode_families_generic": [
            "进料配比/流量扰动（流股1-4，含流股4组成变化）",
            "冷却系统退化（冷却水量、入口水温、结垢UA下降）",
            "purge/循环阀异常（回路组分漂移、压力波动）",
            "分离器/汽提塔液位与采出控制异常",
            "传感器漂移/分析仪偏差（组成通道）",
            "蒸汽系统扰动（XMEAS_19/XMEAS_18）",
        ],
        "confounders": ontology["confounders"],
    },
    "r2_claim_validations": [
        {"claim": "采样间隔为3分钟", "check": "相邻时间戳差值集合（全部960样本）", "result": "CONSISTENT" if len(dt_set) == 1 else "INCONSISTENT", "detail": "唯一间隔=%ds" % SAMPLING_S},
        {"claim": "XMV_1..11为阀门开度（0-100%）", "check": "全量程极值检查", "result": "CONSISTENT" if not xmv_out_of_range else "INCONSISTENT", "detail": "越界列=%s" % (xmv_out_of_range or "无")},
        {"claim": "XMEAS_9反应器温度基准≈120.4°C", "check": "样本1-160基线均值", "result": "CONSISTENT" if abs(S["XMEAS_9"]["b_mean"] - 120.4) < 1.5 else "INCONSISTENT", "detail": "基线均值=%s°C" % r4(S["XMEAS_9"]["b_mean"])},
        {"claim": "XMEAS_7反应器压力基准≈2705 kPa", "check": "样本1-160基线均值", "result": "CONSISTENT" if abs(S["XMEAS_7"]["b_mean"] - 2705) < 60 else "INCONSISTENT", "detail": "基线均值=%s kPa" % r4(S["XMEAS_7"]["b_mean"])},
        {"claim": "组分块XMEAS_23-28与29-34为摩尔分数（和≈100%）", "check": "基线均值求和", "result": "CONSISTENT" if 85 <= comp6_sum <= 105 and 85 <= comp9_sum <= 105 else "PARTIAL", "detail": "stream6和=%s%%，stream9和=%s%%（其余为G/H等未列入通道的组分）" % (r4(comp6_sum), r4(comp9_sum))},
        {"claim": "XMEAS_35-41为产品流股11组分（G≈53.7%、H≈43.8%）", "check": "基线均值求和与G/H量级", "result": "PARTIAL", "detail": "七通道和={}（>100%，存在未知的归一化基准差异，见clarification_needed.json A3）；XMEAS_40基线均值={}、XMEAS_41={}，与TE基准产品G/H组成53.7/43.8高度吻合".format(r4(comp11_sum), r4(S["XMEAS_40"]["b_mean"]), r4(S["XMEAS_41"]["b_mean"]))},
        {"claim": "XMEAS_5循环气流量基准≈202.9 kscmh（Downs-Vogel公开基准）", "check": "样本1-160基线均值", "result": "INCONSISTENT", "detail": "基线均值=%s，与公开基准202.9量级不符（≈/8）；通道身份由标准次序确定，数值基准疑为生成器差异（见clarification_needed.json A2）" % r4(S["XMEAS_5"]["b_mean"])},
        {"claim": "故障时段自样本161起（user_context提供）", "check": "本阶段不做变点统计（data-processor Stage-2职责）", "result": "untestable", "detail": "仅用于基线（1-160）与后段（161-960）分段描述，不作为诊断结论依据"},
    ],
    "validation_queue": [
        {"item": "全通道基线-后段变点/漂移统计检验", "owner": "data-processor (Stage 2)"},
        {"item": "物理关系表逐条方向/滞后验证（lag-compensated CCF）", "owner": "data-processor (Stage 2)"},
        {"item": "组分通道归一化基准差异的定量核验", "owner": "data-processor (Stage 2)"},
    ],
    "r3_physics_principles": [
        "质量守恒（混合器/分离器/塔釜物料衡算）",
        "能量守恒（CSTR能量衡算、换热器Q=UA·LMTD、冷却水Q=ṁCpΔT）",
        "化学计量与Arrhenius温度依赖（r=k0·e^(−E/RT)）",
        "相平衡（Raoult/Henry，闪蒸VLE决定气液分配）",
        "阀门安装流量特性与压缩机等熵功",
        "回路组分平衡：purge是轻组分唯一气相出口，决定富集稳态",
    ],
    "r4_gap_identification": [
        "user_context引用的映射表 data/references/tep_variables.md 不存在——采用标准TE语义并全部标注auto_inferred=true",
        "XMEAS_5数值基准与公开TE基准量级不符（生成器差异），保留通道身份、单位标注存疑",
        "XMEAS_35-41通道按A,B,C,D,E,G,H判读（F未包含），组分和>100%的归一化基准待核",
        "RAG知识库不可用，无rag_retrieval来源条目；全部knowledge_source=auto_inferred",
    ],
    "knowledge_source": KS,
}

# ---------- clarification gate (auto mode) ----------
clar = {
    "run_dir": RUN_DIR,
    "generated_by": "context-builder",
    "interaction_mode": "auto",
    "clarification_status": "AUTO_RESOLVED",
    "resolution_method": "physics_inference_framework L1-L5 推断 + 标准TE领域知识 + 数据自描述核对（无用户提问；auto模式下按协议自动裁决）",
    "ambiguities": [
        {"id": "A1", "topic": "变量映射表缺失", "importance": "CRITICAL",
         "question": "user_context引用映射表 data/references/tep_variables.md，但该文件不存在，XMEAS_1..41/XMV_1..11的物理语义如何确定？",
         "auto_resolution": "采用标准Tennessee Eastman变量表语义（Downs & Vogel 1993 / Rieth et al. 2017 TEP数据集的标准通道次序），并与数据基值交叉核对：XMEAS_7基线均值≈2705、XMEAS_9≈120.4、XMEAS_19≈230、XMV基值≈63.1/53.7/24.6/61.3/22.1/40.0/…与TE公开基准值一致，通道身份判定可靠",
         "inference_basis": "过程描述（TE过程）+ 列名规范 + 领域知识 + 数据基值核对", "auto_inferred": True, "confidence": "high"},
        {"id": "A2", "topic": "XMEAS_5循环流量数值基准异常", "importance": "HIGH",
         "question": "XMEAS_5基线均值≈26.7，与Downs-Vogel公开基准202.9 kscmh量级不符，是否误判通道？",
         "auto_resolution": "保留XMEAS_5=循环气流量（流股8）的通道身份（标准次序+其余40列基值全部吻合，排除错位可能）；单位暂标kscmh并注明数值基准疑为数据生成器差异。诊断时以数据自身基线为准，不以公开基准作硬阈值",
         "inference_basis": "排除法（其余通道全部吻合）+ 数据自描述", "auto_inferred": True, "confidence": "moderate"},
        {"id": "A3", "topic": "产品组分块XMEAS_35-41的组分构成", "importance": "MEDIUM",
         "question": "标准41通道清单中产品块为7个通道，其组分次序（是否含F）存在版本差异，如何判读？",
         "auto_resolution": "判读为流股11的 A,B,C,D,E,G,H（F未包含）：XMEAS_40/41基线均值53.7/43.8与TE基准产品G/H组成53.7%/43.8%精确吻合，F≈痕量不可能占53.7%；七通道基线和≈105.6%>100%提示存在归一化基准差异，已在rag_deep_understanding.json登记待Stage-2核验。该差异不影响相对趋势诊断",
         "inference_basis": "G/H基准值匹配 + 化学计量合理性（F为痕量副产物）", "auto_inferred": True, "confidence": "high"},
        {"id": "A4", "topic": "诊断目标变量未显式指定", "importance": "MEDIUM",
         "question": "用户目标为'诊断本次异常的根本原因'，未指定目标列，role=target如何分配？",
         "auto_resolution": "全部XMEAS置为predictor（pre-analysis阶段无法预知哪些通道偏离）；诊断目标由diagnostician基于异常时段的实际偏离通道确定。产品G/H（XMEAS_40/41）与反应器温度/压力在expected_data_behavior中已标注为关键质量/安全指标",
         "inference_basis": "协议默认 + 任务性质（根因诊断为追溯型，非单目标监控）", "auto_inferred": True, "confidence": "high"},
        {"id": "A5", "topic": "组分通道单位假设", "importance": "LOW",
         "question": "XMEAS_23-41单位是否为摩尔百分比（mole%）？",
         "auto_resolution": "按TE惯例判读为mole%（数据量纲0-100、组分块求和≈93-106%符合摩尔分数块特征）",
         "inference_basis": "TE领域惯例 + 数据量纲核对", "auto_inferred": True, "confidence": "high"},
        {"id": "A6", "topic": "故障起始样本161的来源与使用", "importance": "HIGH",
         "question": "故障时段自第161样本（8h）起的信息仅来自user_context描述，未经数据独立验证，是否可作为事实使用？",
         "auto_resolution": "仅用于基线（样本1-160）/后段（161-960）分段统计描述（normal_range取自基线段），不作为诊断结论依据；变点/漂移的独立验证列入validation_queue由data-processor完成",
         "inference_basis": "用户上下文 + 协议数据真实性约束", "auto_inferred": True, "confidence": "high"},
    ],
}

# ---------- write outputs ----------
onto_dir = os.path.join(RUN_DIR, "01_ontology")
os.makedirs(onto_dir, exist_ok=True)
onto_path = os.path.join(onto_dir, "ontology.json")
with open(onto_path, "w", encoding="utf-8") as f:
    json.dump(ontology, f, ensure_ascii=False, indent=1)
shutil.copyfile(SKILL_SCHEMA, os.path.join(onto_dir, "schema.json"))
with open(os.path.join(RUN_DIR, "00_input", "clarification_needed.json"), "w", encoding="utf-8") as f:
    json.dump(clar, f, ensure_ascii=False, indent=1)
with open(os.path.join(RUN_DIR, "00_input", "rag_deep_understanding.json"), "w", encoding="utf-8") as f:
    json.dump(rag_doc, f, ensure_ascii=False, indent=1)

n_signals = len(process_parameters) + len(control_variables)
print("OK rows=%d cols=%d signals=%d relationships=%d size=%dB" % (
    n, len(header), n_signals, len(ontology["relationships"]), os.path.getsize(onto_path)))
print("sampling=%ds start=%s end=%s" % (SAMPLING_S, ontology["metadata"]["start_time"], ontology["metadata"]["end_time"]))
