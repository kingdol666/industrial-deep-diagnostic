// Post-process the visual_analysis.py skeleton into metadata_backed_inference mode
// (non-VLM environment). Keeps analysis_provenance.source_agent = "visual_analysis.py".
import fs from "fs";

const run = process.argv[2];
const p = `${run}/03_figures/visual_analysis.json`;
const v = JSON.parse(fs.readFileSync(p, "utf8"));

v.observation_mode = "metadata_backed_inference";
v.analysis_provenance.stage = "metadata_backed_inference";
v.analysis_provenance.grounding_summary =
  "NON-VLM ENVIRONMENT: no image pixels were read by any model. All observations below are metadata-backed: computed from 02_processed/cleaned_data.csv (n=923) and the run statistical artifacts (validate_report.json, anomaly_report.json, production_regime_filter.json, physics_check.json, time_lag_analysis.json). Chart PNGs exist for downstream human/VLM review but their pixel content is NOT interpreted here. Authored by visual_analysis.py skeleton + data-processor metadata enrichment.";
v.analysis_provenance.figure_inputs_attempted = [];
v.analysis_provenance.figure_inputs_read_successfully = [];
v.analysis_provenance.skeleton_overwritten = false;

// fix schema gaps + enrich cross_parameter_temporal_alignment (all stats from data artifacts)
v.cross_parameter_temporal_alignment = {
  summary:
    "State-level synchrony computed from cleaned_data.csv (n=923): Accelerometer1RMS and Thermocouple co-move opposite to Volume Flow RateRMS (r=-0.821/-0.742); both accelerometers co-move together (r=0.796). Pressure, Current, Voltage are linearly decoupled from flow (|r|<=0.05). Lag-compensated CCF shows a broad flat envelope (Thermocouple~Flow lag0 r=-0.7415 ranks 21/41, best -0.7897 at +19 s; Accelerometer1RMS~Flow peak +1 s r=-0.883) -> synchronous state coupling with no resolvable temporal precedence at 1 Hz.",
  synchronous_groups: [
    {
      group_id: "SG1_vibration_thermal_inverse_flow",
      parameters: ["Accelerometer1RMS", "Accelerometer2RMS", "Thermocouple"],
      description:
        "Both accelerometer channels (mutual r=0.796) and fluid temperature rise together while flow collapses (flow-acc1 r=-0.821, flow-acc2 r=-0.651, flow-temp r=-0.7415, Spearman -0.7357; persists within circulation r=-0.7201 and on the 119-128 L/min plateau r=-0.6384)",
      estimated_group_lag: "0 (synchronous; CCF envelope flat, no precedence peak)",
      synchronous_with_quality: false,
      group_diagnostic_implication:
        "One physical state switch simultaneously drives vibration excitation and fluid stagnation heating while flow collapses - a real hydraulic-state event, not an instrumentation artifact",
    },
    {
      group_id: "SG2_electrical",
      parameters: ["Current", "Voltage"],
      description:
        "Current co-moves with supply voltage (r=0.500) but is decoupled from flow (r=0.052; partial r|Voltage=0.043)",
      estimated_group_lag: "0 (synchronous)",
      synchronous_with_quality: false,
      group_diagnostic_implication:
        "Electrical channel reflects grid disturbance confounding only; pump load stays on during collapse (2.338 vs 2.396 A)",
    },
  ],
  precedence_signals: [],
  independent_parameters: [
    {
      parameters: ["Pressure"],
      description:
        "7 quantized levels (step ~0.33 bar); linear r with flow -0.022 but normalized mutual information 1.0 (validate_report) - pressure levels nearly determine flow-state bins while magnitude is unmeasurable",
      diagnostic_weight: "STRONG",
    },
    {
      parameters: ["Voltage"],
      description: "Decoupled from flow/vibration (r=0.030/-0.061) - supply disturbance is not the anomaly driver",
      diagnostic_weight: "WEAK",
    },
    {
      parameters: ["Temperature"],
      description:
        "Motor-body temperature stable (std 0.299 C, thermal inertia >> 19 min window); instantaneous correlations not diagnostic",
      diagnostic_weight: "WEAK",
    },
  ],
};

v.visual_observations = [
  {
    figure: "fig_regime_stratified_scatter.png",
    observations: [
      {
        type: "clustering",
        description:
          "METADATA-BACKED (computed, not pixel-read): Volume Flow RateRMS is two-plateau + recovery band - 76/923 rows (8.2%) collapse below 10 L/min (min 0.556) in 40 brief 1-3 s bursts recurring from row 3 to row 759 (min gap 2 s, median gap 4 s); 710 rows (76.9%) sit on a 119-128 L/min saturated plateau (flow std 1.83); 119 transition rows in between. Collapsed-state means: Accelerometer1RMS 0.2595 g vs 0.2472 g (+5.0%), Thermocouple 29.235 vs 29.002 C (+0.233), Current 2.338 vs 2.396 A (-2.4%).",
        parameters_involved: ["Volume Flow RateRMS", "Accelerometer1RMS", "Thermocouple", "Current"],
        estimated_lag: "0 (synchronous)",
        confidence: "high",
        diagnostic_implication:
          "The anomaly is a recurring intermittent flow-instability state, not a single shutdown window; the pump keeps its load while fluid heats and vibration rises - the state signature the diagnostician must explain.",
        statistical_cross_reference: {
          source_file: "02_processed/production_regime_filter.json",
          validation_note: "all values computed from 02_processed/cleaned_data.csv n=923",
        },
        ontology_context: {
          parameter_physical_meanings: {
            "Volume Flow RateRMS": "回路流量 (L/min), role=target",
            Accelerometer1RMS: "泵体振动测点1 (g)",
            Thermocouple: "回路流体温度 (℃)",
            Current: "电机电流 (A)",
          },
          process_stage: "ST0_STANDBY (collapsed) vs ST1_CIRCULATION",
        },
      },
    ],
  },
  {
    figure: "fig_vlm_temporal_overlay.png",
    observations: [
      {
        type: "temporal_synchronization",
        description:
          "METADATA-BACKED: the z-normalized overlay data model groups Accelerometer1RMS+Thermocouple as moving opposite to flow (script-computed, r<-0.7); lag-compensated CCF envelope is broad and flat (Thermocouple~Flow lag0 r=-0.7415 rank 21/41, best -0.7897 at +19 s; Accelerometer1RMS~Flow peak +1 s r=-0.883, window-consistent) - no sharp causal-precedence peak either direction at 1 Hz.",
        parameters_involved: ["Volume Flow RateRMS", "Accelerometer1RMS", "Thermocouple"],
        estimated_lag: "0 (synchronous)",
        confidence: "high",
        diagnostic_implication:
          "Vibration rise, fluid warming and flow collapse co-occur as one state switch; temporal ordering cannot discriminate driver vs consequence from this window - arbitrate on mechanism instead.",
        statistical_cross_reference: {
          correlation: -0.8211,
          source_file: "02_processed/time_lag_analysis.json",
          validation_note: "cross-checked with validate_report.json lagged_ccf (target=Accelerometer1RMS)",
        },
        ontology_context: {
          parameter_physical_meanings: {
            Accelerometer1RMS: "受迫振动 + 水力脉动激励",
            Thermocouple: "滞止/搅拌加热平衡",
            "Volume Flow RateRMS": "泵-阀-管路联合工况点",
          },
          process_stage: "ST0/ST1 switching",
        },
      },
      {
        type: "direction_consistency",
        description:
          "METADATA-BACKED: both independent accelerometer channels move in the same direction against flow (r=-0.8211/-0.6511; mutual r=0.796 Pearson / 0.724 Spearman); detrended flow~acc1 r=-0.7885 (not trend-confounded); leave-one-out max shift 0.0029 - the coupling is robust and dual-channel.",
        parameters_involved: ["Accelerometer1RMS", "Accelerometer2RMS", "Volume Flow RateRMS"],
        estimated_lag: "N/A - cross-sectional",
        confidence: "high",
        diagnostic_implication:
          "Refutes single-probe artifact or drift explanation for the vibration-flow anomaly (H4 of analysis_method_plan.json).",
        statistical_cross_reference: {
          correlation: 0.796,
          source_file: "02_processed/validate_report.json",
          validation_note:
            "outlier_sensitivity + spearman_divergence + leave_one_out_leverage blocks; regime view in production_regime_filter.json supersedes the IQR-outlier sign-flip reading",
        },
        ontology_context: {
          parameter_physical_meanings: { Accelerometer2RMS: "第二测点冗余通道" },
          process_stage: "ST1_CIRCULATION",
        },
      },
    ],
  },
  {
    figure: "fig_temporal_overview.png",
    observations: [
      {
        type: "anomaly_clustering",
        description:
          "METADATA-BACKED: 3-sigma point anomalies are rare and isolated (Pressure idx 212 high 5.02-sigma / idx 307 low 3.73-sigma; Accelerometer1RMS idx 155/163 ~3.0-sigma; Accelerometer2RMS max|z|=3.45) while the dominant event - the flow-collapse state (76 rows) - never exceeds 3 sigma pointwise (max|z|=2.41) because the bimodal mixture inflates the global std (42.44 L/min).",
        parameters_involved: ["Pressure", "Accelerometer1RMS", "Accelerometer2RMS", "Volume Flow RateRMS"],
        estimated_lag: "N/A - cross-sectional",
        confidence: "high",
        diagnostic_implication:
          "The primary anomaly is regime-level, not point-anomaly level; sigma-threshold alarm logic would miss it - the diagnostician must weigh state-occupancy evidence (8.2% collapsed).",
        statistical_cross_reference: {
          source_file: "02_processed/anomaly_report.json",
          validation_note: "targets/anomaly_intervals + process_parameter_fluctuation",
        },
        ontology_context: {
          parameter_physical_meanings: { Pressure: "量化开关式泵后压力 (Bar)" },
          process_stage: "whole-run",
        },
      },
    ],
  },
  {
    figure: "fig_vlm_synchronization.png",
    observations: [
      {
        type: "profile_shape",
        description:
          "METADATA-BACKED: Pressure exhibits a 7-level quantized profile (levels -0.6011/-0.2732/0.0547/0.3826/0.7106/1.0385/1.3664 bar, step ~0.33 bar; mode level 0.0547 = 530 rows/57%). Negative levels are decoupled from collapse (141/151 negative rows occur during circulation; the -0.6011 level has 0 low-flow rows); collapse rows sit mostly on the lowest positive platform 0.0547 bar (50/76).",
        parameters_involved: ["Pressure", "Volume Flow RateRMS"],
        estimated_lag: "N/A - cross-sectional",
        confidence: "high",
        diagnostic_implication:
          "Pressure magnitude is not measurable through this transmitter; its state-sequence information (MI with flow-state = 1.0) still carries diagnostic value: collapse happens WITHOUT high shutoff-head pressure and WITHOUT suction vacuum - constrains both the closed-valve and the suction-loss sub-mechanisms.",
        statistical_cross_reference: {
          source_file: "02_processed/physics_check.json",
          validation_note: "PHY1/PHY4 checks; cross-tab in production_regime_filter.json pressure_level_x_flow_state",
        },
        ontology_context: {
          parameter_physical_meanings: { Pressure: "压力开关/低分辨率变送器 (ontology EQ_PT)" },
          process_stage: "ST0/ST1 switching",
        },
      },
    ],
  },
];

v.vlm_chart_count = 4;
v.pipeline_warnings = [
  {
    warning:
      "NON-VLM ENVIRONMENT: visual_analysis.json is metadata-backed only. No PNG pixel content was interpreted; downstream VLM review of the 5 figures in 03_figures/ remains possible.",
    severity: "WARNING",
  },
  {
    warning:
      "Volume Flow RateRMS suspected range saturation on the 119-128 L/min plateau (76.9% of rows); absolute flow level there is unreliable.",
    severity: "WARNING",
  },
  {
    warning:
      "Pressure transmitter quantization (~0.33 bar step) makes pressure-flow magnitude physics untestable; use level sequence only.",
    severity: "INFO",
  },
];
v.synthesis =
  "Metadata-backed synthesis (no image reading): this 15.9-min loop run is a two-state system - a 119-128 L/min saturated circulation plateau (76.9% of rows) interrupted by 40 brief (1-3 s) flow-collapse bursts (76 rows, 8.2%) recurring from the 3rd second onward. Each collapse is accompanied synchronously by vibration rise (acc1 0.2472->0.2595 g, both channels coherently), fluid-temperature rise (+0.233 C), and NO motor unloading (2.338 vs 2.396 A; voltage-adjusted residual ~ -0.076 A). Pressure is a 7-level quantized state signal whose sequence nearly determines the flow-state bin (MI=1.0) but whose magnitude physics is untestable; negative-pressure levels are decoupled from collapse. The coupling evidence is robust (rank/detrend/LOO/lag-CCF all pass) - the anomaly is a real, recurring hydraulic-state instability, not an instrumentation artifact and not an electrical disturbance.";
v.reading_guide = [
  {
    for_agent: "diagnostician",
    primary_sections_to_read: ["synthesis", "visual_observations", "cross_parameter_temporal_alignment", "pipeline_warnings"],
    key_insights: [
      "All observations are statistics-derived, not pixel-derived; cite the JSON artifacts, not the PNGs.",
      "H3 pump-stoppage, H4 sensor-artifact, H5 voltage-driver are refuted; H1 valve/dead-head vs H2 cavitation/suction-loss remain competing with specific discriminative constraints from PHY4.",
    ],
  },
  {
    for_agent: "judge",
    primary_sections_to_read: ["analysis_provenance", "pipeline_warnings"],
    key_insights: [
      "observation_mode=metadata_backed_inference: non-VLM environment; provenance records visual_analysis.py + data-processor as authors.",
    ],
  },
];

fs.writeFileSync(p, JSON.stringify(v, null, 1));
console.log("visual_analysis.json -> observation_mode =", v.observation_mode);
