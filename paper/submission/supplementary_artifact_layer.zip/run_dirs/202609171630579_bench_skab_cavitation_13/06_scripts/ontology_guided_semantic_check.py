# -*- coding: utf-8 -*-
"""Ontology-guided semantic checks for run 202609171630579_bench_skab_cavitation_13
(SKAB water-circulation test bench, process_only view).

Executes only the methods selected by 02_processed/analysis_method_plan.json:
  M5  regime detection (ontology ST0/ST1 + data-driven 2-means threshold)
  M8  stratified (per-regime) statistics + partial correlations + leave-one-out
  M13 pressure-level x flow-state cross-tab + low-flow episode table
  M6  lag-compensated CCF for cited pair Thermocouple ~ Volume Flow RateRMS
  M7  physics sanity checks (quantization, saturation, dead-head energy, NPSHa proxy)

Outputs (all numbers recomputable from 02_processed/cleaned_data.csv, n=923):
  02_processed/production_regime_filter.json
  02_processed/physics_check.json
  02_processed/time_lag_analysis.json
  02_processed/causal_evidence_map.json
  03_figures/fig_regime_stratified_scatter.png
Every value that involves an assumption carries "derived": true.
"""
import json
import math
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RUN_DIR = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRO = os.path.join(RUN_DIR, "02_processed")
FIG = os.path.join(RUN_DIR, "03_figures")

FLOW = "Volume Flow RateRMS"
A1 = "Accelerometer1RMS"
A2 = "Accelerometer2RMS"
CUR = "Current"
VOL = "Voltage"
PRES = "Pressure"
TMOT = "Temperature"
TFLU = "Thermocouple"

df = pd.read_csv(os.path.join(PRO, "cleaned_data.csv"))
n = len(df)
assert n == 923, f"expected 923 rows, got {n}"
for c in df.columns:
    if c != "datetime":
        df[c] = pd.to_numeric(df[c])

r = lambda x: round(float(x), 4)


def pearson(a, b):
    m = (~a.isna()) & (~b.isna())
    return r(a[m].corr(b[m], method="pearson"))


def spearman(a, b):
    m = (~a.isna()) & (~b.isna())
    return r(a[m].corr(b[m], method="spearman"))


def leave_one_out_max_shift(a, b):
    """Max |delta r| over single-row removals (anti-spurious leverage check)."""
    x = a.to_numpy(float)
    y = b.to_numpy(float)
    m = ~(np.isnan(x) | np.isnan(y))
    x, y = x[m], y[m]
    r_full = np.corrcoef(x, y)[0, 1]
    npts = len(x)
    sx, sy, sxx, syy, sxy = x.sum(), y.sum(), (x * x).sum(), (y * y).sum(), (x * y).sum()
    max_shift = 0.0
    for i in range(npts):
        SX = sx - x[i]; SY = sy - y[i]
        SXX = sxx - x[i] * x[i]; SYY = syy - y[i] * y[i]; SXY = sxy - x[i] * y[i]
        k = npts - 1
        cov = SXY - SX * SY / k
        vx = SXX - SX * SX / k
        vy = SYY - SY * SY / k
        if vx <= 0 or vy <= 0:
            continue
        ri = cov / math.sqrt(vx * vy)
        max_shift = max(max_shift, abs(r_full - ri))
    return r(max_shift)


def partial_corr(x, y, z):
    """Pearson partial correlation of x,y controlling z (linear): correlate the
    residuals of x~z and y~z."""
    bz = np.asarray(z, float)
    bx = np.polyfit(bz, np.asarray(x, float), 1)
    by = np.polyfit(bz, np.asarray(y, float), 1)
    rx = pd.Series(np.asarray(x, float) - (bx[0] * bz + bx[1]))
    ry = pd.Series(np.asarray(y, float) - (by[0] * bz + by[1]))
    return pearson(rx, ry)


def two_means_threshold(vals):
    """1-D 2-means split; returns (center_lo, center_hi, threshold)."""
    v = np.sort(np.asarray(vals, float))
    c1, c2 = np.percentile(v, [25, 75])
    for _ in range(100):
        m1 = np.abs(v - c1) <= np.abs(v - c2)
        n1, n2 = m1, ~m1
        if n1.sum() == 0 or n2.sum() == 0:
            break
        c1n, c2n = v[n1].mean(), v[n2].mean()
        if abs(c1n - c1) < 1e-9 and abs(c2n - c2) < 1e-9:
            c1, c2 = c1n, c2n
            break
        c1, c2 = c1n, c2n
    thr = (c1 + c2) / 2.0
    return r(c1), r(c2), r(thr)


# ---------------------------------------------------------------- M5: regimes
c_lo, c_hi, thr_2means = two_means_threshold(df[FLOW])
THRESH = 10.0  # L/min, ontology ST0 definition (low-flow/dead-head); validated by 2-means
low_mask = df[FLOW] < THRESH
circ_mask = ~low_mask
n_low = int(low_mask.sum())
n_circ = int(circ_mask.sum())

regime = {
    "method": "ontology_stage_split + 1D 2-means verification",
    "ontology_stages": {"ST0_STANDBY": "low-flow / dead-head", "ST1_CIRCULATION": "steady circulation"},
    "flow_threshold_l_per_min": THRESH,
    "two_means_check": {
        "cluster_centers": [c_lo, c_hi],
        "decision_boundary": thr_2means,
        "rows_between_ontology_threshold_and_boundary": {
            "count_flow_in_10_to_73": int(((df[FLOW] >= THRESH) & (df[FLOW] < thr_2means)).sum()),
            "interpretation": "transition/recovery rows exist between the collapsed state and the plateau: the run is NOT a clean two-state partition — plateau (~120-128 L/min), collapse bursts (<10 L/min) and recovery ramps (10-119 L/min) coexist",
        },
        "bimodal_separation_supported": bool(c_hi - c_lo > 50.0),
        "note": "two plateaus (near 0-10 and near 120-125 L/min) exist; ontology threshold 10 L/min is used for the collapsed-state definition because recovery ramps are transient passages, not an operating state",
        "derived": True,
    },
    "regimes": [
        {"regime_id": "ST1_CIRCULATION", "description": "circulation incl. recovery ramps (flow >= 10 L/min)", "row_count": n_circ, "fraction_pct": r(100.0 * n_circ / n),
         "circulation_flow_p5_p25_p50": [r(df.loc[circ_mask, FLOW].quantile(0.05)), r(df.loc[circ_mask, FLOW].quantile(0.25)), r(df.loc[circ_mask, FLOW].quantile(0.5))]},
        {"regime_id": "ST0_LOW_FLOW_DEADHEAD", "description": "low-flow / collapsed state (flow < 10 L/min)", "row_count": n_low, "fraction_pct": r(100.0 * n_low / n)},
    ],
    "steady_row_indices_circulation": [int(i) for i in df.index[circ_mask]],
    "exclude_regimes": ["ST0_LOW_FLOW_DEADHEAD (8.2% rows; treated as a distinct physical operating state, NOT deleted from data)"],
    "caution_regimes": [],
    "per_product_anomaly_analysis": {"applicable": False, "reason": "no product/group column (single loop, batch_integrity.applicable=false)"},
}

# episodes: contiguous low-flow runs
episodes = []
idx_low = df.index[low_mask].to_numpy()
if len(idx_low):
    start = prev = idx_low[0]
    for i in idx_low[1:]:
        if i == prev + 1:
            prev = i
        else:
            episodes.append((int(start), int(prev)))
            start = prev = i
    episodes.append((int(start), int(prev)))
ep_list = [
    {
        "start_row": s, "end_row": e, "duration_s": e - s + 1,
        "start_time": str(df["datetime"].iloc[s]), "end_time": str(df["datetime"].iloc[e]),
        "min_flow_l_per_min": r(df[FLOW].iloc[s:e + 1].min()),
    }
    for s, e in episodes
]
regime["low_flow_episodes"] = {
    "count": len(ep_list),
    "total_rows": n_low,
    "episodes": ep_list,
    "duration_stats_s": {
        "min": min(e["duration_s"] for e in ep_list) if ep_list else 0,
        "max": max(e["duration_s"] for e in ep_list) if ep_list else 0,
        "mean": r(np.mean([e["duration_s"] for e in ep_list])) if ep_list else 0,
    },
    "morphology": {
        "n_episodes": len(ep_list),
        "row_span": [ep_list[0]["start_row"], ep_list[-1]["end_row"]] if ep_list else None,
        "min_gap_s": min((ep_list[i + 1]["start_row"] - ep_list[i]["end_row"]) for i in range(len(ep_list) - 1)) if len(ep_list) > 1 else None,
        "median_gap_s": r(np.median([ep_list[i + 1]["start_row"] - ep_list[i]["end_row"] for i in range(len(ep_list) - 1)])) if len(ep_list) > 1 else None,
        "interpretation": "collapsed-flow appears as many brief 1-3 s bursts recurring throughout the whole 15.9 min run (first burst at row 3), not as one sustained shutdown/dead-head window — an intermittent, recurring flow-instability morphology",
        "derived": True,
    },
}

# per-regime means for every channel
per_regime = {}
for col in [A1, A2, CUR, PRES, TMOT, TFLU, VOL, FLOW]:
    per_regime[col] = {
        "circulation_mean": r(df.loc[circ_mask, col].mean()),
        "circulation_std": r(df.loc[circ_mask, col].std()),
        "low_flow_mean": r(df.loc[low_mask, col].mean()),
        "low_flow_std": r(df.loc[low_mask, col].std()),
        "delta_pct": r(100.0 * (df.loc[low_mask, col].mean() - df.loc[circ_mask, col].mean()) / abs(df.loc[circ_mask, col].mean())) if df.loc[circ_mask, col].mean() != 0 else None,
    }
regime["per_regime_channel_stats"] = per_regime

# ------------------------------------------------------------- M8: stratified
pairs = [
    (A1, FLOW), (A2, FLOW), (TFLU, FLOW), (A1, TFLU), (A2, TFLU),
    (CUR, FLOW), (PRES, FLOW), (CUR, VOL), (TMOT, TFLU), (TMOT, FLOW),
]
strat = {}
for x, y in pairs:
    strat[f"{x} ~ {y}"] = {
        "overall_pearson": pearson(df[x], df[y]),
        "overall_spearman": spearman(df[x], df[y]),
        "within_circulation_pearson": pearson(df.loc[circ_mask, x], df.loc[circ_mask, y]),
        "within_circulation_spearman": spearman(df.loc[circ_mask, x], df.loc[circ_mask, y]),
        "within_low_flow_pearson": pearson(df.loc[low_mask, x], df.loc[low_mask, y]),
        "n_overall": n, "n_circulation": n_circ, "n_low_flow": n_low,
    }
regime["stratified_correlations"] = strat

# partial correlations (ontology-requested confounder checks)
part = {}
part["Accelerometer1RMS ~ Thermocouple | Volume Flow RateRMS"] = {
    "value": partial_corr(df[A1], df[TFLU], df[FLOW]),
    "expectation_from_ontology": "should decay toward 0 if the association is a common-cause (flow-state) confound",
}
part["Current ~ Volume Flow RateRMS | Voltage"] = {
    "value": partial_corr(df[CUR], df[FLOW], df[VOL]),
    "expectation_from_ontology": "tests whether voltage fluctuation masks or creates the current-flow coupling",
}
regime["partial_correlations"] = part

# voltage-adjusted current state contrast (H3/H5 discriminative check)
b_cv = np.polyfit(df[VOL].to_numpy(float), df[CUR].to_numpy(float), 1)
resC = pd.Series(df[CUR].to_numpy(float) - (b_cv[0] * df[VOL].to_numpy(float) + b_cv[1]), index=df.index)
regime["voltage_adjusted_current_state_contrast"] = {
    "residual_current_low_flow_mean_a": r(resC[low_mask].mean()),
    "residual_current_circulation_mean_a": r(resC[circ_mask].mean()),
    "interpretation": "after removing the voltage effect (V~I r=0.500), the collapsed state still shows essentially NO current unloading (delta about -0.08 A on a ~2.4 A load) — the pump keeps absorbing its load during flow collapse; refutes pump-stoppage/motor-underload (H3)",
    "derived": True,
}

# leave-one-out leverage for cited pairs not covered by prepare (validate_report covered A1~A2, A1~TFLU, A1~FLOW)
loo = {}
for x, y in [(TFLU, FLOW), (A2, FLOW), (CUR, VOL)]:
    loo[f"{x} ~ {y}"] = {
        "full_r": pearson(df[x], df[y]),
        "max_abs_shift_single_row_removal": leave_one_out_max_shift(df[x], df[y]),
        "leveraged": False,
    }
regime["leave_one_out_leverage_added"] = loo

# strict steady-state plateau subset (flow >= 119 L/min: the saturated band)
plateau_mask = df[FLOW] >= 119.0
n_plat = int(plateau_mask.sum())
plateau = {
    "definition": "Volume Flow RateRMS >= 119 L/min (saturated plateau band)",
    "n_rows": n_plat,
    "fraction_pct": r(100.0 * n_plat / n),
    "flow_std_on_plateau": r(df.loc[plateau_mask, FLOW].std()),
    "note": "on the plateau flow variance is compressed (suspected saturation), so within-plateau linear r is variance-starved and NOT interpretable; state-level (regime) coupling is the meaningful decomposition",
    "correlations_on_plateau": {
        f"{x} ~ {y}": {"pearson": pearson(df.loc[plateau_mask, x], df.loc[plateau_mask, y]), "n": n_plat}
        for x, y in [(A1, FLOW), (A2, FLOW), (TFLU, FLOW), (CUR, VOL)]
    },
}
regime["steady_plateau_subset"] = plateau

with open(os.path.join(PRO, "production_regime_filter.json"), "w", encoding="utf-8") as f:
    json.dump(regime, f, ensure_ascii=False, indent=1)

# ------------------------------------------------------------- M13: pressure x state
levels = sorted(df[PRES].round(4).unique().tolist())
lvl_tab = []
for lv in levels:
    m = df[PRES].round(4) == lv
    lvl_tab.append({
        "pressure_level_bar": r(lv),
        "rows": int(m.sum()),
        "fraction_pct": r(100.0 * m.sum() / n),
        "rows_with_low_flow": int((m & low_mask).sum()),
        "rows_in_circulation": int((m & circ_mask).sum()),
        "mean_flow_at_level": r(df.loc[m, FLOW].mean()),
    })
regime["pressure_level_x_flow_state"] = lvl_tab

# ------------------------------------------------------------- M6: CCF TFLU~FLOW
def ccf(target, param, max_lag=20):
    """r(target_t, param_{t-k}) for k in [-max_lag, max_lag]; k>0 means param LEADS target by k s."""
    out = []
    t = df[target].to_numpy(float)
    p = df[param].to_numpy(float)
    for k in range(-max_lag, max_lag + 1):
        if k > 0:
            a, b = t[k:], p[:-k]
        elif k < 0:
            a, b = t[:k], p[-k:]
        else:
            a, b = t, p
        if len(a) < 30:
            continue
        out.append({"lag_s": k, "r": r(np.corrcoef(a, b)[0, 1]), "n": int(len(a))})
    return out

ccf_tf = ccf(TFLU, FLOW)
best = max(ccf_tf, key=lambda d: abs(d["r"]))
lag0 = next(d for d in ccf_tf if d["lag_s"] == 0)
envelope = [d for d in ccf_tf if d["lag_s"] in (-20, -10, -5, -2, -1, 0, 1, 2, 5, 10, 15, 19, 20)]
rank0 = sorted((abs(d["r"]) for d in ccf_tf), reverse=True).index(abs(lag0["r"])) + 1

tla = {
    "applicable": False,
    "not_applicable_reason": "v6.4 process-to-inspection lag compensation requires process_plus_inspection view; data view is process_only. Lag CCF used here only to verify synchrony/precedence of cited process-process pairs (anti-spurious v6.4).",
    "sampling_interval_seconds": 1,
    "max_lag_searched": {"steps": 20, "seconds": 20},
    "pairs_analyzed": 1,
    "significant_lags_found": 1,
    "pair_results": [
        {
            "predictor": FLOW, "target": TFLU,
            "raw_r_lag0": lag0["r"],
            "best_abs_r": best["r"], "best_lag_s": best["lag_s"], "n_best": best["n"],
            "lag0_rank_by_abs_r": rank0,
            "ccf_envelope": envelope,
            "window_consistency": {
                "adjacent_lags": [d for d in ccf_tf if abs(d["lag_s"] - best["lag_s"]) <= 1 and d["lag_s"] != best["lag_s"]],
                "isolated_spike": False,
            },
            "interpretation": ("CCF envelope is broad and flat (|r| stays in a narrow band from lag -20 s to +20 s; lag0 r=%.4f ranks #%d of 41 lags, best %.4f at lag %d s): the association is a persistent state-level coupling, NOT a sharp causal-precedence peak. Temporal precedence between flow state and fluid temperature is unresolvable at 1 Hz over 1-3 s collapse bursts."
                               % (lag0["r"], rank0, best["r"], best["lag_s"])),
            "derived": True,
        }
    ],
    "cross_reference": "02_processed/validate_report.json lagged_ccf for target=Accelerometer1RMS: Volume Flow RateRMS best lag +1 s r=-0.883 (window-consistent, not isolated spike; lag0 r=-0.8211) — vibration-flow coupling likewise synchronous within 1 s",
    "key_recommendations": [
        {"pair": f"{FLOW} -> {TFLU}", "recommended_lag_steps": 0, "recommended_lag_seconds": 0,
         "action": "treat the flow-state/temperature association as synchronous state coupling; no lag compensation is warranted (envelope flat, no precedence peak)"}
    ],
}
with open(os.path.join(PRO, "time_lag_analysis.json"), "w", encoding="utf-8") as f:
    json.dump(tla, f, ensure_ascii=False, indent=1)

# ------------------------------------------------------------- M7: physics checks
def lin_slope(y):
    x = np.arange(len(y), dtype=float)
    if len(y) < 3:
        return 0.0
    return float(np.polyfit(x, np.asarray(y, float), 1)[0])

# dead-head episode fluid-temperature slope + state thermal contrast
slopes = []
for e in ep_list:
    seg = df[TFLU].iloc[e["start_row"]:e["end_row"] + 1].to_numpy(float)
    if len(seg) >= 3:
        slopes.append(lin_slope(seg))
slope_med = float(np.median(slopes)) if slopes else 0.0
cp_water = 4186.0  # J/(kg K)
V_mean_low = float(df[VOL].loc[low_mask].mean())
I_mean_low = float(df[CUR].loc[low_mask].mean())
PF_ASSUMED = 0.85  # derived assumption: induction motor power factor at load
P_elec_low = V_mean_low * I_mean_low * PF_ASSUMED  # single-phase equivalent
dT_state = float(df[TFLU].loc[low_mask].mean() - df[TFLU].loc[circ_mask].mean())

physics = {
    "checks": [
        {
            "id": "PHY1_pressure_quantization",
            "claim": "Pressure is quantized to discrete levels (step ~0.33 bar) — pressure switch / low-resolution transmitter",
            "method": "unique-value census on rounded Pressure, n=923",
            "n_unique_levels": len(levels),
            "levels": lvl_tab,
            "min_abs_step_bar": r(min(abs(levels[i + 1] - levels[i]) for i in range(len(levels) - 1))),
            "verdict": "CONFIRMED — linear P~Q law (delta_P = k_sys*Q^2) is untestable on this transmitter; pressure carries state (level) information, not magnitude",
        },
        {
            "id": "PHY2_flow_saturation_plateau",
            "claim": "Flow readings hug a 120-128 L/min plateau in circulation — suspected range saturation",
            "method": "quantile check on Volume Flow RateRMS within circulation regime",
            "circulation_p50": r(df.loc[circ_mask, FLOW].median()),
            "circulation_p90": r(df.loc[circ_mask, FLOW].quantile(0.9)),
            "circulation_p99": r(df.loc[circ_mask, FLOW].quantile(0.99)),
            "circulation_max": r(df.loc[circ_mask, FLOW].max()),
            "fraction_in_119_128_pct": r(100.0 * ((df.loc[circ_mask, FLOW] >= 119) & (df.loc[circ_mask, FLOW] <= 128)).mean()),
            "verdict": "SUSPECTED — >60% of circulation rows sit in a narrow 119-128 band; absolute flow level in this band is unreliable, state membership still valid",
        },
        {
            "id": "PHY3_dead_head_energy_balance",
            "claim": "During low-flow bursts the pump keeps absorbing near-full electrical power; energy balance direction supports stagnation/industrial heating of the fluid rather than loss of pumping",
            "method": "state-mean fluid-temperature contrast + median slope inside >=3 s episodes; P_elec = V*I*cos(phi), cos(phi)=0.85 assumed; episode-internal heating rate is NOT resolvable at 1-3 s bursts",
            "low_flow_mean_voltage": r(V_mean_low),
            "low_flow_mean_current": r(I_mean_low),
            "assumed_power_factor": PF_ASSUMED,
            "estimated_electrical_power_w_low_flow": r(P_elec_low),
            "fluid_temp_low_flow_minus_circulation_c": r(dT_state),
            "n_episodes_used_for_slope": len(slopes),
            "median_episode_temp_slope_c_per_s": r(slope_med),
            "verdict": ("DIRECTIONALLY CONSISTENT — collapsed-state fluid is warmer by %.2f C while the pump absorbs ~%.0f W (only ~7%% below circulation power); the sign agrees with stagnation/churn heating, but the within-burst heating rate is unresolvable at 1-3 s episode length, so a quantitative energy closure is NOT possible from this window" % (dT_state, P_elec_low)),
            "derived": True,
            "derived_note": "power factor assumed 0.85; single-phase-equivalent power; all other inputs measured",
        },
        {
            "id": "PHY4_negative_pressure_occurrence",
            "claim": "Negative pressure levels (-0.273/-0.601 bar) indicate suction-side vacuum sensing or gauge zero offset",
            "method": "co-occurrence of Pressure<0 rows with flow state",
            "rows_negative_pressure": int((df[PRES] < 0).sum()),
            "fraction_of_negative_pressure_rows_in_circulation_pct": r(100.0 * ((df[PRES] < 0) & circ_mask).sum() / max(int((df[PRES] < 0).sum()), 1)),
            "fraction_of_low_flow_rows_with_negative_pressure_pct": r(100.0 * ((df[PRES] < 0) & low_mask).sum() / max(n_low, 1)),
            "mean_pressure_low_flow_bar": r(df.loc[low_mask, PRES].mean()),
            "mean_pressure_circulation_bar": r(df.loc[circ_mask, PRES].mean()),
            "verdict": "NEGATIVE PRESSURE IS DECOUPLED FROM COLLAPSE: ~93% of the negative-pressure rows occur DURING circulation (the -0.6011 bar level has 0 low-flow rows) — a suction-vacuum-during-collapse reading is NOT supported; negative levels are more consistent with gauge zero offset / switch-line behavior. During collapse the dominant level is the LOWEST positive platform 0.0547 bar (50/76 rows) — not a closed-valve high shutoff head. Both discriminative facts are handed to the diagnostician (weakens a specific H2 sub-branch and the naive H1 shutoff-head variant).",
        },
        {
            "id": "PHY5_vibration_magnitude_band",
            "claim": "Absolute vibration stays in a benign band; the anomaly is state-coupling, not absolute severity",
            "method": "max/min of both accelerometer channels vs ISO 10816-style 0.5 g screening bound",
            "accel1_max_g": r(df[A1].max()), "accel1_min_g": r(df[A1].min()),
            "accel2_max_g": r(df[A2].max()), "accel2_min_g": r(df[A2].min()),
            "screening_bound_g": 0.5,
            "verdict": "CONFIRMED — both channels < 0.32 g at all times; elevated-but-benign absolute levels with strong state coupling",
        },
        {
            "id": "PHY6_current_no_load_floor",
            "claim": "Current minimum ~0.894 A matches induction-motor magnetizing (near no-load) floor predicted by ontology (~0.9 A)",
            "method": "min(Current) vs ontology expectation",
            "current_min_a": r(df[CUR].min()),
            "ontology_expected_floor_a": 0.9,
            "verdict": "CONSISTENT — the motor does reach true no-load at least once, so the pump CAN be electrically unloaded; during flow collapse it is NOT unloaded (2.338 A vs 2.396 A overall mean)",
        },
    ],
    "n_checks": 6,
    "note": "all inputs from 02_processed/cleaned_data.csv (n=923); derived quantities flagged per-check",
}
with open(os.path.join(PRO, "physics_check.json"), "w", encoding="utf-8") as f:
    json.dump(physics, f, ensure_ascii=False, indent=1)

# ------------------------------------------------------------- causal evidence map
cem = {
    "nodes": [
        {"id": FLOW, "role": "target", "ontology": "回路功能输出量 (L/min), role=target"},
        {"id": PRES, "role": "process_state", "ontology": "泵后压力，量化开关式信号"},
        {"id": A1, "role": "process_state", "ontology": "泵体振动测点1 (g)"},
        {"id": A2, "role": "process_state", "ontology": "泵体振动测点2 (g)"},
        {"id": TFLU, "role": "process_state", "ontology": "回路流体温度 (℃)"},
        {"id": CUR, "role": "process_state", "ontology": "电机电流 (A)"},
        {"id": VOL, "role": "confounder", "ontology": "外生供电电压 (V)"},
        {"id": TMOT, "role": "process_state", "ontology": "电机本体温度 (℃，大热惯性)"},
        {"id": "VALVE_STATE_UNRECORDED", "role": "latent_common_cause", "ontology": "阀门开度未记录 — 最强潜在共同原因 (ontology confounders[1])"},
    ],
    "edges": [
        {"from": FLOW, "to": A1, "r_overall": -0.8211, "r_within_circulation": strat[f"{A1} ~ {FLOW}"]["within_circulation_pearson"],
         "status": "validated_state_coupled", "note": "aggregate negative r decomposes into state mixture; within circulation the sign flips positive (hydraulic excitation grows with flow); robust: detrended -0.7885, CCF peak lag +1 s r=-0.883, LOO max shift 0.0029",
         "sources": ["02_processed/validate_report.json", "02_processed/production_regime_filter.json"]},
        {"from": FLOW, "to": A2, "r_overall": -0.6511, "r_within_circulation": strat[f"{A2} ~ {FLOW}"]["within_circulation_pearson"],
         "status": "validated_state_coupled", "note": "second independent channel co-varies with flow state — rules out single-probe artifact",
         "sources": ["02_processed/validate_report.json", "02_processed/production_regime_filter.json"]},
        {"from": FLOW, "to": TFLU, "r_overall": -0.7415, "r_within_circulation": strat[f"{TFLU} ~ {FLOW}"]["within_circulation_pearson"],
         "status": "validated_synchronous", "note": "Pearson -0.7415 / Spearman -0.7357 (rank-robust); CCF envelope broad and flat (no precedence peak); collapsed-state fluid warmer by 0.233 C — consistent with stagnation/churn heating while pump load stays on",
         "sources": ["02_processed/validate_report.json", "02_processed/time_lag_analysis.json"]},
        {"from": FLOW, "to": PRES, "r_overall": -0.0223,
         "status": "quantization_decoupled", "note": "linear law destroyed by 7-level quantization + regime mixture; MI(P,F)=1.0 normalized in validate_report — pressure levels nearly determine flow state bins; negative-pressure levels occur ~93% during circulation (decoupled from collapse); collapse rows sit mostly on the LOWEST positive platform 0.0547 bar (50/76) — not a closed-valve high shutoff head",
         "sources": ["02_processed/validate_report.json", "02_processed/physics_check.json"]},
        {"from": FLOW, "to": CUR, "r_overall": 0.0522, "partial_controlled": part["Current ~ Volume Flow RateRMS | Voltage"]["value"],
         "status": "decoupled_load_proxy", "note": "pump does NOT unload during collapse (2.338 vs 2.396 A); decoupling contradicts pump-curve operation, supports dead-head/throttled operation",
         "sources": ["02_processed/validate_report.json", "02_processed/production_regime_filter.json"]},
        {"from": VOL, "to": CUR, "r_overall": 0.4998, "status": "confounder_channel", "note": "voltage confounds current only; V~Flow r=0.030, V~Accel1 r=-0.061 — electricity fluctuation is NOT the anomaly driver",
         "sources": ["02_processed/validate_report.json"]},
        {"from": TFLU, "to": A1, "r_overall": 0.5675, "partial_controlled": part["Accelerometer1RMS ~ Thermocouple | Volume Flow RateRMS"]["value"],
         "status": "common_cause_confound_suspected", "note": "ontology flagged; partial correlation given flow conditioning quantifies residual direct association",
         "sources": ["01_ontology/ontology.json", "02_processed/production_regime_filter.json"]},
        {"from": TMOT, "to": TFLU, "r_overall": -0.3865, "status": "no_causal_edge", "note": "ontology: no causal edge set; both driven by different processes; motor temp itself stable (std 0.299)",
         "sources": ["01_ontology/ontology.json", "02_processed/validate_report.json"]},
        {"from": "VALVE_STATE_UNRECORDED", "to": FLOW, "status": "latent_hypothesis", "note": "H1 candidate driver — simultaneously explains flow collapse, pressure platform switching, vibration rise, stagnation heating; handed to diagnostician as competing hypothesis",
         "sources": ["01_ontology/ontology.json"]},
    ],
    "root_cause_candidates_fed_forward": [
        "H1 throttled/closed-valve dead-head operation (unrecorded valve state) — load kept on + stagnation heating support it; BUT collapse pressure sits on the LOW platform (not shutoff head) and the morphology is 40 brief recurring bursts (1-3 s), not a sustained closure — the naive 'one-time valve closing' variant is disfavored",
        "H2 cavitation / suction-side NPSHa loss — intermittent burst morphology, vibration rise and low-platform pressure during collapse are compatible; the specific 'negative suction vacuum during collapse' sub-signal is NOT supported (negative-pressure rows are ~93% during circulation)",
        "EXCLUDED by data: pump stoppage / motor underload (H3) — current stays near full load during collapse (2.338 vs 2.396 A; voltage-adjusted residual delta ~ -0.08 A)",
        "EXCLUDED by data: vibration sensor artifact (H4) — dual-channel sync, detrended/CCF/LOO robustness",
        "EXCLUDED by data: supply-voltage disturbance as driver (H5) — decoupled from flow/vibration",
    ],
}
with open(os.path.join(PRO, "causal_evidence_map.json"), "w", encoding="utf-8") as f:
    json.dump(cem, f, ensure_ascii=False, indent=1)

# ------------------------------------------------------------- figure
fig, axes = plt.subplots(1, 2, figsize=(12, 5), sharey=False)
circ = df[circ_mask]; low = df[low_mask]
ax = axes[0]
ax.scatter(circ[FLOW], circ[A1], s=8, alpha=0.5, color="#1f77b4", label=f"circulation (n={n_circ})")
ax.scatter(low[FLOW], low[A1], s=12, alpha=0.8, color="#d62728", label=f"low-flow/dead-head (n={n_low})")
ax.axvline(THRESH, color="k", ls="--", lw=1)
ax.set_xlabel("Volume Flow RateRMS (L/min)"); ax.set_ylabel("Accelerometer1RMS (g)")
ax.set_title(f"Vibration vs Flow by regime\nr_all={strat[f'{A1} ~ {FLOW}']['overall_pearson']}, r_circ={strat[f'{A1} ~ {FLOW}']['within_circulation_pearson']}")
ax.legend(fontsize=9); ax.grid(alpha=0.3)
ax = axes[1]
ax.scatter(circ[FLOW], circ[TFLU], s=8, alpha=0.5, color="#1f77b4", label=f"circulation (n={n_circ})")
ax.scatter(low[FLOW], low[TFLU], s=12, alpha=0.8, color="#d62728", label=f"low-flow/dead-head (n={n_low})")
ax.axvline(THRESH, color="k", ls="--", lw=1)
ax.set_xlabel("Volume Flow RateRMS (L/min)"); ax.set_ylabel("Thermocouple (degC)")
ax.set_title(f"Fluid temperature vs Flow by regime\nr_all={strat[f'{TFLU} ~ {FLOW}']['overall_pearson']}, r_circ={strat[f'{TFLU} ~ {FLOW}']['within_circulation_pearson']}")
ax.legend(fontsize=9); ax.grid(alpha=0.3)
fig.suptitle("SKAB loop — regime-stratified scatter (data: 02_processed/cleaned_data.csv, n=923)", fontsize=11)
fig.tight_layout(rect=[0, 0, 1, 0.94])
fig_path = os.path.join(FIG, "fig_regime_stratified_scatter.png")
fig.savefig(fig_path, dpi=150)
plt.close(fig)

print("WROTE:")
for p in ["production_regime_filter.json", "physics_check.json", "time_lag_analysis.json", "causal_evidence_map.json"]:
    print("  02_processed/" + p)
print("  03_figures/fig_regime_stratified_scatter.png")
print("\nKEY NUMBERS:")
print(f"  two_means_boundary={thr_2means}, threshold={THRESH}, n_low={n_low}, episodes={len(ep_list)}")
print(f"  A1~FLOW overall={strat[f'{A1} ~ {FLOW}']['overall_pearson']} circ={strat[f'{A1} ~ {FLOW}']['within_circulation_pearson']} low={strat[f'{A1} ~ {FLOW}']['within_low_flow_pearson']}")
print(f"  TFLU~FLOW overall={strat[f'{TFLU} ~ {FLOW}']['overall_pearson']} spearman={strat[f'{TFLU} ~ {FLOW}']['overall_spearman']} circ={strat[f'{TFLU} ~ {FLOW}']['within_circulation_pearson']}")
print(f"  CUR low/circ mean: {per_regime[CUR]['low_flow_mean']} / {per_regime[CUR]['circulation_mean']}")
print(f"  partial A1~TFLU|FLOW = {part['Accelerometer1RMS ~ Thermocouple | Volume Flow RateRMS']['value']}")
print(f"  partial CUR~FLOW|VOL = {part['Current ~ Volume Flow RateRMS | Voltage']['value']}")
print(f"  CCF TFLU~FLOW best lag {best['lag_s']}s r={best['r']} (lag0 {lag0['r']}, rank #{rank0})")
print(f"  state dT (low-circ) = {dT_state:.4f} C, P_elec_low = {P_elec_low:.1f} W")
for t in lvl_tab:
    print("  P-level", t["pressure_level_bar"], "rows", t["rows"], "low_flow_rows", t["rows_with_low_flow"], "mean_flow", t["mean_flow_at_level"])
