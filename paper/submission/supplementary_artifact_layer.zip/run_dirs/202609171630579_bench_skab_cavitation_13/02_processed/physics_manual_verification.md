# Physics Manual Verification — L1-L5 量级手工证明（diagnostician）

run_id: 202609171630579_bench_skab_cavitation_13
author: diagnostician (Chief Engineer Liu persona), Step 4
date: 2026-09-17T18:57Z

## 目的与边界

本文件是 `02_processed/physics_check.json`（data-processor 产物，6 项检查 PHY1-PHY6）的
**诊断侧手工量级复核（L1-L5 阶梯）**，供 `diagnostic-quality-check.mjs` 物理证明门使用。
所有数值取自运行目录既有工件并在括号内注明来源，可由 `00_input/data.csv`（n=923, 1 Hz）经
venv python 复算。本文件不修改任何上游工件。

说明：上游 `physics_check.json` 使用 `checks[] / n_checks` 字段命名；本门脚本按
`physical_checks / checks_performed` 契约读取而计为 0。自动检查实际已执行（n_checks=6），
本手工文档按门要求补齐诊断侧 L1-L5 量级证明，不构成对上游工件的替换。

## L1 物理量识别（列名/量纲/量程）

| 通道 | 物理量 | 单位 | 实测量程 | 来源 |
|---|---|---|---|---|
| Volume Flow RateRMS | 闭环回路体积流量（功能输出） | L/min | 0.5555–127.692 | 02_processed/feature_summary.json |
| Pressure | 泵后回路压力（7 级量化，步距≈0.328 bar） | Bar | -0.6011–1.3664 | 02_processed/physics_check.json PHY1 |
| Current | 电机定子电流（轴负载代理） | A | 0.894–3.2846 | 02_processed/feature_summary.json |
| Accelerometer1/2RMS | 泵体双测点振动加速度 RMS | g | 0.2363–0.2705 / 0.2784–0.3127 | 02_processed/feature_summary.json |
| Thermocouple / Temperature | 回路流体温度 / 电机本体温度 | ℃ | 28.8126–29.401 / 84.9816–86.4466 | 02_processed/feature_summary.json |
| Voltage | 供电电压（外生混杂） | V | 201.719–251.344 | 02_processed/feature_summary.json |

## L2 支配律选择

- 泵工况点：H = H0 − kQ² ∩ ΔP = k_sys·Q²（01_ontology/ontology.json EQ_PUMP/EQ_VALVE）
- 电机功率/转矩：P = V·I·cosφ·η；T ≈ k_T·I（ontology Current 条目）
- 流体能量平衡：m·Cp·dT/dt = Q̇_in − Q̇_out；死点下 Q̇_in ≈ 搅拌/摩擦耗散（ontology ST0 key_physics）
- 受迫振动：m·ẍ + c·ẋ + k·x = F(t)，F(t) 含水力脉动/气泡溃灭冲击（ontology EQ_ACC1）

## L3 因果链（塌落签名四元组）

阀路阻力改变（H1，阀位未记录）或吸入汽化（H2，NPSHa 未记录）→ 工况点迁移/两相阻塞
→ 流量塌落（<10 L/min，76 行）→ 同步：振动激励上升（+5.0%/+3.0%）、
滞止/搅拌升温（+0.233 ℃）、压力平台切换（MI=1.0）；电流通道证明泵未失去驱动（2.338 vs 2.396 A）。

## L4 量级校核（观测/预言比值）

| 校核 | 预言 | 观测 | 比值/结论 | 来源 |
|---|---|---|---|---|
| M1 死点功率保持 | 塌落期电功率 ≈ 循环态（比值≈1，死点下输入功转搅拌热） | 454.0 W vs ≈464 W（V·I·cosφ=0.85 假设） | 0.98 → PLAUSIBLE | 02_processed/physics_check.json PHY3 |
| M2 滞止加热方向 | 死点/节流态流体更暖（方向为正） | +0.233 ℃（29.235 vs 29.002 ℃）；爆发内中位 +0.0017 ℃/s | 方向 MATCH；爆发仅 1-3 s，能量闭合定量不可实现 → 不作定量判定 | PHY3 |
| M3 关死扬程量级 | 完全关阀预言压力升至高平台（≥1.0 bar 级） | 塌落期 50/76 行位于 0.0547 bar（最低正平台）；≥1.0 bar 级全数据仅 2 行（均在循环态） | 观测/预言 ≈ 0.05 → 关死子变体 IMPLAUSIBLE（修剪 H1 关死变体；不否定节流变体） | PHY4 + PHY1 levels 表 |
| M4 振动幅值筛查 | 结构性损伤/发达汽蚀预言持续 elevated（ISO 10816 型 ≥0.5 g 筛查限） | 全程 0.236–0.313 g | 观测/预言 ≈ 0.6×筛查限 → 良性窄带；状态耦合型而非损伤型 | PHY5 |
| M5 空载电流下限 | 感应电机空载励磁 ≈0.9 A（本体预期） | min(Current)=0.894 A（出现在非塌落时刻） | 0.99 → 通道对卸载敏感；塌落期 2.338 A 即"未卸载" | PHY6 |
| M6 塌落深度 | 任一"输送被阻断"机理预言 Q→0 量级 | min 0.56 L/min（循环平台 124.7 L/min 的 0.4%） | 与阻断类机理量级一致（泵停转 H3 无需此深度即可被电流通道否证） | production_regime_filter.json |

## L5 竞争机制清单（每链 ≥2 备择）

对"流量塌落+振动升+温升+负载保持"签名：H1 阀路阻力类（存活）、H2 吸入汽化类（存活）、
H3 驱动丧失类（M1/M5 反驳，排除置信 97）、H4 测量伪影类（五路稳健性反驳，95）、
H5 电气扰动类（三通道解耦反驳，95）——详见 04_diagnostics/diagnosis.json hypotheses.eliminated
与 discriminability_matrix。

## 量级校核结论

- M1/M2/M5 PLAUSIBLE（方向+量级命中）→ 支撑存活假设的物理底座；
- M3 IMPLAUSIBLE → 修剪 H1 完全关阀子变体与 H2 吸入真空子签名（对称修剪，不改变类级判别）；
- M4 提示两存活假设的激励均为状态耦合型、非结构损伤型；
- 判别缺口（阀位、吸入压力、高频谱）不在量级校核可达范围内 → 维持 COMPETING_SET（天花板 65）。
