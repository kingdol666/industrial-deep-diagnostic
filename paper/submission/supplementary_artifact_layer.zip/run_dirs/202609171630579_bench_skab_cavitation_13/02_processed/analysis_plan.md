# Analysis Plan — Step 3 data-processor (202609171630579_bench_skab_cavitation_13)

Persona: Engineer Zhang（工艺数据分析，16年）。默认语言：中文；图表标题/轴标签用英文。

## 0. Data View & Sources

- 数据视图：**process_only**（与 `02_processed/anomaly_report.json` 的 `dual_drive_analysis.data_view_mode` 一致）。8 个数值通道全部为过程/状态信号，**无检验/质量结果列** → 过程-质量联动（dual-drive）按协议记录为证据缺口。
- 数据源（单一权威源）：`02_processed/cleaned_data.json`（benchmark prepare 确定性摄取产物；923 行 = 原始 923 行，零删除、零改值；min/max 与 `00_input/input_inspection.json` 一致 → range fidelity 通过）。本阶段补齐其 CSV 形态 `02_processed/cleaned_data.csv`（逐值转换，供脚本与绘图使用）。
- 时间轴：真实时间列 `datetime`，1 Hz，2020-02-08 18:47:32 → 19:06:26（923 行，时间有序，已在 validate_report.sorting_validation 验证）。时序先序声明允许。

## Ontology-Guided Analysis Architecture

（Phase 0.4 门禁产物为 `02_processed/analysis_parameter_selection.json`，本节为其语义扩展）

### 参数物理分组（ontology.parameter_groups）
| 组 | 列 | 物理角色 |
|---|---|---|
| hydraulic | Volume Flow RateRMS (target), Pressure | 回路功能输出 + 泵后压力（量化台阶 ≈0.33 bar） |
| vibration | Accelerometer1RMS, Accelerometer2RMS | 泵体双测点冗余振动（g，窄带平稳） |
| electrical | Current, Voltage | 轴负载代理 + 外生混杂（Voltage role=confounder） |
| thermal | Temperature (电机本体), Thermocouple (流体) | 双热节点，热惯性不同 |

### 必析配对（Tier 1）与剪枝
- **必析**：Flow~Accel1/2（ontology 一级诊断信号，r=-0.821/-0.651，需反虚假复核）；Flow~Thermocouple（r=-0.741，方向与物理预期相反）；Accel1~Thermocouple（r=0.567，ontology 判为疑似共因混杂，需分层/偏相关核验）；Current~Flow（解耦 r=0.052，与相似律矛盾）；Pressure~Flow（解耦 r=-0.022 + 量化平台 + MI≈1.0）；Current~Voltage（混杂通道 r=0.500）。
- **剪枝**：无列剪枝（仅 8 通道，全部保留）；Temperature 的瞬时逐点相关不作因果证据（热惯性 >> 19 min 窗口，ontology 预言）。

### 本数据形态下无效的分析（不执行）
- 过程-质量跨域联动（无检验列）；批次/产品分层（无分组列）；多区域漂移定位；事件标记对齐；逐点 Current→Temperature CCF（热滞后超过窗口）。

## Hypothesis-Method Map（Phase 1.2）

详见 `02_processed/analysis_method_plan.json`（H1–H5，方法 M2/M5/M6/M7/M8/M13）。

| H | 主张 | 判别方法 | 预期判别力 |
|---|---|---|---|
| H1 | 阀门节流/闭阀死点工况切换 | M5 状态分割 + M8 分状态统计 + M13 压力平台×流量状态交叉表 + M7 功率-温升核算 | 高：电流是否卸载、流体是否滞止加热可直接判别 |
| H2 | 汽蚀（NPSHa 不足） | M13 负压共现 + M8 分状态振动/温度 + M7 | 高：负压平台与低流量的共现结构是关键判别量 |
| H3 | 泵停转/电机欠载 | M8 分状态电流/振动均值 | 高（预期被数据反驳：电流 2.338 vs 2.396 A，振动反升） |
| H4 | 振动-流量负相关为仪表伪影 | M2 反虚假族 + M6 lag CCF + M8 分状态分解 | 高（预期被反驳：双测点同步、detrended -0.789、lag1 -0.883、状态内符号反转） |
| H5 | 电压波动驱动 | M2 矩阵 + M8 电压分层偏相关 | 高（预期被反驳：V~Flow r=0.030） |

## Deviations from default battery

- 未跑全量三模式 `--mode full`：correlation+anti_spurious+batch 已由 prepare 阶段确定性执行（`full_battery_justified=false`，批次模式不适用）。
- v6.4 跨视图滞后补偿不适用（process_only）；M6 降级用于同步性验证。
- VLM 视觉分析（Phase 5.5）为非 VLM 环境：`visual_analysis.py` 输出脚本签名骨架，终态 metadata_backed_inference，不做 PNG 像素级解读。

## Production State / Steady-State（Phase 1.5）

单产品、无分组列 → 无 per-product 强制分析。状态分割按 ontology ST0/ST1：`Volume Flow RateRMS < 10 L/min` 为低流量/死点态（阈值同时用 2-means 双峰检验数据化复核，写入 `02_processed/production_regime_filter.json`）。被引用相关全部补做分状态（steady-state）复核 + 留一杠杆 + 滞后补偿 CCF（`06_scripts/ontology_guided_semantic_check.py`）。

## Baseline Script Findings and Gaps（Phase 2.7）

- prepare 已交付：cleaned_data / feature_summary / validate_report（Pearson+Spearman+detrended+lag CCF max_lag20+MI / 分布+离群敏感度+留一杠杆+Simpson+变点）/ anomaly_report / scenario_classification / analysis_parameter_selection / batch_integrity / fig_temporal_overview.png。
- **人工程师还会问什么（缺口）**：① 聚合 r=-0.821 剔除离群后反转为 +0.476 —— 状态混合还是真实两态物理？→ 需分状态相关（本阶段补）。② 负压平台（-0.273/-0.601 bar，151 行）与低流量是否共现？→ 压力水平×状态交叉表（本阶段补）。③ 死点期功率去哪了？→ 功率-温升数量级核算（本阶段补，标注假设）。④ Thermocouple~Flow 的先行性？→ 该对 lag CCF（validate_report 未覆盖该 target，本阶段补）。
- 自定义脚本：`06_scripts/ontology_guided_semantic_check.py`（venv python；输出 production_regime_filter.json / physics_check.json / time_lag_analysis.json / causal_evidence_map.json / fig_regime_stratified_scatter.png）。

## What we will NOT do

不解读 prepare 之外的 PNG 像素（非 VLM 环境）；不引入 run 目录外数据或网络检索；不用未经反虚假复核的相关作因果边；不替 diagnostician 做根因裁决（H1 vs H2 留给竞争假设协议）。
