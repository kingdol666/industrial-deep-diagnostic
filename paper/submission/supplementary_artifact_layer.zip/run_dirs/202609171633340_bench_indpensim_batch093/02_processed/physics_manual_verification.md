# Physics Manual Verification — diagnostician Step 4 (L1-L5 magnitude proofs)

Run: `202609171633340_bench_indpensim_batch093`
Author: diagnostician (Chief Engineer Liu). All numbers are recomputable from `00_input/data.csv`
via venv python scripts `06_scripts/diag_recompute_step4.py`, `06_scripts/diag_window_trace.py`,
`06_scripts/diag_recovery_pin.py`, and from the data-processor artifact
`06_scripts/semantic_batch093_output.json`. Automated targeted checks live in
`02_processed/physics_check.json` (5 checks); this file adds the manual magnitude ladder the
quality gate expects when automated coverage is thin.

## L1 Physical quantity identification

| Quantity | Column / source | Value |
|---|---|---|
| Controlled temperature T | `Temperature(T:K)` | setpoint 298.15 K, tolerance ±0.5 K (ontology `control_variables`), observed 297.81-301.44 K |
| Cooling actuator output Fc | `Heating/cooling water flow rate(Fc:L/h)` | normal range 0-940 L/h (ontology), observed 0.0001-939.2 |
| Heating actuator output Fh | `Heating water flow rate(Fh:L/h)` | mutually exclusive with Fc (ontology control edges) |
| Thermal-load channel Q | `Generated heat(Q:kJ)` | PROVEN T-coupled, not metabolic (see L3-2) |
| Metabolic intensity OUR | `Oxygen Uptake Rate(OUR:(g min^{-1}))` | absolute scale unreliable (60x unit-label mismatch, `02_processed/data_analysis_conclusion.json` H5); relative ratios only |

## L2 Governing laws applied

1. Energy balance: `m·Cp·dT/dt = Q̇_met − Fc·ρw·Cpw·ΔTw − losses` (ontology edge Generated heat→Temperature).
2. Control law: `Fc = f(T_sp − T)` PID, mutually exclusive with Fh (ontology edge Temperature→Fc).
3. Respiratory enthalpy: `Q̇_met ≈ 862.5·OUR kJ/h` (ΔH_O2 ≈ 460 kJ/mol O2, ontology OUR→Q edge).
4. Respiratory quotient: `RQ = CER·M_O2/(OUR·M_CO2) ≈ 0.9-1.1` (fully aerobic).

## L3 Causal chains verified (link-by-link)

- C1 (H1 chain): metabolic load up (OUR window mean 1.772 g/min vs pre-window 66-75.8 h 1.380, +28.4%; dP/dt 0.2234 vs production baseline 0.1471 g/L/h, +52%) → T leaves band at 75.8 h → cooling execution fails (Fc pinned 2.0 L/h for 72/72 rows of 75.8-90.0 h) → T integrates up to 301.44 K → Fc releases at 90.2 h (132.2→271.6 L/h) → T back in band by 92.4-93.0 h. Every arrow is directly observed at dt=0.2 h.
- C2 (Fh exclusion): Fh = 0 across the entire excursion window — heating side contributed no heat; mutual-exclusion logic intact.

## L4 Magnitude checks (PLAUSIBLE / BORDERLINE / IMPLAUSIBLE)

1. **Actuator response contrast (H1 decisive)**: 11 earlier same-direction over-band transients (15.2-49.6 h) at Q_mean 274.7-454.5 kJ show healthy-loop Fc responses 192.8-700.2 L/h (`06_scripts/semantic_batch093_output.json` above_band_intervals_ge_2samples). The fault window load was higher (Q_mean 1060.3 kJ in-window, peak sample 1369.7), so a healthy loop would demand ≥ the earlier range, saturating toward 940 L/h. Observed: 2.0 L/h pinned, 72/72 rows, none >5 L/h. Observed/expected ≈ 0.002-0.01 → IMPLAUSIBLE for an executing loop; this magnitude violation IS the fault signature of H1.
2. **Q-channel semantics (ontology OUR→Q CONTRADICTED)**: r(Q,T)=0.9958 full batch, 0.9996 inside the window, CCF best lag 0; r(Q,OUR)=0.1767. Expected metabolic power in-window ≈ 862.5×1.772 ≈ 1528 kJ/h ≈ 306 kJ per 0.2 h sample vs observed Q_mean 1060 kJ/sample (ratio ≈ 3.5) — Q is a coincident thermal (T-coupled) indicator, NOT a calibrated metabolic meter. Consequence: load quantification uses OUR/dP/dt relative ratios only. Verdict matches `02_processed/physics_check.json` metabolic_heat_vs_OUR FAIL.
3. **Pure capacity-exceeded check (H2)**: capacity floor demonstrated at 700 L/h rejecting Q≈455 kJ without saturation; even granting the 2.3x larger window load, a capacity-limited loop saturates Fc at max — observed 2.0 L/h. Additionally T fell within 2.4 h of Fc release while OUR stayed elevated (1.646 g/min post-window vs 1.306 baseline) — "surge passed" prediction falsified.
4. **DO critical margin**: DO min 10.402 mg/L (t=24.0 h) vs ontology normal-range low 6 mg/L; in-window DO rose to 15.08 mg/L. Oxygen limitation never active. (`02_processed/physics_check.json` DO_above_critical PASS.)
5. **Arrhenius direction (H6)**: rate view dP/dt~T in production phase r=+0.2478, rho=+0.336, n=978, LOO max_shift 0.0026 — no negative rate effect at excursion temperatures; the negative level-level P~T (rho=-0.57) is trend confounding (T~t rho=-0.57).
6. **RQ scale (data quality)**: naive RQ median 0.011 ≈ 80x below the aerobic window 0.9-1.1; single 60x reconciliation → 0.689 (IQR 0.624-0.823). At least one respiratory column carries a 60x unit-label mismatch; absolute RQ banned from the diagnosis.

## L5 Alternative mechanisms screened

- Common cause (batch phase change t=14.6 h): stratified away; fault window is entirely inside the fed-batch phase, 61 h after the boundary.
- Reverse causation (T drives OUR): the OUR step leads/accompanies band exit at onset within one sample; and cooling release at 90.2 h drove T down with no OUR drop — T is not driving the load.
- Artifact (sensor false-high): eliminated — controller acts on the same reading, Q co-move r=0.9996, post-recovery settling at band center. See `04_diagnostics/diagnosis.json` H3 elimination.
- Control-loop tuning artifact (weak gain): rejected as primary — healthy response 192.8-700.2 L/h at smaller errors proves authority; a gain problem cannot hold output at hard minimum (2.0 L/h) for 14.4 h of growing error.

Manual verification result: the only mechanism consistent with all L3-L4 evidence is H1 (cooling
execution-path non-response 75.8-90.2 h with recovery), riding on a real but secondary metabolic
load upsurge.
