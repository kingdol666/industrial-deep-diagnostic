# Analysis Plan — data-processor (Engineer Zhang) — batch_093 (IndPenSim penicillin fed-batch)

RUN_DIR: workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093
Data: 00_input/data.csv, 1050 rows x 32 cols, Time (h) 0.2-210.0, dt=0.2 h, no missing (feature_summary.json).
Ontology: 01_ontology/ontology.json (read BEFORE any statistics — ontology_first honored; semantic phases executed after prepare-stage deterministic artifacts).

## Detected data view mode

**process_only**（与 02_processed/anomaly_report.json dual_drive_analysis.data_view_mode 一致）。
离线化验列（X_offline / P_offline / PAA_offline / NH3_offline / Viscosity）各仅 19 点（约 12 h 间隔），属同域化验补充而非独立检验(inspection)数据流，不足以支撑跨域双驱动联动层。过程->质量联动缺口如实写入交接。

## Ontology-Guided Analysis Architecture (Phase 0.4 gate)

- 基线选择文件：02_processed/analysis_parameter_selection.json（benchmark prepare 阶段确定性生成）。
- 本批执行时的两处语义修正（记录于结论 analysis_boundary.notes）：
  1. `Fault reference(Fault_ref:Fault ref)` 被 prepare 列入 predictor_cols，但本体 events 节明确 truth_withheld、禁用于诊断 → 本阶段所有语义分析（含自定义脚本）**未加载该列**，并从引用列表中剔除。
  2. 本体 stage STG-0 推断 ≈0-45 h，由数据修正：残糖 S<0.05 g/L 规则定位批次相->补料相边界 **t=14.6 h**（S 批次相均值 2.03 g/L → 生产相中位 0.00117 g/L）。
- Tier-1 配对：P / DO2 两个质量目标 × 29 个过程预测列（validate_report.correlation.target_analysis 已全量给出，本阶段仅对**被引用**配对做反伪链验证）。
- Pruned：Agitator RPM（std=0）、Ammonia shots（恒 0）零方差不可辨识；Fault_ref 禁用。

## Hypothesis-Method Map (Phase 1.2 — 详见 02_processed/analysis_method_plan.json)

| H | 假设 | 方法 | 判别力来源 |
|---|------|------|-----------|
| H1 | 冷却执行侧非响应 | M13 窗口对照 + M6 CCF(T->Fc/Fh) + M7 | 越带窗口内/外 Fc 行为差异；控制方向滞后 |
| H2 | 越带窗口真实代谢上移 | M13 窗口统计 + M7 + M2 变点 | OUR/dP/DO 同步性 |
| H3 | 全批相关被相变混杂 | M8 相分层 + M2 + M13 LOO | 22 对 × 3 层符号/量级变化 |
| H4 | 高温损害产率 | M13 dP/dt~T + M1 + M2 | 速率视角 vs 水平视角分离 |
| H5 | OUR/CER 单位错配 | M7 RQ 量纲 | naive vs 60x 修正 RQ |
| H6 | 粘度-X 末段脱钩 | M13 化验点级 | 末 6 点同步性 |

传统必跑方法的跳过项及理由见 analysis_method_plan.json `skipped`（M3/M9/M10/M11 不可用，M6 降级，M5 以数据推导批次相替代）。

## Adaptive Decision Audit

| 决策 | 触发 | 处置 |
|------|------|------|
| 基线全量统计由 prepare 确定性完成 | benchmark 纪律（脚本只算不创作） | 直接消费 validate_report.json，不重跑 |
| H5/H6 为计划外新增 | M7 执行中发现 naive RQ=0.011、粘度末段形态 | 先回填 analysis_method_plan.escape_valve_additions 再执行 |
| focus_window_70_100h 追加 | H1 区间发现 75.8-92.4 h 持续越带 | 窗口内 OUR/DO/dP 对照以判别 H1 vs H2 |
| visual_analysis.py 输出 skeleton_pre_vlm | 本环境无 VLM | 升级为 metadata_backed_inference（脚本署名，零 PNG 读图声明） |

## Analysis Coverage Matrix

| 维度 | 状态 | 证据 |
|------|------|------|
| 纯过程分析 | covered | validate_report + 06_scripts/semantic_batch093_output.json + physics_check.json |
| 过程-检验双驱动 | not_applicable（process_only） | 缺口写入 handoff.evidence_gaps |
| 分组/混淆 | covered（批次相分层 + LOO + 混淆集声明） | phase_stratified_correlations、leave_one_out_leverage |
| 时间/工况/事件 | covered（相边界、排料事件、CCF 先序、越带区间） | time_lag_analysis.json、production_regime_filter.json |
| 场景专属 | covered（发酵批次相/呼吸/温控） | physics_check.json、analysis_method_plan.json |

## Product grouping strategy

单批次、无产品列（batch_integrity.json applicable=false）→ 不做 per-product 分析；以批次相（batch growth / fed-batch production）为分层单位。

## Baseline Script Findings and Gaps

- 基线发现：T max|z|=4.10、超 3σ 占 5.43%（anomaly_report）；P 变点 idx 120（anti_spurious.change_point_detection）；DO2 的 4 条"离群驱动"相关（Fw -75.9%、Q -67.1%、T -67.4% 衰减）；P~S、P~T Spearman 发散 0.30-0.31（SERIOUS）；跨域链接候选 10 条（V~Wt 0.999、T~Q 0.996 等）。
- 人类工艺工程师仍会问而基线未答的缺口（由 M13 自定义脚本补齐）：越带时段在哪、冷却侧是否动作、Q 通道与谁的物理一致、RQ 量纲是否可信、哪些相关在相分层后存活。

## What I will NOT do

- 不读取/不引用 `Fault reference` 列的任何值分布（本体 + 基准纪律）。
- 不读 results/ 与 scripts/benchmark/（基准红线）。
- 不对本体 discrepancy（温度越带、粘度-X、OUR 微负）之外的"异常"做无假设的扫描式声索。
- 不在无 VLM 的环境下声称读取了任何 PNG 内容。
- 不把批次相（生长相/补料相/排料操作）当作故障——它们是合法工况。
