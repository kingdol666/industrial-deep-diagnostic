import json, sys
try:
    import pandas as pd
    import numpy as np
except ImportError:
    print("NO_PANDAS"); sys.exit(2)

path = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093/00_input/data.csv"
df = pd.read_csv(path)
out = {"n_rows": int(len(df)), "n_cols": int(df.shape[1]), "columns": {}}
tcol = "Time (h)"
t = df[tcol]
out["time"] = {"start_h": float(t.iloc[0]), "end_h": float(t.iloc[-1]),
               "dt_h": float(np.median(np.diff(t.values)))}
for c in df.columns:
    s = pd.to_numeric(df[c], errors="coerce")
    d = {"dtype": str(df[c].dtype), "n_missing": int(s.isna().sum())}
    v = s.dropna()
    if len(v) > 0:
        d.update({"min": float(v.min()), "p05": float(v.quantile(0.05)),
                  "median": float(v.median()), "p95": float(v.quantile(0.95)),
                  "max": float(v.max()), "mean": float(v.mean()), "std": float(v.std())})
        thirds = np.array_split(v.values, 3)
        d["third_means"] = [float(np.mean(x)) for x in thirds]
    if c == "Fault reference(Fault_ref:Fault ref)":
        d["value_counts"] = {str(k): int(x) for k, x in df[c].value_counts(dropna=False).items()}
    out["columns"][c] = d
with open(r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093/00_input/context_builder_probe.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("OK rows=%d cols=%d t=[%s..%s]h" % (out["n_rows"], out["n_cols"], out["time"]["start_h"], out["time"]["end_h"]))
