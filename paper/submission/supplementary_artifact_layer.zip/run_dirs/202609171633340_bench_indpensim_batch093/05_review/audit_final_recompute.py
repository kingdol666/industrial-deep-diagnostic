# -*- coding: utf-8 -*-
"""Step 7 FINAL audit — independent recomputation from 00_input/data.csv only.
Auditor Sun, FINAL_AUDIT mode. Reads NO pipeline summary values."""
import csv, math

RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093"
CSV = RUN + "/00_input/data.csv"

rows = []
with open(CSV, newline="", encoding="utf-8") as f:
    rd = csv.DictReader(f)
    for r in rd:
        rows.append(r)

def num(r, k):
    v = r[k]
    try:
        return float(v)
    except (TypeError, ValueError):
        return None

t   = [num(r, "Time (h)") for r in rows]
T   = [num(r, "Temperature(T:K)") for r in rows]
Fc  = [num(r, "Heating/cooling water flow rate(Fc:L/h)") for r in rows]
Fh  = [num(r, "Heating water flow rate(Fh:L/h)") for r in rows]
Q   = [num(r, "Generated heat(Q:kJ)") for r in rows]
OUR = [num(r, "Oxygen Uptake Rate(OUR:(g min^{-1}))") for r in rows]
P   = [num(r, "Penicillin concentration(P:g/L)") for r in rows]

n = len(rows)
out = []
def say(s): out.append(s); print(s)

say("n_rows = %d" % n)

# F1 band compliance (band 297.65-298.65 K)
above = sum(1 for v in T if v > 298.65)
below = sum(1 for v in T if v < 297.65)
say("F1 above_band=%d/%d (%.2f%%) below_band=%d" % (above, n, 100.0*above/n, below))

# F2 sustained excursion window 75.8-92.4 h
idx_win = [i for i in range(n) if 75.8 <= t[i] <= 92.4]
say("F2 excursion_rows=%d t=[%.1f..%.1f] Tmax=%.3f @t=%.1f" %
    (len(idx_win), t[idx_win[0]], t[idx_win[-1]], max(T[i] for i in idx_win),
     t[max(idx_win, key=lambda i: T[i])]))

# F3 pin: 75.8-90.0 h, Fc unique values, >5 count
idx_pin = [i for i in range(n) if 75.8 <= t[i] <= 90.0]
pin_vals = set(round(Fc[i], 6) for i in idx_pin)
n_gt5 = sum(1 for i in idx_pin if Fc[i] > 5.0)
say("F3 pin_rows=%d t=[%.1f..%.1f] Fc_unique=%s n_gt5=%d T_start=%.2f T_end=%.3f" %
    (len(idx_pin), t[idx_pin[0]], t[idx_pin[-1]], sorted(pin_vals), n_gt5,
     T[idx_pin[0]], T[idx_pin[-1]]))

# F3b peak plateau
peak = max(T)
plat = [t[i] for i in range(n) if abs(T[i]-peak) < 1e-6]
say("F3b Tmax=%.3f plateau_t=%s" % (peak, plat))

# F4 strict band re-entry after release
for i in range(n):
    if t[i] >= 90.0 and T[i] <= 298.65:
        say("F4 strict_reentry t=%.1f T=%.3f (prev t=%.1f T=%.3f)" %
            (t[i], T[i], t[i-1], T[i-1])); break

# F5 release sequence 90.2-91.0 h
seq = [(t[i], Fc[i]) for i in range(n) if 90.0 < t[i] <= 91.0]
say("F5 release_seq=" + " ".join("%.1f:%.1f" % (a, b) for a, b in seq))

# F6 recovery T trajectory 90.0-93.0 h
traj = [(t[i], T[i]) for i in range(n) if 90.0 <= t[i] <= 93.0]
say("F6 T_traj=" + " ".join("%.1f:%.2f" % (a, b) for a, b in traj))

# F7 Fh in [66,100] h
fh = [Fh[i] for i in range(n) if 66.0 <= t[i] <= 100.0]
say("F7 Fh[66,100] max=%.4f" % max(fh))

# F8 last healthy strong response: Fc>100 before 75.8
pre = [(t[i], Fc[i]) for i in range(n) if t[i] < 75.8 and Fc[i] > 100.0]
say("F8 last Fc>100 before 75.8: t=%.1f Fc=%.1f ; tail_end(t_last>100 incl decay)=%.1f" %
    (pre[-1][0], pre[-1][1], pre[-1][0]))
tail = [x for x in pre if x[0] <= 56.0]
say("F8b tail 52-56h: " + " ".join("%.1f:%.1f" % a for a in [x for x in pre if 52.0 <= x[0] <= 56.0]))

# F9 healthy peak Fc
imax = max(range(n), key=lambda i: Fc[i])
say("F9 Fc_max=%.2f @t=%.1f" % (Fc[imax], t[imax]))

# F10 Fc==2.0 rows whole batch
n_pin_all = sum(1 for v in Fc if abs(v-2.0) < 1e-9)
say("F10 Fc==2.0 rows whole batch=%d" % n_pin_all)

# F11 12 rows Fc>100 inside 75.8-92.4, and inside 75.8-90.0
w_gt100 = [(t[i], Fc[i]) for i in idx_win if Fc[i] > 100.0]
pin_gt100 = [x for x in w_gt100 if x[0] <= 90.0]
say("F11 window Fc>100 rows=%d (t %.1f..%.1f) ; inside fault segment=%d" %
    (len(w_gt100), w_gt100[0][0], w_gt100[-1][0], len(pin_gt100)))

# F12 OUR four baselines
def mean(idx, arr): 
    vs = [arr[i] for i in idx if arr[i] is not None]
    return sum(vs)/len(vs) if vs else float('nan')
iw   = [i for i in range(n) if 75.8 <= t[i] <= 92.4]
ipre = [i for i in range(n) if 66.0 <= t[i] < 75.8]
ipos = [i for i in range(n) if 92.4 < t[i] <= 100.0]
o_w, o_pre, o_pos = mean(iw, OUR), mean(ipre, OUR), mean(ipos, OUR)
say("F12 OUR win=%.4f pre=%.4f (+%.1f%%) post=%.4f" %
    (o_w, o_pre, 100*(o_w-o_pre)/o_pre, o_pos))

# F13 dP/dt (0.2 h diff)
dp = [( (P[i]-P[i-1])/(t[i]-t[i-1]) ) for i in range(1, n)]
dp_t = [t[i] for i in range(1, n)]
def mean_dp(a, b):
    vs = [dp[j] for j in range(len(dp)) if a <= dp_t[j] <= b]
    return sum(vs)/len(vs)
say("F13 dP/dt win=%.4f pre=%.4f (+%.1f%%) Pmax=%.3f" %
    (mean_dp(75.8, 92.4), mean_dp(66.0, 75.8),
     100*(mean_dp(75.8,92.4)-mean_dp(66.0,75.8))/mean_dp(66.0,75.8), max(P)))

# F14 Q window vs outside band
q_win = mean(iw, Q)
q_out = [Q[i] for i in range(n) if not (75.8 <= t[i] <= 92.4)]
say("F14 Q_win_mean=%.1f Q_out_mean=%.1f" % (q_win, sum(q_out)/len(q_out)))

# F15 r(Q,T) full batch
def pearson(xs, ys):
    pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    m = len(pairs)
    mx = sum(x for x, _ in pairs)/m; my = sum(y for _, y in pairs)/m
    sxy = sum((x-mx)*(y-my) for x, y in pairs)
    sxx = math.sqrt(sum((x-mx)**2 for x, _ in pairs))
    syy = math.sqrt(sum((y-my)**2 for _, y in pairs))
    return sxy/(sxx*syy)
say("F15 r(Q,T) full=%.4f ; r(Q,OUR) full=%.4f" % (pearson(Q, T), pearson(Q, OUR)))

# F16 T after 93 h: min and 93-100 mean
after = [(t[i], T[i]) for i in range(n) if t[i] >= 93.0]
m93100 = mean([i for i in range(n) if 93.0 <= t[i] <= 100.0], T)
say("F16 T[93+] min=%.2f ; mean(93-100)=%.3f ; n_below_band_after93=%d" %
    (min(v for _, v in after), m93100, sum(1 for _, v in after if v < 297.65)))

with open(RUN + "/05_review/audit_final_recompute_output.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(out))
