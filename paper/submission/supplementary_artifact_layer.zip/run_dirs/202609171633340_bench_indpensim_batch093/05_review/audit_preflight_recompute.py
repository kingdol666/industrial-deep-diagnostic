# Auditor Sun pre-report audit: INDEPENDENT recomputation from 00_input/data.csv only.
# No pipeline artifact values are imported; every number below is recomputed from raw input.
import pandas as pd, numpy as np, json

RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093"
df = pd.read_csv(RUN + "/00_input/data.csv")
t = df["Time (h)"].values.astype(float)
T = df["Temperature(T:K)"].values.astype(float)
Fc = df["Heating/cooling water flow rate(Fc:L/h)"].values.astype(float)
Fh = df["Heating water flow rate(Fh:L/h)"].values.astype(float)
Q = df["Generated heat(Q:kJ)"].values.astype(float)
OUR = df["Oxygen Uptake Rate(OUR:(g min^{-1}))"].values.astype(float)
CER = df["Carbon evolution rate(CER:g/h)"].values.astype(float)
DO = df["Dissolved oxygen concentration(DO2:mg/L)"].values.astype(float)
P = df["Penicillin concentration(P:g/L)"].values.astype(float)
S = df["Substrate concentration(S:g/L)"].values.astype(float)
pH = df["pH(pH:pH)"].values.astype(float)
Fs = df["Sugar feed rate(Fs:L/h)"].values.astype(float)
Foil = df["Oil flow(Foil:L/hr)"].values.astype(float)
Fg = df["Aeration rate(Fg:L/h)"].values.astype(float)
CO2 = df["carbon dioxide percent in off-gas(CO2outgas:%)"].values.astype(float)

print("== A0 time grid ==")
print("rows", len(df), "t range", t.min(), t.max(), "dt unique-ish", np.unique(np.round(np.diff(t), 4))[:5],
      "sorted", bool(np.all(np.diff(t) > 0)), "nan T/Fc", int(np.isnan(T).sum()), int(np.isnan(Fc).sum()))

print("\n== A1 band compliance (298.15 +/- 0.5) ==")
above = T > 298.65
below = T < 297.65
print("above:", int(above.sum()), f"({100*above.mean():.2f}%)  below:", int(below.sum()))

print("\n== A2 contiguous above-band runs ==")
idx = np.where(above)[0]
runs = []
start = idx[0]
prev = idx[0]
for i in idx[1:]:
    if i != prev + 1:
        runs.append((start, prev))
        start = i
    prev = i
runs.append((start, prev))
print("n_runs:", len(runs))
early = [(a, b) for a, b in runs if t[b] < 75.0]
sust = [(a, b) for a, b in runs if t[b] >= 75.0]
print("early runs (<75.8h):")
for a, b in early:
    print(f"  {t[a]:6.1f}-{t[b]:6.1f} h  n={b-a+1:2d}  Tmax={T[a:b+1].max():.2f}  Fc_max={Fc[a:b+1].max():7.1f}  Q_mean={Q[a:b+1].mean():7.1f}")
print("sustained runs (>=75.8h):")
for a, b in sust:
    print(f"  {t[a]:6.1f}-{t[b]:6.1f} h  n={b-a+1}  Tmax={T[a:b+1].max():.3f} at t={t[a+int(np.argmax(T[a:b+1]))]:.1f}  Fc_mean={Fc[a:b+1].mean():.1f}  Q_mean={Q[a:b+1].mean():.1f}  T_std={T[a:b+1].std(ddof=0):.3f}")

print("\n== B1 actuator pin [75.8, 90.0] ==")
m = (t >= 75.8) & (t <= 90.0)
print("rows:", int(m.sum()), "Fc unique:", np.unique(Fc[m]), "Fc>5:", int((Fc[m] > 5).sum()),
      "T start/end:", round(T[m][0], 2), round(T[m][-1], 2), "max T-err vs 298.65:", round(float(T[m].max() - 298.65), 2))

print("\n== B2 release sequence 90.0-91.2 ==")
m2 = (t >= 90.0) & (t <= 91.2)
for i in np.where(m2)[0]:
    print(f"  t={t[i]:5.1f}  T={T[i]:7.2f}  Fc={Fc[i]:7.1f}  Fh={Fh[i]:5.1f}")

print("\n== B3 Fh in [66,100], last healthy Fc>150 before 75.8 ==")
m3 = (t >= 66) & (t <= 100)
print("Fh max in [66,100]:", float(Fh[m3].max()), " Fh mean:", round(float(Fh[m3].mean()), 4))
last = np.where((t < 75.8) & (Fc > 150))[0]
print("last t<75.8 with Fc>150:", float(t[last[-1]]), "Fc=", float(Fc[last[-1]]))

print("\n== B4 Fc>100 rows inside sustained window [75.8,92.4] ==")
m4 = (t >= 75.8) & (t <= 92.4)
ii = np.where(m4)[0]
hot = ii[Fc[ii] > 100]
print("n>100:", len(hot), "time range:", (float(t[hot.min()]), float(t[hot.max()])) if len(hot) else None)
print("Fc==2.0 rows whole batch:", int((Fc == 2.0).sum()), " Fc global min/max:", float(Fc.min()), float(Fc.max()))

print("\n== C recovery trajectory 90.0-93.0 ==")
m5 = (t >= 90.0) & (t <= 93.0)
for i in np.where(m5)[0][::1]:
    print(f"  t={t[i]:5.1f}  T={T[i]:7.2f}  Fc={Fc[i]:7.1f}")
back = np.where((t > 90.2) & (T <= 298.65))[0]
print("first t>90.2 back in band:", float(t[back[0]]))

print("\n== D1 window baselines ==")
prod = t > 14.6
inw = (t >= 75.8) & (t <= 92.4)
pre = (t >= 66) & (t < 75.8)
post = (t > 92.4) & (t <= 100)
outb = prod & ~((t >= 70) & (t <= 100))
def stat(mask, arr):
    return round(float(arr[mask].mean()), 4)
for name, arr in [("T", T), ("Fc", Fc), ("Q", Q), ("OUR", OUR), ("DO", DO), ("Fs", Fs), ("Foil", Foil), ("Fg", Fg), ("CER", CER), ("CO2", CO2)]:
    print(f"  {name:5s} pre={stat(pre,arr):>9} in={stat(inw,arr):>9} post={stat(post,arr):>9} prod_out={stat(outb,arr):>9}")
OUR_pct_pre = 100 * (OUR[inw].mean() / OUR[pre].mean() - 1)
OUR_pct_out = 100 * (OUR[inw].mean() / OUR[outb].mean() - 1)
OUR_pct_post = 100 * (OUR[post].mean() / OUR[outb].mean() - 1)
print(f"  OUR in vs pre: +{OUR_pct_pre:.1f}%   in vs prod_out: +{OUR_pct_out:.1f}%   post vs prod_out: +{OUR_pct_post:.1f}%")

print("\n== D2 OUR 10h buckets 40-130h (step vs trend) ==")
for lo in range(40, 130, 10):
    mm = (t >= lo) & (t < lo + 10)
    print(f"  {lo:3d}-{lo+10:3d}h  OUR={OUR[mm].mean():.3f}  Fg={Fg[mm].mean():7.1f}  Fs={Fs[mm].mean():6.1f}  DO={DO[mm].mean():6.2f}")

print("\n== D3 dP/dt (gradient of 5-pt centered rolling mean of P) ==")
dP = np.gradient(pd.Series(P).rolling(5, center=True, min_periods=1).mean().values, t)
print(f"  pre={dP[pre & prod].mean():.4f}  in={dP[inw & prod].mean():.4f}  post={dP[post & prod].mean():.4f}  prod_out={dP[outb].mean():.4f}")
print(f"  in vs prod_out: +{100*(dP[inw&prod].mean()/dP[outb].mean()-1):.1f}%   in vs pre: +{100*(dP[inw&prod].mean()/dP[pre&prod].mean()-1):.1f}%")

print("\n== D4 DO extremes ==")
print("  DO min:", float(DO.min()), "at t=", float(t[int(np.argmin(DO))]), " DO in-window mean:", round(float(DO[inw].mean()), 3),
      " prod_out mean:", round(float(DO[outb].mean()), 3))

print("\n== E1 Q channel semantics ==")
print("  r(Q,T) full:", round(float(np.corrcoef(Q, T)[0, 1]), 4), " r(Q,T) in-window:", round(float(np.corrcoef(Q[inw], T[inw])[0, 1]), 4))
print("  r(Q,OUR) full:", round(float(np.corrcoef(Q, OUR)[0, 1]), 4), " r(Q,OUR) production:", round(float(np.corrcoef(Q[prod], OUR[prod])[0, 1]), 4))
# lag CCF T->Fc and T->Fh on production phase, +/-20 steps
def best_lag(x, y, lags=range(-20, 21)):
    rs = {}
    for L in lags:
        if L < 0:
            a, b = x[-L:], y[:L]
        elif L > 0:
            a, b = x[:-L], y[L:]
        else:
            a, b = x, y
        rs[L] = float(np.corrcoef(a, b)[0, 1])
    bl = max(rs, key=lambda k: abs(rs[k]))
    return bl, rs[0], rs[bl]
bl, r0, rb = best_lag(T[prod], Fc[prod])
print(f"  CCF T->Fc (prod): best lag {bl} steps, r0={r0:.4f}, r_best={rb:.4f}")
bl2, r02, rb2 = best_lag(T[prod], Fh[prod])
print(f"  CCF T->Fh (prod): best lag {bl2} steps, r0={r02:.4f}, r_best={rb2:.4f}")

print("\n== E2 RQ and enthalpy ==")
with np.errstate(all="ignore"):
    rq_naive = CER / OUR / 60.0  # g/h vs g/min literal
rq_ok = rq_naive[np.isfinite(rq_naive) & (OUR > 0)]
print("  naive RQ median:", round(float(np.median(rq_ok)), 4), "n=", len(rq_ok))
print("  x60-corrected median:", round(float(np.median(rq_ok)) * 60, 3))
rat = (Q / 0.2) / (862.5 * OUR)
rat = rat[np.isfinite(rat) & (OUR > 0)]
print("  (Q/0.2h)/(862.5*OUR) median prod:", round(float(np.median(rat[prod[np.isfinite(rat)&(OUR>0)]])), 3), " batch:", round(float(np.median(rat)), 3))
print("  in-window Q_mean(kJ/0.2h):", round(float(Q[inw].mean()), 1), " metabolic expected:", round(862.5 * float(OUR[inw].mean()), 1),
      " ratio:", round(float(Q[inw].mean()) / (862.5 * float(OUR[inw].mean())), 2))

print("\n== F general kinetics sanity ==")
print("  P final:", float(P[-1]), " P max:", float(P.max()), " S median prod:", float(np.median(S[prod])))
print("  pH outside [6.4,6.6]:", int(((pH < 6.4) | (pH > 6.6)).sum()), " pH range:", float(pH.min()), float(pH.max()))
xo = df["Offline Biomass concentratio(X_offline:X(g L^{-1}))"].values.astype(float)
tt = t[~np.isnan(xo)]
xo = xo[~np.isnan(xo)]
r6 = float(np.corrcoef(tt[-6:], xo[-6:])[0, 1])
print("  X_offline last-6 r vs t:", round(r6, 3), " (claimed -0.992)")
print("  Fault reference col present:", "Fault reference(Fault_ref:Fault ref)" in df.columns,
      " unique:", df["Fault reference(Fault_ref:Fault ref)"].unique()[:5] if "Fault reference(Fault_ref:Fault ref)" in df.columns else None)
print("  T after recovery 93-100h mean:", round(float(T[(t >= 93) & (t <= 100)].mean()), 3),
      " min/max:", round(float(T[(t >= 93)].min()), 3), round(float(T[(t >= 93)].max()), 3))
print("  n rows T below 297.65 after 93h:", int((T[t >= 93] < 297.65).sum()))
