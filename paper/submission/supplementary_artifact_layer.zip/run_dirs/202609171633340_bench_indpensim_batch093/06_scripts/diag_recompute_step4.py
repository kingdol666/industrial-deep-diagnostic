# Diagnostician Step-4 recomputation spot-checks (venv python, 00_input/data.csv only)
import pandas as pd, numpy as np, json
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093"
df = pd.read_csv(RUN + "/00_input/data.csv")
t = df["Time (h)"].values
T = df["Temperature(T:K)"].values
Fc = df["Heating/cooling water flow rate(Fc:L/h)"].values
Fh = df["Heating water flow rate(Fh:L/h)"].values
Q  = df["Generated heat(Q:kJ)"].values
OUR= df["Oxygen Uptake Rate(OUR:(g min^{-1}))"].values
DO = df["Dissolved oxygen concentration(DO2:mg/L)"].values
P  = df["Penicillin concentration(P:g/L)"].values
Fs = df["Sugar feed rate(Fs:L/h)"].values
Foil=df["Oil flow(Foil:L/hr)"].values
Fg = df["Aeration rate(Fg:L/h)"].values
CO2= df["carbon dioxide percent in off-gas(CO2outgas:%)"].values

def win(m):
    return dict(n=int(m.sum()), T_mean=round(float(T[m].mean()),3), T_max=round(float(T[m].max()),3),
                Fc_mean=round(float(Fc[m].mean()),1), Fc_max=round(float(Fc[m].max()),1),
                Fh_mean=round(float(Fh[m].mean()),1), Q_mean=round(float(Q[m].mean()),1),
                OUR_mean=round(float(OUR[m].mean()),4), DO_mean=round(float(DO[m].mean()),3),
                Fs_mean=round(float(Fs[m].mean()),2), Foil_mean=round(float(Foil[m].mean()),2),
                Fg_mean=round(float(Fg[m].mean()),2), CO2_mean=round(float(CO2[m].mean()),4))

# dP/dt with 1-h centered rolling mean, production phase
dP = np.gradient(pd.Series(P).rolling(5, center=True, min_periods=1).mean().values, t)
prod = t > 14.6
inw  = (t >= 75.8) & (t <= 92.4)
pre  = (t >= 66.0) & (t < 75.8) & prod          # pre-window production baseline
post = (t > 92.4) & (t <= 100.0)                # post-window recovery
outb = prod & ~((t >= 70.0) & (t <= 100.0))     # production outside 70-100h

print("PRE_WINDOW 66-75.8h:", json.dumps(win((t>=66)&(t<75.8))))
print("IN_WINDOW 75.8-92.4h:", json.dumps(win(inw)))
print("POST_WINDOW 92.4-100h:", json.dumps(win(post)))
print("OUTSIDE70_100 prod:", json.dumps(win(outb)))
print("dP/dt in-window mean:", round(float(dP[inw & prod].mean()),4))
print("dP/dt pre-window mean:", round(float(dP[pre].mean()),4))
print("dP/dt post-window mean:", round(float(dP[post & prod].mean()),4))
print("dP/dt outside-70-100 prod mean:", round(float(dP[outb].mean()),4))
# T maximum timing and trajectory coarseness in window (setpoint-plateau check)
iw = np.where(inw)[0]
print("T in window: start", float(T[iw[0]]), "end", float(T[iw[-1]]), "argmax t", float(t[iw[int(np.argmax(T[iw]))]]))
print("T std in window:", round(float(T[iw].std()),3))
# number of window rows where Fc>100 and >50
print("Fc>100 rows in window:", int((Fc[inw]>100).sum()), " Fc>50:", int((Fc[inw]>50).sum()), "of", int(inw.sum()))
# Pearson r T~Q inside window (is the co-move preserved inside the fault window?)
r_in = float(np.corrcoef(T[inw], Q[inw])[0,1]); print("r(T,Q) inside window:", round(r_in,4))
# OUR % vs pre-window baseline
print("OUR pct vs pre 66-75.8h:", round(100*(OUR[inw].mean()/OUR[(t>=66)&(t<75.8)].mean()-1),1))
print("OUR pct vs outside70-100:", round(100*(OUR[inw].mean()/OUR[outb].mean()-1),1))
# CO2 and CER co-move inside window (independent corroboration of real surge)
CER = df["Carbon evolution rate(CER:g/h)"].values
print("CER in-window mean:", round(float(CER[inw].mean()),3), "outside:", round(float(CER[outb].mean()),3),
      "pre:", round(float(CER[(t>=66)&(t<75.8)].mean()),3))
