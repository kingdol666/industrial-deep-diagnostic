import pandas as pd, numpy as np
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093"
df = pd.read_csv(RUN + "/00_input/data.csv")
t = df["Time (h)"].values; T = df["Temperature(T:K)"].values
Fc = df["Heating/cooling water flow rate(Fc:L/h)"].values
m = (t >= 89.8) & (t <= 91.0)
for i in np.where(m)[0]:
    print(f"t={t[i]:5.1f}  T={T[i]:7.2f}  Fc={Fc[i]:7.1f}")
# count consecutive rows at Fc == 2.0 within window
w = (t >= 75.8) & (t <= 90.0)
print("rows in 75.8-90.0h:", int(w.sum()), "Fc==2.0 rows:", int((Fc[w] == 2.0).sum()),
      "Fc>5 rows:", int((Fc[w] > 5).sum()))
# last pre-window healthy strong response
last = np.where((t < 75.8) & (Fc > 150))[0]
print("last pre-window Fc>150 sample:", float(t[last[-1]]), "Fc =", float(Fc[last[-1]]))
