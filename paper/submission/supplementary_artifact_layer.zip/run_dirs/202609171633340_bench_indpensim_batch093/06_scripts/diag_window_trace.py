import pandas as pd, numpy as np
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093"
df = pd.read_csv(RUN + "/00_input/data.csv")
t = df["Time (h)"].values
T = df["Temperature(T:K)"].values
Fc = df["Heating/cooling water flow rate(Fc:L/h)"].values
Q  = df["Generated heat(Q:kJ)"].values
OUR= df["Oxygen Uptake Rate(OUR:(g min^{-1}))"].values
m = (t >= 75.0) & (t <= 93.5)
idx = np.where(m)[0]
print(" t_h     T      Fc      Q      OUR")
for i in idx[::3]:
    bar = "#" * int(min(Fc[i], 60) / 1.5)
    print(f"{t[i]:6.1f} {T[i]:7.2f} {Fc[i]:6.1f} {Q[i]:7.1f} {OUR[i]:6.3f} {bar}")
