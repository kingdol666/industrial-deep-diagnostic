# -*- coding: utf-8 -*-
"""
semantic_batch093.py — data-processor Phase 2.7/3 custom semantic analysis ( Engineer Zhang )
Run dir : workspace/diagnostic-runs/202609171633340_bench_indpensim_batch093
Input   : 00_input/data.csv (raw, 1050 rows x 32 cols; 'Fault reference' column is NEVER loaded)
Output  : 06_scripts/semantic_batch093_output.json   (all numbers below are recomputable from here)
          02_processed/production_regime_filter.json (batch-phase regime filter)
          02_processed/time_lag_analysis.json        (lag CCF over cited process pairs)
          02_processed/physics_check.json            (RQ + metabolic-heat energy sanity)
          03_figures/fig_temp_excursion_window.png   (targeted figure, matplotlib)

Ontology-guided questions (01_ontology/ontology.json):
  Q1 Where are the Temperature excursions vs setpoint 298.15+/-0.5 K, and what co-moves (Q, Fc, Fh, DO2)?
  Q2 Which correlations survive batch-phase (regime) stratification? (full-batch stats are trend-confounded)
  Q3 Lag CCF temporal precedence for the cited pairs (anti-spurious v6.4, process-only pairs).
  Q4 Physics sanity: RQ (aerobic window 0.9-1.1), metabolic heat Q vs OUR (deltaH_O2 ~ 460 kJ/mol O2).
  Q5 DO2 low windows; P production rate vs T (Arrhenius direction); Viscosity vs X_offline decoupling;
     OUR zero-bias artifact; pH band excursions vs Fa/Fb action.
"""
import json, csv, math, os
import numpy as np

RUN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(RUN, "00_input", "data.csv")
OUT_DIR = os.path.join(RUN, "06_scripts")
PROC = os.path.join(RUN, "02_processed")
FIG = os.path.join(RUN, "03_figures")

T_SET, T_TOL = 298.15, 0.5
DT_H = 0.2  # sampling interval, hours (ontology metadata)

C = {
    "t": "Time (h)",
    "T": "Temperature(T:K)",
    "Q": "Generated heat(Q:kJ)",
    "Fc": "Heating/cooling water flow rate(Fc:L/h)",
    "Fh": "Heating water flow rate(Fh:L/h)",
    "DO": "Dissolved oxygen concentration(DO2:mg/L)",
    "P": "Penicillin concentration(P:g/L)",
    "S": "Substrate concentration(S:g/L)",
    "Fs": "Sugar feed rate(Fs:L/h)",
    "Fg": "Aeration rate(Fg:L/h)",
    "OUR": "Oxygen Uptake Rate(OUR:(g min^{-1}))",
    "CER": "Carbon evolution rate(CER:g/h)",
    "CO2": "carbon dioxide percent in off-gas(CO2outgas:%)",
    "V": "Vessel Volume(V:L)",
    "Wt": "Vessel Weight(Wt:Kg)",
    "Foil": "Oil flow(Foil:L/hr)",
    "pH": "pH(pH:pH)",
    "Fb": "Base flow rate(Fb:L/h)",
    "Fa": "Acid flow rate(Fa:L/h)",
    "visc": "Viscosity(Viscosity_offline:centPoise)",
    "Xoff": "Offline Biomass concentratio(X_offline:X(g L^{-1}))",
    "Frem": "Dumped broth flow(Fremoved:L/h)",
}

rows = []
with open(DATA, encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)
n = len(rows)
col = lambda k: np.array([float(x[C[k]]) if x[C[k]] not in ("", "NaN", "nan") else np.nan for x in rows])
d = {k: col(k) for k in C}
assert n == 1050, n
t = d["t"]

def pr(a, b, mask=None):
    """pearson + spearman on optional mask, nan-dropped pairwise"""
    x, y = a, b
    if mask is not None:
        x, y = a[mask], b[mask]
    ok = ~(np.isnan(x) | np.isnan(y))
    x, y = x[ok], y[ok]
    if len(x) < 3:
        return {"n": int(len(x)), "r": None, "rho": None}
    r = float(np.corrcoef(x, y)[0, 1])
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    rho = float(np.corrcoef(rx, ry)[0, 1])
    return {"n": int(len(x)), "r": round(r, 4), "rho": round(rho, 4)}

def loo(a, b, mask=None):
    x, y = (a, b) if mask is None else (a[mask], b[mask])
    ok = ~(np.isnan(x) | np.isnan(y))
    x, y = x[ok], y[ok]
    r0 = np.corrcoef(x, y)[0, 1]
    worst = 0.0
    for i in range(len(x)):
        m = np.ones(len(x), bool); m[i] = False
        r1 = np.corrcoef(x[m], y[m])[0, 1]
        worst = max(worst, abs(r0 - r1))
    return {"full_r": round(float(r0), 4), "max_shift": round(float(worst), 4), "leveraged": bool(worst > 0.05)}

def intervals(mask):
    """contiguous True runs -> list of (i0, i1) inclusive"""
    out, i = [], 0
    while i < len(mask):
        if mask[i]:
            j = i
            while j + 1 < len(mask) and mask[j + 1]:
                j += 1
            out.append((i, j)); i = j + 1
        else:
            i += 1
    return out

def merge_short(iv, min_len):
    return [x for x in iv if x[1] - x[0] + 1 >= min_len]

res = {"meta": {
    "script": "06_scripts/semantic_batch093.py",
    "input": "00_input/data.csv",
    "n_rows": n, "dt_h": DT_H,
    "excluded_columns": ["Fault reference(Fault_ref:Fault ref) — ontology events section: truth withheld, excluded from diagnosis"],
    "t_span_h": [float(t.min()), float(t.max())],
}}

# ---------- Q2a: batch-phase segmentation from data (S = residual sugar) ----------
S = d["S"]
depleted = S < 0.05
# production phase starts at first index from which S stays < 0.05 to the end
k0 = None
for i in range(n):
    if depleted[i:].all():
        k0 = i; break
res["batch_phase"] = {
    "rule": "batch growth phase = rows with Substrate concentration S >= 0.05 g/L; production phase = S < 0.05 g/L to batch end",
    "threshold_S_gL": 0.05,
    "batch_phase_rows": int((~depleted).sum()),
    "production_phase_rows": int(depleted.sum()),
    "transition_index": int(k0),
    "transition_time_h": float(t[k0]),
    "last_S_ge_thres_time_h": float(t[k0 - 1]),
    "S_batch_mean": round(float(S[~depleted].mean()), 4),
    "S_production_median": round(float(np.median(S[depleted])), 5),
}

prod = np.zeros(n, bool); prod[k0:] = True

# ---------- draw-off events ----------
Frem = d["Frem"]
draw = Frem < 0
iv_draw = intervals(draw)
res["draw_off_events"] = {
    "rows_with_draw_off": int(draw.sum()),
    "n_events": len(iv_draw),
    "first_event_h": float(t[iv_draw[0][0]]) if iv_draw else None,
    "last_event_end_h": float(t[iv_draw[-1][1]]) if iv_draw else None,
    "total_removed_L": round(float(-(Frem[draw].sum() * DT_H)), 1),
    "max_rate_Lh": float(Frem.min()),
}

# ---------- Q1: temperature excursions ----------
T = d["T"]
hi = T > (T_SET + T_TOL)
lo = T < (T_SET - T_TOL)
exc = hi | lo
iv_hi = merge_short(intervals(hi), 2)
iv_lo = merge_short(intervals(lo), 2)
res["temperature_control"] = {
    "setpoint_K": T_SET, "tolerance_K": T_TOL,
    "p95_K": round(float(np.percentile(T, 95)), 2),
    "max_K": float(T.max()), "min_K": float(T.min()),
    "n_above_band": int(hi.sum()), "pct_above_band": round(float(hi.mean() * 100), 2),
    "n_below_band": int(lo.sum()), "pct_below_band": round(float(lo.mean() * 100), 2),
    "above_band_intervals_ge_2samples": [
        {"i0": int(a), "i1": int(b), "t_start_h": float(t[a]), "t_end_h": float(t[b]),
         "n": int(b - a + 1), "T_max_K": round(float(T[a:b + 1].max()), 2),
         "Q_mean": round(float(d["Q"][a:b + 1].mean()), 1),
         "Fc_mean": round(float(d["Fc"][a:b + 1].mean()), 1),
         "Fh_mean": round(float(d["Fh"][a:b + 1].mean()), 1),
         "DO_mean": round(float(d["DO"][a:b + 1].mean()), 2)}
        for a, b in iv_hi][:12],
    "below_band_intervals_ge_2samples": [
        {"i0": int(a), "i1": int(b), "t_start_h": float(t[a]), "t_end_h": float(t[b]),
         "n": int(b - a + 1), "T_min_K": round(float(T[a:b + 1].min()), 2)}
        for a, b in iv_lo][:8],
}
# inside vs outside excursion comparison
res["temperature_control"]["inside_vs_outside"] = {
    "Q_mean_in": round(float(d["Q"][hi].mean()), 1) if hi.any() else None,
    "Q_mean_out": round(float(d["Q"][~hi].mean()), 1),
    "Fc_mean_in": round(float(d["Fc"][hi].mean()), 1) if hi.any() else None,
    "Fc_mean_out": round(float(d["Fc"][~hi].mean()), 1),
    "Fh_mean_in": round(float(d["Fh"][hi].mean()), 1) if hi.any() else None,
    "Fh_mean_out": round(float(d["Fh"][~hi].mean()), 1),
}

# ---------- Q5b: DO2 windows ----------
DO = d["DO"]
low = DO < 12.0
iv_do = merge_short(intervals(low), 2)
res["dissolved_oxygen"] = {
    "min_mgL": float(DO.min()), "min_at_h": float(t[int(np.argmin(DO))]),
    "mean_production_phase": round(float(DO[prod].mean()), 2),
    "mean_batch_phase": round(float(DO[~prod].mean()), 2),
    "n_below_12": int(low.sum()),
    "below_12_intervals_ge_2samples": [
        {"t_start_h": float(t[a]), "t_end_h": float(t[b]), "n": int(b - a + 1),
         "DO_min": round(float(DO[a:b + 1].min()), 2)} for a, b in iv_do][:10],
    "critical_oxygen_margin": "min 10.40 mg/L vs ontology normal_range low 6 mg/L — DO never below ontology normal band",
}

# ---------- Q5c: P production rate vs T (production phase) ----------
P = d["P"]
dP = np.full(n, np.nan); dP[1:] = (P[1:] - P[:-1]) / DT_H
# 1-h centered rolling mean of dP
w = 5
dPs = np.convolve(np.nan_to_num(dP, nan=0.0), np.ones(w) / w, mode="same")
m = prod & ~np.isnan(dPs)
res["p_rate_vs_T_production_phase"] = {
    "method": "dP/dt (0.2 h diff) with 1-h centered rolling mean, production phase rows only",
    **pr(dPs[m], T[m]),
    "dP_mean_gLh": round(float(np.nanmean(dP[prod])), 4),
    "T_mean_production": round(float(T[prod].mean()), 2),
}

# ---------- Q2b: phase-stratified correlations for cited pairs ----------
pairs = [
    ("P", "Fg"), ("P", "V"), ("P", "Wt"), ("P", "CO2"), ("P", "OUR"), ("P", "Foil"),
    ("P", "T"), ("P", "S"), ("P", "CER"), ("P", "Fs"),
    ("DO", "T"), ("DO", "Fg"), ("DO", "OUR"), ("DO", "Q"),
    ("T", "Q"), ("T", "Fh"), ("T", "Fc"), ("Q", "OUR"), ("Q", "t"), ("T", "t"),
    ("OUR", "CER"), ("visc", "Xoff"),
]
strat = {}
for a, b in pairs:
    strat[f"{a}~{b}"] = {
        "full_batch": pr(d[a], d[b]),
        "production_phase": pr(d[a], d[b], prod),
        "batch_phase": pr(d[a], d[b], ~prod),
    }
res["phase_stratified_correlations"] = {
    "note": "anti-spurious v6.5: full-batch correlations span the batch->fed-batch regime change (change point at idx 120 in validate_report anti_spurious.change_point_detection.P) and are trend-confounded; stratification by data-derived batch phase",
    "pairs": strat,
}

# ---------- Q2c: leave-one-out leverage for pairs actually cited ----------
loo_pairs = [("T", "Q", None), ("P", "T", prod), ("P", "Fg", prod), ("P", "CO2", prod), ("P", "Foil", prod), ("P", "V", prod), ("DO", "T", prod)]
res["leave_one_out_leverage"] = {
    f"{a}~{b}" + ("" if msk is None else "@production"): loo(d[a], d[b], msk)
    for a, b, msk in loo_pairs
}

# ---------- Q3: lag CCF (dt=0.2 h, |lag| <= 20 steps = 4 h) ----------
def ccf(x, y, max_lag=20):
    ok = ~(np.isnan(x) | np.isnan(y))
    x, y = x[ok], y[ok]
    out = {}
    for k in range(-max_lag, max_lag + 1):
        if k > 0:
            r = np.corrcoef(x[:-k], y[k:])[0, 1]   # x leads y by k steps
        elif k < 0:
            r = np.corrcoef(x[-k:], y[:k])[0, 1]   # y leads x by |k| steps
        else:
            r = np.corrcoef(x, y)[0, 1]
        out[k] = float(r)
    return out

ccf_pairs = [("Q", "T"), ("T", "Fc"), ("T", "Fh"), ("Fg", "DO"), ("OUR", "CER"), ("Fs", "S"), ("Q", "OUR")]
ccf_res = {}
for a, b in ccf_pairs:
    cc = ccf(d[a], d[b])
    best = max(cc, key=lambda k: abs(cc[k]))
    ccf_res[f"{a}-> {b}"] = {
        "r_lag0": round(cc[0], 4),
        "best_lag_steps": int(best),
        "best_lag_h": round(abs(best) * DT_H, 2),
        "r_best": round(cc[best], 4),
        "leader": ("x(" + a + ")" if best > 0 else ("y(" + b + ")" if best < 0 else "synchronous")),
        "improvement_pct": round((abs(cc[best]) - abs(cc[0])) / max(abs(cc[0]), 1e-9) * 100, 1),
    }
res["lag_ccf"] = {
    "method": "lagged cross-correlation, lags -20..+20 steps (dt=0.2 h, +/-4 h); positive lag: first-named series leads",
    "pairs": ccf_res,
}

# ---------- Q4: physics — RQ and metabolic heat ----------
OUR, CER, Q = d["OUR"], d["CER"], d["Q"]
rq = np.full(n, np.nan)
m = (OUR > 0.05) & ~np.isnan(OUR) & ~np.isnan(CER)
rq[m] = (CER[m] / 44.01) / (OUR[m] * 60.0 / 32.00)
dh_o2 = 460.0  # kJ/mol O2
q_expected_power = OUR * 60.0 * (dh_o2 / 32.00)          # kJ/h
q_obs_power_interval = Q / DT_H                            # kJ/h if Q is kJ per 0.2 h sample
ratio = q_obs_power_interval / np.where(q_expected_power > 0, q_expected_power, np.nan)
res["physics_checks"] = {
    "RQ": {
        "definition": "RQ = (CER[g/h]/M_CO2) / (OUR[g/min]*60/M_O2); M_CO2=44.01, M_O2=32.00",
        "mask": "OUR > 0.05 g/min",
        "n": int(np.sum(~np.isnan(rq))),
        "median": round(float(np.nanmedian(rq)), 3),
        "p25_p75": [round(float(np.nanpercentile(rq, 25)), 3), round(float(np.nanpercentile(rq, 75)), 3)],
        "min_max": [round(float(np.nanmin(rq)), 3), round(float(np.nanmax(rq)), 3)],
        "aerobic_window_check": "ontology governing law RQ~0.9-1.1",
    },
    "metabolic_heat": {
        "definition": "expected metabolic power = OUR[g/min]*60*(460 kJ/mol O2 / 32 g/mol) = 862.5*OUR kJ/h; observed power = Q/0.2 assuming Q is kJ accumulated per 0.2 h sample",
        "ratio_median_all": round(float(np.nanmedian(ratio)), 3),
        "ratio_median_batch_phase": round(float(np.nanmedian(ratio[~prod])), 3),
        "ratio_median_production_phase": round(float(np.nanmedian(ratio[prod])), 3),
        "Q_mean_by_phase": [round(float(Q[~prod].mean()), 1), round(float(Q[prod].mean()), 1)],
        "OUR_mean_by_phase": [round(float(OUR[~prod].mean()), 3), round(float(OUR[prod].mean()), 3)],
        "Q_T_r_full": strat["T~Q"]["full_batch"]["r"],
        "Q_OUR_r_full": strat["Q~OUR"]["full_batch"]["r"],
    },
}

# ---------- Q5d: viscosity vs X_offline (19 lab points) ----------
visc, Xoff = d["visc"], d["Xoff"]
mv = ~np.isnan(visc)
last6 = np.zeros(n, bool)
idxs = np.where(mv)[0]
last6[idxs[-6:]] = True
res["viscosity_vs_biomass"] = {
    "n_lab_points": int(mv.sum()),
    "visc_X_r_full_lab": pr(visc, Xoff),
    "visc_t_r_lab": pr(visc[mv], t[mv]),
    "X_t_r_last6_lab": pr(Xoff[last6], t[last6]),
    "last6_X_mean": round(float(np.nanmean(Xoff[last6])), 2),
    "last6_visc_first_last": [float(visc[idxs[-6]]), float(visc[idxs[-1]])],
    "last6_visc_rise_pct": round(float((visc[idxs[-1]] / visc[idxs[-6]] - 1) * 100), 1),
    "last6_X_range": [float(np.nanmin(Xoff[last6])), float(np.nanmax(Xoff[last6]))],
}

# ---------- Q5e: OUR zero-bias; pH band ----------
OURv = d["OUR"]
early = t <= 2.0
res["our_zero_bias"] = {
    "n_rows_t_le_2h": int(early.sum()),
    "n_negative_early": int((OURv[early] < 0).sum()),
    "min_early": round(float(OURv[early].min()), 4),
    "n_negative_overall": int((OURv < 0).sum()),
    "first_time_OUR_ge_0_all_rest": None,
}
pH, Fb, Fa = d["pH"], d["Fb"], d["Fa"]
ph_hi = pH > 6.6
ph_lo = pH < 6.4
res["ph_control"] = {
    "n_outside_6p4_6p6": int((ph_hi | ph_lo).sum()),
    "pct_outside": round(float((ph_hi | ph_lo).mean() * 100), 2),
    "min": float(pH.min()), "max": float(pH.max()),
    "Fb_mean_when_in_band": round(float(Fb[~(ph_hi | ph_lo)].mean()), 1),
    "Fb_mean_when_out": round(float(Fb[ph_hi | ph_lo].mean()), 1) if (ph_hi | ph_lo).any() else None,
    "Fa_n_active": int((Fa > 0).sum()),
}

# ---------- Q1b: focus window 70-100 h — cooling-side response during the sustained excursion ----------
w0, w1 = 70.0, 100.0
wm = (t >= w0) & (t <= w1)
big = (t >= 75.8) & (t <= 92.4)
out_prod = prod & ~big & ~wm
res["focus_window_70_100h"] = {
    "window_h": [w0, w1],
    "sustained_excursion_h": [75.8, 92.4],
    "T_max": float(T[wm].max()),
    "T_max_at_h": float(t[int(np.argmax(np.where(wm, T, -np.inf)))]),
    "Fc_mean": round(float(d["Fc"][wm].mean()), 1),
    "Fc_max": round(float(d["Fc"][wm].max()), 1),
    "Fc_rows_above_100Lh_in_big_window": int((d["Fc"][big] > 100).sum()),
    "Fc_rows_total_in_big_window": int(big.sum()),
    "Fh_max_in_big_window": round(float(d["Fh"][big].max()), 1),
    "Q_mean": round(float(Q[wm].mean()), 1),
    "OUR_mean": round(float(OUR[wm].mean()), 3),
    "DO_mean": round(float(DO[wm].mean()), 2),
    "production_baseline_outside_window": {
        "T_mean": round(float(T[out_prod].mean()), 2),
        "Fc_mean": round(float(d["Fc"][out_prod].mean()), 1),
        "Q_mean": round(float(Q[out_prod].mean()), 1),
        "OUR_mean": round(float(OUR[out_prod].mean()), 3),
        "DO_mean": round(float(DO[out_prod].mean()), 2),
        "n": int(out_prod.sum()),
    },
    "dP_mean_in_big_window": round(float(np.nanmean(dP[big])), 4),
    "dP_mean_outside_prod": round(float(np.nanmean(dP[out_prod])), 4),
    "T_after_excursion_93_100h_mean": round(float(T[(t >= 93) & (t <= 100)].mean()), 2),
    "Fc_after_excursion_93_100h_mean": round(float(d["Fc"][(t >= 93) & (t <= 100)].mean()), 1),
}

# ---------- Q4b: RQ unit reconciliation ----------
rq_med = float(np.nanmedian(rq))
res["rq_unit_reconciliation"] = {
    "naive_rq_median": round(rq_med, 3),
    "note": "naive RQ uses column labels literally (OUR g/min, CER g/h); a single 60x unit reconciliation (either column) multiplies RQ by 60",
    "rq_if_unit_corrected_median": round(rq_med * 60.0, 3),
    "rq_if_unit_corrected_iqr": [round(float(np.nanpercentile(rq, 25)) * 60.0, 3), round(float(np.nanpercentile(rq, 75)) * 60.0, 3)],
    "rq_if_unit_corrected_range": [round(float(np.nanmin(rq)) * 60.0, 3), round(float(np.nanmax(rq)) * 60.0, 3)],
    "verdict": "UNIT_LABEL_MISMATCH_SUSPECTED — respiratory columns are internally consistent trends but absolute RQ is not trustworthy from labels",
}

# ---------- write outputs ----------
os.makedirs(OUT_DIR, exist_ok=True)
with open(os.path.join(OUT_DIR, "semantic_batch093_output.json"), "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=1)

# --- production_regime_filter.json (batch-phase regime filter; process_only view) ---
seg = lambda a, b: {"start_idx": int(a), "end_idx": int(b), "start_h": float(t[a]), "end_h": float(t[b])}
regime = {
    "applicable": True,
    "basis": "data-derived batch phases (production_regime_detector equivalent for a single-batch fermentation): residual sugar S threshold 0.05 g/L separates batch growth phase from fed-batch production phase; draw-off rows (Fremoved<0) flagged as events, not faults",
    "data_view_mode": "process_only",
    "regimes": [
        {"name": "batch_growth_phase", **seg(0, k0 - 1), "role": "legitimate operating regime (Monod growth), kept for phase-stratified stats"},
        {"name": "fedbatch_production_phase", **seg(k0, n - 1), "role": "legitimate operating regime (limited-sugar fed-batch), primary steady window for correlation analysis"},
    ],
    "exclude_regimes": [],
    "caution_regimes": [{"name": "draw_off_events", "rows": int(draw.sum()), "reason": "Fremoved<0 volume transients; excluded from volume-linked correlation pairs"}],
    "steady_row_indices_rule": "production_phase rows (idx >= %d) used as the steady window for cited pairs" % k0,
    "per_product_anomaly_analysis": {"applicable": False, "reason": "single batch, no product/lot grouping column (batch_integrity.json applicable=false)"},
}
with open(os.path.join(PROC, "production_regime_filter.json"), "w", encoding="utf-8") as f:
    json.dump(regime, f, ensure_ascii=False, indent=1)

# --- time_lag_analysis.json (process-pair CCF; process_only view) ---
sig = {k: v for k, v in ccf_res.items() if abs(v["best_lag_steps"]) > 0 and v["improvement_pct"] >= 10.0}
tla = {
    "applicable": True,
    "pairs_analyzed": len(ccf_res),
    "significant_lags_found": len(sig),
    "key_recommendations": [
        {
            "pair": k,
            "recommended_lag_steps": int(v["best_lag_steps"]),
            "recommended_lag_seconds": round(abs(v["best_lag_steps"]) * DT_H * 3600, 1),
            "action": f"align {v['leader']} as leading series when citing this pair; |r| improves {v['improvement_pct']}% vs lag-0 ({v['r_lag0']} -> {v['r_best']})",
        }
        for k, v in sig.items()
    ] or [{
        "pair": "all analyzed pairs",
        "recommended_lag_steps": 0,
        "recommended_lag_seconds": 0.0,
        "action": "no pair improved >=10% at a nonzero lag within +/-4 h; cite pairs as synchronous at 0.2 h sampling resolution",
    }],
    "status": "completed_process_pairs",
    "reason": "process_only data view (anomaly_report.dual_drive_analysis.data_view_mode): v6.4 process->inspection lag compensation is not applicable, so lag CCF was run on the cited process-process pairs for temporal-precedence verification (dt=0.2 h, max |lag| 20 steps = 4 h); results in 06_scripts/semantic_batch093_output.json lag_ccf",
    "sampling_interval_seconds": DT_H * 3600,
    "max_lag_searched": {"steps": 20, "seconds": 20 * DT_H * 3600},
    "detail_source": "06_scripts/semantic_batch093_output.json",
}
with open(os.path.join(PROC, "time_lag_analysis.json"), "w", encoding="utf-8") as f:
    json.dump(tla, f, ensure_ascii=False, indent=1)

# --- physics_check.json ---
rq = res["physics_checks"]["RQ"]
mh = res["physics_checks"]["metabolic_heat"]
rqc = res["rq_unit_reconciliation"]
pc = {
    "applicable": True,
    "tool": "06_scripts/semantic_batch093.py (targeted M7-style checks on ontology relationships; fermentation respiration/energy balance)",
    "checks": [
        {
            "name": "respiratory_quotient_aerobic_window",
            "expected": "RQ ~ 0.9-1.1 (ontology: OUR~CER correlative edge, fully aerobic carbon metabolism)",
            "observed": f"naive median {rq['median']} (column labels taken literally); single 60x unit reconciliation median {rqc['rq_if_unit_corrected_median']}, IQR {rqc['rq_if_unit_corrected_iqr']}, range {rqc['rq_if_unit_corrected_range']}, n={rq['n']}",
            "verdict": "CHECK",
            "interpretation": "naive RQ=0.011 is ~80x below the aerobic window -> at least one respiratory column carries a 60x unit-label mismatch; after one 60x reconciliation RQ~0.66 (IQR 0.60-0.84), still below 0.9-1.1 (oil co-metabolism and/or remaining unit ambiguity). Use respiratory columns as relative trends only, never as absolute RQ.",
        },
        {
            "name": "metabolic_heat_vs_OUR_scale_and_direction",
            "expected": "Generated heat Q ~ deltaH_O2*OUR (ontology causal edge OUR->Q, deltaH_O2 ~ 460 kJ/mol O2): Q should track OUR",
            "observed": f"r(Q,T)={mh['Q_T_r_full']} vs r(Q,OUR)={mh['Q_OUR_r_full']}; power ratio (Q/0.2h)/(862.5*OUR): median production {mh['ratio_median_production_phase']}, batch {mh['ratio_median_batch_phase']}",
            "verdict": "FAIL",
            "interpretation": "Q co-moves with Temperature (r=0.996, LOO-robust, synchronous at lag 0) instead of with OUR (r=0.177): the 'Generated heat' channel behaves as a T-coupled quantity, contradicting the ontology OUR->Q edge. Treat Q as a coincident thermal-load indicator, not a calibrated metabolic power meter.",
        },
        {
            "name": "cooling_actuator_response_during_sustained_excursion",
            "expected": "ontology control edge Temperature->Fc: T above 298.65 K band -> cooling water Fc opens; earlier similar-Q load transients (24-50 h) show Fc 200-700 L/h",
            "observed": f"sustained excursion 75.8-92.4 h (84 rows): T_max {res['temperature_control']['max_K']} K (at 89.6 h), Q_mean 1060.3 kJ inside excursion, Fc_mean 32.3 L/h inside (12/84 rows >100 L/h), Fh=0; co-metabolic shift: OUR 1.673 vs 1.305 g/min baseline (+28%), DO 15.2 vs 13.19 mg/L, dP/dt 0.2236 vs 0.1469 g/L/h (+52%)",
            "verdict": "FAIL",
            "interpretation": "a real metabolic upsurge occurred (OUR +28%, P accumulation rate +52%, DO margin wide) AND the temperature loop kept the cooling valve near-closed through 16.6 h of ~3.3 K over-temperature: control-side non-response is directly evidenced on top of a genuine load surge. Excursion self-resolved at 92.4 h (T back to 298.03 K by 93-100 h) as the surge passed.",
        },
        {
            "name": "DO_above_critical_for_penicillin_synthesis",
            "expected": "ontology: DO2 normal 6-16 mg/L; q_p oxygen Monod threshold — below critical DO product synthesis is oxygen-limited",
            "observed": f"DO min {res['dissolved_oxygen']['min_mgL']} mg/L at t={res['dissolved_oxygen']['min_at_h']} h; production-phase mean {res['dissolved_oxygen']['mean_production_phase']} mg/L",
            "verdict": "PASS",
            "interpretation": "DO never enters the ontology normal-range low bound; bulk-oxygen limitation is not supported as a primary driver",
        },
        {
            "name": "temperature_band_compliance",
            "expected": "298.15 +/- 0.5 K (ontology control variable, tolerance 0.5 K)",
            "observed": f"p95 {res['temperature_control']['p95_K']} K, max {res['temperature_control']['max_K']} K, {res['temperature_control']['n_above_band']} rows ({res['temperature_control']['pct_above_band']}%) above band, 0 rows below",
            "verdict": "FAIL",
            "interpretation": "temperature loop leaves its band for a non-trivial fraction of the batch — matches ontology discrepancy_signal (behavior_match CONTRADICTED)",
        },
    ],
}
with open(os.path.join(PROC, "physics_check.json"), "w", encoding="utf-8") as f:
    json.dump(pc, f, ensure_ascii=False, indent=1)

# --- targeted figure: T excursion windows with Q/Fh co-movement ---
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, ax1 = plt.subplots(figsize=(13, 6))
ax1.plot(t, T, color="tab:red", lw=1.2, label="Temperature (K)")
ax1.axhline(T_SET, color="gray", ls="--", lw=1, label="setpoint 298.15 K")
ax1.axhspan(T_SET - T_TOL, T_SET + T_TOL, color="gray", alpha=0.15, label="tolerance band +/-0.5 K")
for a, b in iv_hi:
    ax1.axvspan(t[a], t[b], color="red", alpha=0.18)
ax1.set_xlabel("Time (h)"); ax1.set_ylabel("Temperature (K)", color="tab:red")
ax1.tick_params(axis="y", labelcolor="tab:red")
qz = (Q - np.nanmean(Q)) / np.nanstd(Q)
ax2 = ax1.twinx()
ax2.plot(t, qz, color="tab:blue", lw=0.9, alpha=0.85, label="Generated heat Q (z-score)")
fcz = (d["Fc"] - np.nanmean(d["Fc"])) / np.nanstd(d["Fc"])
ax2.plot(t, fcz, color="tab:green", lw=0.8, alpha=0.7, label="Cooling water Fc (z-score)")
ax2.set_ylabel("z-score (Q, Fc)")
ax1.axvline(t[k0], color="black", ls=":", lw=1.2)
ax1.annotate("batch -> fed-batch (%.1f h)" % t[k0], xy=(t[k0], T.min()), fontsize=9,
             xytext=(t[k0] + 2, T.min() + 0.1))
lines = ax1.get_lines() + ax2.get_lines()
ax1.legend([l for l in lines], [l.get_label() for l in lines], fontsize=9, loc="upper left")
plt.title("batch_093: Temperature excursions vs Generated heat / cooling water (script-emitted, no VLM reading)")
plt.tight_layout()
fig.savefig(os.path.join(FIG, "fig_temp_excursion_window.png"), dpi=130)
plt.close(fig)

print("OK — outputs written:")
for p in ["06_scripts/semantic_batch093_output.json", "02_processed/production_regime_filter.json",
          "02_processed/time_lag_analysis.json", "02_processed/physics_check.json",
          "03_figures/fig_temp_excursion_window.png"]:
    print("  ", p)
