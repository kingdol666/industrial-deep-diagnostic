# -*- coding: utf-8 -*-
"""
finalize_semantic_artifacts.py — post-visual_analysis.py enrichment (non-VLM environment).
- Rewrites 03_figures/visual_analysis.json skeleton_pre_vlm -> metadata_backed_inference
  (author stays the script; NO PNG content is read or described — observations cite
  statistical/metadata artifacts only, per Data Truth Mandate rule 5).
- Updates 03_figures/plot_manifest.json with the figures added in this phase.
- Appends metadata-backed caption entries to 03_figures/image_captions.json.
- Phase 3.3: merges physical_checks + anomaly_onset_coincidence into 02_processed/anomaly_report.json
  (schema-open additions; dual_drive_analysis left untouched).
"""
import json, os

RUN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(RUN, "03_figures")
PROC = os.path.join(RUN, "02_processed")
SEM = "06_scripts/semantic_batch093_output.json"
sem = json.load(open(os.path.join(RUN, SEM), encoding="utf-8"))
NONVLM = "non-VLM environment (no vision model in this run): not image-read; documented from statistical metadata only"

# ---------------- visual_analysis.json ----------------
va_path = os.path.join(FIG, "visual_analysis.json")
va = json.load(open(va_path, encoding="utf-8"))

tw = sem["temperature_control"]
fw = sem["focus_window_70_100h"]

va["observation_mode"] = "metadata_backed_inference"
va["chart_design_purpose"] = ("Answer four diagnostic questions: (1) where and how the temperature loop leaves the "
                              "298.15+/-0.5 K band and whether cooling responds; (2) whether Generated heat co-moves "
                              "with Temperature or with OUR; (3) where the batch->fed-batch regime boundary lies so "
                              "correlations are regime-honest; (4) where DO2 sags relative to regime transients.")

prov = va["analysis_provenance"]
prov["stage"] = "metadata_backed_inference"
prov["skeleton_overwritten"] = True
prov["context_files_read"] = [
    "02_processed/cleaned_data.csv",
    "02_processed/feature_summary.json",
    "02_processed/validate_report.json",
    "01_ontology/ontology.json",
    "02_processed/anomaly_report.json",
    "02_processed/production_regime_filter.json",
    "02_processed/physics_check.json",
    SEM,
]
prov["grounding_summary"] = ("Non-VLM environment: no PNG was read by any vision model and no visual observation of "
                             "image content is claimed. All observations below are metadata-backed: they cite values "
                             "computed from 00_input/data.csv (recomputable via " + SEM + "), validate_report.json "
                             "anti-spurious sections, and physics_check.json. Per-data-truth rule 5, chart content "
                             "beyond this metadata documentation is NOT_APPLICABLE for VLM reading in this run.")
prov["grounding_sources"] = [
    "01_ontology/ontology.json",
    "02_processed/validate_report.json",
    "02_processed/anomaly_report.json",
    "02_processed/physics_check.json",
    SEM,
]

for item in va["chart_inventory"]:
    item["read_status"] = "READ_FAILED"
    item["read_failure_reason"] = NONVLM

va["chart_inventory"].extend([
    {
        "figure": "fig_temp_excursion_window.png",
        "read_status": "READ_FAILED",
        "read_failure_reason": NONVLM,
        "purpose": "Locate temperature-band excursions and test cooling-water response; T with 298.15+/-0.5 K band, excursion spans shaded, Q and Fc z-scores overlaid, batch->fed-batch line marked",
        "visual_questions": [
            "Which time windows exceed the tolerance band and how long do they last?",
            "Does Fc open when T is above band?",
            "Does Q co-move with T or with OUR?"
        ],
        "read_order": 5,
        "diagnostic_weight": "CRITICAL"
    },
    {
        "figure": "fig_temporal_overview.png",
        "read_status": "READ_FAILED",
        "read_failure_reason": NONVLM,
        "purpose": "Temporal overview grid of key process variables with +/-3 sigma thresholds (benchmark prepare stage)",
        "read_order": 6,
        "diagnostic_weight": "MODERATE"
    },
])

onto_ctx_T = {
    "parameter_physical_meanings": {
        "Temperature(T:K)": "受控变量测量值，设定 298.15 K +/-0.5 K（青霉素发酵最适温度），加热/冷却水回路 PID 执行",
        "Heating/cooling water flow rate(Fc:L/h)": "温度回路冷却执行量：T 越带上限时开大冷却水移热",
        "Generated heat(Q:kJ)": "本体登记为代谢生成热（OUR→Q，ΔH_O2≈460 kJ/mol O2）——本批数据中该边被证伪（Q 随 T 走，不随 OUR 走）"
    },
    "process_stage": "STG-1 补料产素相（fed-batch production phase）"
}
onto_ctx_phase = {
    "parameter_physical_meanings": {
        "Substrate concentration(S:g/L)": "限糖流加策略下的残糖；补料相被控制于近零（中位 0.00117 g/L）",
        "Penicillin concentration(P:g/L)": "目标产物（在线），补料相约线性累积至 30.82 g/L",
        "Oil flow(Foil:L/hr)": "植物油：独立混淆碳源+消泡剂，早期 35 后回落至 23 L/h"
    },
    "process_stage": "STG-0 批次生长相 -> STG-1 补料产素相 转换"
}

va["visual_observations"] = [
    {
        "figure": "fig_temp_excursion_window.png",
        "observations": [
            {
                "type": "anomaly_clustering",
                "description": ("Metadata-backed: T-band excursions (>298.65 K) cluster in two eras — (a) brief load "
                                "transients 15.2-49.6 h (2-5 samples each, T_max 300.10 K) during which cooling water "
                                "Fc responds with 200-700 L/h; and (b) ONE sustained excursion 75.8-92.4 h (84 samples, "
                                "16.6 h, T_max 301.44 K at 89.6 h) during which Fc stays near-closed (mean 32.3 L/h; "
                                "only 12/84 rows >100 L/h; Fh=0). Total 120/1050 rows (11.43%) above band, 0 below."),
                "parameters_involved": ["Temperature(T:K)", "Heating/cooling water flow rate(Fc:L/h)", "Heating water flow rate(Fh:L/h)"],
                "estimated_lag": "N/A — cross-sectional clustering in time windows",
                "confidence": "high",
                "diagnostic_implication": "The sustained excursion is a cooling-actuator non-response event, not a controller-tuning transient — directly citable against hypothesis 'cooling side failed'.",
                "statistical_cross_reference": {"source_file": SEM, "validation_note": "temperature_control + focus_window_70_100h blocks; LOO max_shift 0.0002 on r(T,Q)"},
                "ontology_context": onto_ctx_T,
            },
            {
                "type": "temporal_synchronization",
                "description": ("Metadata-backed: Generated heat Q is synchronous with Temperature at lag 0 "
                                "(r=0.9958, CCF best lag 0, phase-consistent: batch 0.9997 / production 0.9961) and "
                                "NOT with OUR (r=0.1767; CCF best -5 steps, +6.2% only). Inside the sustained "
                                "excursion Q_mean=1060.3 kJ vs 66.3 outside-band mean — Q switches on/off with the T excursion."),
                "parameters_involved": ["Generated heat(Q:kJ)", "Temperature(T:K)", "Oxygen Uptake Rate(OUR:(g min^{-1}))"],
                "estimated_lag": "0 (synchronous)",
                "confidence": "high",
                "diagnostic_implication": "Q must be treated as a coincident thermal-load indicator, not an OUR-proportional metabolic meter — the ontology OUR->Q edge is contradicted by data.",
                "statistical_cross_reference": {"correlation": 0.9958, "source_file": SEM, "validation_note": "phase_stratified_correlations T~Q + lag_ccf 'Q-> T' + leave_one_out_leverage T~Q"},
                "ontology_context": onto_ctx_T,
            },
            {
                "type": "event_response",
                "description": ("Metadata-backed: inside the sustained excursion the batch genuinely shifts metabolic "
                                "state — OUR 1.673 vs 1.305 g/min production baseline (+28%), DO2 rises to 15.2 vs "
                                "13.19 mg/L, P accumulation rate dP/dt 0.2236 vs 0.1469 g/L/h (+52%); after 92.4 h T "
                                "returns to 298.03 K (93-100 h) without Fc recovering (27.7 L/h)."),
                "parameters_involved": ["Oxygen Uptake Rate(OUR:(g min^{-1}))", "Dissolved oxygen concentration(DO2:mg/L)", "Penicillin concentration(P:g/L)", "Temperature(T:K)"],
                "estimated_lag": "coincident within 0.2 h sampling",
                "confidence": "medium",
                "diagnostic_implication": "The excursion window carries a real physiological upsurge, so 'sensor-only artifact' is a weak candidate; the loop's failure to cool during a genuine load surge is the actionable fault signature.",
                "statistical_cross_reference": {"source_file": SEM, "validation_note": "focus_window_70_100h block"},
                "ontology_context": onto_ctx_T,
            },
        ]
    },
    {
        "figure": "fig_vlm_temporal_overlay.png",
        "observations": [
            {
                "type": "trend_morphology",
                "description": ("Metadata-backed: the batch->fed-batch boundary is data-located at t=14.6 h (first "
                                "index from which residual sugar S stays <0.05 g/L; S batch-phase mean 2.03 g/L, "
                                "production median 0.00117 g/L) — earlier than the ontology's ~45 h stage-0 estimate. "
                                "P accumulates near-linearly 0.001->30.82 g/L thereafter; level-level P~T in the "
                                "production phase is negative (rho=-0.57) purely because T drifts down across the "
                                "phase (T~t rho=-0.57) while P rises — the rate view (dP/dt vs T r=+0.25, n=978) shows "
                                "no production-rate penalty at excursion temperatures."),
                "parameters_involved": ["Substrate concentration(S:g/L)", "Penicillin concentration(P:g/L)", "Temperature(T:K)"],
                "estimated_lag": "unclear",
                "confidence": "high",
                "diagnostic_implication": "Regime stratification at t=14.6 h is mandatory before citing any full-batch correlation — phase-mixed statistics flip signs (e.g. P~V: -0.92 batch vs +0.77 production).",
                "statistical_cross_reference": {"correlation": -0.2891, "source_file": SEM, "validation_note": "batch_phase + phase_stratified_correlations + p_rate_vs_T_production_phase; P change point idx 120 in validate_report anti_spurious.change_point_detection"},
                "ontology_context": onto_ctx_phase,
            },
        ]
    },
    {
        "figure": "fig_vlm_synchronization.png",
        "observations": [
            {
                "type": "clustering",
                "description": ("Metadata-backed correlation clusters: P moves with CER/Fg/Vessel Volume (production-phase "
                                "r: CER 0.775, Fg 0.817, V 0.774) and against Oil flow (-0.869); all are LOO-robust "
                                "(max shift <=0.0012) but are co-trends of the fed-batch schedule, not pairwise-causal "
                                "proofs. Agitator RPM (constant 100, std=0) and Ammonia shots (constant 0) carry zero "
                                "information."),
                "parameters_involved": ["Penicillin concentration(P:g/L)", "Carbon evolution rate(CER:g/h)", "Aeration rate(Fg:L/h)", "Vessel Volume(V:L)", "Oil flow(Foil:L/hr)"],
                "estimated_lag": "0 (synchronous) at 0.2 h resolution",
                "confidence": "medium",
                "diagnostic_implication": "Co-trend structure defines the confounder set (schedule-driven Fg/Foil/V) that the diagnostician must partial out before claiming any single-driver cause.",
                "statistical_cross_reference": {"source_file": SEM, "validation_note": "phase_stratified_correlations pairs + leave_one_out_leverage"},
                "ontology_context": onto_ctx_phase,
            },
        ]
    },
    {
        "figure": "fig_vlm_temporal_overlay_single_product_g1.png",
        "observations": [
            {
                "type": "profile_shape",
                "description": ("Metadata-backed: DO2 shows exactly two sag windows — t=20.0-24.0 h (21 samples, min "
                                "10.40 mg/L at 24.0 h, straddling the early fed-batch handoff) and t=150.4-160.0 h "
                                "(49 samples, min 11.51 mg/L, during the draw-off era; 5 draw-off events 100.2-192.0 h "
                                "remove 40000 L total). DO2 never approaches the ontology normal-range low bound (6 mg/L)."),
                "parameters_involved": ["Dissolved oxygen concentration(DO2:mg/L)", "Dumped broth flow(Fremoved:L/h)", "Substrate concentration(S:g/L)"],
                "estimated_lag": "N/A — window inventory",
                "confidence": "high",
                "diagnostic_implication": "Both DO2 sags align with legitimate regime transients (phase handoff, draw-off operations), not with the temperature excursion window — oxygen limitation stays a background hypothesis only.",
                "statistical_cross_reference": {"source_file": SEM, "validation_note": "dissolved_oxygen + draw_off_events blocks"},
                "ontology_context": onto_ctx_phase,
            },
        ]
    },
]

cta = va["cross_parameter_temporal_alignment"]
cta["summary"] = ("Metadata-backed alignment picture (0.2 h grid): the P/CER/Fg/V cluster rises together through the "
                  "fed-batch phase while Oil flow steps down (mirror image); Generated heat is synchronous with "
                  "Temperature (lag 0, r=0.996) and decoupled from OUR; control pairs react at +1 sample (T->Fc r "
                  "0.069->0.124; T->Fh 0.043->-0.146, i.e. heating correctly cuts as T rises). The only regime-mixing "
                  "hazard is the t=14.6 h batch->fed-batch boundary — full-batch statistics across it flip signs "
                  "relative to within-phase strata.")
cta["precedence_signals"] = [
    {"earlier": "Temperature(T:K)", "later": "Heating/cooling water flow rate(Fc:L/h)",
     "description": "CCF best lag +1 step (0.2 h): cooling reacts one sample after T (r 0.069 at lag 0 -> 0.124 at +1) — correct controller direction, weak gain",
     "visual_confidence": "MEDIUM",
     "diagnostic_implication": "The loop is alive but under-gained; during the sustained excursion it fails to drive Fc at all (actuator-level suspect)."},
    {"earlier": "Temperature(T:K)", "later": "Heating water flow rate(Fh:L/h)",
     "description": "CCF best lag +1 step with NEGATIVE sign (0.043 -> -0.146): heating correctly backs off as T rises",
     "visual_confidence": "MEDIUM",
     "diagnostic_implication": "Fh=0 inside the excursion is correct control logic; the missing action is on the cooling side, not a stuck-heating conflict."},
    {"earlier": "Generated heat(Q:kJ)", "later": "Temperature(T:K)",
     "description": "CCF best lag 0 (r=0.996): synchronous — Q carries no lead over T, so it cannot serve as an earlier warning indicator",
     "visual_confidence": "HIGH",
     "diagnostic_implication": "No sub-0.2 h precedence exists between Q and T; treat them as one coincident thermal channel."},
]

va["synthesis"] = ("Metadata-backed story of this batch: after an early batch phase ending at t=14.6 h, the run behaves "
                   "as a disciplined limited-sugar fed-batch (S~0.001 g/L, P ->30.82 g/L). Temperature control holds "
                   "except for brief load transients (15.2-49.6 h, cooling responds normally) and one sustained "
                   "16.6 h excursion (75.8-92.4 h, up to 301.44 K) in which the metabolic state genuinely surges "
                   "(OUR +28%, dP/dt +52%, DO wide open at 15.2 mg/L) while the cooling valve stays near-closed "
                   "(32.3 L/h) — a cooling-side non-response riding on a real load surge. Generated heat co-moves "
                   "with Temperature (r=0.996, synchronous), not with OUR, so the ontology OUR->Q edge is contradicted "
                   "and Q is only a coincident thermal indicator. No PNG-content observations are claimed: this is a "
                   "non-VLM environment and every statement cites recomputable statistics.")

va["reading_guide"] = [
    {"for_agent": "diagnostician",
     "primary_sections_to_read": ["visual_observations", "cross_parameter_temporal_alignment", "analysis_provenance"],
     "key_insights": [
         "observation_mode is metadata_backed_inference — no VLM read any PNG in this run; all numbers are recomputable from 06_scripts/semantic_batch093_output.json.",
         "Sustained T excursion 75.8-92.4 h with Fc non-response is the primary fault signature.",
         "Stratify by the t=14.6 h regime boundary before citing any correlation.",
     ]},
    {"for_agent": "judge",
     "primary_sections_to_read": ["analysis_provenance", "chart_inventory"],
     "key_insights": ["All chart_inventory entries are READ_FAILED by design (non-VLM environment); diagnostic_weight still ranks each figure's intended role."]},
    {"for_agent": "reporter",
     "primary_sections_to_read": ["synthesis", "visual_observations"],
     "key_insights": ["Quote observations as metadata-backed statistics, not as image reading."]},
]

json.dump(va, open(va_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---------------- plot_manifest.json ----------------
pm_path = os.path.join(FIG, "plot_manifest.json")
pm = json.load(open(pm_path, encoding="utf-8"))
pm["plots"].extend([
    {"file": "03_figures/fig_temp_excursion_window.png", "filename": "fig_temp_excursion_window.png",
     "figure_type": "temporal_overlay", "priority": "MANDATORY",
     "title": "Temperature excursions vs Generated heat / cooling water",
     "description": "T 序列 + 298.15±0.5K 容差带 + 越带区间红色阴影；Q 与 Fc z-score 叠加；黑点线为 t=14.6h 批次相->补料相边界（数据推导）",
     "status": "rendered", "tool": "matplotlib (06_scripts/semantic_batch093.py)"},
    {"file": "03_figures/fig_vlm_temporal_overlay.png", "filename": "fig_vlm_temporal_overlay.png",
     "figure_type": "vlm_temporal_overlay", "priority": "MANDATORY",
     "title": "VLM temporal overlay (z-normalized, shared Time (h) axis)",
     "description": "全部过程参数 z-normalized 时间对齐叠加图（visual_analysis.py Phase 2）", "status": "rendered", "tool": "visual_analysis.py"},
    {"file": "03_figures/fig_vlm_temporal_overlay_single_product_g1.png", "filename": "fig_vlm_temporal_overlay_single_product_g1.png",
     "figure_type": "per_product_overlay", "priority": "MANDATORY",
     "title": "Per-group temporal overlay g1", "description": "单批次分组叠加图 g1（visual_analysis.py Phase 1）", "status": "rendered", "tool": "visual_analysis.py"},
    {"file": "03_figures/fig_vlm_temporal_overlay_single_product_g2.png", "filename": "fig_vlm_temporal_overlay_single_product_g2.png",
     "figure_type": "per_product_overlay", "priority": "MANDATORY",
     "title": "Per-group temporal overlay g2", "description": "单批次分组叠加图 g2（visual_analysis.py Phase 1）", "status": "rendered", "tool": "visual_analysis.py"},
    {"file": "03_figures/fig_vlm_synchronization.png", "filename": "fig_vlm_synchronization.png",
     "figure_type": "synchronization_heatmap", "priority": "SUPPLEMENTARY",
     "title": "Rolling synchronization heatmap", "description": "参数与质量目标同步性热图（visual_analysis.py Phase 5）", "status": "rendered", "tool": "visual_analysis.py"},
])
pm["rendering_available"] = True
json.dump(pm, open(pm_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---------------- image_captions.json (flat format) ----------------
ic_path = os.path.join(FIG, "image_captions.json")
ic = json.load(open(ic_path, encoding="utf-8"))
ic["fig_temp_excursion_window.png"] = {
    "description": "温度越带区间定位图：T+容差带+越带阴影，Q/Fc z-score 叠加（metadata-backed，未做 VLM 读图）",
    "key_observations": [
        "越带样本 120/1050（11.43%），全部为越上限；p95=300.81 K，max=301.44 K（89.6 h）",
        "持续越带窗口 75.8-92.4 h（84 样本），期间 Fc 均值 32.3 L/h（84 行中仅 12 行 >100 L/h），Fh=0",
        "早期负荷瞬态（15.2-49.6 h）Fc 响应正常（200-700 L/h）且 T 快速回带",
        "Q 与 T 同步（lag-0 r=0.996）；越带窗口内 Q_mean=1060.3 kJ vs 带外 66.3",
        "批次相->补料相边界 t=14.6 h（S<0.05 g/L 规则）",
    ],
    "diagnostic_implication": "持续越带 + 冷却阀近闭 = 冷却侧执行非响应的直接证据，是根因诊断的首要候选签名。",
}
ic["fig_vlm_temporal_overlay.png"] = {
    "description": "全参数 z-normalized 时间对齐叠加图（visual_analysis.py 生成；non-VLM 环境仅作 metadata 文档化）",
    "key_observations": [
        "补料相约线性积累：P 0.001->30.82 g/L；S 中位 0.00117 g/L（限糖平台）",
        "OUR/CER/CO2outgas 先升后平台（三段均值 0.90/1.75/1.21 g/min 等）",
        "Oil flow 与 P 镜像（生产相 r=-0.869）；Fg/V/Wt 与 P 同向爬升",
        "T~Q 同步起伏；T 在生产相内缓降（T~t rho=-0.57）",
    ],
    "diagnostic_implication": "共趋势簇定义了调度驱动的混淆集（Fg/Foil/V），诊断师引用任何单驱动结论前须先剔除。",
}
ic["fig_vlm_temporal_overlay_single_product_g1.png"] = {
    "description": "分组叠加图 g1（visual_analysis.py；metadata 文档化）",
    "key_observations": [
        "DO2 两个低谷窗：20.0-24.0 h（min 10.40 mg/L @24.0 h）与 150.4-160.0 h（min 11.51）",
        "DO2 全程未低于本体正常带下限 6 mg/L（min 10.40）",
        "两低谷分别对齐批次相交接与排料期（5 次排料共 40000 L，100.2-192.0 h）",
    ],
    "diagnostic_implication": "DO2 低谷对齐合法工况过渡而非温度越带窗口——氧限制仅能作为背景假设。",
}
ic["fig_vlm_temporal_overlay_single_product_g2.png"] = {
    "description": "分组叠加图 g2（visual_analysis.py；metadata 文档化）",
    "key_observations": [
        "离线化验列仅 19 点（~12 h 间隔），亚小时动态不可分辨",
        "末 6 个化验点 X 与粘度同步回落（X~t r=-0.992；粘度 77.5->70.4 cP，-9.2%）",
        "粘度与 X 全程 r=0.805（n=19），与时间 r=0.914",
    ],
    "diagnostic_implication": "本体『末段 X 平台而粘度升 54%』的失配信号在点级数据下部分解除：末 6 点两者同落，末段粘度- X 脱钩不成立。",
}
ic["fig_vlm_synchronization.png"] = {
    "description": "滚动同步性热图（visual_analysis.py；metadata 文档化）",
    "key_observations": [
        "P-CER-Fg-V 同步簇（生产相 r 0.774-0.817）",
        "Oil flow 与 P 反向（-0.869）；Fa/Fh 与 P 弱相关（|r|<0.2）",
        "Agitator RPM（std=0）与 Ammonia shots（恒 0）零信息",
    ],
    "diagnostic_implication": "零方差列与共趋势簇界定了可辨识变量集，防止诊断师对不可辨识边过度归因。",
}
json.dump(ic, open(ic_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---------------- anomaly_report.json Phase 3.3 merge ----------------
ar_path = os.path.join(PROC, "anomaly_report.json")
ar = json.load(open(ar_path, encoding="utf-8"))
pc = json.load(open(os.path.join(PROC, "physics_check.json"), encoding="utf-8"))
ar["physical_checks"] = {
    "summary": "5 targeted physics checks: temperature_band_compliance FAIL, cooling_actuator_response FAIL, metabolic_heat_vs_OUR FAIL (Q tracks T not OUR), respiratory_quotient CHECK (unit-label mismatch), DO_above_critical PASS",
    "verdicts": [{k: c[k] for k in ("name", "verdict")} for c in pc["checks"]],
    "detail_file": "02_processed/physics_check.json",
    "tool": pc["tool"],
}
ar["anomaly_onset_coincidence"] = {
    "threshold_target_anomalies": "none — P 与 DO2 阈值异常区间均为空（anomaly_intervals=[]），质量目标无越限",
    "process_anomaly_coincidence": ("持续 T 越带 75.8-92.4 h 与以下事件同步（0.2 h 分辨率）：Q 批次峰值（窗口内均值 1060.3 kJ vs 带外 66.3）、"
                                    "Fc 非响应（32.3 L/h，12/84 行 >100）、OUR +28%（1.673 vs 1.305 g/min）、dP/dt +52%（0.2236 vs 0.1469 g/L/h）、"
                                    "DO2 走高（15.2 vs 13.19 mg/L）；早期瞬态越带（15.2-49.6 h）则 Fc 正常响应（200-700 L/h）——"
                                    "两类越带的执行器行为差异是关键判别特征"),
    "detail_file": SEM,
}
json.dump(ar, open(ar_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

print("OK: visual_analysis.json -> metadata_backed_inference; plot_manifest %d plots; captions %d entries; anomaly_report merged" %
      (len(pm["plots"]), len(ic)))
