# -*- coding: utf-8 -*-
"""Backfill visual_analysis.json from skeleton_pre_vlm to metadata_backed_inference.

Non-VLM environment: no PNG pixel is read. All observations are metadata-backed,
derived exclusively from 02_processed statistics + ontology. The script
visual_analysis.py remains the author of record (source_agent unchanged).
"""
import json
import sys

RUN = sys.argv[1] if len(sys.argv) > 1 else "."
p = RUN + "/03_figures/visual_analysis.json"
v = json.load(open(p, encoding="utf-8"))

v["observation_mode"] = "metadata_backed_inference"
v["vlm_chart_count"] = 0
v["chart_design_purpose"] = ("Answer: which actuation channel fights a post-onset disturbance, in which direction, with what lead/lag — "
                             "reactor cooling loop (XMV_10/XMEAS_9) vs stripper steam loop (XMV_9/XMEAS_19/XMEAS_18), feed block and condenser block as controls.")
prov = v["analysis_provenance"]
prov["stage"] = "metadata_backed_inference"
prov["skeleton_overwritten"] = True
prov["grounding_summary"] = ("Non-VLM environment: no PNG was read as an image. All observations are metadata-backed, derived exclusively from "
                             "02_processed/validate_report.json, 02_processed/cooling_loop_semantic_analysis.json, 02_processed/anomaly_report.json, "
                             "02_processed/physics_check.json and 01_ontology/ontology.json; figures were rendered from those same statistics by scripts "
                             "(visual_analysis.py, 06_scripts/cooling_loop_semantic_analysis.py). No pixel-level claim is made.")
prov["grounding_sources"] = ["01_ontology/ontology.json", "02_processed/validate_report.json",
                             "02_processed/cooling_loop_semantic_analysis.json", "02_processed/anomaly_report.json",
                             "02_processed/physics_check.json"]
prov["note_non_vlm"] = ("vlm-visual-analyzer not available in this run; data-processor backfilled metadata-backed observations. "
                        "source_agent remains visual_analysis.py (script as author).")

for c in v["chart_inventory"]:
    c["read_status"] = "READ_FAILED"
    c["read_failure_reason"] = "non-VLM environment: image not read; metadata-only observation mode"
v["chart_inventory"].append({
    "figure": "fig_cooling_loop_variance.png", "read_status": "READ_FAILED",
    "read_failure_reason": "non-VLM environment: image not read; metadata-only observation mode",
    "purpose": ("Baseline-referenced z-overlay of XMEAS_9 and XMV_10 plus rolling std: does XMV_10 actuation variance inflate together with "
                "reactor temperature variance after onset index 160?"),
    "visual_questions": ["Do XMV_10 and XMEAS_9 variance bursts start together?",
                         "Is the post-onset fluctuation sustained broadband noise or a single-frequency limit cycle?"],
    "read_order": 7, "diagnostic_weight": "CRITICAL"})

v["cross_parameter_temporal_alignment"]["summary"] = ("Metadata-backed alignment picture: the reactor TC loop (XMV_10 <-> XMEAS_9) is the only channel whose coupling "
                                                      "structure changes after onset (lag-0 r=+0.50 with XMV_10 leading XMEAS_9 by ~5 samples at r=-0.64); the stripper steam loop "
                                                      "(XMV_9/XMEAS_19/XMEAS_18) is internally near-static (|r|>0.95, lag 1-2) with inflated actuation variance; feed and condenser "
                                                      "blocks stay statistically flat (variance ratio 0.79-1.38).")
v["cross_parameter_temporal_alignment"]["synchronous_groups"] = [
    {"group_id": "reactor_cooling_tc_loop", "parameters": ["XMV_10", "XMEAS_9"],
     "description": "Closed-loop pair: lag-0 r=+0.5007 (n=960), lag-compensated r=-0.6356 at XMV_10 leading by 5 samples (p=3.4e-109); lag window -8..-2 consistently |r|>0.39 (validate_report lag_window_consistency: consistent=true)",
     "estimated_group_lag": "5 samples (~15 min, XMV_10 leads XMEAS_9 in feedback sense)", "synchronous_with_quality": True,
     "group_diagnostic_implication": "TC controller actuation dominates reactor temperature fluctuation post-onset — the disturbance is seen and fought inside the reactor cooling loop."},
    {"group_id": "stripper_steam_loop", "parameters": ["XMV_9", "XMEAS_19", "XMEAS_18"],
     "description": "Controller-action triple: XMV_9->XMEAS_19 r=+0.9913 (lag 1), XMEAS_19->XMEAS_18 r=+0.9539 (lag 2), XMV_9->XMEAS_18 r=+0.9750 (lag 1); loop variance ratios x2.44-2.51 post-onset",
     "estimated_group_lag": "1-2 samples", "synchronous_with_quality": False,
     "group_diagnostic_implication": "Stripper steam loop acts coherently but with inflated variance — a secondary signature; cross-loop coupling to XMV_10 is weak (best |r|=0.13), so propagation vs independent stripper disturbance is not established."},
    {"group_id": "condenser_separator_train", "parameters": ["XMEAS_22", "XMEAS_11"],
     "description": "XMEAS_22->XMEAS_11 lag-compensated r=+0.6630 (lag 1); XMEAS_9->XMEAS_11 r=+0.4539 (lag 2); loop actuation variances stay near baseline (XMV_11 x0.89, XMEAS_22 x1.18)",
     "estimated_group_lag": "1-2 samples", "synchronous_with_quality": False,
     "group_diagnostic_implication": "Downstream thermal train tracks reactor temperature mildly while its own actuation stays quiet — passive propagation, not an independent driver."}]
v["cross_parameter_temporal_alignment"]["precedence_signals"] = [
    {"earlier": "XMV_10 (reactor cooling water valve)", "later": "XMEAS_9 (reactor temperature)",
     "description": "Statistical (lag-compensated CCF, not pixel reading): best |r| at XMV_10 leading 5 samples; post-onset stratum r=-0.6416 vs baseline stratum r=-0.2051 at the same lag — the lead-lag structure activates with the disturbance",
     "visual_confidence": "LOW",
     "diagnostic_implication": "Controller response precedes temperature correction by ~15 min — consistent with feedback fighting a persistent cooling-side disturbance."}]

onto_means = {"XMV_10": "反应器冷却水阀 — TC回路操纵量, 开度↑→冷却水流量↑→移热↑→T9↓",
              "XMEAS_9": "反应器温度 — 质量目标, TC控制, 基线σ≈0.021°C",
              "XMEAS_21": "反应器冷却水出口温度 — 移热能力直接观测量",
              "XMV_9": "汽提塔蒸汽阀 — 塔温操纵量",
              "XMEAS_19": "汽提塔蒸汽流量 — 热输入Q=m_s·λ",
              "XMEAS_18": "汽提塔温度 — 塔能量平衡被控量",
              "XMV_11": "冷凝器冷却水阀 — 冷凝能力操纵量",
              "XMEAS_22": "分离器(冷凝器)冷却水出口温度"}

v["visual_observations"] = [
    {"figure": "fig_cooling_loop_variance.png", "observations": [
        {"type": "anomaly_clustering",
         "description": ("Metadata-backed (no PNG reading): after the declared onset (sample 161, idx 160) the fluctuation amplitude of the reactor cooling loop jumps — "
                         "XMV_10 sd 0.573->3.631 (x6.33, F-test p=1.5e-92, Levene p=8.0e-50, mean shift only +1.22 baseline-sigma) and XMEAS_9 sd 0.021->0.085 "
                         "(x4.04, F-test p=5.0e-63, mean shift +0.01 sigma). Rolling 20-sample std of XMV_10 first exceeds 2x baseline at idx 166, agreeing with the declared onset within the window."),
         "parameters_involved": ["XMV_10", "XMEAS_9"], "estimated_lag": "N/A — variance comparison",
         "confidence": "high",
         "diagnostic_implication": "The disturbance signature is a VARIANCE burst without mean shift concentrated on the reactor cooling actuation channel — a control fight, not a setpoint or load change.",
         "statistical_cross_reference": {"source_file": "02_processed/cooling_loop_semantic_analysis.json",
                                         "validation_note": "per_column_baseline_vs_post + onset_cross_check; baseline rows 0-159, post-onset rows 160-959 (n=160/800)"},
         "ontology_context": {"parameter_physical_meanings": {k: onto_means[k] for k in ["XMV_10", "XMEAS_9", "XMEAS_21"]},
                              "process_stage": "STG1 反应 (反应器冷却水系统 EQ_CW_REACTOR)"}},
        {"type": "direction_consistency",
         "description": ("Metadata-backed (no PNG reading): post-onset fluctuation is broadband — post-onset XMV_10 spectrum has flatness 0.068 with the largest single-bin power only 4.8% "
                         "(no limit-cycle peak); baseline spectrum is near-white (flatness 0.580). Feed block variance ratios 0.79-1.26 and condenser loop 0.89-1.38 stay flat across onset."),
         "parameters_involved": ["XMV_10", "XMEAS_9", "XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4", "XMV_11", "XMEAS_22"],
         "estimated_lag": "N/A",
         "confidence": "medium",
         "diagnostic_implication": "Broadband sustained actuation is the fingerprint of a persistent random disturbance entering the cooling side — not valve stiction (single-frequency limit cycle) and not a feed/condenser cause.",
         "statistical_cross_reference": {"source_file": "02_processed/cooling_loop_semantic_analysis.json",
                                         "validation_note": "spectral_signature + physics_discriminators.feed_flow_vr/condenser_loop_vr"},
         "ontology_context": {"parameter_physical_meanings": {k: onto_means[k] for k in ["XMV_10", "XMV_11", "XMEAS_22"]},
                              "process_stage": "STG1/STG2/STG0"}}]},
    {"figure": "fig_vlm_temporal_overlay.png", "observations": [
        {"type": "temporal_synchronization",
         "description": ("Metadata-backed (no PNG reading): within the post-onset stratum XMV_10 leads XMEAS_9 by 5 samples with r=-0.6416 (n=795) while the same lag in the baseline stratum "
                         "is only r=-0.2051 (n=155); lag-0 correlation stays positive in both strata (+0.6919 / +0.5011, no Simpson sign flip)."),
         "parameters_involved": ["XMV_10", "XMEAS_9"], "estimated_lag": "5 samples (~15 min)",
         "confidence": "high",
         "diagnostic_implication": "The lead-lag structure is disturbance-activated: the TC valve moves first and temperature responds inversely — closed-loop compensation of an active cooling-side disturbance.",
         "statistical_cross_reference": {"source_file": "02_processed/cooling_loop_semantic_analysis.json",
                                         "validation_note": "stratified_correlation_XMV_10_XMEAS_9; consistent with validate_report.json target_analysis XMEAS_9.best_lags XMV_10 lag=-5 r=-0.6356"},
         "ontology_context": {"parameter_physical_meanings": {k: onto_means[k] for k in ["XMV_10", "XMEAS_9"]},
                              "process_stage": "STG1 反应"}},
        {"type": "clustering",
         "description": ("Metadata-backed (no PNG reading): the stripper steam loop acts as one coherent cluster (XMV_9~XMEAS_19 r=+0.9882 lag-0, best lag -1 r=+0.9913; "
                         "XMEAS_19~XMEAS_18 r=+0.9528 lag-0) while cross-loop coupling to the reactor cooling valve is weak (XMV_10~XMV_9 best |r|=0.1241 at lag 12; XMEAS_9~XMEAS_19 r=+0.0135 lag-0)."),
         "parameters_involved": ["XMV_9", "XMEAS_19", "XMEAS_18", "XMV_10"],
         "estimated_lag": "1-2 samples within loop; cross-loop unclear",
         "confidence": "medium",
         "diagnostic_implication": "Stripper variance inflation (x2.4-2.5) is a real secondary signature, but its causal link to the reactor cooling disturbance is NOT established by these data — both readings stay open for the diagnostician.",
         "statistical_cross_reference": {"source_file": "02_processed/cooling_loop_semantic_analysis.json",
                                         "validation_note": "lag_compensated_ccf XMV_9~XMEAS_19 / XMEAS_19~XMEAS_18 / XMV_10~XMV_9 / XMEAS_9~XMEAS_19"},
         "ontology_context": {"parameter_physical_meanings": {k: onto_means[k] for k in ["XMV_9", "XMEAS_19", "XMEAS_18"]},
                              "process_stage": "STG4 汽提与产品"}}]}]

v["pipeline_warnings"] = [
    {"warning": ("Non-VLM environment: vlm-visual-analyzer unavailable; visual_analysis.json kept in metadata_backed_inference mode authored by visual_analysis.py + "
                 "data-processor metadata backfill (06_scripts/backfill_visual_analysis_metadata.py). No PNG pixel content was read or described."), "severity": "WARNING"},
    {"warning": "quality targets XMEAS_9/XMEAS_21 are process measurements (process_only data view): no independent inspection-side quality signal exists; process-to-quality linkage is an evidence gap.", "severity": "INFO"}]

v["synthesis"] = ("Metadata-backed story (no image reading): a persistent, broadband disturbance on the reactor cooling-water side switches on at sample 161 and the TC controller answers through XMV_10 — "
                  "valve actuation variance x6.33 with reactor temperature variance x4.04 while both means stay in-band, and XMV_10 leads XMEAS_9 by ~5 samples at r=-0.64 post-onset. "
                  "The measured cooling-water outlet temperature XMEAS_21 stays at baseline spread (x1.03), arguing the loop absorbs the disturbance rather than a large real coolant-flow swing. "
                  "Feed and condenser blocks stay statistically flat (variance ratios 0.79-1.38), excluding those drivers. "
                  "The stripper steam loop (XMV_9/XMEAS_19/XMEAS_18, variance x2.4-2.5) is a coherent secondary signature whose coupling to the reactor side is weak in these data (best |r|~0.13) — propagation vs independent stripper disturbance remains open.")
v["reading_guide"] = [
    {"for_agent": "diagnostician", "primary_sections_to_read": ["visual_observations", "cross_parameter_temporal_alignment", "pipeline_warnings"],
     "key_insights": ["All observations are metadata-backed from 02_processed statistics — cite them as statistical evidence (L3), not as visual (L4) evidence.",
                      "Variance-change detection: signature set {XMV_10, XMEAS_9, XMV_9, XMEAS_18, XMEAS_19} with F-test p<1e-30 and mean shifts <=1.22 sigma.",
                      "XMV_10 leads XMEAS_9 by 5 samples post-onset (r=-0.64); physics_check.py classifies XMV_10 as PRECURSOR/POTENTIAL_CAUSE for the first XMEAS_9 anomaly interval."]}]

json.dump(v, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("visual_analysis.json transformed: mode=%s | observations=%d | charts=%d"
      % (v["observation_mode"], len(v["visual_observations"]), len(v["chart_inventory"])))
