# -*- coding: utf-8 -*-
"""Cooling-loop semantic analysis (data-processor custom script, Phase 1.2/2.7/3.x).

Hypotheses under test (from analysis_method_plan.json):
  H1 reactor cooling-side disturbance (cooling water inlet temperature / heat-transfer)
  H2 feed-side disturbance
  H3 condenser / recycle-side disturbance
  H4 XMV_10 valve fault (stiction / deadband)

Computes ONLY from 00_input/data.csv (960 rows x 52 signal cols, 3-min sampling):
  A. baseline (idx 0-159) vs post-onset (idx 160-959) mean/std per column,
     variance ratio + two-sided F-test + Levene (center=median) + Welch t (baseline-sigma units)
  B. variance-inflation signature set (vr >= 2.0)
  C. production regime / steady-state check (level & flow stability, no ramp steps)
  D. lag-compensated CCF for cited pairs (lag -20..20, convention r(X[t+lag], Y[t]))
  E. stratified correlation (baseline stratum vs post-onset stratum) + post-onset-only r
  F. leave-one-out leverage for XMV_10 ~ XMEAS_9
  G. spectral signature of post-onset XMV_10 / XMEAS_9 (broadband vs narrowband limit cycle)
  H. physics discriminators: T21 stability vs T9, XMV_10 -> T21 inverse sign, feed composition vr

Outputs:
  02_processed/cooling_loop_semantic_analysis.json
  02_processed/production_regime_filter.json
  03_figures/fig_cooling_loop_variance.png (+ manifest entry in the JSON output)
"""
import json
import sys
import numpy as np
import pandas as pd
from scipy import stats

RUN_DIR = sys.argv[1] if len(sys.argv) > 1 else "."
DATA = RUN_DIR + "/00_input/data.csv"
ONSET = 160            # 0-based index of first post-onset sample (sample 161, 1-based)
BASE_N = ONSET         # baseline = idx 0..159
MAX_LAG = 20

df = pd.read_csv(DATA)
ts = pd.to_datetime(df["timestamp"])
cols = [c for c in df.columns if c != "timestamp"]
X = df[cols].astype(float)
n_rows = len(df)
dt_sec = float((ts.iloc[1] - ts.iloc[0]).total_seconds())

pre = X.iloc[:ONSET]
post = X.iloc[ONSET:]

# ---------- A. baseline vs post-onset per-column ----------
per_col = {}
for c in cols:
    a = pre[c].to_numpy(float)
    b = post[c].to_numpy(float)
    ma, mb = float(a.mean()), float(b.mean())
    sa, sb = float(a.std(ddof=1)), float(b.std(ddof=1))
    vr = sb / sa
    F = sb**2 / sa**2
    p_f = float(2 * min(stats.f.sf(F, len(b) - 1, len(a) - 1),
                        stats.f.cdf(F, len(b) - 1, len(a) - 1)))
    p_lev = float(stats.levene(a, b, center="median").pvalue)
    t_res = stats.ttest_ind(a, b, equal_var=False)
    per_col[c] = {
        "baseline_mean": round(ma, 6), "baseline_std": round(sa, 6),
        "post_mean": round(mb, 6), "post_std": round(sb, 6),
        "variance_ratio_sd": round(vr, 4),
        "f_test_F": round(F, 4), "f_test_p_two_sided": p_f,
        "levene_p": p_lev,
        "mean_shift_baseline_sigma": round((mb - ma) / sa, 3),
        "welch_t": round(float(t_res.statistic), 4),
        "welch_p": float(t_res.pvalue),
    }

# ---------- B. variance-inflation signature ----------
sig = sorted((c for c in cols if per_col[c]["variance_ratio_sd"] >= 2.0),
             key=lambda c: -per_col[c]["variance_ratio_sd"])
feed_cols = ["XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4", "XMV_1", "XMV_2", "XMV_3", "XMV_4"]
cond_cols = ["XMV_11", "XMEAS_22", "XMEAS_5", "XMEAS_20", "XMV_5", "XMEAS_11", "XMEAS_13"]
feed_vr = {c: per_col[c]["variance_ratio_sd"] for c in feed_cols}
cond_vr = {c: per_col[c]["variance_ratio_sd"] for c in cond_cols}

# ---------- C. production regime / steady-state ----------
# Continuous TE plant: steady production if level/flow anchors stay within baseline +-3sigma all run
anchors = ["XMEAS_8", "XMEAS_12", "XMEAS_15", "XMEAS_6", "XMEAS_17"]
anchor_ok = True
anchor_detail = {}
for c in anchors:
    m, s = per_col[c]["baseline_mean"], per_col[c]["baseline_std"]
    z = (X[c].to_numpy(float) - m) / s
    frac_out = float((np.abs(z) > 3).mean())
    anchor_detail[c] = {"frac_outside_baseline_3sigma": round(frac_out, 5),
                        "range_baseline_sigma": [round(float(z.min()), 2), round(float(z.max()), 2)]}
    if frac_out > 0.02:
        anchor_ok = False
regime = {
    "detection": "level/flow anchor stability (XMEAS_8/12/15/6/17 within baseline mean+-3sigma)",
    "single_steady_regime": anchor_ok,
    "startup_shutdown_transition_rows_excluded": 0,
    "steady_row_indices": [0, n_rows - 1],
    "anchor_detail": anchor_detail,
    "product_grouping": "none (single continuous G/H product, batch_integrity.json applicable=false)",
    "note": "Steady-state filtering therefore reduces to era stratification (baseline vs post-onset); no rows excluded.",
}

# ---------- D. lag-compensated CCF ----------
def ccf_best(xs, ys, max_lag=MAX_LAG):
    """Convention identical to validate_report.json: r = corr(xs[t+lag], ys[t])."""
    xs = np.asarray(xs, float); ys = np.asarray(ys, float)
    best = None
    curve = []
    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            x2, y2 = xs[:lag], ys[-lag:]
        elif lag > 0:
            x2, y2 = xs[lag:], ys[:-lag]
        else:
            x2, y2 = xs, ys
        if len(x2) < 30 or x2.std() == 0 or y2.std() == 0:
            continue
        r = float(np.corrcoef(x2, y2)[0, 1])
        n = len(x2)
        t = abs(r) * np.sqrt((n - 2) / (1 - r * r))
        p = float(2 * stats.t.sf(t, n - 2))
        curve.append({"lag": lag, "r": round(r, 4), "n": n})
        if best is None or abs(r) > abs(best["r"]):
            best = {"lag": lag, "r": round(r, 4), "n": n, "p": p}
    r0 = next(e for e in curve if e["lag"] == 0)["r"]
    best["r0"] = r0
    best["improvement_pct_vs_lag0"] = round((abs(best["r"]) - abs(r0)) / max(abs(r0), 1e-9) * 100, 1)
    best["curve_abs_gt_0p3_fraction"] = round(float(np.mean([abs(e["r"]) > 0.3 for e in curve])), 3)
    return best, curve

pairs = [
    ("XMV_10", "XMEAS_9",  "TC feedback loop: valve actuation vs reactor temperature"),
    ("XMEAS_9", "XMV_10",  "reverse direction (same closed loop, opposite shift convention)"),
    ("XMEAS_21", "XMEAS_9", "cooling water outlet temp vs reactor temperature"),
    ("XMV_10", "XMEAS_21", "valve -> cooling water outlet temp (ontology predicts inverse)"),
    ("XMV_9", "XMEAS_19",  "steam valve -> steam flow"),
    ("XMEAS_19", "XMEAS_18", "steam flow -> stripper temperature (ontology: monotonic)"),
    ("XMV_9", "XMEAS_18",  "steam valve -> stripper temperature"),
    ("XMV_11", "XMEAS_22", "condenser CW valve -> condenser CW outlet temp (ontology: inverse)"),
    ("XMEAS_22", "XMEAS_11", "condenser CW outlet temp -> separator temperature"),
    ("XMEAS_9", "XMEAS_11", "reactor temperature -> separator temperature"),
]
lag_results = {}
for x, y, why in pairs:
    best, curve = ccf_best(X[x].to_numpy(float), X[y].to_numpy(float))
    lag_results[f"{x}~{y}"] = {"physics_context": why, "best": best}

# ---------- E. stratified + post-onset-only correlation ----------
def pear(xa, ya):
    xa = np.asarray(xa, float); ya = np.asarray(ya, float)
    if xa.std() == 0 or ya.std() == 0:
        return None
    r = float(np.corrcoef(xa, ya)[0, 1])
    n = len(xa)
    t = abs(r) * np.sqrt((n - 2) / (1 - r * r))
    return {"r": round(r, 4), "n": n, "p": float(2 * stats.t.sf(t, n - 2))}

strata = {
    "aggregate_lag0": pear(X["XMV_10"], X["XMEAS_9"]),
    "baseline_stratum_lag0": pear(pre["XMV_10"], pre["XMEAS_9"]),
    "post_onset_stratum_lag0": pear(post["XMV_10"], post["XMEAS_9"]),
    "baseline_stratum_lag-5": pear(pre["XMV_10"].iloc[:-5], pre["XMEAS_9"].iloc[5:]),
    "post_onset_stratum_lag-5": pear(post["XMV_10"].iloc[:-5], post["XMEAS_9"].iloc[5:]),
}
# ---------- F. leave-one-out leverage ----------
r_full = strata["aggregate_lag0"]["r"]
xa = X["XMV_10"].to_numpy(float); ya = X["XMEAS_9"].to_numpy(float)
shifts = []
for i in range(len(xa)):
    m = np.ones(len(xa), bool); m[i] = False
    shifts.append(abs(np.corrcoef(xa[m], ya[m])[0, 1] - r_full))
loo = {"full_r": round(r_full, 4), "max_abs_shift": round(float(max(shifts)), 4),
       "leveraged": bool(max(shifts) > 0.05),
       "note": "leave-one-out over all 960 points, lag 0"}

# ---------- G. spectral signature (broadband vs narrowband) ----------
def spectral(x):
    x = np.asarray(x, float)
    x = x - x.mean()
    w = np.hanning(len(x))
    ps = np.abs(np.fft.rfft(x * w)) ** 2
    ps = ps[1:]  # drop DC
    freqs = np.fft.rfftfreq(len(x), d=dt_sec)[1:]
    flat = float(np.exp(np.mean(np.log(ps + 1e-18))) / np.mean(ps))
    k = int(np.argmax(ps))
    return {"spectral_flatness": round(flat, 5),
            "dominant_period_samples": round(float(1.0 / freqs[k] * dt_sec) / dt_sec, 1) if freqs[k] > 0 else None,
            "dominant_period_seconds": round(float(1.0 / freqs[k]), 1) if freqs[k] > 0 else None,
            "peak_power_fraction": round(float(ps[k] / ps.sum()), 4),
            "interpretation_hint": "broadband (flatness high, peak fraction low) = random disturbance; single sharp peak = limit cycle / stiction"}
spec = {
    "XMV_10_post_onset": spectral(post["XMV_10"].to_numpy(float)),
    "XMEAS_9_post_onset": spectral(post["XMEAS_9"].to_numpy(float)),
    "XMV_10_baseline": spectral(pre["XMV_10"].to_numpy(float)),
}

# rolling 20-sample std onset cross-check (baseline sigma units)
w = 20
roll_std = X["XMV_10"].rolling(w).std().to_numpy(float)
base_sd = per_col["XMV_10"]["baseline_std"]
burst_idx = int(np.argmax(roll_std > 2 * base_sd)) if np.any(roll_std > 2 * base_sd) else -1
onset_check = {"xm_var_burst_first_index": burst_idx, "declared_onset_index": ONSET,
               "agreement": bool(abs(burst_idx - ONSET) <= w)}

# ---------- H. physics discriminators ----------
disc = {
    "T21_vs_T9_variance": {
        "XMEAS_21_vr": per_col["XMEAS_21"]["variance_ratio_sd"],
        "XMEAS_9_vr": per_col["XMEAS_9"]["variance_ratio_sd"],
        "ratio_T9_over_T21": round(per_col["XMEAS_9"]["variance_ratio_sd"] / per_col["XMEAS_21"]["variance_ratio_sd"], 2),
        "interpretation": "T9 fluctuation x%.2f while measured CW outlet temperature stays at baseline spread (x%.2f): the TC loop absorbs the disturbance before it registers as a T21 swing; a large actual coolant-flow swing (severe valve fault) would drive T21 = T_cw,in + Q/(m_cw*Cp) visibly." % (per_col["XMEAS_9"]["variance_ratio_sd"], per_col["XMEAS_21"]["variance_ratio_sd"]),
    },
    "T21_T9_coupling": {
        "full_lag0": pear(X["XMEAS_21"], X["XMEAS_9"]),
        "best_ccf": lag_results["XMEAS_21~XMEAS_9"]["best"],
    },
    "feed_composition_vr": {c: per_col[c]["variance_ratio_sd"] for c in ["XMEAS_23", "XMEAS_24", "XMEAS_25", "XMEAS_26", "XMEAS_27", "XMEAS_28"]},
    "feed_flow_vr": feed_vr,
    "condenser_loop_vr": cond_vr,
    "stripper_loop_vr": {c: per_col[c]["variance_ratio_sd"] for c in ["XMV_9", "XMEAS_19", "XMEAS_18", "XMV_8", "XMEAS_15", "XMEAS_16", "XMEAS_17"]},
    "reactor_loop_vr": {c: per_col[c]["variance_ratio_sd"] for c in ["XMV_10", "XMEAS_9", "XMEAS_21", "XMEAS_7", "XMEAS_8", "XMEAS_6"]},
}

# ---------- figure ----------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

fig, axes = plt.subplots(3, 1, figsize=(13, 9), sharex=True)
tmin = np.arange(n_rows)
def z_base(c):
    return (X[c].to_numpy(float) - per_col[c]["baseline_mean"]) / per_col[c]["baseline_std"]
for ax, c, color in [(axes[0], "XMEAS_9", "tab:red"), (axes[1], "XMV_10", "tab:blue")]:
    ax.plot(tmin, z_base(c), color=color, lw=0.8)
    ax.axhline(3, color="gray", ls=":", lw=0.8); ax.axhline(-3, color="gray", ls=":", lw=0.8)
    ax.axvline(ONSET, color="k", ls="--", lw=1)
    ax.set_ylabel(c + " (z, baseline-referenced)")
    ax.set_title("%s baseline vs post-onset (onset idx 160 dashed)" % c)
axes[2].plot(tmin, pd.Series(z_base("XMEAS_9")).rolling(w).std(), color="tab:red", lw=1, label="XMEAS_9 rolling std")
axes[2].plot(tmin, pd.Series(z_base("XMV_10")).rolling(w).std(), color="tab:blue", lw=1, label="XMV_10 rolling std")
axes[2].axvline(ONSET, color="k", ls="--", lw=1)
axes[2].set_ylabel("rolling std (baseline sigma, w=%d)" % w)
axes[2].set_xlabel("sample index (3 min/sample)")
axes[2].legend(loc="upper left")
fig.suptitle("Reactor cooling loop variance burst - XMEAS_9 vs XMV_10 (TE unit)")
fig.tight_layout(rect=[0, 0, 1, 0.97])
fig_path = RUN_DIR + "/03_figures/fig_cooling_loop_variance.png"
fig.savefig(fig_path, dpi=110)
plt.close(fig)

# ---------- assemble ----------
out = {
    "script": "06_scripts/cooling_loop_semantic_analysis.py",
    "generated_at": pd.Timestamp.utcnow().isoformat(),
    "data_source": "00_input/data.csv (raw, identical to 02_processed/cleaned_data.json content; prepare-stage cleaning changed no values)",
    "n_rows": n_rows, "n_cols": len(cols), "sampling_interval_seconds": dt_sec,
    "baseline_rows": [0, ONSET - 1], "post_onset_rows": [ONSET, n_rows - 1],
    "per_column_baseline_vs_post": per_col,
    "variance_inflation_signature_vr_ge_2": [
        {"column": c, **{k: per_col[c][k] for k in ["variance_ratio_sd", "f_test_F", "f_test_p_two_sided", "levene_p", "mean_shift_baseline_sigma", "baseline_std", "post_std"]}}
        for c in sig
    ],
    "production_regime": regime,
    "lag_compensated_ccf": lag_results,
    "ccf_convention": "r = corr(xs[t+lag], ys[t]); negative lag = xs EARLIER than ys (matches validate_report.json target_analysis best_lags)",
    "stratified_correlation_XMV_10_XMEAS_9": strata,
    "leave_one_out_XMV_10_XMEAS_9": loo,
    "spectral_signature": spec,
    "onset_cross_check": onset_check,
    "physics_discriminators": disc,
    "figure_added": {"file": "03_figures/fig_cooling_loop_variance.png",
                     "plot_type": "temporal_overlay",
                     "title": "Reactor cooling loop variance burst - XMEAS_9 vs XMV_10",
                     "description": "Baseline-referenced z-score overlay of XMEAS_9 and XMV_10 plus rolling std; onset idx 160 marked",
                     "status": "rendered", "tool": "matplotlib"},
}
with open(RUN_DIR + "/02_processed/cooling_loop_semantic_analysis.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
with open(RUN_DIR + "/02_processed/production_regime_filter.json", "w", encoding="utf-8") as f:
    json.dump({
        "applicable": True,
        "method": regime["detection"],
        "regimes": [{"regime": "steady_production", "row_range": [0, n_rows - 1], "rows": n_rows}] if anchor_ok else [],
        "exclude_regimes": [],
        "caution_regimes": [],
        "steady_row_indices": [0, n_rows - 1] if anchor_ok else [],
        "rows_filtered_out": 0,
        "per_product_anomaly_analysis": {"applicable": False, "reason": "single continuous product (batch_integrity.json: id_col=null)"},
        "focus_product": None,
        "note": regime["note"],
    }, f, ensure_ascii=False, indent=1)

print("signature set:", sig)
print("onset cross-check:", onset_check)
print("XMV_10~XMEAS_9 ccf best:", lag_results["XMV_10~XMEAS_9"]["best"])
print("strata:", json.dumps(strata))
print("T21 vr %.3f  T9 vr %.3f" % (per_col["XMEAS_21"]["variance_ratio_sd"], per_col["XMEAS_9"]["variance_ratio_sd"]))
print("spectral XMV_10 post:", spec["XMV_10_post_onset"])
print("figure:", fig_path)
