# 最终物理审计（Step 7 — FINAL_AUDIT）

- **审计人**: Auditor Sun（report-reviewer，物理审计 persona，32 年过程安全与质量审计经验）
- **RUN_DIR**: `D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171639527_bench_tep_d11_reactor_cooling_random`
- **审计模式**: FINAL_AUDIT（报告发布前最后一道独立闸门；不读取 `results/`、`scripts/benchmark/`，无网络）
- **审计对象**: `report.md` + `run_summary.json`，对账 `04_diagnostics/diagnosis.json|confidence.json|evidence.json|reasoning_chain.json`、`05_review/judge_feedback.json`、`05_review/optimizer_preflight.md`、`02_processed/*`，并以 VENV python 从 `00_input/data.csv`（960 行 × 52 信号列 + timestamp，0 缺失）**独立重算全部载荷数字**
- **前置闸门状态**: Judge 97/100 pass（12/12 抽查复算吻合，blocking_issues=[]）；Step 5b 前置物理审计 PREFLIGHT_PASS（0 FATAL / 0 MAJOR / 5 MINOR 措辞 guardrail P1–P5）

---

## 1. 审计总览

`report.md` 如实承载 `04_diagnostics/diagnosis.json` 的 **COMPETING_SET** 判定，**无任何隐性升格**：

| 项 | 工件声明 | report.md 表述 | 一致性 |
|------|------|------|:--:|
| 诊断类型 | COMPETING_SET（diagnosis.json） | 第 1/6 节均写 COMPETING_SET，明确"未升格为单一根因" | ✅ |
| H1（冷却侧随机扰动，主） | 62，封顶 65 | "置信度 62/100（MEDIUM，封顶 65）" | ✅ |
| H4（阀自身故障） | [WEAK_EXCLUSION] 保留，30（≤50 规则） | "次可能解释（置信度 30，弱排除保留）" | ✅ |
| H2/H3/H5 | eliminated，排除置信度各 90 | "作为主因均已被定量排除（排除置信度各 90）" | ✅ |
| overall_confidence | 62（ceiling 65） | 执行摘要/§6.3/§7.2 三处均 62 | ✅ |
| primary_finding 引用 | diagnosis.json 原文 | §6.1 逐字引用（含"方差×6.33，均值仅+1.22σ钳制"） | ✅ |
| 收敛条件 | 任一决定性测量（位置器/T_cw,in/实际流量） | P0 行动与 §6.4 可证伪条件均如实声明"加装任一件即可收敛为 DETERMINED" | ✅ |

**审计结论**：核心证据链（方差爆发签名、阀先温度后、T21 判别子、宽带谱、空间排除、下游被动传播）经本审计从 `00_input/data.csv` 独立重算**全部复现，零失实**；五条措辞 guardrail P1–P5 **全部在报告中正确应用**（见 §2.3）；判定为 **ENDORSED**（0 FATAL / 0 MAJOR / 2 MINOR / 3 INFO，均不阻断发布）。

| 严重度 | 数量 |
|:--|:--|
| FATAL | **0** |
| MAJOR | **0** |
| MINOR | 2（M1–M2，见 §5） |
| INFO | 3（N1–N3，见 §5） |

---

## 2. 统计核验

### 2.1 独立重算 vs 工件 vs report.md（VENV python，raw=00_input/data.csv，基线=行0–159，异常段=行160–959）

| # | 量 | 工件声明 | report.md | 本审计重算 | 判定 |
|:--|:--|:--|:--|:--|:--|
| 1 | XMV_10 基线→异常段 | 41.0607±0.5733 → 41.7620±3.6312 | §4.1 同 | 41.0608±0.5733 → 41.7620±3.6312 | 一致 |
| 2 | XMV_10 vr / F / 漂移 / Welch p | 6.334 / 40.1199 / +1.223σ / 3.17e-07 | 6.334 / +1.223σ / 3.2e-07 | 6.3340 / 40.1199 / +1.223σ / 3.166e-07 | 一致 |
| 3 | XMEAS_9 vr / 漂移 | 4.0442 / +0.01σ | ×4.044 / +0.010σ | 4.0442 / +0.010σ | 一致 |
| 4 | XMEAS_21 vr / F p | 1.0266 / 0.691 | ×1.027 / p=0.691 | 1.0266 / 0.691 | 一致 |
| 5 | XMV_9/XMEAS_18/XMEAS_19 vr | 2.511 / 2.468 / 2.440 | §4.1 同 | 2.5109 / 2.4684 / 2.4401（漂移 −0.92/−0.80/−0.98σ） | 一致 |
| 6 | 阀→温度 lead5 r（n=955） | −0.6356 | −0.6356 | **−0.6356**（lag0 +0.5007） | 一致 |
| 7 | 分层 lag-5 基线/异常 | −0.2051(n=155) / −0.6416(n=795) | §4.3 同 | −0.2051 / −0.6416 | 一致 |
| 8 | 分层 lag0 基线/异常/总体 | +0.6919 / +0.5011 / +0.5007 | §4.4 同 | +0.6919 / +0.5011 / +0.5007（无 Simpson 翻转） | 一致 |
| 9 | XMEAS_9 越限单点 | 5 点 @256/305/410/539/636，3.23/3.10/3.73/3.21/3.21σ，pct=0.521% | §4.8 同 | **恰好 5 点**，\|z\|=3.23/3.10/3.73/3.21/3.21，pct=0.521% | 一致 |
| 10 | XMEAS_9 全段 mean/std/range | 120.3994 / 0.0776 / 120.11–120.65 | §4.8 同 | 120.3994 / 0.0777 / 120.11–120.65（第 4 位舍入） | 一致 |
| 11 | 进料列最大领先 \|r\| | XMEAS_26@lag−9 r=0.149（validate_report best_lags） | §5.2 同（P2 口径） | **0.149**（n=951；XMEAS_2@lag−7 为 −0.1283） | 一致 |
| 12 | onset 首现 | idx 166（agreement=true） | idx 166 | idx 166（滚动 20 样本 std=1.348 首超 2×0.573） | 一致 |
| 13 | XMV_10 异常段开度范围 | 34.53–50.07%（未饱和） | 34.5–50.1% | 34.53–50.07 | 一致 |
| 14 | 谱 flatness（估计器差异披露） | 0.06764/单频 4.78%/基线 0.5796 | §4.5 同 + 披露重算 0.075/6.2%/0.539 | periodogram（去均值）：0.075 / 6.2% / 0.539 | 定性一致（宽带，两种估计器稳健） |

14 组载荷数字全部复现。`04_diagnostics/evidence.json` 清单计数（visual 2 / numerical 10 / physical 4 / validation 5）与 evidence_inventory 实际条目一致；`confidence.json` 核算 86−21−3=62、46−16=30 算术正确且与 `diagnosis.json` competing_sets（CS1 ceiling=65）、`reasoning_chain.json` hypothesis_evolution（H1 40→62、H4 35→30）三处口径一致。

### 2.2 verdict 保真性与反升格检查 — **通过**

- Judge 给出 97/100 高分，report.md **未借势上调**任何置信度：62/30/封顶 65 原样保留，并在 §1"有多大把握"与 §6.1 明确"把握分层"——空间定位硬、机制细分受限。
- H4 的 [WEAK_EXCLUSION] 语义完整保留（排除置信度 <90 不入 eliminated 的 schema 纪律）；§5.3 如实披露"真实阀非线性在闭环下可表现为宽带"的残余风险，未把间接否证写成决定性否证。
- 机理链首环（未测扰动→XMV_10）在 §6.2 以 `[INFERRED/DATA_LINK_MISSING]` 标注，未伪装为已证；STRONG_EVIDENCE（非 PROVEN）的定位如实转述。

### 2.3 前置 guardrail P1–P5 应用对照 — **全部应用，无原样传播**

| # | 上游不精确表述 | report.md 采用口径 | 本审计核验 |
|:--:|------|------|:--:|
| P1 | R3"窗口-8..-2 一致 \|r\|>0.39" | §4.3："lead 3–8 步 \|r\|>0.39（0.390/0.555/0.636/0.624/0.554/0.454，峰值 lead5），lead2 步回落 ≈0.10；consistent=true（5/6）" | 与 validate_report lag_window_consistency.XMV_10.adjacent_r 逐值一致；R3 原文偏差在 §4.3 显式披露 ✅ |
| P2 | "进料无领先相关(\|r\|<0.13)" | §5.2："无进料通道达到 \|r\|≥0.3 判据（最大 \|r\|=0.149，XMEAS_26@lag−9，p=3.9e-6，无方差签名 vr=0.79）" | 本审计重算确认 0.149 为真实最大值；"<0.13"未传播 ✅（judge 抽查备注中的 0.1283 亦未被报告带入主口径） |
| P3 | "5σ越限" | §4.8："3σ 越限的 5 个孤立单点（全序列 σ，max_deviation_sigma 3.23/3.10/3.73/3.21/3.21，pct=0.521%）"；执行摘要"max 3.73σ" | 与 anomaly_report 及重算逐位一致；"5σ"零出现（diagnosis.json predicted_observables 中的上游"5σ"字样未被报告复制）✅ |
| P4 | XMV_9"其余 4 次 CONCURRENT" | §4.3/§5.2："1/5 PRECURSOR（idx410）、3 次 CONCURRENT、1 个区间未达列入阈值（idx256）" | physics_check 实录：XMV_9 仅 4 条记录（305/539/636 CONCURRENT + 410 PRECURSOR），idx256 无记录——报告口径与工件精确一致；XMV_10 5/5 PRECURSOR（\|4.35–5.48\|σ，idx256 mean_during=49.113）亦复现 ✅ |
| P5 | XMV_10"均值不变" | §4.1："+1.223σ（Welch p=3.2e-07）……定性为'均值钳制'，不读作'均值完全不变'" | Welch p 重算 3.166e-07 ✅ |

### 2.4 Judge 三条 warning 的落报告核验 — **全部落实**

- warning #1（R3 lag 窗口）→ §4.3 披露并按工件字段引用；warning #2（L3-content-in-L4-slot）→ §7.1 强制披露"置于 L4 槽位但内容为 L3"，全部图形引用按统计内容处理；warning #3（cleaning_integrity 未登记）→ §3 数据质量表"缺口披露"行 + §8.3 P2 整改项 + §9.3 局限表。

---

## 3. 物理核验

1. **机理链可回溯性**：report.md §6.2 机理链每一环挂接主导方程（mCp·dT9/dt=Q_rxn−UA·ΔT_lm；u=Kp·e+Ki∫e dt；T21=T_cw,in+Q/(ṁ·Cp)；P∝Q²），与 `01_ontology/ontology.json` relationships 一致；首环 DATA_LINK_MISSING 如实标注——无物理上不可能环节，无断裂伪装为已证。
2. **量纲与时间尺度**：5 步=900s 铅滞落在反应器冷却回路分钟级热惯性带内，与本体"分钟级(回路响应)"预测一致；"均值钳制(+1.223σ)+方差爆发(×6.33/×4.04)"是 PI 闭环对抗有界随机扰动的预期形态，量级阶次论证（×3–10 / ×2–5）为 derived 且已标记。
3. **T21 量级否证自洽性**：dT21/dṁ=−(T21−T_cw,in)/ṁ。出口温度实测仅 σ=0.146°C、vr=1.027，大幅实际流量摆动必在 T21 留下 0.1–1K 量级波动——未观察到，否证方向正确；报告 §4.6/§9.3 已按 derived/阶次论证定位（依赖未测 T_cw,in，备案 I2），未越界宣称第一性证明。
4. **谱形态物理**：宽带（flatness≈0.07，单频功率<7%）与卡涩/死区/位置器振荡的窄带极限环指纹相反；report.md 用于**弱排除**（而非 ≥90 硬排除），并在 §4.5/§9.3 披露估计器间数值差异而定性稳健——排除纪律合规。
5. **空间排他与因果方向不对称**：进料/冷凝/循环块 13 通道 vr 0.79–1.38 全处基线带（重算一致）；反应器→下游正向传播（XMEAS_9→XMEAS_11 r=0.4539@lag2）已验证而汽提→反应器无过判据领先相关（|r|≤0.148，XMEAS_9~XMEAS_19 p=0.241 不显著）——"扰动入口在反应器冷却水侧"的空间定位成立；汽提环"传播 vs 独立"溯源诚实悬置（−3 扣分来源）。
6. **闭环判别力边界**：§4.3 明确"阀先动、温度后应只能证明扰动在 TC 回路内被对抗，不能单独区分外部扰动与阀自身乱动"——这是 H4 保留、封顶 65 的原因，报告未回避。

---

## 4. 矛盾扫描

- **report.md 内部**：执行摘要/§4/§5/§6/§7 之间无自相矛盾；置信度三处（62/30/65）口径一致。
- **report.md vs 04_diagnostics**：primary_finding 逐字一致；五因素分解、adjustment_log、data_gaps 6 项、可证伪条件 5 条均与工件一致；§6.4 条目与 diagnosis.json falsification_conditions 语义一致（新增第 5 条"检修记录"来自 H4 falsification_conditions，合法）。
- **report.md vs judge_feedback.json**：97/100 pass、12/12 复算、3 条 warnings 的披露位置逐条落实（§7.4 对照）；judge 抽查备注中"<0.13/0.1283"的次生不精确**未**被报告采用（§5.2 以工件与重算为准的 0.149）。
- **report.md vs optimizer_preflight.md**：P1–P5 全部应用并附对照表（§7.4）；I1（谱估计器差异）、I2（T21 否证假设依赖）在 §4.5/§9.3 备案。
- **report.md vs 原始数据**：见 §2.1，14 组重算零矛盾。
- **未发现被忽略的反证**：闭环反馈污染、汽提溯源缺口、非 VLM 环境（L3-in-L4）三项主要反证均在报告中显式登记而非隐藏。

---

## 5. MINOR 与 INFO 记录（均不阻断发布）

- **M1 [MINOR]** §7.2 validate_report 行将"进料列最优 \|r\|=0.1283（judge 抽查备注口径）"与"XMEAS_26@lag−9 报告口径 0.149"并列于同一单元格，表述略绕；经本审计重算，**0.149 才是该工件字段的真实值**（XMEAS_2@lag−7=−0.1283 为另一列的值）。§5.2 主口径正确，建议发布 HTML 时在图表层仅呈现 0.149 与 \|r\|≥0.3 判据，避免读者混淆。
- **M2 [MINOR]** XMEAS_9 全段 std 工件记 0.0776、ddof=1 重算为 0.0777（judge 亦已注明第 4 位舍入差）——第 4 位舍入差异，无任何结论依赖；HTML 固化时统一保留 4 位有效数字即可。
- **N1 [INFO]** physics_check effect_size 的 before 窗口定义仍未在工件中登记（沿用 preflight 备案）；mean_during=49.113 已逐位验证。
- **N2 [INFO]** XMEAS_18 在 3/3 条记录中为 PRECURSOR（含 idx256——该区间 XMV_9 缺记录）；与"汽提环次级签名"读法兼容，不构成矛盾，但后续 run 可在 H5 排除叙述中顺带说明，免生疑问。
- **N3 [INFO]** 报告页脚"judge 12 项独立复算零偏差"指 judge_feedback.json spot_check_findings（12/12 verified）——表述准确；`run_summary.json` audit_verdict_note 已声明 Step 7 未在报告时点运行，本文件即该缺口闭合记录。

---

## 6. 判定

证据链完整、可复算、无升格、无措辞缺陷传播；判定诚实（COMPETING_SET + 封顶 65 + [WEAK_EXCLUSION]），置信度核算与全部载荷数字经原始数据独立重算逐位吻合。

**FINAL_VERDICT: ENDORSED**

（FATAL=0，MAJOR=0，MINOR=2，INFO=3；放行 Step 8 HTML 构建。M1/M2 建议在 HTML 固化时以规范化口径呈现，不构成回炉条件。）

**判定： ENDORSED — 物理逻辑扎实，准予发布。**
