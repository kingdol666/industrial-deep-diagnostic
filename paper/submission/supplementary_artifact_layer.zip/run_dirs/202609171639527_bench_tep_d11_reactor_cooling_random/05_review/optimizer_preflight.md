# 报告前物理审计（Step 5b — PRE_REPORT_AUDIT=true）

- **审计人**: Auditor Sun（report-reviewer，物理审计 persona）
- **RUN_DIR**: `D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171639527_bench_tep_d11_reactor_cooling_random`
- **审计模式**: PRE_REPORT_AUDIT（报告生成前，与 Judge 并行；本审计不依赖也不读取 report.md）
- **审计对象**: `04_diagnostics/diagnosis.json`、`04_diagnostics/evidence.json`、`04_diagnostics/confidence.json`、`04_diagnostics/reasoning_chain.json`、`01_ontology/ontology.json`、`02_processed/*`（cooling_loop_semantic_analysis / time_lag_analysis / causal_evidence_map / physics_check / anomaly_report / validate_report / data_analysis_conclusion / production_regime_filter / feature_summary）、`00_input/data.csv`
- **独立复核方法**: 全部关键数字以 VENV python（numpy 2.5.2 / pandas 3.0.5 / scipy 1.18.0）从 `00_input/data.csv`（960 行 × 52 信号列 + timestamp，180s 均匀采样，0 缺失）独立重算，不采信管线摘要。所有 JSON 工件均通过 json.load 语法校验。
- **与 Judge（Step 5a）的关系**: 独立执行。事后核对 `05_review/judge_feedback.json`：overall_score=97、verdict=pass、blocking_issues=[]，与本审计结论无冲突。

---

## 1. 审计总览

诊断结论为 **COMPETING_SET**：H1（反应器冷却水侧持续性随机扰动，经 TC 环由 XMV_10 补偿表达）为主（62，封顶 65）；H4（XMV_10 阀自身故障）以 [WEAK_EXCLUSION] 保留（30）；H2/H3/H5 定量排除（各 90）。

**审计结论**：核心证据链——方差爆发签名（XMV_10 ×6.33 / XMEAS_9 ×4.04、均值钳制）、阀先温度后（领先 5 步 r=-0.6356，仅异常段激活）、T21 判别子（×1.027）、宽带谱（非极限环）、进料/冷凝/循环空间排除、下游被动传播——**全部从原始数据独立复现成功，无一处数字失实**。机理链可回溯至主导方程（mCp·dT9/dt=Q_rxn−UA·ΔT_lm、T21=T_cw,in+Q/(ṁ·Cp)、u=Kp·e+Ki∫e dt），三态诚实输出与置信度封顶符合协议。发现 **0 项 FATAL、0 项 MAJOR、5 项 MINOR**（全部为二次表述精度问题，不动摇结论，但 Step 6 报告员必须按第 6 节的 guardrail 措辞引用）。

| 严重度 | 数量 |
|:--|:--|
| FATAL | **0** |
| MAJOR | **0** |
| MINOR | 5（P1–P5，见 §6） |
| INFO | 3（I1–I3，见 §7） |

---

## 2. 逐项检查结果

### 检查 2.1 方差签名与均值钳制（variance-burst topology）— **通过**
- [PASS] XMV_10：基线(行0–159) 41.0607±0.5733% → 异常段(行160–959) 41.7620±3.6312%，方差比 **6.334**，F=40.1199（p=1.52e-92）、Levene p=8.03e-50、均值漂移 **+1.223σ**（Welch t=-5.1505, p=3.17e-07）——与 `02_processed/cooling_loop_semantic_analysis.json` per_column_baseline_vs_post 逐位一致。
- [PASS] XMEAS_9：120.3993±0.0209 → 120.3995±0.0846 °C，方差比 **4.0442**（F p=4.96e-63），均值漂移 +0.010σ——一致。
- [PASS] 方差签名仅集中于 5 通道（XMV_10/XMEAS_9/XMV_9/XMEAS_18/XMEAS_19，vr≥2.44，p<1e-32），其余 47 通道 vr 0.79–1.57——复核一致。
- [PASS] 阀未饱和假设成立：异常段 XMV_10 范围 34.53–50.07%，远离 0/100% 限位（`04_diagnostics/confidence.json` assumptions 第三条的前提验证通过）。
- [MINOR→P5] XMV_10 均值漂移 +1.223σ 在统计上显著（p=3.2e-07）。"均值钳制"作为定性描述可接受（漂移远小于方差膨胀），报告必须保留 "+1.223σ" 原值，不得写成"均值不变"。

### 检查 2.2 起点一致性（onset）— **通过**
- [PASS] 滚动 20 样本标准差首超 2× 基线σ：重算首现 **idx 166**，与声明起点 idx 160 一致（`onset_cross_check` 复现）。

### 检查 2.3 铅滞结构（lead-lag）— **通过（附表述修正 P1）**
- [PASS] XMV_10 领先 XMEAS_9 5 步（900s）：r=**-0.6356**，n=955，p=3.44e-109（≪Bonferroni 5e-4）；lag0 r=+0.5007——逐位复现。
- [PASS] 分层证明领先结构仅异常段激活：异常段层内 lag-5 r=**-0.6416**(n=795) vs 基线层 **-0.2051**(n=155)；lag0 分层基线 +0.6919 / 异常 +0.5011 与总体同号，无 Simpson 翻转——逐位复现。
- [PASS] leave-one-out（960 点）max|Δr|=**0.0035**——复现（cooling_loop 工件记 0.0036、validate_report 记 0.0035，差异为舍入）。
- [MINOR→P1] reasoning_chain R3 称"窗口-8..-2 一致|r|>0.39"。实测（与 validate_report.lag_window_consistency.XMV_10.adjacent_r 完全一致）：lead 3–8 步 |r|=0.390/0.555/0.636/0.624/0.554/0.454，lead 2 步仅 |r|=0.097。工件自身标记 consistent_count=5/6、isolated_spike=false——"非孤立尖峰"的定性结论成立，但"|r|>0.39"应限定为 **-8..-3**。

### 检查 2.4 T21 判别子 — **通过**
- [PASS] XMEAS_21 vr=**1.0266**（F p=0.691）；T9/T21 方差比 3.94=4.0442/1.0266——复现。
- [PASS] XMV_10→XMEAS_21 滞后补偿 r=-0.2029（lead 4 步，p=2.45e-10）、XMEAS_21~XMEAS_9 best r=0.2827@1——复现。
- [PASS] 物理判读方向正确：T21=T_cw,in+Q/(ṁ·Cp) 端无可见波动，闭环在扰动到达 T21 前吸收——与 H1 自洽，构成对"大幅实际流量摆动型阀故障"的量级否证（该否证依赖未测 T_cw,in，诊断已按 derived/阶次论证标注，见 I2）。

### 检查 2.5 宽带谱判别（broadband spectrum）— **通过**
- [PASS] 独立重算（periodogram，去均值）：XMV_10 异常段 flatness=0.075 / 单频功率占比 6.2%，基线段 0.539（近白）；XMEAS_9 异常段 0.134/6.2%。工件值（0.068/4.78%、0.580、0.116）为另一谱估计器所得，数值有估计器间差异但**定性结论完全稳健**：异常段为宽带持续涨落，无窄带极限环主峰（见 I1）。
- [PASS] 该判别正确用于 H4 弱排除而非硬排除（决定性位置器反馈缺失）。

### 检查 2.6 空间排除（进料/冷凝/循环）— **通过（附表述修正 P2）**
- [PASS] 进料块 vr：XMEAS_1-4=1.256/0.925/1.064/1.158、XMV_1-4=0.832/1.212/1.256/1.025、组成 XMEAS_23-28=0.790–1.216；均值漂移全部 <0.3σ（最大 XMEAS_25 -0.248σ）——逐项复现。
- [PASS] 冷凝/循环块 vr：XMV_11 0.891、XMEAS_22 1.181、XMEAS_5 0.977、XMEAS_20 1.369、XMEAS_13 1.253；XMEAS_7（反应器压力）漂移 -0.136σ/vr=1.264——复现。
- [PASS] 压缩机功（XMEAS_20）-温度耦合 r=**-0.0784**——逐位复现（physics_check energy_balance）；P∝Q² CV=1.07% 的输入区间（流量 41.7–43.1、压力 2678–2726）与数据一致。
- [MINOR→P2] 诊断称进料通道"对 XMEAS_9 无领先相关（|r|<0.13）"。validate_report best_lags 实测进料组成 **XMEAS_26@lag-9 r=+0.149**（p=3.9e-6）>0.13。该相关远低于 |r|≥0.3 判据且 XMEAS_26 vr=0.79/漂移-0.04σ 无任何方差签名，**排除结论不受影响**，但 "<0.13" 的表述不成立。

### 检查 2.7 下游传播与汽提次级签名 — **通过**
- [PASS] XMEAS_9→XMEAS_11 lag-2 r=**0.4539**（p=7.4e-50）、XMEAS_22→XMEAS_11 lag-1 r=**0.663**（p=1.77e-122）；下游执行量 XMV_11 vr=0.891 处基线——复现，被动传播判读成立。
- [PASS] 环内相干 XMV_9→XMEAS_19 r=**0.9913**、XMEAS_19→XMEAS_18 r=**0.9539**；跨环 XMV_10~XMV_9 |r|=0.1241、XMV_10~XMEAS_19 0.133、XMEAS_9~XMEAS_19 0.0381（p=0.241 不显著）、XMEAS_9~XMEAS_18 0.1481——全部复现。"传播 vs 独立不可判"的诚实披露与数据一致。
- [PASS] validate_report 中的第 7 个过判据对（XMEAS_22~XMEAS_9 lag1 r=0.3452，跟随方向）复现——time_lag_analysis 元数据 significant_lags_found=7 与两工件分处统计一致（I3）。

### 检查 2.8 异常形态与 physics_check 时序 — **通过（附表述修正 P3/P4）**
- [PASS] XMEAS_9 越限为**恰好 5 个孤立单点**（idx 256/305/410/539/636，间隔 49–129 样本，无相邻连片），全序列 σ 下 |z|=3.10/3.10/3.73/3.21/3.21，pct=0.521%——与 anomaly_report 逐位一致；"方差驱动散点而非持续偏移/台阶"判读成立。
- [PASS] physics_check idx256 XMV_10 mean_during=49.113 逐位复现（该点阀位较基线均值高 15.9 个基线σ，方向与量级支持阀先动）。
- [MINOR→P3] 诊断称 XMEAS_9 点位"5σ越限"：工件锚定值为 3.10–3.73σ（全序列 σ；按基线 σ 则为 11.9–13.8σ）。"5σ" 两头不靠，报告必须写 "3σ 越限的 5 个孤立单点（max 3.73σ，全序列σ）"。
- [MINOR→P4] "XMV_9 其余 4 次 CONCURRENT"：physics_check 中 XMV_9 在 XMEAS_9 的 5 个区间仅有 4 条记录（305/539/636 CONCURRENT + 410 PRECURSOR），idx256 无 XMV_9 记录。1/5 PRECURSOR 的不对称结论不变（缺失反而更弱）。

### 检查 2.9 本体引用忠实性 — **通过**
- [PASS] 本体 5 个 CONTRADICTED 信号（XMEAS_9/XMEAS_18/XMEAS_19/XMV_9/XMV_10）及其 discrepancy_signal 原文、confounders 第 1 条（XMV_10 双重身份，controlled=false）、governing_equation（能量平衡/PI 反馈/T21 表达式）、XMEAS_9→XMEAS_31 ">10采样步(循环累积)" 关系——逐一在 `01_ontology/ontology.json` 中核实存在且被忠实引用（data_gaps 中 "XMEAS_9~XMEAS_31 本体预测>10步" 有本体依据，非笔误）。
- [PASS] 无 CONTRADICTED 断言被当支持证据使用；CONTRADICTED 仅用作差异检出，角色正确。

### 检查 2.10 竞争假设完备性、可证伪性与置信度封顶 — **通过**
- [PASS] ≥3 个竞争假设：H1–H5 预注册，2 存活 + 3 定量排除；每个排除有定量证据 + 复兴条件；H4 以 [WEAK_EXCLUSION]（<90）保留而非强行入 eliminated——四抗条件与排除标准执行正确。
- [PASS] 反事实三态选择正确：H4 不可 ≥90 排除（无位置器/T_cw,in/实际流量测点，本体预登记的结构性事实）→ COMPETING_SET 而非 DETERMINED；证据远超 NEEDS_DATA 门槛 → 不降级。
- [PASS] 置信度核算复算：H1 五因素 22+22+17+17+8=86 → 封顶 -21 → 62（≤65 封顶 ✓，再 -3 有跨环缺口依据）；H4 WEAK 证明 46-16=30（≤50 规则 ✓）；overall=62 与分解一致。
- [PASS] 可证伪条件 4 条均具体可执行（位置器反馈形态、T_cw,in 平稳性、均值漂移超带、进料领先相关）；predicted_observables 5 条中 4 条已被本数据证实、1 条属加装仪表后可验。
- [PASS] 证据分级：统计主体 L3、本体 L5、图形证据 L4 槽位但内容按 L3（metadata-backed 非像素判读，已显式披露，无伪造 VLM 出处）——合规。
- [PASS] 证据清单计数（visual 2 / numerical 10 / physical 4 / validation 5）与 evidence.json 实际条目数一致。

---

## 3. 统计复核汇总（独立重算 vs 工件声明）

| # | 量 | 工件声明 | 本审计重算 | 判定 |
|:--|:--|:--|:--|:--|
| 1 | XMV_10 vr / F / Levene / 漂移 | 6.334 / 40.1199 / 8.03e-50 / +1.223σ | 6.3340 / 40.1199 / 8.026e-50 / +1.223σ | 一致 |
| 2 | XMEAS_9 vr / 漂移 | 4.0442 / +0.01σ | 4.0442 / +0.010σ | 一致 |
| 3 | XMEAS_21 vr / F p | 1.0266 / 0.691 | 1.0266 / 0.6911 | 一致 |
| 4 | 阀→温度 lead5 r / p / n | -0.6356 / 3.44e-109 / 955 | -0.6356 / 3.436e-109 / 955 | 一致 |
| 5 | 分层 lag0 基线/异常 | +0.6919 / +0.5011 | +0.6919 / +0.5011 | 一致 |
| 6 | 分层 lag-5 基线/异常 | -0.2051 / -0.6416 | -0.2051 / -0.6416 | 一致 |
| 7 | LOO max\|Δr\| | 0.0036/0.0035 | 0.0035 | 一致 |
| 8 | onset 首现 | idx 166 | idx 166 | 一致 |
| 9 | XMEAS_9→XMEAS_11 | 0.4539@lag2 | 0.4539@lag2 (p=7.40e-50) | 一致 |
| 10 | 跨环最大 \|r\| | 0.124–0.148 | 0.1241/0.1330/0.1481 | 一致 |
| 11 | 进料/冷凝块 vr | 0.79–1.26 / 0.89–1.37 | 逐项一致 | 一致 |
| 12 | 越限单点 | 5 点 @256/305/410/539/636, 3.10–3.73σ | 5 点隔离, z=3.10–3.73（全序列σ） | 一致 |
| 13 | 谱形态 | 宽带 0.068 / 基线 0.580 | 宽带 0.075 / 基线 0.539（估计器差异，定性一致） | 定性一致 |
| 14 | 阀饱和检查 | 假设远离限位 | 34.5–50.1% | 成立 |

数据完整性：960 行、52 信号列、timestamp 180s 等间隔无丢失、0 缺失、time_sorted=true——全部复核通过。

## 4. 物理验证

1. **机理链可回溯性**：主链每一环挂接主导方程——移热/能量平衡 mCp·dT9/dt=Q_rxn−UA·ΔT_lm 与 Q=ṁ·Cp·(T21−T_cw,in)，控制器 u=Kp·e+Ki∫e dt。无物理上不可能的环节；机理链首环（未测扰动→阀）如实标注 DATA_LINK_MISSING/inferred，未见断裂伪装为已证。
2. **量纲与时间尺度**：900s（5×180s）的阀-温度铅滞落在反应器冷却回路分钟级热惯性带内，与本体 "分钟级(回路响应)" 预测一致；+1.223σ 均值漂移 + ×6.33 方差膨胀的"方差泄漏"签名是 PI 闭环对抗有界随机扰动的预期形态。
3. **T21 量级否证的自洽性**：dT21/dṁ=−(T21−T_cw,in)/ṁ。工业冷却水供水温度远低于实测出口 94.6°C，8.8% 相对流量摆动必然在 T21 留下 ≥ 量级 0.1–1K 的可检波动，实测仅 σ=0.146°C 且 vr=1.027——否证方向正确。该论证依赖未测 T_cw,in 与线性阀特性，诊断已按 derived/阶次论证标注并将 H4 保留于竞争集——诚实性合格（I2）。
4. **谱形态物理**：卡涩/死区/位置器失稳的经典指纹是窄带极限环；实测异常段宽带（flatness≈0.07，单频功率<7%）与该预测相反——用于弱排除（而非 ≥90 硬排除）符合"排除必须可执行、不足即降级"的红线。
5. **空间排他性**：若扰动源在进料/冷凝/循环侧，其本地通道必先现同量级方差签名——实测该三块 13 通道 vr 0.79–1.38 全处基线带，排他逻辑成立。
6. **因果方向不对称**：反应器→分离器正向传播已验证（0.4539@lag2）且下游执行量安静；汽提→反应器方向无过判据领先相关——"反应器侧为上游"的物理读法成立，H5 主因排除合理，次级签名溯源诚实悬置。

## 5. 矛盾扫描

- 诊断文内部：无自相矛盾；confidence.json 调整链（86→65→62；46→30）与 diagnosis.json/reasoning_chain.json 三处口径一致。
- 诊断 vs 上游工件：抽查的全部引用数字（≥30 项）无一处超出工件原文；发现的偏差均为二次表述精度（P1–P4），底层工件自身正确。
- 诊断 vs 本体：CONTRADICTED/consistent 标记使用方向正确；discrepancy_signal 引用忠实。
- 诊断 vs 数据：见 §3，无矛盾。
- 未发现被忽略的矛盾证据：闭环反馈污染、汽提环溯源缺口、非 VLM 环境三项主要反证均已在 contradicting_evidence / reasoning_weaknesses 显式登记。

## 6. MINOR 发现与对 Step 6（Reporter）的强制措辞 guardrail

- **P1 [MINOR]** lag 窗口表述："窗口-8..-2 一致|r|>0.39" → 报告必须写 "**lead 3–8 步 \|r\|>0.39（峰值 lead5），lead2 步回落至 0.10；工件标记 consistent=true（5/6）**"，或直接引用 validate_report.lag_window_consistency 字段。
- **P2 [MINOR]** 进料排除表述："进料通道对 XMEAS_9 无领先相关(\|r\|<0.13)" → 报告必须写 "**无进料通道达到 \|r\|≥0.3 判据（最大 \|r\|=0.149，XMEAS_26@lag-9，p=3.9e-6，无方差签名 vr=0.79）**"。不得复述 "<0.13"。
- **P3 [MINOR]** 越限幅度表述："5σ越限" → 报告必须写 "**3σ 越限的 5 个孤立单点（全序列σ，max_deviation_sigma 3.10–3.73，pct=0.521%）**"。
- **P4 [MINOR]** XMV_9 时序计数："1/5 PRECURSOR、其余 4 次 CONCURRENT" → 写 "**1/5 PRECURSOR(idx410)、3 次 CONCURRENT、1 个区间未达列入阈值(idx256)**"。
- **P5 [MINOR]** XMV_10 均值漂移：报告保留 "+1.223σ（Welch p=3.2e-07，相对方差膨胀 ×6.3 为小幅显著漂移）"，不得写"均值完全不变"。
- 上述 5 项均为文字精度修正，**不需要回炉 Step 4**；若管线选择执行文字级修复，仅需对 diagnosis.json/evidence.json/reasoning_chain.json 对应字段做上述替换。

## 7. INFO 观察备案

- **I1** 谱 flatness 存在估计器间差异（periodogram 0.075 vs 工件 0.068）；定性"宽带"结论在两种估计器下均稳健。
- **I2** H4 的 T21 量级否证隐含 (T21−T_cw,in) 为常规量级的假设；因 T_cw,in 无测点，该否证保持"间接/阶次"定位是正确且必要的。
- **I3** time_lag_analysis.json 元数据 significant_lags_found=7 中第 7 对（XMEAS_22~XMEAS_9, 0.345@lag1）登记于 validate_report.target_analysis 而非 cooling_loop 14 对清单——跨文件计数口径问题，无结论依赖。
- physics_check effect_size（如 5.481@idx256）的 before 窗口定义未在工件中写明，mean_during=49.113 已逐位验证、方向与量级复核一致；建议后续 run 在工件中登记窗口定义。

## 8. 最终裁定

物理机理链完整、可量化复现、无一处证据链断裂；诚实性处理（COMPETING_SET + 封顶 65 + WEAK_EXCLUSION）符合协议；5 项 MINOR 全部为报告措辞精度问题并已给出 guardrail。

**PREFLIGHT_VERDICT: PREFLIGHT_PASS**
（FATAL=0，MAJOR=0，MINOR=5；Step 6 Reporter 放行，须遵守 §6 五条措辞 guardrail。）
