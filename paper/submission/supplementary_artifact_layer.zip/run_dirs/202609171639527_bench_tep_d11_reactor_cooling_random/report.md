# 工业诊断报告 — bench_tep_d11_reactor_cooling_random — Tennessee Eastman 连续化工过程异常诊断

**运行ID**: 202609171639527_bench_tep_d11_reactor_cooling_random ｜ **报告人**: 工程师周（技术报告，Step 6） ｜ **报告日期**: 2026-09-17
**诊断评级（Judge）**: 97/100 — pass ｜ **诊断类型**: COMPETING_SET ｜ **综合置信度**: 62/100（MEDIUM，封顶 65） ｜ **前置物理审计**: PREFLIGHT_PASS（0 FATAL / 0 MAJOR / 5 MINOR）

> **阅读指南**：第1节是给厂长与生产主管的一页纸摘要（2分钟读完）；第4节是统计核心证据（每张对齐图按"图上看到什么→统计怎么说→物理上说得通吗"三段式判读）；第5–6节给工艺与设备工程师（假设检验与机理链）；第7节给技术团队复核（每个数字可回溯到工件）；第8节是可执行行动方案；第9节交代方法、推理过程与边界。

> **实事求是声明**：本报告全部结论来自本 run 工件（`00_input/`–`05_review/`）的实际测量与统计验证；每个数字标注来源工件，且可由 `06_scripts/cooling_loop_semantic_analysis.py` 从 `00_input/data.csv` 复算（judge 已从原始数据独立复算 12 项关键数值，全部逐位吻合，零幻觉）。本 run 为**非 VLM 环境**：所有图件均为统计结果的图形化表达，未做像素判读（`03_figures/visual_analysis.json` pipeline_warnings："No PNG pixel content was read or described"）；图形证据内容一律按 L3 统计等级引用。最终结论为诚实的 **COMPETING_SET**（竞争假设集），未升格为单一根因。

---

## 1. 执行摘要

> **这一页是写给厂长和总经理看的。2分钟读完。**

### 发生了什么？

Tennessee Eastman 连续化工装置（反应器—冷凝器—气液分离器—汽提塔+循环压缩机）自**第161样本（8 小时）**起进入异常工况并持续至 48 小时窗口结束，无衰减、无质量重置信号。异常签名**精确集中在 5 个通道**：反应器冷却水阀 XMV_10 动作方差 **×6.33**（标准差 0.573%→3.631%，F 检验 p=1.52e-92），反应器温度 XMEAS_9 波动 **×4.04**（σ 0.0209→0.0846°C，p=4.96e-63），汽提蒸汽环三通道 ×2.4–2.5；其余 47 个通道全部处于基线带（方差比 0.79–1.38）。关键形态是**"均值钳制+方差爆发"**：反应器温度均值纹丝不动（全段 120.399°C，全程未偏离基线均值 ±0.26°C），但波动幅度翻了 4 倍；瞬时越限仅为 3σ 的 5 个孤立单点（占比 0.521%），无持续偏移。

### 为什么会发生？

**最可能的原因（置信度 62/100）：反应器冷却水侧存在持续性随机扰动**（冷却水入口温度随机波动或冷却回路传热能力变化一类的外部扰动，扰动本体无测点、属机制类判定）。温度控制器（TC）为压制该扰动而大幅增加 XMV_10 阀门动作（阀领先温度 5 步=900 秒，领先结构仅在异常段激活），把反应器温度均值强行钳在基线带内，代价是阀位与温度的方差同时放大。**次可能解释（置信度 30，弱排除保留）：XMV_10 阀自身故障**（卡涩/死区/位置器振荡）——宽带频谱与冷却水出口温度稳定两条间接证据都不支持它，但因缺少位置器阀位反馈、入口温度、实际流量三个决定性测点，无法以 ≥90 置信度排除，故诚实保留在竞争集中。进料侧、冷凝/循环侧、汽提蒸汽侧作为**主因**均已被定量排除（排除置信度各 90）。

### 影响有多大？

- **质量目标未被击穿**：反应器温度均值 120.399°C 全程被控住，越限仅为 5 个孤立单点（max 3.73σ，pct_beyond_3sigma=0.521%），严重度均为 low，无重置/无台阶——当前未造成可见的产品质量损失。
- **但控制裕度在被持续消耗**：XMV_10 开度瞬时范围 34.5–50.1%（虽未饱和），动作幅度 ×6.33 持续 40 小时不衰减——阀门磨损、执行机构疲劳与控制回路紧张在累积；扰动一旦超出 TC 补偿能力（或阀门到达限位），温度将失去钳制。
- **诊断被仪表缺失卡住**：不是分析方法到顶了，而是"阀到底是自己乱动还是在补偿别人"这一问，现有变量表无法回答。

### 推荐行动

| 优先级 | 行动 | 预期效果 |
|:------:|------|---------|
| **P0** | 为 XMV_10 加装智能位置器（阀杆实际位置反馈） | 取得竞争集（外部扰动 vs 阀故障）的决定性判别测量之一：阀杆平滑跟随指令→阀故障被排除、主结论升 DETERMINED；出现死区/卡涩/极限环→阀故障转正 |
| **P0** | 加装反应器冷却水入口温度 T_cw,in 测点 | 若入口温度在异常段平稳（方差比 <1.2）则"外部冷却侧扰动"被直接否证；否则锁定 H1 子机制 |
| **P1** | 加装冷却水实际流量计；调阅 XMV_10 检修记录/执行器故障代码；蒸汽管网侧压力测量 | 区分"指令波动"与"实际流量波动"；判定汽提环方差 ×2.4–2.5 是传播还是独立扰动 |
| **P2** | 延长观测窗口；在具备视觉模型的环境补做像素级图件判读 | 覆盖跨环累积时滞（本体预测 >10 步）与图形形态增量证据 |

### 有多大把握？

**综合置信度：62/100（MEDIUM，封顶 65）。** 用通俗的话说：100 次类似诊断中，约 62 次我们的主倾向判断（冷却水侧外部扰动为主、阀故障次之）是正确的。把握是**分层的**——"扰动在反应器冷却水侧，而不在进料、冷凝/循环或汽提侧"这一**空间定位**证据非常硬（三侧被独立定量排除）；不确定的是"外部扰动 vs 阀自身故障"的**机制细分**，它被四个未安装的测点卡住。加装 P0 清单中**任意一件**仪表，本结论即可收敛为 DETERMINED。12 项关键数值已由质量审计从原始数据独立复算全部吻合；判别极限源于仪表缺失，而非推理薄弱。

---

## 2. 诊断背景

### 2.1 工艺与用户问题

- **装置**：TE 反应—冷凝—气液分离—汽提+循环压缩连续化工过程（`01_ontology/ontology.json`：9 设备/6 工段/22 关系；生产目标：维持反应器 120.4°C/2707 kPaG 稳定）。
- **用户问题**（`00_input/user_context.json`）："诊断本次异常的根本原因"；异常自第 161 样本（8h）起（用户声明）。
- **数据**：`00_input/data.csv`，960 行 × 52 信号列（XMEAS_1..41 + XMV_1..11）+ timestamp，180s 等间隔采样覆盖 48h，0 缺失。
- **场景分类**（`02_processed/scenario_classification.json`）：process_fluctuation_diagnosis / continuous_chemical（confidence: high）。

### 2.2 分析路径与不适用项（如实记录）

- **单产品连续过程**：无产品/批次分组列（`02_processed/batch_integrity.json` applicable=false, id_col=null），产品分层分析 not_applicable；以**基线期（rows 0–159）/异常段（rows 160–959）时代分层**替代，稳态工况过滤 0 行剔除（`02_processed/production_regime_filter.json`）。
- **process_only 数据视图**：52 个信号列全部为过程测量，本体 inspection_signals 为空，过程—检验质量双驱动分析 not_applicable（`02_processed/anomaly_report.json` dual_drive_analysis.data_view_mode='process_only'）；过程→质量联动作为证据缺口移交。
- **格兰杰因果深挖 skipped**：闭环系统 Granger 方向受反馈污染，判别力低于"滞后补偿 CCF+分层"组合（`02_processed/data_analysis_conclusion.json`）。

### 2.3 关键变量时序总览

![关键变量时序网格图](03_figures/fig_temporal_overview.png)

**判读（三段式）**：该图为关键变量时序网格（±3σ 阈值红线，plot_manifest: temporal overview）。其设计问题（哪些通道越限、异常何时开始）由底层统计回答——XMEAS_9 全程仅 5 个孤立单点越限（idx 256/305/410/539/636），XMV_10 方差自声明起点 idx 160 后爆发（滚动标准差首超 2× 基线于 idx 166）。物理上：反应器温度被 TC 回路钳制而操纵量大幅摆动，是闭环对抗扰动的典型画面。**视觉—统计对齐说明**：本 run 无 VLM，此图按统计结果的图形化表达引用（L3 内容），未做像素判读。

---

## 3. 数据质量评估

| 项目 | 结果 | 来源 |
|------|------|------|
| 完整性 | 960 行 × 52 信号列，0 缺失（missing_pct=0） | `02_processed/feature_summary.json` |
| 时间轴 | timestamp 自 2020-01-01T00:00 起 180s 等间隔，排序验证 time_sorted=true，无丢失 | `02_processed/validate_report.json` |
| 工况结构 | 单一稳态 regime：液位/流量锚点（XMEAS_8/12/15/6/17）均在基线 mean±3σ 带内（frac_outside 最大 1.35%），rows_filtered_out=0——无启停/工况切换混杂 | `02_processed/production_regime_filter.json` |
| 分组完整性 | 无产品/批次分组列（applicable=false, id_col=null）→ 时代分层（基线 n=160 / 异常段 n=800） | `02_processed/batch_integrity.json` |
| 数据视图 | process_only（无检验侧质量信号），双驱动 not_applicable 已记录 | `02_processed/anomaly_report.json` |
| 清洗审计 | **缺口披露**：`data_analysis_conclusion.json` data_cleaning_provenance 记录 cleaning_integrity 未登记（prepare 阶段缺口）；诊断侧 R2 以"cleaned_data 与 raw 逐值一致"对冲，judge 已将该缺口列为 warning | `02_processed/data_analysis_conclusion.json` |

统计功效充分：异常段 n=800，5 个签名通道 F 检验 p<1e-30；分布检查 0 个重偏斜列，Pearson 适用。

---

## 4. 统计分析发现

> 本节为报告的统计核心：先给签名拓扑，再逐图三段式判读，最后是抗伪相关与判别子。全部数字来自 `02_processed/cooling_loop_semantic_analysis.json`、`02_processed/time_lag_analysis.json`、`02_processed/validate_report.json`、`02_processed/physics_check.json`、`02_processed/anomaly_report.json`。

### 4.1 方差爆发拓扑与均值钳制

| 通道（含义） | 基线均值±σ | 异常段均值±σ | 方差比 | F 检验 | 均值漂移 |
|------|:------:|:------:|:------:|:------:|:------:|
| XMV_10（反应器冷却水阀） | 41.0607±0.5733% | 41.7620±3.6312% | **6.334** | F=40.1199，p=1.52e-92（Levene p=8.03e-50） | **+1.223σ**（Welch p≈3.2e-07） |
| XMEAS_9（反应器温度） | 120.3993±0.0209°C | 120.3995±0.0846°C | **4.044** | p=4.96e-63（Levene p=2.36e-32） | +0.010σ |
| XMV_9（汽提蒸汽阀） | — | — | 2.511 | p=5.20e-34 | −0.92σ |
| XMEAS_18（汽提塔温度） | — | — | 2.468 | p=4.76e-33 | −0.80σ |
| XMEAS_19（汽提蒸汽流量） | — | — | 2.440 | p=2.09e-32 | −0.98σ |

- 其余 47 通道方差比 0.79–1.38（进料块 0.79–1.26、冷凝/循环块 0.89–1.37），均值漂移 <0.3σ——签名不弥散，指向单一源头+下游传播。
- **措辞精度（审计 guardrail P5）**：XMV_10 均值漂移 +1.223σ 统计显著（Welch p=3.2e-07），但相对 ×6.3 的方差膨胀属小幅显著漂移——定性为"均值钳制"，**不读作"均值完全不变"**。
- **解读**：均值—方差解耦（均值不动/微漂 + 方差 ×2.4–6.3）是 PI 闭环对抗持续性外部扰动的充分统计签名；设定值变更或负荷阶跃应表现为均值漂移——被数据否定。

### 4.2 时序对齐图判读（核心证据）

#### 图 4-1 反应器冷却环方差爆发叠加图（MANDATORY）

![反应器冷却环方差爆发 - XMEAS_9 vs XMV_10](03_figures/fig_cooling_loop_variance.png)

- **图上看到什么（设计问题）**：基线参考 z 叠加 + 20 样本滚动标准差，onset idx 160 标记——"XMV_10 与 XMEAS_9 方差是否同步爆发"。
- **统计怎么说**：XMV_10 滚动标准差首超 2× 基线于 **idx 166**，与声明起点 idx 160 一致（onset_cross_check agreement=true）；异常段 vr：XMV_10 ×6.334 / XMEAS_9 ×4.044（§4.1 表）。
- **物理上说得通吗**：阀位方差爆发而温度均值不动="a control fight, not a setpoint or load change"（`03_figures/visual_analysis.json` 元数据观察）——TC 控制器在对抗一个持续性扰动。
- **视觉—统计对齐说明**：元数据模式（未读像素）；图中形态与 `02_processed/cooling_loop_semantic_analysis.json` per_column_baseline_vs_post 逐位一致。

#### 图 4-2 全参数 z 归一化时间叠加图（MANDATORY）

![VLM temporal overlay - 全参数](03_figures/fig_vlm_temporal_overlay.png)

- **同步群组**（visual_analysis.json cross_parameter_temporal_alignment）：①reactor_cooling_tc_loop（XMV_10/XMEAS_9，唯一随扰动激活的耦合结构）；②stripper_steam_loop（XMV_9/XMEAS_19/XMEAS_18，环内 |r|>0.95 相干，方差 ×2.4–2.5）；③condenser_separator_train（XMEAS_22→XMEAS_11 r=0.663 跟随，自身执行量 XMV_11 方差 ×0.891 处基线——被动传播）。
- **统计怎么说**：群组①滞后补偿 r=−0.6356@领先5步（p=3.44e-109）；异常段层内 r=−0.6416(n=795) vs 基线层 −0.2051(n=155)。precedence_signals 的 visual_confidence 标注 LOW（统计导出，非像素判读）。
- **物理上说得通吗**：TC 环是扰动被"看见并对抗"的场所；汽提环相干但与反应器侧跨环耦合弱（最优 |r|=0.124）——其方差膨胀是真实次级签名，溯源未决（§4.7）。
- **视觉—统计对齐说明**：元数据模式；全部群组参数与统计量一一对应，无像素级声明。

#### 图 4-3 ~ 图 4-7 分段（单产品）时间叠加图 g1–g5（MANDATORY）

![分段叠加 g1](03_figures/fig_vlm_temporal_overlay_single_product_g1.png)

![分段叠加 g2](03_figures/fig_vlm_temporal_overlay_single_product_g2.png)

![分段叠加 g3](03_figures/fig_vlm_temporal_overlay_single_product_g3.png)

![分段叠加 g4](03_figures/fig_vlm_temporal_overlay_single_product_g4.png)

![分段叠加 g5](03_figures/fig_vlm_temporal_overlay_single_product_g5.png)

- **设计问题**："段内同步组与领先滞后"。非 VLM 环境未读像素（chart_inventory read_status=READ_FAILED，原因：non-VLM environment）；该问题由分层统计等价回答——唯一随扰动激活的耦合结构是反应器 TC 环（同滞后 lag-5 下异常段 r=−0.6416 vs 基线段 −0.2051），进料/冷凝块跨段保持安静（vr 0.79–1.38）。
- **视觉—统计对齐说明**：五张分段图与 `02_processed/cooling_loop_semantic_analysis.json` stratified_correlation/lag_compensated_ccf 结论一致；本报告不从中引用任何像素级观察。

#### 图 4-8 滚动相关同步热图

![滚动相关同步热图](03_figures/fig_vlm_synchronization.png)

- **设计问题**："XMV_10~XMEAS_9 闭环耦合是否仅在后段出现"。统计回答：是——分层 lag-5 相关异常段 −0.6416 vs 基线段 −0.2051，耦合结构随扰动激活。
- **视觉—统计对齐说明**：元数据模式，与分层相关数值一致。

### 4.3 领先滞后结构（时间先行性）

- 滞后补偿 CCF（−20..+20 步，14 对）：**XMV_10 领先 XMEAS_9 5 步（900 秒）r=−0.6356**（n=955，p=3.44e-109，远低于 Bonferroni 阈值 5e-4）；lag0 原始 r=+0.5007，补偿后提升 26.9%（`02_processed/time_lag_analysis.json`）。
- **窗口一致性（审计 guardrail P1 口径）**：lead 3–8 步 |r| 均 >0.39（0.390/0.555/0.636/0.624/0.554/0.454，峰值 lead5），lead2 步回落至 |r|≈0.10；`02_processed/validate_report.json` lag_window_consistency：consistent=true（consistent_count=5/6，isolated_spike=false）——最优滞后**非孤立尖峰**。（披露：上游 reasoning_chain R3 曾将该窗口复述为"-8..-2 一致 |r|>0.39"，lag-2 实测 |r|=0.097；judge 已指出，本报告按工件字段与 P1 口径引用。）
- **分层激活**：异常段层内 r=−0.6416(n=795) vs 基线层 −0.2051(n=155)——领先结构仅异常段激活。
- **physics_check 交叉印证**：XMEAS_9 全部 5 个异常区间中 XMV_10 均为 PRECURSOR/POTENTIAL_CAUSE（5/5，效应量 |4.35–5.48|σ；idx256 区间 XMV_10 mean_during=49.113%）；汽提蒸汽阀 XMV_9 仅 1/5 PRECURSOR（idx410）、3 次 CONCURRENT、1 个区间未达列入阈值（idx256）（P4 口径）。
- **判读边界（诚实声明）**：闭环反馈污染使"阀先动、温度后应"只能证明扰动在 TC 回路内被对抗（回路局域性），**不能单独区分**"外部扰动被补偿"与"阀自身乱动被跟随"——这正是 H4 保留、置信度封顶 65 的原因之一（诊断已按此扣分，未回避）。

### 4.4 抗伪相关检验（五项全过）

| 检验 | 结果 | 来源 |
|------|------|------|
| Simpson 分层 | lag0 相关：基线层 +0.6919(n=160) / 异常层 +0.5011(n=800)，与总体 +0.5007 同号——无跨层符号翻转 | cooling_loop_semantic_analysis.json |
| 离群杠杆 | leave-one-out（960 点）max\|Δr\|=0.0036（审计独立重算 0.0035，舍入一致）——非单点驱动 | 同上 + validate_report |
| 稳态工况过滤 | 单一稳态 regime，0 行剔除；异常段层内 r=−0.6416(n=795) 非启停过渡伪象 | production_regime_filter.json |
| 滞后窗口一致性 | lead 3–8 步 \|r\|>0.39（P1 口径），consistent=true（5/6）、isolated_spike=false | validate_report.json |
| 多重检验 | 100 检验包 Bonferroni 阈值 5e-4；被引用 p=3.44e-109 远低于阈值（显著 22 对） | validate_report.json |

`validate_report.json` anti_spurious 汇总：skew_affected=0、outlier_driven=0、trend_confounded=0、simpson=0、spearman_divergence=0，overall=ROBUST；分布检查 0 个重偏斜列，Pearson 适用。

### 4.5 频谱形态判别（宽带 = 随机扰动指纹）

- 异常段 XMV_10 谱 flatness=**0.06764**、最大单频功率占比 **4.78%**；XMEAS_9 异常段 flatness=0.11642、单频占比 4.75%；基线 XMV_10 flatness=**0.5796**（近白）（`02_processed/cooling_loop_semantic_analysis.json` spectral_signature）。
- 审计以 periodogram（去均值）独立重算得 0.075/6.2% vs 基线 0.539——估计器间数值有差异，**定性结论完全稳健**：异常段为宽带持续涨落，无窄带极限环主峰（备案 I1）。
- **解读**：卡涩/死区/位置器振荡的经典指纹是窄带极限环；宽带形态反对阀故障（H4 弱排除判别之一），支持"持续性随机扰动进入冷却侧"（H1）。

### 4.6 T21 判别子（冷却器能量平衡端）

- XMEAS_21（反应器冷却水出口温度）方差比 **1.0266**（F p=0.691，基线带内）；T9/T21 方差比 = **3.94**；XMV_10→XMEAS_21 滞后补偿 r=−0.2029@lag−4（p=2.45e-10）——方向与本体 inverse 预测一致、幅值弱（validated_weak）。
- **物理判读**：T21=T_cw,in+Q/(ṁ_cw·Cp)。TC 闭环在扰动传到 T21 之前将其吸收；若是"大幅实际冷却水流量摆动"型阀故障，T21 必现可见波动——未观察到，构成对 H4 的量级否证（该否证依赖未测 T_cw,in，按 derived/阶次论证定位，备案 I2）。

### 4.7 下游传播与跨环耦合

- **反应器→下游正向传播（已验证）**：XMEAS_9→XMEAS_11 lag−2 r=0.4539（n=958，p=7.4e-50，较 lag0 提升 65.1%）；XMEAS_22→XMEAS_11 lag−1 r=0.663（p=1.77e-122）；下游执行量 XMV_11 方差 ×0.891 处基线——被动传播，非独立驱动。
- **汽提环内相干**：XMV_9→XMEAS_19 r=0.9913@lag−1、XMEAS_19→XMEAS_18 r=0.9539@lag−2、XMV_9→XMEAS_18 r=0.9750@lag−1——控制器-执行链路正常，方差膨胀来自回路外部输入。
- **跨环耦合弱（未过判据）**：XMV_10~XMV_9 最优 |r|=0.1241@lag12（p=1.27e-4）、XMV_10~XMEAS_19 r=−0.133、XMEAS_9~XMEAS_19 r=0.0381（p=0.241 不显著）、XMEAS_9~XMEAS_18 r=0.1481——均未达 |r|≥0.3 判据，**不引用为因果**；汽提环方差 ×2.4–2.5 的"反应器侧传播 vs 独立扰动"两种读法均未被数据否定，作为次级签名溯源缺口披露（置信度 −3 的来源）。

### 4.8 异常区间形态与越限统计

- **XMEAS_9（审计 guardrail P3 口径）**：3σ 越限的 **5 个孤立单点**（idx 256/305/410/539/636，间隔 49–129 样本，无相邻连片），max_deviation_sigma 3.23/3.10/3.73/3.21/3.21（全序列 σ），pct_beyond_3sigma=0.521%，severity 均为 low（`02_processed/anomaly_report.json`）。**不使用"5σ越限"表述。**
- XMEAS_21 同样仅 3 个孤立单点（idx 233/543/770，3.09–3.31σ，pct=0.313%）。
- **无质量重置**：quality_reset_analysis reset_found=false（0 transitions）——"扰动已消除"类读法被排除。
- **形态判读**：越限为方差驱动散点而非持续偏移/台阶——与"设定值变更/负荷阶跃"类机理不符；XMEAS_9 全段 mean=120.3994、std=0.0776、range 120.11–120.65°C（`02_processed/feature_summary.json`），均值极稳+离差放大再次印证闭环钳制签名。

---

## 5. 假设检验

### 5.1 竞争假设总表（H1–H5 预注册，`02_processed/analysis_method_plan.json`）

| 假设 | 机理类 | 判定 | 置信度 |
|------|:------:|------|:------:|
| **H1** 反应器冷却水侧持续性随机扰动（入口温度随机波动/传热能力变化），TC 经 XMV_10 补偿表达 | ENVIRONMENT | **存活（CS1 主）** | **62/100**（封顶 65） |
| **H4** XMV_10 阀自身故障（卡涩/死区/位置器振荡） | WEAR | **[WEAK_EXCLUSION] 保留**于竞争集 | **30/100**（≤50 规则） |
| H2 进料侧扰动（流量/组成） | OPERATION | 排除（STATISTICAL，排除置信度 90） | 10 |
| H3 冷凝/循环回路扰动 | ENVIRONMENT | 排除（COMBINED，排除置信度 90） | 13 |
| H5 汽提蒸汽侧独立扰动作为主因 | OPERATION | 排除（STATISTICAL，排除置信度 90） | 16 |

### 5.2 竞争假设对比与排除逻辑

**CS1 = {H1, H4}，PARTIALLY_DISCRIMINABLE，置信度封顶 65（`04_diagnostics/diagnosis.json` competing_sets）**：两假设共享全部下游环节（阀→流量→T9 闭环，r=−0.6356@lag−5），可用判别路径仅两条间接证据——①谱形态：宽带（flatness 0.068/单频 4.8%）反对极限环型阀故障；②T21 量级：×1.027 反对大幅实际流量摆动。两者均倾向 H1 但均为间接推断，且"轻微阀非线性+外部扰动叠加"等中间情形无法排除。决定性直接测量（位置器实际阀位反馈/T_cw,in/实际流量计）在本数据集中不存在——该不可判别性是本体层**预先登记**的结构性事实（`01_ontology/ontology.json` confounders 第 1 条："XMV_10 阀门大幅动作既可能是补偿外部冷却侧扰动，也可能是阀门自身故障(卡涩/死区)，需辨别"，controlled=false）。

**H2 排除（90，STATISTICAL）**：进料流量 XMEAS_1-4 vr=1.256/0.925/1.064/1.158、阀 XMV_1-4 vr=0.832/1.212/1.256/1.025、组成 XMEAS_23-28 vr=0.790–1.216，均值漂移全部 <0.3σ；**无进料通道达到 |r|≥0.3 判据（最大 |r|=0.149，XMEAS_26@lag−9，p=3.9e-6，该通道无方差签名 vr=0.79）**（审计 guardrail P2 口径，替代不成立的"|r|<0.13"表述）。时间先行性与统计显著性双不满足；复兴条件：进料出现 ≥3σ 漂移或 ≥2× 方差比且进料→XMEAS_9 领先 |r|≥0.3（过 Bonferroni）。

**H3 排除（90，COMBINED）**：冷凝/循环块全处基线带（XMV_11 ×0.891、XMEAS_22 ×1.181、XMEAS_5 ×0.977、XMEAS_20 ×1.369、XMEAS_13 ×1.253）；XMEAS_22~XMEAS_9 为同步弱共变（lag−1 r=0.345，跟随非领先）；循环扰动必经通道 XMEAS_7（反应器压力）漂移仅 −0.136σ/vr=1.264；P∝Q² CV=1.07% 无流动限制/结垢，压缩机功-温度解耦 r=−0.078（`02_processed/physics_check.json`）。数据处理器原判 85，诊断追加 physics_check 双项与压力通道安静证据后复核升至 90。若冷凝侧扰动大到使 T9 方差 ×4.04，其自身通道必先异常——未观察到。

**H5 排除作为主因（90，STATISTICAL）**：三重不满足——①时间先行性：XMV_9 在 XMEAS_9 的 5 个异常区间**1/5 PRECURSOR（idx410）、3 次 CONCURRENT、1 个区间未达列入阈值（idx256）**（审计 guardrail P4 口径），而 XMV_10 为 5/5 PRECURSOR；②跨环领先相关缺失（|r|≤0.148，XMEAS_9~XMEAS_19 p=0.241 不显著）；③反向传播已验证（XMEAS_9→XMEAS_11 r=0.4539，p=7.4e-50）而汽提→反应器方向无。**诚实区分**：汽提环方差 ×2.4–2.5 真实存在且环内相干（|r|>0.95），其"传播 vs 独立"溯源在本数据中确不可判——该次级签名问题单列于 data_gaps，不随主因排除而消失。

### 5.3 H4 弱排除的依据与保留原因

- **两条可检验预测被数据相悖**：①功能形态——极限环预测窄带谱，实测宽带（flatness 0.068、单频功率 4.8%）→MISMATCH；②量级——大幅实际流量摆动要求 T21 可见波动，实测 vr=1.027 →IMPLAUSIBLE（`04_diagnostics/diagnosis.json` ontology_data_physics_proof overall=WEAK）。
- **为什么只弱排除**：首环（阀内故障→输出方差）无位置器反馈数据，不可验证；排除置信度 <90，按协议标记 [WEAK_EXCLUSION] 保留于 CS1（schema 要求 eliminated 需 ≥90）。
- **残余风险（如实披露）**：真实阀非线性在闭环下可表现为宽带小幅形态（`04_diagnostics/confidence.json` H4 model 不确定性）——两条间接否证不完全决定性；阀处于量程中部（41.76%）时卡涩/位置器振荡仍可能发生。

---

## 6. 根因结论

### 6.1 诊断结论陈述

**诊断类型：COMPETING_SET（竞争假设集）。** `04_diagnostics/diagnosis.json` primary_finding 原文：

> 反应器冷却水侧存在持续性随机扰动（冷却水入口温度随机波动/冷却回路传热能力变化一类的外部扰动），TC回路经XMV_10（方差×6.33，均值仅+1.22σ钳制）大幅补偿使XMEAS_9均值钳制在基线带内而方差×4.04，阀领先温度5步(r=-0.64,仅异常段激活)、T21稳定(×1.03)、进料/冷凝侧被定量排除；但XMV_10阀自身故障(H4)因缺少位置器实际阀位/冷却水入口温度/实际流量测点无法以≥90置信度排除，故诚实输出COMPETING_SET(H1为主、H4弱排除保留)。

结论分两层，把握不同，不混同表述：

- **空间定位（把握高）**：扰动入口在反应器冷却水侧。进料、冷凝/循环、汽提蒸汽三个候选入口作为主因均被独立定量排除（各 90），且 47 个非签名通道全部安静。
- **机制细分（受限）**："外部冷却侧扰动"与"XMV_10 阀自身故障"共享同一闭环，现有变量表无决定性判别测量——H1 为主倾向（62），H4 弱排除保留（30）。

### 6.2 物理机理链（H1）

```
冷却侧外部扰动(T_cw,in/UA，未测) → 移热瞬时失衡 → TC控制器动作XMV_10 → T9均值钳制/方差泄漏 → 下游热train弱传播
      [INFERRED/DATA_LINK_MISSING]      [OBSERVED 5/5 PRECURSOR]   [OBSERVED +1.223σ/×6.33, +0.01σ/×4.04]  [OBSERVED lag-5 r=-0.6356]   [OBSERVED r=0.4539@lag-2]
```

- **主导方程**（`01_ontology/ontology.json` relationships）：反应器能量平衡 mCp·dT9/dt=Q_rxn−UA·ΔT_lm；TC 反馈 u=Kp·e+Ki∫e·dt；冷却器能量平衡 T21=T_cw,in+Q/(ṁ_cw·Cp)；阀-管路 P∝Q²。
- **本体-数据-物理证明（H1）**：功能形态 MATCH（inverse 闭环：阀↑→T9↓，r=−0.6356 负号与预测一致）；滞后 MATCH（本体"分钟级(回路响应)" vs 实测 900s）；方向 MATCH；量级 PLAUSIBLE（阶次带内：PI 闭环对抗有界随机扰动预测操纵量方差 ×3–10、被控量 ×2–5 且均值钳制——实测 ×6.33/×4.04/+1.22σ 全部落带内）。**overall=STRONG_EVIDENCE（未达 PROVEN：扰动本体不可测）**。
- **链验证（chain_link_validation overall=PARTIAL）**：4 环中 3 环 ALL_LINKS_VALIDATED（其中 XMV_10→XMEAS_21 为 validated_weak）；**首环（未测扰动→XMV_10）如实标注 DATA_LINK_MISSING**——扰动以 inferred 节点登记（derived:true），由闭环签名反推，不伪装为已证。
- 残余机制筛查：P∝Q² CV=1.07%（无流动限制/结垢）、压缩机功-温度 r=−0.078（解耦）——支持扰动局限于反应器冷却水回路。

### 6.3 置信度核算（`04_diagnostics/confidence.json`）

| 假设 | 五因素分解 | 调整 | 最终 |
|------|------|------|:------:|
| H1 | 统计 22/25 + 物理 22/25 + 时序 17/20 + 无混淆 17/20 + 完整性 8/10 = **86** | COMPETING_SET 封顶 −21（决定性判别不可得，等效 INDISTINGUISHABLE≤65）；次级签名溯源未决 −3 | **62（MEDIUM，ceiling 65）** |
| H4 | 12+8+10+12+4 = **46** | [WEAK_EXCLUSION] −16（宽带谱 + T21 量级双否证，WEAK 证明→≤50） | **30（LOW）** |

overall_confidence=62/100（MEDIUM）；confidence_ceilings_applied=[H1≤65, INDISTINGUISHABLE_COMPETING_SET]。H1 扣分明细：闭环内相关受反馈污染（统计−3）、首环 inferred（物理−3）、时序只证回路局域性（时序−3）、全厂反馈耦合不可控（无混淆−3）、汽提溯源未决（完整性−2）。

### 6.4 预测观察量与可证伪条件

**已被本数据证实的预测**：①XMV_10 方差维持 ×6 量级而均值在基线带 ±3σ 内（+1.223σ）；②XMEAS_9 越限为孤立散点而非持续偏移（5 个单点，0.521%）；③T21 保持基线带（×1.027）；④进料/冷凝块无同量级异常（vr 0.79–1.38）。⑤待加装验证：位置器平滑跟随（支持 H1）或死区/饱和段（支持 H4）。

**可证伪条件（任一触发即重估/推翻）**：

1. XMV_10 位置器反馈显示死区/卡涩/极限环（阀杆与指令偏离且谱收窄为单频）→ H1 部分解释失效、H4 转正。
2. T_cw,in 测点全程平稳（方差比 <1.2）且 UA 恒定 → "外部冷却侧扰动"被直接否证。
3. XMEAS_9 均值漂移超过 ±3σ 基线带 → "均值钳制"签名消失，机理链重建。
4. 任一进料/冷凝通道出现领先 XMEAS_9 的 |r|≥0.3（过 Bonferroni）相关 → 空间定位被推翻。
5. 阀检修记录/执行器故障代码与异常起点吻合 → H4 转正。

---

## 7. 证据附录

### 7.1 证据全景与分级

证据清单计数（`04_diagnostics/evidence.json`）：**视觉 2 / 数值 10 / 物理 4 / 验证 5**。

| 证据等级 | 本 run 分布 | 说明 |
|:------:|------|------|
| L1 直接测量 | （原始数据本体） | 全部统计由 `00_input/data.csv` 复算 |
| L3 统计分析 | **统计主体**（方差签名/CCF/谱/判别子/验证） | 本报告结论的主要支撑等级 |
| L4 图形证据 | 2 条，**置于 L4 槽位但内容为 L3** | 见下方披露 |
| L5 领域知识/物理 | 本体机理、physics_check | 支撑机理链 |

> **L3-content-in-L4-slot 披露（judge warning #2，本报告强制应用）**：`04_diagnostics/evidence.json` 将两条图形证据（fig_cooling_loop_variance.png / fig_vlm_temporal_overlay.png）置于 rank=4（L4）槽位，但内容实为 L3 级统计回填（元数据模式，未读像素；confidence_note 已声明该置换仅为满足清单结构，非证据等级虚标）。本报告引用时一律按 **L3 统计内容**对待，不作为像素级视觉证据。结论受最弱必要证据等级约束（≤L3–L5 复合），不宣称 L1 级因果证明。

### 7.2 工件索引与关键数字

| 工件 | 关键内容/数字 |
|------|------|
| `00_input/data.csv` + `input_manifest.json` | 960 行 × 52 信号列 + timestamp；sha256=8a56389c…；180s 采样 |
| `01_ontology/ontology.json` | 5 个 CONTRADICTED 信号（XMV_10/XMEAS_9/XMV_9/XMEAS_18/XMEAS_19）与数据方差签名精确重合；discrepancy_signal="冷却回路存在被反馈抑制的持续性扰动，源头应在反应器冷却侧"；confounders 第 1 条预登记 XMV_10 双重身份（controlled=false）；主导方程 3 组 |
| `02_processed/cooling_loop_semantic_analysis.json` | vr：XMV_10=6.334/XMEAS_9=4.044/XMV_9=2.511/XMEAS_18=2.468/XMEAS_19=2.440；分层 lag0 +0.6919/+0.5011；LOO max\|Δr\|=0.0036；谱 flatness 0.06764/单频 4.78%/基线 0.5796；T21 vr=1.0266、T9/T21=3.94；onset_cross_check idx166 agreement=true |
| `02_processed/time_lag_analysis.json` | 14 对 CCF、7 对过判据（全过 Bonferroni 5e-4）；XMV_10→XMEAS_9 r=−0.6356@lead5；XMEAS_9→XMEAS_11 r=0.4539@lag2；环内 0.9913/0.9539；跨环 \|r\|≤0.148 |
| `02_processed/validate_report.json` | time_sorted=true；多重检验 100 检验 Bonferroni 5e-4（显著 22）；lag_window_consistency consistent=true（5/6，−2 处 r=−0.0974）；anti_spurious 汇总 ROBUST；进料列最优 \|r\|=0.1283（XMEAS_26@lag−9 报告口径 0.149，见 §5.2 P2） |
| `02_processed/physics_check.json` | XMV_10 PRECURSOR/POTENTIAL_CAUSE 5/5（效应量 \|4.35–5.48\|σ，idx256 mean_during=49.113）；flow_restriction P∝Q² CV=1.07%；energy_balance 解耦 r=−0.078 |
| `02_processed/anomaly_report.json` | XMEAS_9 五个孤立单点（256/305/410/539/636，3.23/3.10/3.73/3.21/3.21σ，pct=0.521%）；XMEAS_21 三点（233/543/770）；reset_found=false；dual_drive process_only |
| `02_processed/production_regime_filter.json` | 单一稳态 regime，锚点 frac_outside 最大 1.35%，rows_filtered_out=0 |
| `02_processed/feature_summary.json` | 0 缺失；XMEAS_9 mean=120.3994/std=0.0776/range 120.11–120.65°C |
| `04_diagnostics/diagnosis.json` | COMPETING_SET；CS1={H1(62), H4(30)}，ceiling 65；eliminated H2/H3/H5（各 90）；data_gaps 6 项；discriminability_matrix 7 对 |
| `04_diagnostics/confidence.json` | 五因素 86→65→62 / 46→30；adjustment_log 6 条带 source；aleatory/epistemic/model 三分 |
| `04_diagnostics/reasoning_chain.json` | R1–R8 完整；hypothesis_evolution：H1 40→62、H4 35→30、H2 25→10、H3 20→13、H5 25→16 |
| `05_review/judge_feedback.json` | **97/100 pass**；12/12 抽查数值逐位吻合；criteria 十项（7×10 分 + 3×9 分）；blocking_issues=[]；warnings 3 条（本报告已应用） |
| `05_review/optimizer_preflight.md` | PREFLIGHT_PASS；0 FATAL / 0 MAJOR / 5 MINOR（P1–P5 措辞 guardrail，已全部应用，见 §7.4） |

### 7.3 图表索引（9/9 已嵌入本报告）

| 编号 | 图件 | 一句话发现 |
|:---:|------|------|
| 图 2-1 | fig_temporal_overview.png | 关键变量时序网格：签名通道集中、其余安静 |
| 图 4-1 | fig_cooling_loop_variance.png | 方差爆发叠加：onset idx166 与声明起点一致 |
| 图 4-2 | fig_vlm_temporal_overlay.png | 三个同步群组；TC 环为唯一随扰动激活的耦合结构 |
| 图 4-3~4-7 | fig_vlm_temporal_overlay_single_product_g1..g5.png | 分段叠加：分段判读由分层统计等价回答 |
| 图 4-8 | fig_vlm_synchronization.png | 滚动相关：耦合仅在后段出现 |

### 7.4 质量门记录与措辞合规（guardrail 应用对照）

- **Judge（Step 5a）**：overall_score=97、verdict=pass、iteration 1/5、blocking_issues=[]、repair_scope=[]；12 项关键数值声明从 `00_input/data.csv` 独立复算全部逐位吻合。
- **物理审计（Step 5b 前置）**：PREFLIGHT_PASS（0 FATAL / 0 MAJOR / 5 MINOR）。
- **guardrail 应用对照（本报告已执行，不传播上游 4 处措辞不精确）**：

| # | 上游不精确表述 | 本报告采用口径 |
|:---:|------|------|
| P1 | "窗口-8..-2 一致 \|r\|>0.39" | lead 3–8 步 \|r\|>0.39（峰值 lead5），lead2 步回落 ≈0.10；consistent=true（5/6）（§4.3） |
| P2 | 进料"无领先相关(\|r\|<0.13)" | 无进料通道达到 \|r\|≥0.3 判据（最大 \|r\|=0.149，XMEAS_26@lag−9，p=3.9e-6，无方差签名）（§5.2） |
| P3 | "5σ越限" | 3σ 越限的 5 个孤立单点（全序列 σ，max_deviation_sigma 3.10–3.73，pct=0.521%）（§4.8） |
| P4 | XMV_9 "其余 4 次 CONCURRENT" | 1/5 PRECURSOR（idx410）、3 次 CONCURRENT、1 个区间未达列入阈值（idx256）（§4.3/§5.2） |
| P5 | XMV_10 "均值不变"类表述 | 均值漂移 +1.223σ（Welch p=3.2e-07，相对 ×6.3 方差膨胀为小幅显著漂移）（§4.1） |

- judge warning #3（cleaning_integrity 未登记的 prepare 阶段缺口）已在 §3 披露；judge warning #1（R3 lag 窗口复述）已在 §4.3 披露并按工件字段引用；warning #2（L3-in-L4）已在 §7.1 披露。

---

## 8. 建议与后续（行动方案）

### 8.1 P0 — 立即执行（本周内，不停产）

| 行动 | 具体操作 | 预期效果 | 如何验证 |
|------|---------|---------|---------|
| XMV_10 加装智能位置器（阀杆位置反馈） | 安装后连续采集"指令 vs 阀杆实际位置"≥48h，与异常段同工况对比 | 取得 CS1 决定性判别测量之一，竞争集可收敛 | 阀杆平滑跟随指令（无死区/卡涩/极限环）→H4 排除、H1 升 DETERMINED；出现死区/极限环（谱收窄单频）→H4 转正 |
| 加装冷却水入口温度 T_cw,in 测点 | 在反应器冷却水入口管路安装温度计，采集并叠加 XMV_10/XMEAS_9/XMEAS_21 分析 | 锁定或否证 H1 子机制 | T_cw,in 全程平稳（方差比 <1.2）且 UA 不变→H1 直接否证；T_cw,in 与异常起点同步波动→子机制锁定入口温度 |

### 8.2 P1 — 本月计划内

| 行动 | 具体操作 | 预期效果 | 如何验证 |
|------|---------|---------|---------|
| 加装冷却水实际流量计 | 区分"阀指令大幅波动但实际流量被吸收"与"实际流量真实摆动" | 补齐 CS1 第三条决定性测量 | 实际流量平稳而指令大幅波动且 T_cw,in 同步波动→H4 排除 |
| 调阅 XMV_10 检修记录/执行器故障代码 | 核对历次检修与故障码时间戳与异常起点（idx160/166）的关系 | 检维修侧独立证据 | 记录与异常起点吻合→H4 转正 |
| 蒸汽管网侧压力/多用户流量测量 | 判定汽提环方差 ×2.4–2.5 是反应器侧传播还是独立扰动 | 关闭次级签名溯源缺口 | 管网压力显示独立扰动先于 idx160→异常模型改双扰动源 |
| 工艺侧临时缓解评估 | 在扰动持续期间评估 TC 回路参数与阀门行程裕度（当前开度 34.5–50.1%，未饱和） | 防止阀门到达限位后温度失控 | 监控 §8.4 指标 |

### 8.3 P2 — 条件成熟时

| 行动 | 具体操作 | 前提条件 |
|------|---------|---------|
| 延长观测窗口（>48h） | 覆盖跨环累积时滞（本体预测 XMEAS_9~XMEAS_31 >10 采样步）与扰动长期演化（自限/恶化/季节性） | 连续数据接入 |
| 像素级视觉复核 | 在具备视觉模型的环境对 9 张图件补做 L4 级判读（趋势形态、间歇簇发） | VLM 环境可用 |
| 仪表完整性整改 | 补齐 cleaning_integrity 审计轨迹（prepare 阶段 Phase 2.2.5），使"清洗零改动"具备工件级证明 | 管线更新 |

### 8.4 行动效果监控

| 监控指标 | 当前基线 | 异常段现值 | 报警阈值 |
|---------|:------:|:------:|:------:|
| XMV_10 滚动 20 样本标准差 | σ=0.573% | 3.631%（首超 2× 基线于 idx166） | >2× 基线σ（≈1.15%） |
| XMEAS_9 3σ 越限 | 0（基线段） | 5 个孤立单点（pct=0.521%，max 3.73σ） | 出现连片越限（相邻样本连续越限）即升级 |
| XMEAS_21 方差比 | ×1.027（基线带） | ×1.027 | >1.5 且伴随阀位方差爆发→复判 H4 |
| 均值漂移 | ±0.3σ 带内 | XMV_10 +1.223σ / T9 +0.01σ | 任一通道 >±3σ 基线带→机理链重建 |

---

## 9. 方法论说明与局限

### 9.1 分析方法

- **竞争假设协议**：H1–H5 预注册（`02_processed/analysis_method_plan.json`），每假设带主导方程+因果链+可证伪条件；四抗猜想条件（时间先行+统计显著+物理机理+无矛盾）逐条核查；三态输出规则（DETERMINED/COMPETING_SET/NEEDS_DATA）——本 run 依"多假设存活且不可全排除"输出 COMPETING_SET。
- **滞后补偿 CCF**：−20..+20 步、14 对、约定 r=corr(xs[t+lag], ys[t])（与 validate_report 一致）；闭环耦合引用补偿值（r=−0.6356@lead5）而非 lag0 值。
- **抗伪相关铁律（v6.4–v6.7）**：分层（Simpson）/去杠杆（leave-one-out）/稳态工况过滤/滞后窗口一致性/多重检验（Bonferroni 5e-4）五项，对全部被引用相关执行并有工件留痕。
- **证据分级 L1–L7**：结论受最弱必要证据等级约束；本 run 主体 L3 + 本体/物理 L5。
- **数值可追溯性**：每个数字标注来源工件、行区间与计算方法；`06_scripts/cooling_loop_semantic_analysis.py` 等三个自定义脚本可从 `00_input/data.csv` 复算；judge 独立复算 12 项全部吻合。

### 9.2 推理过程与推理链（R1–R8）摘要

R1 数据特征化与场景定位（960×52、时代分层、onset 双源一致）→ R2 统计发现与多源融合（5 通道签名、均值-方差解耦、三同步群组）→ R3 验证过滤与反伪相关审查（五项全过、跨环弱相关降级）→ R4 竞争假设生成（H1–H5 MECE，H6/传感器漂移两个候选被论证排除）→ R5 可判别性评估（[H1,H4] PARTIALLY_DISCRIMINABLE→封顶 65）→ R6 排除执行（H2/H3/H5 入 eliminated，H4 因 <90 弱排除保留）→ R7 结论与可证伪表述（三态选择论证：非 DETERMINED、非 NEEDS_DATA）→ R8 不确定性定界（epistemic 缺口排序：位置器>T_cw,in>实际流量>管网压力；前两个任一即可定案）。置信度轨迹（hypothesis_evolution）：H1 40→62（+15 签名/+15 时序/+16 判别子/−21 封顶/−3 溯源）、H4 35→30。

### 9.3 局限与不确定性（诚实边界）

| 类型 | 局限 | 对结论的影响 |
|------|------|------|
| 数据盲区 | 位置器阀位/T_cw,in/实际流量/蒸汽管网压力 4 个测点缺失（TE 标准变量表结构性事实） | H1–H4 机制细分不可终判→COMPETING_SET、封顶 65 |
| 方法局限 | 闭环反馈污染：领先滞后只证回路局域性；Granger 被合理跳过 | 时序证据判别力上限已反映到扣分（时序 17/20） |
| 环境局限 | 非 VLM 环境：全部图形证据为元数据回填（L3 内容），像素形态证据缺失 | 若图中存在统计摘要未捕捉的形态细节（如间歇簇发），当前读法不完整 |
| 估计器差异 | 谱 flatness periodogram 重算 0.075 vs 工件 0.068（备案 I1） | 数值有差异、定性"宽带"结论在两种估计器下均稳健 |
| 假设依赖 | T21 量级否证隐含 (T21−T_cw,in) 常规量级假设（备案 I2）；阶次论证为 derived 非第一性预测 | 否证保持"间接/阶次"定位，H4 保留于竞争集 |
| 采样与窗口 | 180s 采样对阀快动态略欠采样；48h 窗口外扰动演化不可知 | 不影响主签名（180s 对分钟级回路充分） |
| 溯源缺口 | 汽提环方差 ×2.4–2.5 的"传播 vs 独立"不可判（跨环 \|r\|≤0.148；I3：significant_lags_found=7 计数口径跨文件，无结论依赖） | H1 置信度 −3；已列入 data_gaps |
| 审计缺口 | cleaning_integrity 未登记（prepare 阶段） | 以"cleaned_data 与 raw 逐值一致"对冲；建议补齐 |

不确定性三分解（`04_diagnostics/confidence.json`）：aleatory（扰动本体随机，不可逐样本预测）；epistemic（四个缺失测点+溯源缺口，加装任一关键仪表即可消除）；model（线性 PI+稳态分层近似；闭环下方向解释受限）。

### 9.4 数据缺口清单（`04_diagnostics/diagnosis.json` data_gaps）

1. XMV_10 位置器实际阀位反馈（阀杆位置）——CS1 决定性判别测量之一。
2. 反应器冷却水入口温度 T_cw,in 测点（TE 变量表无）——H1 子机制不可细分。
3. 反应器冷却水实际流量计——"指令波动"与"实际流量波动"不可区分。
4. 蒸汽管网侧压力/多用户流量测量——汽提环次级签名溯源不可判。
5. 独立检验侧质量信号（process_only 视图）——过程→质量联动不在可行域。
6. 更长观测窗口——跨环累积时滞可能超过当前样本窗。

---

*报告完。全部数字可回溯至 run 目录工件；judge 12 项独立复算零偏差；报告生成：工程师周（reporter，Step 6），2026-09-17。*
