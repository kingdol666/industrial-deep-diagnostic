import pandas as pd, numpy as np, json
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171631116_bench_skab_normal_control"
df = pd.read_csv(RUN + "/00_input/data.csv", parse_dates=["datetime"])
a1 = df["Accelerometer1RMS"].values; a2 = df["Accelerometer2RMS"].values
z1 = (a1 - a1.mean())/a1.std(ddof=0); z2 = (a2 - a2.mean())/a2.std(ddof=0)
# Accel2 min and its own argmin
i2 = int(np.argmin(a2))
print("Accel2 min:", a2[i2], "at 0-based row", i2, "z=", z2[i2])
print("Accel2 z at 0-based 9199 (Accel1 min row):", z2[9199])
print("Accel1 z at Accel2 min row:", z1[i2])
# window 0-based 9187..9208 inclusive (22 rows)
w = slice(9187, 9209)
print("window 9187-9208 (0-based incl) mean z: A1", z1[w].mean(), "A2", z2[w].mean())
# datetime of key rows
print("t[9199]:", df['datetime'].iloc[9199], "t[9187]:", df['datetime'].iloc[9187], "t[9208]:", df['datetime'].iloc[9208])
print("t[2001] (flow min 0-based?):", df['datetime'].iloc[int(np.argmin(df['Volume Flow RateRMS'].values))])
# |z|>2 run length for flow around min
f = df["Volume Flow RateRMS"].values; zf=(f-f.mean())/f.std(ddof=0)
iminf=int(np.argmin(f))
lo=iminf
while lo>0 and abs(zf[lo-1])>2: lo-=1
hi=iminf
while hi<len(zf)-1 and abs(zf[hi+1])>2: hi+=1
print("flow |z|>2 run 0-based:", lo, "-", hi, "len:", hi-lo+1)
print("F at min+87s:", f[iminf+87], "first F>=123 after min:", next((k for k in range(iminf,len(f)) if f[k]>=123.0), None)-iminf, "s; value:", next((f[k] for k in range(iminf,len(f)) if f[k]>=123.0), None))
print("rows 2069-2129 (1-based data? -> iloc 2069:2129) mean F:", f[2069:2129].mean())
# steady fraction per production_regime_filter method - read artifact to see method
art = json.load(open(RUN + "/02_processed/production_regime_filter.json"))
print("regime artifact keys:", list(art.keys()))
print(json.dumps(art, ensure_ascii=False)[:1500])
