import pandas as pd, numpy as np, json
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171631116_bench_skab_normal_control"
df = pd.read_csv(RUN + "/00_input/data.csv", parse_dates=["datetime"])
n = len(df)
CH = ["Accelerometer1RMS","Accelerometer2RMS","Current","Pressure","Temperature","Thermocouple","Voltage","Volume Flow RateRMS"]
# exact replication of anti_spurious_verify.py steady gate
steady = np.ones(n, dtype=bool)
for c in CH:
    x = df[c].to_numpy()
    d = np.diff(x)
    med = np.median(d); mad = np.median(np.abs(d - med)); scale = 1.4826*mad
    if scale <= 0: scale = d.std() if d.std() > 0 else 1.0
    ok = np.abs(d - med) <= 5.0*scale
    steady[1:] &= ok
print("EXACT-GATE nonsteady:", int((~steady).sum()), "steady_fraction:", float(steady.mean()))

# ontology normal ranges vs channel extremes
ont = json.load(open(RUN + "/01_ontology/ontology.json"))
s = json.dumps(ont, ensure_ascii=False)
# find normal_range entries
def find_nr(o, path=""):
    if isinstance(o, dict):
        if "normal_range" in o and isinstance(o["normal_range"], dict):
            yield (o.get("name") or o.get("id") or path, o["normal_range"])
        for k,v in o.items():
            yield from find_nr(v, path+"/"+k)
    elif isinstance(o, list):
        for i,v in enumerate(o): yield from find_nr(v, f"{path}[{i}]")
nr = list(find_nr(ont))
print("\nontology normal ranges found:", len(nr))
out = {}
for name, r in nr:
    lo, hi = r.get("min"), r.get("max")
    # match to column
    for c in CH:
        if c.lower() in str(name).lower() or str(name).lower() in c.lower():
            x = df[c]
            out[c] = {"band": [lo,hi], "obs_min": float(x.min()), "obs_max": float(x.max()),
                      "in_band": bool(x.min()>=lo and x.max()<=hi)}
for c in CH:
    if c in out:
        o=out[c]; print(f"{c:26s} band={o['band']} obs=[{o['obs_min']:.4f},{o['obs_max']:.4f}] in_band={o['in_band']}")
    else:
        print(c, "NO BAND MATCHED")

# Voltage / Current stats quoted in report
print("\nVoltage mean/sd/min/max:", df["Voltage"].mean(), df["Voltage"].std(ddof=0), df["Voltage"].min(), df["Voltage"].max())
print("Current min:", df["Current"].min(), "Pressure min/max:", df["Pressure"].min(), df["Pressure"].max())
print("Temp min/max:", df["Temperature"].min(), df["Temperature"].max(), "TC min/max:", df["Thermocouple"].min(), df["Thermocouple"].max())
print("Flow min/max:", df["Volume Flow RateRMS"].min(), df["Volume Flow RateRMS"].max())
print("A1 min/max:", a1m:=df["Accelerometer1RMS"].min(), df["Accelerometer1RMS"].max(), "A2:", df["Accelerometer2RMS"].min(), df["Accelerometer2RMS"].max())
# Accel1 max vs band 0.23?
# cavitation channel P~A1 r
print("\nP~A1 r:", float(np.corrcoef(df["Pressure"], df["Accelerometer1RMS"])[0,1]))
print("Q~P steady r:", float(np.corrcoef(df["Volume Flow RateRMS"], df["Pressure"])[0,1]))
print("V~A1 r:", float(np.corrcoef(df["Voltage"], df["Accelerometer1RMS"])[0,1]), "V~F r:", float(np.corrcoef(df["Voltage"], df["Volume Flow RateRMS"])[0,1]))
# low current rows
cur = df["Current"].to_numpy(); low = cur < 1.5
print("low_current rows:", int(low.sum()), "pct:", 100*float(low.mean()))
