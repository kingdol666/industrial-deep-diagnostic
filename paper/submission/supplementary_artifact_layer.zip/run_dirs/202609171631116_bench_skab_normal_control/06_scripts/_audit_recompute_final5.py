import pandas as pd, numpy as np, json
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171631116_bench_skab_normal_control"
df = pd.read_csv(RUN + "/00_input/data.csv", parse_dates=["datetime"])
CH = ["Accelerometer1RMS","Accelerometer2RMS","Current","Pressure","Temperature","Thermocouple","Voltage","Volume Flow RateRMS"]
# exact steady mask
steady = np.ones(len(df), dtype=bool)
for c in CH:
    d = np.diff(df[c].to_numpy()); med=np.median(d); mad=np.median(np.abs(d-med)); sc=1.4826*mad
    if sc<=0: sc = d.std() if d.std()>0 else 1.0
    steady[1:] &= np.abs(d-med) <= 5.0*sc
ss = df[steady]
print("steady subset n:", len(ss))
print("V~F steady r:", float(np.corrcoef(ss["Voltage"], ss["Volume Flow RateRMS"])[0,1]))
print("V~A1 steady r:", float(np.corrcoef(ss["Voltage"], ss["Accelerometer1RMS"])[0,1]))
print("Q~P steady r:", float(np.corrcoef(ss["Volume Flow RateRMS"], ss["Pressure"])[0,1]))
print("V~I steady r:", float(np.corrcoef(ss["Voltage"], ss["Current"])[0,1]))
