import pandas as pd, numpy as np, json
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171631116_bench_skab_normal_control"
df = pd.read_csv(RUN + "/00_input/data.csv", parse_dates=["datetime"])
for step,name in [(4,"4:1 downsample"),(5,"5:1"),(2,"2:1")]:
    d2 = df.iloc[::step]
    print(name, "n=", len(d2), "V~F r=", round(float(np.corrcoef(d2["Voltage"], d2["Volume Flow RateRMS"])[0,1]),6),
          "V~A1 r=", round(float(np.corrcoef(d2["Voltage"], d2["Accelerometer1RMS"])[0,1]),6))
# detrended V~F
from numpy.polynomial import polynomial as P
t = np.arange(len(df), dtype=float)
for c in ["Voltage","Volume Flow RateRMS","Accelerometer1RMS"]:
    co = np.polyfit(t, df[c].values, 1)
    df[c+"_dt"] = df[c].values - np.polyval(co, t)
print("detrended V~F r:", round(float(np.corrcoef(df["Voltage_dt"], df["Volume Flow RateRMS_dt"])[0,1]),6))
print("detrended V~A1 r:", round(float(np.corrcoef(df["Voltage_dt"], df["Accelerometer1RMS_dt"])[0,1]),6))
# check validate_report / causal_evidence_map for the +0.0387 source
vr = json.load(open(RUN + "/02_processed/validate_report.json"))
s = json.dumps(vr)
import re
i = s.find("0.0387")
print("0.0387 in validate_report:", i)
cem = json.load(open(RUN + "/02_processed/causal_evidence_map.json"))
s2 = json.dumps(cem)
print("0.0387 in causal_evidence_map:", s2.find("0.0387"))
dag = open(RUN + "/04_diagnostics/diagnosis.json", encoding="utf-8").read()
print("0.0387 in diagnosis.json:", dag.find("0.0387"))
ont = open(RUN + "/01_ontology/ontology.json", encoding="utf-8").read()
print("0.0387 in ontology.json:", ont.find("0.0387"))
