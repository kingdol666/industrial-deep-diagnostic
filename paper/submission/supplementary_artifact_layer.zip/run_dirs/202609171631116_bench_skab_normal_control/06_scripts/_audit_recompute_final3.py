import pandas as pd, numpy as np, json, re
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171631116_bench_skab_normal_control"
df = pd.read_csv(RUN + "/00_input/data.csv", parse_dates=["datetime"])
a1 = df["Accelerometer1RMS"].values; a2 = df["Accelerometer2RMS"].values
z1 = (a1 - a1.mean())/a1.std(ddof=0); z2 = (a2 - a2.mean())/a2.std(ddof=0)
print("t[7995]:", df['datetime'].iloc[7995], "a1[7995]=", a1[7995], "z1=", z1[7995], "z2=", z2[7995])
print("rows 9190..9210 (0-based): idx, a1, z1, a2, z2")
for i in range(9190, 9211):
    print(i, df['datetime'].iloc[i].strftime('%H:%M:%S'), a1[i], round(z1[i],3), a2[i], round(z2[i],3))
# Accel2 min within window 9187-9208
w = slice(9187, 9209)
i2w = 9187 + int(np.argmin(a2[w]))
print("Accel2 min within window: 0-based", i2w, "z=", z2[i2w], "val=", a2[i2w])
# Accel1 extreme of -5.14: global single min row
print("Accel1 global min: 0-based", int(np.argmin(a1)), "z=", z1.min())
# Accel2 |z|>3 rows
r2 = np.where(np.abs(z2)>3)[0]; r1 = np.where(np.abs(z1)>3)[0]
print("Accel2 |z|>3 rows 0-based:", r2.tolist())
print("Accel1 |z|>3 rows 0-based:", r1.tolist()[:30])
