# FINAL AUDIT independent recomputation (Auditor Sun, Step 7)
import pandas as pd, numpy as np, json
RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171631116_bench_skab_normal_control"
df = pd.read_csv(RUN + "/00_input/data.csv", parse_dates=["datetime"])
n = len(df)
cols = ["Accelerometer1RMS","Accelerometer2RMS","Current","Pressure","Temperature","Thermocouple","Voltage","Volume Flow RateRMS"]
out = {"n_rows": n, "n_cols": df.shape[1]}

# 1. Accel1 min & band edge check (ontology band lower edge 0.19)
a1 = df["Accelerometer1RMS"].values; a2 = df["Accelerometer2RMS"].values
i1 = int(np.argmin(a1))
out["accel1_min"] = float(a1[i1]); out["accel1_min_row_1based"] = i1 + 2  # +2: header + 0-based
z1 = (a1 - a1.mean()) / a1.std(ddof=0); z2 = (a2 - a2.mean()) / a2.std(ddof=0)
out["accel1_z_at_min"] = float(z1[i1]); out["accel2_z_same_row"] = float(z2[i1])
out["accel1_below_0.19_count"] = int((a1 < 0.19).sum())
below = np.where(a1 < 0.19)[0]
out["below_band_rows_1based"] = [int(below.min())+2, int(below.max())+2] if len(below) else []

# window mean z for rows 9187-9208 (1-based data rows incl. header offset -> iloc 9185:9208)
w = slice(9185, 9208)
out["window_9187_9208_mean_z"] = {"accel1": float(np.mean(z1[w])), "accel2": float(np.mean(z2[w]))}

# 2. V->I raw Pearson
out["r_VI_raw"] = float(np.corrcoef(df["Voltage"], df["Current"])[0,1])
out["r_T_TC_raw"] = float(np.corrcoef(df["Temperature"], df["Thermocouple"])[0,1])
out["r_TC_F_raw"] = float(np.corrcoef(df["Thermocouple"], df["Volume Flow RateRMS"])[0,1])

# 3. Flow stats
f = df["Volume Flow RateRMS"].values
zf = (f - f.mean()) / f.std(ddof=0)
iminf = int(np.argmin(f))
out["flow_mean"] = float(f.mean()); out["flow_min"] = float(f.min())
out["flow_min_z"] = float(zf[iminf]); out["flow_min_row_1based"] = iminf + 2
out["flow_target_ratio"] = float(f.mean()/125.0)

# 4. |z|>3 exceedance rates
ex = {}
for c in cols:
    x = df[c].values; z = (x - x.mean())/x.std(ddof=0)
    ex[c] = {"count": int((np.abs(z)>3).sum()), "rate_pct": round(100*float((np.abs(z)>3).mean()),3)}
out["exceedance"] = ex

# 5. P8 thermal endpoints
T = df["Temperature"].values; TC = df["Thermocouple"].values
out["motor_first60s_mean"] = float(T[:60].mean()); out["motor_last600s_mean"] = float(T[-600:].mean())
out["fluid_first60s_mean"] = float(TC[:60].mean()); out["fluid_last600s_mean"] = float(TC[-600:].mean())
out["gap_first"] = out["motor_first60s_mean"] - out["fluid_first60s_mean"]
out["gap_last"] = out["motor_last600s_mean"] - out["fluid_last600s_mean"]

# 6. sampling gaps: 2 s single-sample steps
dt = df["datetime"].diff().dt.total_seconds().dropna()
out["span_s"] = float(dt.sum()); out["steps_2s"] = int((dt == 2).sum()); out["max_gap_s"] = float(dt.max())

# 7. Flow linear trend per hour
t = np.arange(n, dtype=float)
slope, intercept = np.polyfit(t, f, 1)
pred = slope*t + intercept
ss_res = float(np.sum((f-pred)**2)); ss_tot = float(np.sum((f-f.mean())**2))
out["flow_trend_L_per_h"] = float(slope*3600); out["flow_trend_R2"] = 1 - ss_res/ss_tot
sa = np.polyfit(t, a1, 1)
out["accel1_trend_g_per_h"] = float(sa[0]*3600)
# motor temp linear slope
sm = np.polyfit(t, T, 1)
out["motor_trend_C_per_h"] = float(sm[0]*3600)

# 8. steady fraction (robust first-diff gate, 8-channel union, 5*1.4826*MAD)
nonsteady = np.zeros(n, dtype=bool)
for c in cols:
    x = df[c].values; d1 = np.abs(np.diff(x, prepend=x[0]))
    mad = np.median(np.abs(d1 - np.median(d1)))
    nonsteady |= d1 > 5*1.4826*mad
out["nonsteady_rows"] = int(nonsteady.sum()); out["steady_fraction"] = float(1 - nonsteady.sum()/n)

# 9. missing values
out["any_missing"] = int(df[cols].isna().sum().sum())

print(json.dumps(out, indent=1, ensure_ascii=False))
