"""Step-7 FINAL audit RE-CHECK: verify B1 (row attribution) + B2-adjacent stats from raw data.
Methodology identical to _audit_recompute_final3.py (z = (x-mean)/std, ddof=0, full channel).
Rows are 0-based positions in 00_input/data.csv (header excluded).
"""
import pandas as pd, numpy as np, json

RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171631116_bench_skab_normal_control"
df = pd.read_csv(RUN + "/00_input/data.csv", parse_dates=["datetime"])
a1 = df["Accelerometer1RMS"].values
a2 = df["Accelerometer2RMS"].values
z1 = (a1 - a1.mean()) / a1.std(ddof=0)
z2 = (a2 - a2.mean()) / a2.std(ddof=0)

print("== B1 recomputation (all rows 0-based) ==")
print("A1@9199: val=%.6f g  z=%.4f   (expect 0.1882 g, -5.14 sigma)" % (a1[9199], z1[9199]))
print("A2@9199: val=%.6f g  z=%.4f   (expect z=-4.54, NOT -5.10)" % (a2[9199], z2[9199]))

w = slice(9187, 9209)  # rows 9187..9208 inclusive
i2w = 9187 + int(np.argmin(a2[w]))
i1w = 9187 + int(np.argmin(a1[w]))
print("A2 in-window extreme: row=%d  val=%.6f g  z=%.4f  t=%s  (expect row 9201, 0.2493 g, -4.79)"
      % (i2w, a2[i2w], z2[i2w], df["datetime"].iloc[i2w].strftime("%H:%M:%S")))
print("A1 in-window extreme: row=%d  val=%.6f g  z=%.4f  (expect row 9199, -5.14)" % (i1w, a1[i1w], z1[i1w]))

i2g = int(np.argmin(a2))
print("A2 global extreme: row=%d  val=%.6f g  z=%.4f  t=%s  (expect z=-5.10 at row 7992-7995 event)"
      % (i2g, a2[i2g], z2[i2g], df["datetime"].iloc[i2g].strftime("%H:%M:%S")))
r2 = np.where(np.abs(z2) > 3)[0]
r1 = np.where(np.abs(z1) > 3)[0]
ev = [i for i in r2 if 7980 <= i <= 8010]
print("A2 |z|>3 rows near 7992-7995:", ev, " A1 z at 7995 = %.4f (expect -3.71)" % z1[7995])

print("window 9187..9208 mean z: A1=%.3f A2=%.3f  (expect -3.7 / -2.8)"
      % (z1[w].mean(), z2[w].mean()))

below = a1[a1 < 0.19]
print("A1 samples < 0.19 g: n=%d val=%s min=%.6f  (expect n=1, 0.188217)"
      % (len(below), below.tolist(), a1.min()))
print("band-edge deviation: %.2f%%  (expect ~0.9%%)" % ((0.19 - a1.min()) / 0.19 * 100))

print("== B2-adjacent spot re-checks (report/run_summary claims) ==")
f = df["Volume Flow RateRMS"].values
print("flow mean=%.5f ratio=%.5f (expect 125.237 / 1.002)" % (f.mean(), f.mean() / 125.0))
v = df["Voltage"].values
print("V mean/sd=%.3f/%.3f (expect 228.65/10.98)" % (v.mean(), v.std(ddof=0)))
print("rows x cols=%dx%d (expect 9405x9)" % df.shape)
