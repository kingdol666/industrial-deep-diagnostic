# 工业诊断报告 — 水循环试验台闭环回路（bench_skab_normal_control）

**场景**: 水循环试验台闭环回路（水箱 + 离心泵 + 阀门，稳态工况监测） | **产品/批次**: NOT_APPLICABLE（单连续工况记录，无分组列） | **日期**: 2026-09-17 | **运行ID**: 202609171631116_bench_skab_normal_control
**诊断评级**: Judge 97/100 — pass（第 1 轮，无需修复回路） | **诊断类型**: DETERMINED | **综合置信度**: 86/100（HIGH，上限 90）

> **阅读指南**: 第 1 节是给厂长/总经理看的一页纸摘要。第 4 节是统计分析发现（含时序对齐图核心证据）。第 5-6 节解释竞争假设排除与根因结论。第 7 节为证据附录（每个数字注明来源工件）。第 8 节是可执行的行动方案。

> **实事求是声明**: 本报告所有结论均来源于运行工件（02_processed、03_figures、04_diagnostics、05_review）中的实际计算结果；每个结论标注证据来源。视觉观测全部为 **[metadata-backed]**（非 VLM 环境，未做像素级读取，`03_figures/visual_analysis.json` observation_mode=metadata_backed_inference）。Step 5b 报告前物理审计（`05_review/optimizer_preflight.md`）的 1 项 MAJOR + 4 项 MINOR 表述级修复已全部落实到本报告（见 7.7 节落实记录）。

---

## 1. 执行摘要

> **这一页是写给厂长和总经理看的。2 分钟读完。**

### 发生了什么？

对水循环试验台的一段 **2.77 小时**（名义 1 Hz，2020-02-08 13:30:47→16:16:47，n=9405）稳态监测记录做了 9 阶段全流程诊断。结论：**记录中没有故障**。系统处于正常稳态运行，观测到的全部波动属于正常运行变化（normal operating variation），由三类已知来源构成：电网外生电压波动、启动热平衡弛豫、传感器噪声与量化伪迹。

**证据结构（三重证明）**：

1. **稳态**：9378/9405 行稳态，占比 **99.71%**（`02_processed/production_regime_filter.json`）；8 个通道全部以平稳窄带运行。
2. **证伪**：全部强原始相关（|r|=0.45~0.89）经去趋势 / 一阶差分 / 滞后补偿 CCF / 时间三分层四重检验，**全部证伪为慢共漂伪相关**；唯一存活的电压→电流耦合（r=+0.472，滞后 0 s）与本体电气先验完全一致，属正常供电-负载共变（`02_processed/anti_spurious_verification.json`）。
3. **越限审计**：全部 |z|>3 越限**短促（≤25 s）、单域、自恢复**，发生率 0.12%~0.25% 接近高斯期望 0.27%（`02_processed/physics_check.json` P4/P5）。

### 带内运行的准确表述（按物理审计修正）

7/8 通道极值在本体正常带内；**例外**：Accelerometer1RMS 在行 9187–9208 的 22 s 双测点下探中单点最低 **0.1882 g**，短暂低于本体带下缘 0.19 g 约 0.9%（单点 **-5.14σ**，行 9199；同点 Accel2 -4.54σ，窗口内 Accel2 极值 -4.79σ 在行 9201；Accel2 全记录极值 -5.10σ 属行 7992–7995 的独立 4 s 事件，与本窗口无关），窗口内电气/水力通道 |z̄|≤0.4 无响应，**自恢复**，且下探方向与机械劣化预测（RMS 抬升）相反——不构成故障证据（`05_review/optimizer_preflight.md` A2/MAJOR-1）。

### 影响有多大？

**零产量影响、零检修需求。** 流量均值 125.24 L/min，命中本体设计目标 ≈125 L/min（比值 **1.002**）；泵-阀工作点锁定，无气蚀、无劣化方向信号。本次诊断的价值在于建立"健康基线"与可操作的报警规则（见第 8 节），而非故障处置。

### 推荐行动

| 优先级 | 行动 | 预期效果 | 时间 | 大约成本 |
|:------:|------|---------|------|:------:|
| **P0** | 维持运行，无需检修；按 8.4 节基线与证伪条件配置报警（流量持续 <118 L/min >60 s、多域协同越限、振动阶跃不回落等） | 防止漏报真实故障 | 本周 | 极低（规则配置） |
| **P1** | 增设环境温度测点；采集 ≥30 min 等工况记录并做分钟级重采样 CCF（关闭热滞后不可检验缺口，置信上限 90→≈95） | 压缩认知缺口 | 本月 | 低（1 个测点 + 1 次采集） |
| P2 | 压力 ADC 分辨率升级（<0.05 Bar）；补阀位/转速指令列；核查供电/滑差效应以解释 V→I 正号；流量计瞬态记录核查 | 消除小幅异常盲区 | 条件成熟后 | 中 |

### 有多大把握？

**综合置信度 86/100（HIGH），置信上限 90。** 用白话说：这份"无故障"结论是**排除法证明**的——4 个故障假设（传热反向、跨域耦合、尖峰起点、泵劣化/气蚀）全部被量化排除（排除置信度 92~95，各带可操作的复活条件），且 Judge 独立重算全部关键数字**零偏差**。扣掉的 14 分主要在两处诚实缺口：电机→流体的真实传热滞后（本体先验 ≥10 分钟）超出本记录 ±20 s 搜索窗不可检验；环境温度未测量，热工慢漂的共同原因只能间接排除。

---

## 2. 诊断背景

### 2.1 被诊断对象

闭环水力回路试验台（`01_ontology/ontology.json`）：水箱（EQ_TANK）+ 离心泵（EQ_PUMP，电机 EQ_MOTOR 驱动）+ 调节阀（EQ_VALVE）构成循环回路。生产目标：维持闭环水回路稳定循环（稳态流量 ≈125 L/min），并对泵-电机-阀门系统做振动/温度/电气/水力全参数状态监测。

四阶段本体分组（本报告的方法 Stage / 本体 Stage 编号仅在此处使用，不与推理链 R1-R8 混用）：

| 阶段 | 参数 | 物理角色 |
|------|------|---------|
| ST0 电驱与泵送 | Voltage（confounder）、Current（predictor） | P_elec=√3·V·I·cosφ·η；电气时间常数毫秒级 |
| ST1 水力循环 | Volume Flow RateRMS、Pressure | 泵特性 H=H₀−kQ² 与管路特性 ΔP_sys=k_sys·Q² 交点决定工作点 |
| ST2 热状态演化 | Temperature（target）、Thermocouple（predictor） | mCp·dT/dt=P_loss−hA(T−T_cool)；热时间常数分钟-十分钟级 |
| ST3 机械监测 | Accelerometer1RMS、Accelerometer2RMS（target） | a=ω²·d；劣化表现为 RMS 抬升或阶跃（ISO 10816 思想） |

### 2.2 用户问题与数据

数据：`00_input/data.csv`，9405 行 × 9 列（datetime + 8 传感器通道），无缺失。诊断问题：这段记录是否存在故障或异常趋势？数据视图为 **process_only**（无独立检验/质量流，`02_processed/data_analysis_conclusion.json` adaptive_decision_audit.data_view_mode=process_only），因此过程→质量跨域双驱动路径不可用，诊断按纯过程波动路径（View A）执行，并辅以过程+巡检双驱动的适用性核查（结论 NOT_APPLICABLE，`04_diagnostics/diagnosis.json` integrated_dual_drive_analysis）。

---

## 3. 数据质量评估

| 维度 | 结果 | 来源 |
|------|------|------|
| 完整性 | 9405 行，8 通道缺失均为 0 | `02_processed/feature_summary.json` |
| 时间结构 | 真实 1 Hz datetime，单调有序（time_sorted=true） | `02_processed/validate_report.json` |
| **采样空洞** | **556 处单样本（2 s）步长**，合计缺约 556 s（≈5.6%），最大空洞 2 s；各越限游程"秒数"即样本数，误差 ≤1 s/窗口 | `05_review/optimizer_preflight.md` A10（MINOR-4，本报告披露） |
| 通道特性 | Pressure 粗量化（9 台阶，步长 ≈0.33 Bar）；Current 偏态多水平（主水平 2.4–3.2 A） | `02_processed/physics_check.json` P3 |
| 稳态占比 | 99.71%（非稳态仅 27 行）；低电流段（<1.5 A）6.43% 且最长游程 3 s（运行模式，非工况切换） | `02_processed/production_regime_filter.json` |
| 分组结构 | 无产品/批次列（batch_integrity applicable=false）→ Simpson 分层以时间三分层替代 | `02_processed/batch_integrity.json` |
| 视觉证据模式 | 非 VLM 环境：全部为 metadata-backed，未声称任何像素观测 | `03_figures/visual_analysis.json` |
| RAG | UNAVAILABLE_FALLBACK_APPLIED（8764 端口连接拒绝，按规程回退） | `00_input/rag_deep_understanding.json` |
| 溯源标签瑕疵 | feature_summary.metadata.sampling="2000-of-9405" 为制备阶段遗留标签，与实际 9405 行不符（row_count 经 Judge 重算确认）；不影响任何诊断数值 | `05_review/judge_feedback.json` 警告 2 |

特殊值预审：Pressure 负值至 -1.257 Bar、Current 低至 0.856 A 均为已消歧的量化/运行模式现象（`00_input/clarification_needed.json` AMB-02/AMB-04），未预设为故障。

---

## 4. 统计分析发现

> 本章为报告的核心证据章（非附录）。所有相关数值取自全分辨率（n=9405）重算：`02_processed/anti_spurious_verification.json`、`02_processed/time_lag_analysis.json`。

### 4.1 通道间关键相关与四重反虚假检验

| 参数对 | 原始 r | 去趋势 r | 1 s 差分 r | CCF 平台 span | 三分层 r | 裁定 |
|--------|:-----:|:-----:|:-----:|:-----:|:------:|------|
| Temperature~Thermocouple | -0.8906 | -0.572 | **+0.014** | 0.000991 | — | slow_drift_artifact |
| Thermocouple~Flow | +0.8300 | +0.583 | -0.028 | 0.0012 | +0.692 / +0.318 / **-0.414**（符号翻转） | slow_drift_artifact |
| Temperature~Flow | -0.7602 | -0.331 | -0.021 | 0.0054 | — | slow_drift_artifact |
| Accel1~Flow | +0.7134 | +0.422 | +0.004 | 0.0121 | — | slow_drift_artifact |
| Accel2~Flow | -0.7057 | -0.415 | -0.008 | 0.0081 | — | slow_drift_artifact |
| Accel1~Accel2 | -0.4456 | **-0.009** | +0.4226* | 0.0810 | — | slow_drift_artifact |
| **Voltage→Current** | **+0.4723** | +0.4725 | **+0.4904** | lag-0 孤立峰 | [0.4706, 0.4817, 0.4650]（一致） | **validated_moderate（唯一存活）** |

*Accel1~Accel2 的差分 +0.423 反映 22 s 双测点一致性瞬态（见 4.5 节行 9199 单点极值），其证伪依据是去趋势坍缩（-0.009）与分层结构，非差分项。

V→I 存活耦合的完整稳健性：去趋势 +0.472526、一阶差分 +0.490364、稳态滤波 +0.472405、时间三分层 [0.470612, 0.481683, 0.465011]、留一 LOO maxΔr=0.001058、最优滞后 0 s（n=9405，p≈0）。**结论表述（按审计 MINOR-5 限定）**：该耦合**与正常电气运行一致（四重检验稳健）**，滞后 0 s 与电气毫秒级时间常数先验一致；但**其正相关符号不能由一阶电机物理证明**——一阶模型（恒功率 I∝1/V 或恒转矩低压升流）预测负号，观测正号需二阶滑差/泵立方功率或共源电气效应解释，工件未做定量核算（`01_ontology/ontology.json` validation_note 已承认恒功率矛盾）[PHYSICS_UNVERIFIED]。本耦合在本 run 仅作"正常波动描述"，不承载任何故障排除权重。

因果证据图终审：9 条边中 8 条 refuted_as_slow_drift_artifact、2 条 no_link_detected、1 条 validated_moderate（Voltage→Current）；root_cause_candidates=**空**（`02_processed/causal_evidence_map.json`）。

### 4.2 统计陷阱披露与稳健性

- **趋势混淆**：2 对（Temperature~Flow、Voltage~Flow）标记 trend_confounded，均已随慢漂组整体证伪，未被用作任何方向的证据（`02_processed/validate_report.json` anti_spurious.summary）。
- **Simpson 悖论**：0 条；**离群驱动相关**：0 条（outlier_sensitivity 全部 severity=OK，r_change≤6%；leave_one_out_leverage 4 条全部 passed，max_shift≤0.0041）。
- **Spearman 散度**：1 条 MODERATE（Accel2~Flow，divergence 0.151）。说明：该散度由偏态慢漂分布导致，该对已随慢漂组被四重检验证伪（去趋势 -0.4286、1 s 差分 -0.0083），风险已被覆盖（`05_review/judge_feedback.json` 警告 3）。
- **压力独立性**：Pressure 与全部 6 个预测变量 lag-0 |r|≤0.065 且 40 点滞后 CCF 平坦（best |r|≤0.0646）——定工作点近恒定表压 + 粗量化的预期形态。

### 4.3 时序对齐图核心证据（图证三段式）

**总述**：对齐证据为单连续记录（n_products=1）。同步组结构：G1_thermal_slow_drift（Temperature/Thermocouple/Flow/Accel1/Accel2，共同慢漂，CCF 平台 span≤0.012，无可分辨滞后）+ G2_electrical（Voltage/Current，lag 0 同步）；precedence_signals 为空——**记录中不存在任何可分辨的时间先后（因果）信号**（`03_figures/visual_analysis.json`）。

#### 4.3.1 单工况全参数时间对齐 z-overlay

![单产品时序对齐 z-normalized overlay](03_figures/fig_vlm_temporal_overlay_single_product.png)

- **图上看到什么** [metadata-backed]：8 通道 z 轨迹在 2.77 h 内保持在本体正常带附近；记录级主导形态是**启动热平衡收敛**——电机 90.65→89.12℃ 降温、流体 26.85→29.37℃ 升温，两基线收敛。
- **统计怎么说**：稳态占比 99.71%；T~TC 原始 -0.891 在去趋势后 -0.572、1 s 差分 +0.014——强相关主体是慢趋势（4.1 节表）。视觉形态与统计一致，无不一致项需要披露。
- **物理说得通吗**：mCp·dT/dt=P_loss−hA(T−T_cool)：启动后电机向平衡点弛豫降温、较冷的水体被损耗热缓慢加热——收敛轨迹**必然**反相关，热流方向电机→流体与本体 ST2 一致（`02_processed/physics_check.json` P8）。

#### 4.3.2 热工反相关对照图（本体差异信号的消解）

![Temperature~Thermocouple raw vs detrended](03_figures/fig_thermal_drift_confounding.png)

- **图上看到什么** [metadata-backed]：上面板双轴原始序列反向慢漂（raw r=-0.891）；下面板去趋势残差快变分量无相干耦合。
- **统计怎么说**：去趋势 -0.57226、1 s 差分 +0.013563、CCF 平坦平台（span=0.000991，±20 s 内无可分辨滞后）、LOO maxΔr=0.00006。
- **物理说得通吗**：电机首 60 s 均值 91.16℃→末 600 s 88.77℃，流体 26.88→29.35℃，间隙 **64.29→59.42℃** 收敛——本体登记的 discrepancy_signal（热反相关）由此完整消解为启动平衡预期形态，非传热反向、非热故障。真实热滞后（本体先验 ≥600 s）超出 ±20 s 搜索窗，**不可检验 ≠ 反证**。

#### 4.3.3 全通道时序总览（±3σ 越限窗口定位）

![8面板时序总览](03_figures/fig_temporal_overview.png)

[metadata-backed] 红线 ±3σ 定位出全部三个越限窗口：行 36–51（13:31:25–13:31:41，热启动尾段）、行 1987–2011（14:06:11–14:06:36，流量下探）、行 9187–9208（16:13:00–16:13:22，双加速度计下探）——详见 4.5 节审计。

#### 4.3.4 滚动相关同步性热图

![滚动相关稳定性热图](03_figures/fig_vlm_synchronization.png)

[metadata-backed] 底层统计：强 raw 相关对（|r| 0.71–0.83）全部归属 G1 慢漂组；电气对属 G2（lag 0）；无任何符号稳定翻转的因果对。视觉-统计对齐说明：本环境未做像素读取，以上读数全部由生成元数据 + 计算统计承载（`03_figures/visual_analysis.json` grounding_summary），与 4.1/4.2 节数值逐条一致。

（另有全局 overlay 交叉核对视图：`03_figures/fig_vlm_temporal_overlay.png`，结论同上。）

![全局时序 overlay 交叉核对](03_figures/fig_vlm_temporal_overlay.png)

### 4.4 越限窗口审计（P4/P5）

各通道 |z|>3 发生率 vs 高斯期望 0.27%（双侧）：

| 通道 | 越限点数 | 发生率 | 最长游程 | 判读 |
|------|:-----:|:-----:|:-----:|------|
| Accelerometer1RMS | 23 | 0.245% | 12 s | 高斯量级 |
| Accelerometer2RMS | 11 | 0.117% | 4 s | 高斯量级 |
| Current | 89 | 0.946% | 2 s | 偏态多水平分布抬高，非异常 |
| Pressure | 11 | 0.117% | 2 s | 单采样量化/噪声伪迹（9 台阶，步长 0.33 Bar；极值 -5.40σ） |
| Temperature | 22 | 0.234% | 5 s | 集中于首分钟启动尾段（行 36–51） |
| Thermocouple / Voltage | 0 | 0 | — | 无越限 |
| Volume Flow RateRMS | 57 | 0.606% | 25 s | 集中于单一瞬态（下） |

三个关键窗口的跨域审计（窗口内其它通道均值 z）：

1. **流量低谷（行 1987–2011）**：最低 **118.0 L/min（-4.51σ）**；|z|>2 游程 **87 s**；窗口内泵侧无响应（Pressure -0.33σ、Current +0.16σ、振动不变）——单域。**恢复表述（统一口径，按 Judge 建议与审计重算）**：低谷持续 87 s（|z|>2），**游程结束后约 1.5 min 内恢复至 ≥123 L/min**。说明：工件间存在表述差异——`04_diagnostics/diagnosis.json` 记"87 s 后回到 123.0 L/min"，`02_processed/physics_check.json` P5 记"60 s 后回到 123.0 L/min"；Judge 以 `00_input/data.csv` 全量重算为准：+87 s 时 F=121.668 L/min，F≥123.0 首次出现在 **+105 s**（`05_review/judge_feedback.json` 警告 1；审计复算行 2069–2129 均值 122.4 L/min，窗口取法差异，实质相同）。自恢复结论本身不受影响。
2. **双加速度计下探（行 9187–9208，22 s）**：**窗口均值 z 为 -3.7/-2.8σ；单点极值为 Accel1 -5.14σ（0.1882 g，行 9199）、Accel2 -4.79σ（行 9201；行 9199 处为 -4.54σ）**——这是全记录最深的一致性事件（按审计 MINOR-2 披露单点极值；Accel2 全记录单点极值 -5.10σ 属行 7992–7995 的独立 4 s 事件，不在本窗口）。窗口内 Current/Pressure/Voltage |z̄|≤0.4 无响应；下探方向与劣化预测（RMS 抬升）相反；自恢复。
3. **热越限（行 36–51，首分钟）**：启动整定尾段，被 P8 热平衡机制覆盖。

**审计裁定**：全部越限短促（≤25 s）、单域、自恢复、发生率≈高斯期望——不存在持续性、多域协同或前驱-后随结构（H4 排除，见第 5 节）。

### 4.5 平稳性与带内慢游走（按审计 MINOR-3 限定表述）

- 无阶跃：双测点 60 s 滚动均值最大漂移仅 2.26σ（行 293 / 行 64）且回落（P7）。
- "无漂移"的准确表述：**无劣化方向的单调漂移**（P6 首末 10 min 判据）；但带内慢升真实存在——审计线性趋势重算 **Flow ≈+1.63 L/min/h（R²=0.59）、Accel1 ≈+0.0042 g/h（R²=0.45）**（`05_review/optimizer_preflight.md` A5/MINOR-3）。方向向上，与泵磨损方向（Q↓）相反，且与流体升温（黏度↓→管路阻力↓）物理自洽——**支持**正常叙事，取代"完全稳定"的绝对化措辞。
- 热通道慢漂在设计热时间常数内（电机 -0.71 ℃/h 线性拟合斜率，P1；审计重算 -0.75 ℃/h，同量级）。

---

## 5. 竞争假设检验与排除逻辑

### 5.1 假设总表（1 存活 + 4 排除，`04_diagnostics/diagnosis.json`）

| 假设 | 内容 | 初始→最终置信 | 排除类型 / 置信度 | 关键判别量 | 复活条件（摘要） |
|------|------|:------:|:------:|------|------|
| **H1（存活）** | 正常稳态运行：外生电压波动 + 启动热平衡 + 噪声/量化 | 75→**86** | — | V→I 四重稳健 + 8 通道窄带 + 幅值命中目标 | 5 条证伪条件（6.5 节） |
| H2 传热反向/热学异常 | raw r=-0.891 表象 | 85→5 | COMBINED / 95 | 1 s 差分 +0.014、CCF 平坦、P8 收敛轨迹、热流方向与 ST2 一致 | ≥30 min 记录分钟级 CCF 出现 ≥600 s 显著负向滞后耦合 |
| H3 跨域因果耦合/性能劣化 | 5 对强相关表象 | 70→5 | STATISTICAL / 95 | 去趋势衰减 43–57%、差分坍缩 |r|≤0.028、三分层符号翻转 | 分钟级重采样出现稳定优势滞后且分层一致 |
| H4 孤立尖峰为故障起点 | Pressure max 5.4σ 等 | 60→5 | COMBINED / 92 | 游程≤25 s、单域、发生率≈高斯、量化伪迹、自恢复 | 多域协同越限（≤±5 s 窗 ≥2 域 \|z\|>2）且游程>60 s 伴阶跃 |
| H5 泵劣化/气蚀 | 流量/振动表象疑点 | 55→5 | PHYSICAL / 93 | 流量命中目标（1.002）、无振动阶跃、气蚀通道静默（Pressure~Accel1 r=+0.004）、无渐进漂移 | 流量持续下滑 >2% 不恢复 / 振动 ISO 10816 区域迁移 |

### 5.2 H1 五因子置信分解（`04_diagnostics/confidence.json`）

| 因子 | 得分 | 说明 |
|------|:---:|------|
| 统计强度 | 22/25 | 唯一引用耦合 V→I 六重检验全过；扣 3：raw 相关结构大面积由慢漂主导 |
| 物理合理性 | 24/25 | 本体-数据-物理 overall=STRONG_EVIDENCE（未达 PROVEN）；全部 7 条信号 behavior_match=CONSISTENT |
| 时序证据 | 14/20 | V→I lag 0 与先验 MATCH；扣 6：热滞后 ≥600 s 超窗不可检验、precedence 为空 |
| 无混杂 | 16/20 | Simpson=0、LOO≤0.0011；扣 4：环境温度未测、阀位/转速无控制列 |
| 症状完整性 | 10/10 | 全部预测观测量命中；2 个本体差异信号均已消解，无未解释矛盾 |

调整记录：+10（P8 消解差异信号）、+5（V→I 全检验稳健）、-4（热滞后 + 环境温度诚实扣分）；**上限 90**（ALL_CRITERIA_VERIFIED 封顶）。

### 5.3 判别矩阵

6 对假设两两判别全部 **ONE_SIDE_EXCLUDED**——每对均给出数据可执行的判别信号（CCF 形态+差分耦合、去趋势坍缩+分层一致性、游程持续性+跨域协同审计、量级-目标一致性），无 INDISTINGUISHABLE 残留 → 不触发 65 置信上限，competing_sets 为空（`04_diagnostics/diagnosis.json` discriminability_matrix）。

---

## 6. 根因结论

### 6.1 结论陈述

**DETERMINED：系统处于正常稳态运行，未发现故障。** 观测波动的完整归因（三来源，全部有量化证据）：

1. **电网外生电压波动**（228.65±10.98 V，范围 201.4–252.8 V）→ 电流同向共变（V→I r=+0.472，滞后 0 s，六重检验稳健）——正常供电-负载共变；
2. **启动热平衡弛豫**（电机 91.16→88.77℃、流体 26.88→29.35℃、间隙 64.29→59.42℃ 带内收敛）——正常连续工作制热平衡，同时消解本体热反相关差异信号；
3. **传感器噪声与粗量化**（越限率 0.12–0.25% ≈ 高斯期望、游程 ≤25 s、单域、自恢复；压力 9 台阶量化伪迹）。

注：`04_diagnostics/diagnosis.json` primary_finding 原文含"全部 8 个通道在本体正常带内"表述，已按 `05_review/optimizer_preflight.md` MAJOR-1 修正为本报告 1 节的准确口径（7/8 极值带内 + Accel1 单点短暂越界 0.9%、自恢复）；修正不改变结论方向。

### 6.2 物理机制链与验证

| 机制 | 本体方程 | 数据核对 | 结论 |
|------|---------|---------|------|
| ST0 电气功率 | P=√3·V·I·cosφ·η | 方向正、滞后 0 s、四重稳健；幅值与 V σ=10.98 V 相容；**正号机制未定量（见 4.1）** | 与正常电气运行**一致**（非"已证"） |
| ST1 工作点 | H=H₀−kQ²；ΔP=k_sys·Q² | 流量 125.24 vs 目标 125（比值 1.002）；Q-P 稳态 r=+0.0018（定工作点不敏感，本体预声明）；气蚀通道 r=+0.004 静默 | 工作点锁定成立 |
| ST2 热平衡 | mCp·dT/dt=P_loss−hA(T−T_cool) | 收敛轨迹 + 全程带内 + 斜率 -0.71 ℃/h；唯一缺口=≥600 s 滞后不可检验（已扣分） | 差异信号消解成立 |
| ST3 机械监测 | a=ω²·d（ISO 10816 思想） | 双测点窄带 0.2126/0.2684 g；无升阶；22 s 下探方向与劣化相反 | 无机械劣化证据成立 |

本体-数据-物理三要素对齐（`04_diagnostics/diagnosis.json` ontology_data_physics_proof）：函数形式 MATCH、方向 MATCH、幅值 PLAUSIBLE（1.002）、滞后 PARTIAL（热超窗不可检验）→ overall=**STRONG_EVIDENCE**（未达 PROVEN，理由即热滞后）。

### 6.3 因果路径推理过程

五段物理链（H1 physical_logic_chain，每段 OBSERVED/KNOWN_PHYSICS 量化）：电网电压波动→电流共变（OBSERVED，r=+0.472）→ 阀位/转速恒定→泵-管路交点固定→Q/P 各自窄带（OBSERVED，1.002/σ=0.253 Bar）→ 热平衡弛豫收敛（KNOWN_PHYSICS + OBSERVED 端点值）→ 定速激振→振动窄带（OBSERVED，与劣化方向相反的下探不构成矛盾）→ 噪声/量化→短促自恢复越限（OBSERVED，P3/P4/P5）。链路验证 4 条：V→I=ALL_LINKS_VALIDATED；工作点联动、传热、Current→Flow 三条 lag-0 相关缺失（CORRELATION_ABSENT），均按本体关系注记判定为"定工作点/慢时间常数下的预期不敏感"，判据替换为幅值-目标一致性与轨迹收敛性，全部留痕于 inference_gaps，未静默删除（`04_diagnostics/diagnosis.json` chain_link_validation，overall=PARTIAL + correction_applied）。

### 6.4 推理链 R1-R8 摘要

`04_diagnostics/reasoning_chain.json` 8 段齐全（每段含 inputs/reasoning/outputs/alternatives_considered/uncertainty/falsification_condition）：

| 段 | 主题 | 输出置信 |
|----|------|:------:|
| R1 | 数据表征与场景刻画（process_only、无分组、时间判据可用） | 98 |
| R2 | 统计发现与多源融合（慢漂群 + 电气同步对 + 独立压力通道） | 95 |
| R3 | 验证过滤器（四重检验后仅 V→I 存活） | 96 |
| R4 | 竞争假设生成与链路验证（H1-H5 进入竞争） | 93 |
| R5 | 可判别性评估（6 对全部 ONE_SIDE_EXCLUDED） | 94 |
| R6 | 排除验证（4 个故障假设排除 95/95/92/93） | 94 |
| R7 | 诊断结论与可证伪性（DETERMINED，四反臆测条件全满足） | 86 |
| R8 | 不确定性定界与建议测量（上限 90；5 项补测按信息增益排序） | 90 |

### 6.5 诊断结论总结

- **诊断类型**: DETERMINED（非 COMPETING_SET、非 NEEDS_DATA）
- **综合置信度**: 86/100（HIGH，上限 90）
- **结论边界**: "未发现故障"限于本记录 2.77 h 与本数据分辨率内（压力 0.33 Bar、热滞后不可检验均已声明）
- **如果这个结论是错的，最可能因为**（5 条可执行证伪条件，任一成立即重开诊断）：
  1. 任一通道出现持续（>60 s）带外漂移或方差爆发（如流量持续 <118 L/min、振动阶跃不回落、电机温度持续爬升突破 92℃）；
  2. 多域协同越限（同一 ≤±5 s 窗口 ≥2 个物理域同时 |z|>2 且游程 >60 s）；
  3. 滞后补偿 CCF 在 ±20 s 出现稳定优势滞后（plateau span>0.1）且方向与本体矛盾；
  4. V→I 耦合消失或反向（r≤0），或同工况电流持续缓升；
  5. ≥30 min 记录分钟级重采样在 ≥600 s 滞后出现显著负向热耦合。

---

## 7. 证据附录

### 7.1 证据等级总览（`04_diagnostics/evidence.json`，共 23 条）

| 等级 | 数量 | 代表 |
|:---:|:---:|------|
| L1 直接测量统计 | 8 条数值证据（rank 3 为验证统计） | feature_summary 全通道统计 |
| L3 验证统计 | 6 条 validation_evidence | anti_spurious / time_lag / causal_evidence_map |
| L4 metadata-backed 视觉 | 4 条 visual_evidence | 对齐图 / 对照图（非像素读取） |
| L5 本体物理 | 5 条 physical_evidence | ST0-ST3 治理方程 |

### 7.2 关键数值证据（含来源文件与数字）

- `02_processed/production_regime_filter.json`：steady 9378/9405 = **0.997129**；低电流段 605 行 / 6.43%、最长游程 3 s。
- `02_processed/anti_spurious_verification.json`：V→I raw **+0.472287** / 去趋势 +0.472526 / 差分 +0.490364 / 三分层 [0.470612, 0.481683, 0.465011] / LOO maxΔr=0.001058；T~TC -0.8906→-0.572/+0.014；TC~Flow +0.8300→+0.5827/-0.0285。
- `02_processed/physics_check.json`：P2 工作点 flow_mean=**125.237 L/min** vs 目标 125（1.002）、pressure_steady_std=0.253 Bar；P4 越限率 0.117–0.946%（高斯参考 0.27%）；P5 流量低谷 min **118.0 L/min（-4.51σ）**、87 s 游程、窗口泵侧无响应；P8 热平衡 91.1637→88.7664℃ / 26.8781→29.3510℃ / 间隙 64.2856→59.4154℃；P3 压力 9 台阶、步长 0.3279 Bar。
- `02_processed/feature_summary.json`：8 通道 n=9405 无缺失——Accel1 [0.1882, 0.2272] g、Accel2 [0.2481, 0.2799] g、Temperature [88.1713, 91.7249]℃、Thermocouple [26.8508, 29.5221]℃、Flow [118, 128.353] L/min、Voltage [201.365, 252.806] V、Current [0.8553, 3.2415] A、Pressure [-1.257, 1.3664] Bar。**注意**：Accel1 极小值 0.1882 g 低于带下缘 0.19 g（本报告按 MAJOR-1 披露，不以"极值全部带内"表述）。
- `02_processed/time_lag_analysis.json`：9 对 ±20 s CCF，significant_lags_found=0；V~I 最优滞后 0 s；热对 plateau span=0.000991。
- `02_processed/causal_evidence_map.json`：8 refuted + 2 no_link + 1 validated_moderate；root_cause_candidates=[]。
- `02_processed/validate_report.json`：time_sorted=true；Simpson=0、outlier_driven=0、trend_confounded=2（已随慢漂组证伪）、fatal=0、change_points=1（启动段）。

### 7.3 物理证据（本体，`01_ontology/ontology.json`）

7 条关系先验（V→I 功率耦合 / I→T 铜损热 / Q→P 工作点 / I→振动弱耦合 ×2 / T→TC 传热 / P→A1 气蚀阈值通道）+ 3 个混杂变量登记（Voltage 未控但路径不活跃：V~Accel1 r=+0.0074、V~Flow r=+0.0387；valve_position 视为恒定 AMB-04；ambient_temperature 未测量）+ 2 条 discrepancy_signal（热反相关→P8 消解；压力量化→P3 消解），全部闭环留档。

### 7.4 验证与复算

- Judge 独立重算（`05_review/judge_feedback.json` spot_check_findings）：3 组相关 + 全部描述统计 + 越限率 + 异常窗口审计，**零偏差**（correlations_sampled=3, verified=3, questionable=0）。
- 物理审计独立复算（`05_review/optimizer_preflight.md` 第三节）：9 组关键数字全部精确复现（多数到小数点后 6 位）；1 处不符即 MAJOR-1 带内声明，已按第五节修复指令落实。

### 7.5 证据全景与结论可靠性总览

```
数据观测               统计分析                物理验证              结论
────────────        ────────────           ────────────        ────────
8通道窄带+稳态99.71% → 强相关四重证伪为慢漂   → ST2热平衡收敛轨迹   → 正常稳态
V→I r=+0.472 lag0   → 六重检验全过           → ST0功率耦合一致     → （唯一存活耦合=正常）
越限≤25s单域自恢复   → 发生率≈高斯0.27%       → 量化伪迹/劣化反方向 → 无故障（DETERMINED 86）
```

| 结论 | 统计 | 物理 | 时序 | 无混淆 | 综合 | 信度 |
|------|:---:|:---:|:---:|:---:|------|------|
| H1 正常稳态运行 | ★★★★☆ | ★★★★★ | ★★★☆☆ | ★★★★☆ | **86** | HIGH |
| H2 传热反向 | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | **已排除(95)** | — |
| H3 跨域耦合 | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | **已排除(95)** | — |
| H4 尖峰起点 | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | **已排除(92)** | — |
| H5 泵劣化/气蚀 | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | ☆☆☆☆☆ | **已排除(93)** | — |

### 7.6 图表索引

| 图 | 类型 | 一句话发现 |
|----|------|----------|
| `03_figures/fig_temporal_overview.png` | 8 面板时序网格（±3σ） | 定位全部三个越限窗口（行 36–51 / 1987–2011 / 9187–9208） |
| `03_figures/fig_thermal_drift_confounding.png` | 原始 vs 去趋势对照 | raw -0.891 为收敛轨迹伪相关；去趋势 -0.572、差分 +0.014 |
| `03_figures/fig_vlm_temporal_overlay_single_product.png` | z-normalized 对齐 overlay（MANDATORY） | 主导形态=启动热平衡收敛；无带外漂移/阶跃/方差爆发 |
| `03_figures/fig_vlm_temporal_overlay.png` | 全局 overlay（交叉核对） | 与单工况视图结论一致 |
| `03_figures/fig_vlm_synchronization.png` | 滚动相关热图 | G1 慢漂组 + G2 电气同步组；precedence 信号为空 |

### 7.7 审计修正落实记录（`05_review/optimizer_preflight.md` 第五节 → 本报告）

| 编号 | 审计要求 | 落实位置 |
|------|---------|---------|
| MAJOR-1 | 禁用"8/8 通道极值全程带内"，改为 7/8 + Accel1 0.1882 g 单点越界 0.9% | 1 节"带内表述"、4.4 节窗口 2、7.2 节注 |
| MINOR-2 | 振动下探引用单点极值 -5.14σ/-5.10σ（行 9199），注明 -3.7/-2.8σ 为窗口均值 | 4.4 节窗口 2 |
| MINOR-3 | "无漂移"限定为"无劣化方向单调漂移 + 带内慢升（Flow +1.63 L/min/h 自洽）" | 4.5 节 |
| MINOR-4 | 披露 556 处单样本（2 s）采样空洞 ≈5.6% | 3 节表格 |
| MINOR-5 | V→I 表述为"与正常电气运行一致"，不写一阶物理证明正号 | 4.1 节 |

Judge 非阻断建议落实：流量恢复统一口径（4.4 节窗口 1，声明工件差异与 Judge 重算值）；Spearman 散度 MODERATE 条目说明（4.2 节）。

---

## 8. 建议与后续（行动方案）

### 8.1 P0 — 立即执行（本周内）

| 行动 | 具体操作 | 预期效果 | 如何验证 | 时间 |
|------|---------|---------|---------|:--:|
| 维持运行，无需检修 | 不安排停机；本记录归档为健康基线 | 避免不必要的检修损失 | 后续记录与 8.4 基线比对 | 立即 |
| 配置报警规则 | 按 6.5 节 5 条证伪条件设置报警（流量 <118 L/min 持续 >60 s；≥2 域协同 |z|>2 且 >60 s；振动 RMS 阶跃不回落；电机温度 >92℃ 持续爬升；V→I r≤0） | 防止漏报真实故障 | 报警系统回放测试 | 本周 |

### 8.2 P1 — 短期计划（本月内，按信息增益排序，`04_diagnostics/reasoning_chain.json` R8）

| 行动 | 具体操作 | 预期效果 | 时间 |
|------|---------|---------|:--:|
| 增设环境温度测点 | 在水箱/回路附近加装温度通道 | 直接控制热工慢漂共同原因（混杂 16/20 → 提升） | 1 周 |
| 长记录 + 分钟级重采样 CCF | 采集 ≥30 min（≥3 倍热时间常数）等工况记录，执行 ≥600 s 滞后 CCF | 关闭热滞后不可检验缺口；置信上限 90→≈95 | 1 次采集 |
| 流量计瞬态核查 | 调阅行 1987–2011（14:06 前后）流量计诊断日志/原始脉冲 | 区分仪表瞬态 vs 真实微扰动（H4 残余不确定性 92 项） | 0.5 天 |

### 8.3 P2 — 中期计划（条件成熟时）

| 行动 | 前提条件 |
|------|---------|
| 压力 ADC 分辨率升级至 <0.05 Bar | 消除 9 台阶（0.33 Bar）量化盲区，使压力通道可用于小幅异常判读 |
| 补阀位开度/转速指令列 | 直接验证"工作点恒定"假设（当前为平稳窄带间接支撑） |
| 接入独立检验/质量流 | 激活 dual-drive 路径 B（当前 process_only 不可建立） |
| 供电/滑差效应定量核查 | 解释 V→I 正相关符号（一阶模型预测负号，见 4.1 节 [PHYSICS_UNVERIFIED]） |

### 8.4 监控基线与报警阈值（`04_diagnostics/diagnosis.json` predicted_observables）

| 监控指标 | 当前基线 | 报警阈值（本 run 证伪条件） |
|---------|:------:|:------:|
| 流量均值 | 125.24±1.61 L/min | 持续 <118 L/min >60 s 或相对目标衰减 >2% 不恢复 |
| 压力稳态 σ | 0.253 Bar | 方差爆发或工作点迁移 |
| 振动双测点 | 0.2126 / 0.2684 g 窄带 | RMS 水平阶跃（ISO 10816 区域迁移） |
| 电机温度 | 89.47℃（带 [88,92]） | 持续爬升突破 92℃ 或与电流同向异动 |
| V→I 耦合 | r≈+0.47，lag 0 | r 转为 ≤0 或耦合消失 |
| 越限事件形态 | ≤25 s、单域、自恢复 | 多域协同（≤±5 s 窗 ≥2 域 \|z\|>2）且不恢复 |

---

## 9. 方法学注记与局限

### 9.1 方法

反虚假相关性六重检验（稳态过滤→去趋势→1 s 一阶差分→±20 s 滞后补偿 CCF→时间三分层→留一/稳态滤波，`06_scripts/anti_spurious_verify.py` 全分辨率 n=9405）；竞争假设协议（≥3 假设、判别矩阵、量化排除 + 复活条件）；物理检查 P1–P8（`02_processed/physics_check.json`）；本体引导角色分组 + 混杂登记。RAG 不可用，按规程回退（parameter_to_physics 模板 + 数据自描述），无外部网络检索。

### 9.2 局限（诚实清单）

| 类型 | 局限 | 影响 |
|------|------|------|
| 数据盲区 | 环境温度未测量 | 热工慢漂共同原因仅能间接排除（已扣分 -4） |
| 数据盲区 | 热通道真实滞后 ≥600 s 超出 ±20 s 搜索窗 | ST2 传热时间维度不可检验（不可检验 ≠ 反证） |
| 数据盲区 | 阀位/转速无控制列 | 工作点恒定为间接推断 |
| 数据盲区 | 压力分辨率 0.33 Bar | 小幅压力异常存在盲区 |
| 数据盲区 | **556 处 2 s 采样空洞（≈5.6%）** | 游程时长按样本计，误差 ≤1 s/窗口，不影响判据 |
| 数据盲区 | 采样标签"2000-of-9405"为制备遗留（实际 9405 行） | 纯溯源标签瑕疵，数值经重算确认 |
| 方法局限 | 非 VLM 环境，视觉证据全部 metadata-backed | 无像素级形态学新信息；判别全部由定量统计承载 |
| 方法局限 | process_only 视图 | dual-drive 路径 B 不可建立 |
| 物理不确定性 | V→I 正号机制未定量（一阶模型预测负号）[PHYSICS_UNVERIFIED] | 不承载故障排除权重；P2 建议核查 |
| 残余不确定性 | 流量瞬态微观成因（仪表 vs 真实微扰动）本数据内不可进一步区分 | H4 排除置信度定为 92 而非更高 |

### 9.3 什么新证据会推翻结论

见 6.5 节 5 条证伪条件；每条均可由后续记录直接检验。整体置信上限 90（当前 86），剩余 14 分缺口与上述局限逐条对应（`04_diagnostics/confidence.json`）。

---

**报告生成**: reporter（Engineer Zhou） | Step 6 | 输入工件: 04_diagnostics/*.json、05_review/judge_feedback.json（97/pass）、05_review/optimizer_preflight.md、02_processed/*、01_ontology/ontology.json、03_figures/plot_manifest.json | 本报告全部数字可溯源至引用工件。
