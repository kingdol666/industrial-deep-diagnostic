# 工业诊断报告 — bench_tep_d00_normal_control（TE过程 d00 正常工况闭环稳态段）

- 运行目录：`D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171633136_bench_tep_d00_normal_control`
- 报告人：Engineer Zhou（reporter，Step 6）｜Judge 闸门：PASS（96 分，第 1 轮，无修复轮次）｜Step 5b 物理预审计：PREFLIGHT_PASS（0 FATAL / 0 MAJOR / 5 MINOR，5 条 Reporter 修正指令已全部落实到本报告）
- 结论三态：**DETERMINED — 无故障**｜总体置信 90/100（HIGH）｜诊断视图：process_only 单驱动、全变量监测

---

## 1. 执行摘要

**结论一句话：本次 48 小时数据不存在故障——全过程为单一闭环稳态工况，观测到的全部波动均可由正常的执行器律、串联压降物理、蒸汽潜热加热与闭环反馈控制语义定量解释，无需任何检修动作。**

- **判定与置信**：`04_diagnostics/diagnosis.json` 给出 DETERMINED：唯一存活假设 H1（正常闭环稳态运行）置信 92/100，总体置信 90/100（HIGH，较 H1 保守折减 2，理由为未测混杂与 48h 单窗口）；三个故障假设 H2（缓慢漂移）/H3（汽提塔蒸汽回路故障）/H4（测量伪影）分别以 95/93/92 的排除置信度剔除，全部 6 个假设对 DISCRIMINABLE，不触发 COMPETING_SET 置信封顶。
- **无故障的四重证明结构**：(1) 漂移有界——52 列持久 240 样本块均值漂移最大 0.268σ（XMEAS_39），审计更严口径（步长 1 全扫描）复测最大 0.426σ（XMEAS_18），均低于 0.5σ 判据，且 `02_processed/anomaly_report.json` 的 transition_events=[]（0 次转变事件）；(2) 反馈签名——两处与开环预测"反号"的相关（XMV_10~XMEAS_9 = +0.6818、XMEAS_21~XMEAS_9 = -0.3298，均为 lag-0 值）恰为闭环反馈的预期健康签名（T9 升 → PI 开大冷却阀 → T21 降），被 `02_processed/physics_check.json` 的 closed_loop_sign_inversions 定量解释而非掩盖；(3) 瞬态有界可回复——汽提塔蒸汽回路 6 个瞬态窗幅值全部有界（XMEAS_18 全程 [64.304, 66.975] °C、XMV_9 全程 [39.353, 55.624]% 远离饱和），产品纯度 G+H 均值 97.584 mole% 不受影响；(4) 物理闭合——5/5 独立物理校验 PASS（组成闭合/串联压降/纯度/温度带），8/8 引用相关对经滞后补偿/时间分层/留一验证为真实（留一最大偏移 0.00533）。
- **业务影响**：产量与质量无损失（纯度 97.584% 与本体基准 97.6% 吻合）；不建议停车检修。
- **建议行动（详见 §8）**：P0 = 维持运行、无需动作；P1 = 持续监测 XMEAS_39 的持久漂移与 XMV_9 的阀门行程带；P2 = 有条件时补测冷却水入口温度等混杂变量、补跑 VLM 视觉分析、质检数据到位后补做双驱动分析。
- **质量闸门**：Judge 十项准则均 9-10 分、总分 96、0 阻塞项，8/8 抽检相关全部复算吻合；Step 5b 物理审计独立复算 15 项关键数字，12 项逐位精确吻合，5 条 MINOR 级修正指令（滞后标签、σ 口径、量化伪迹归因、本体措辞、变化点计数器）已按指令在本报告中改正。

## 2. 诊断背景与数据概览

- **工艺对象**：Tennessee Eastman（TE）连续化工过程——反应器（CSTR，操作点约 120.4 °C / 2705 kPa）-产品冷凝器-气液分离器（约 2634 kPa）-循环压缩机-蒸汽汽提塔（约 65.9 °C）五设备串级，多回路 PI 闭环控制，生产 G/H 产品混合物（目标 G+H ≈ 97.6 mole%），经放空移除惰性组分 B（`01_ontology/ontology.json` scene 定义：d00 正常工况闭环稳态运行段）。
- **数据概况**：`00_input/data.csv`，960 行 × 52 数值列 + timestamp；3 分钟均匀采样（dt 唯一值 180 s），覆盖 2020-01-01 00:00 至 2020-01-02 23:57 共 48 h；41 列 XMEAS 过程测量（含 23-41 为 GC 组成分析信号）+ 11 列 XMV 操纵变量（`00_input/input_manifest.json`）。
- **用户问题**：诊断本次数据的根本原因。经核验，用户所指的"异常"在数据中仅表现为孤立 3σ 尾部点与有界瞬态两类正常包络现象，不构成故障级异常——本报告如实给出"无故障"结论，而非制造故障叙事（诚实三态原则）。
- **监测模式**：无用户指定目标列 → 全变量监测；无产品/批次分组列（multi_product_grouping.exists=false）→ process_only 单驱动视图，以时间前后半层分层替代产品分层；双驱动（工艺+质检）Path B 不适用并记录为证据缺口（`02_processed/data_analysis_conclusion.json` adaptive_decision_audit.mode_justification）。
- **场景先验与验证纪律**：`02_processed/scenario_classification.json` 给出 normal_baseline_control / continuous_chemical / high confidence 的场景先验；诊断未假设该先验成立，而是以稳态检验、反伪相关基线与物理闭合校验逐项验证数据确实匹配场景。

## 3. 数据质量评估

- **时序有效性**：960 个时间戳严格单调、步长唯一（180 s），time_sorted=true（judge 独立复核成立）——滞后分析前提成立（`02_processed/validate_report.json` sorting_validation）。
- **数据完整性**：`02_processed/cleaned_data.csv` 与 `00_input/data.csv` 逐行逐格完全一致（0 行差异，Step 5b 审计核对），无未申报的清洗改写。**缺口如实披露**：cleaning_integrity 未记录（Phase 2.2.5 未运行），清洗溯源链不完整（`02_processed/data_analysis_conclusion.json` data_cleaning_provenance）。
- **有色噪声与量化**：闭环噪声自相关强（lag-1 自相关最高 0.994，属蒸汽回路变量 XMV_9=0.9964 / XMEAS_18=0.9941；反应器温度 XMEAS_9 自身 lag-1 自相关仅 -0.218 且重度量化——仅 13 个取值、步长 0.01 °C）。该两条数据形态直接影响 §4 中对孤立 3σ 点的归因（Step 5b 审计 MINOR-03）。
- **GC 死区（已受控补偿）**：进料/放空死区 0.1 h、产品 0.25 h，均在滞后补偿 CCF（±20 采样 = ±60 分钟）覆盖范围内；无任何 GC 组成对为承载性结论证据（`02_processed/time_lag_analysis.json` scope_note）。
- **异常扫描结果**（`02_processed/anomaly_report.json`）：XMEAS_9 仅 7 个孤立单样本 3σ 点（行 30/60/373/430/477/805/938，占比 0.729%，severity=low）；XMEAS_7 零异常；全 52 列 max|z| ≤ 3.97；transition_events=[]；quality_reset_analysis.reset_found=false。

![关键变量时序网格图（±3σ 阈值线）](03_figures/fig_temporal_overview.png)

图 3-1（caption 级，`03_figures/image_captions.json`）：max|z| 前三为 XMEAS_15 / XMV_8（3.97，超 3σ 占比 0.2%）与 XMEAS_36（3.85，占比 0.4%）；无持续越限形态，仅孤立尾部点——与异常扫描数值互证。

## 4. 统计分析发现

### 4.1 稳态/工况检验（解释一切波动的前提）

- 单一工况：n_regimes_detected=1，960 行全部保留（excluded_regimes 空、caution_regimes 空），verdict 为 "single closed-loop steady-state operating regime across all 960 rows"（`02_processed/production_regime_filter.json`）。
- 持久漂移：52 列中最大 240 样本块均值漂移 0.268σ（工件值 0.2681σ @ XMEAS_39，审计复算逐位吻合；次高 XMEAS_40 约 0.246σ、XMEAS_41 约 0.245σ）。审计另按更严口径（240 块步长 1 全扫描）复测：最大 0.426σ @ XMEAS_18——**仍低于 0.5σ 判据**，"单一稳态工况"在更严格解释下依然成立。
- 无转变：以 `02_processed/anomaly_report.json` 的 transition_events=[] 与上述持久漂移检验为"无工况阶跃"判据。（按审计 MINOR-04 指令，本报告不引用 validate_report 的 change_points_detected=0 summary 计数器——其明细层存在短段过分割噪声，如 XMEAS_9 列出 83 个原始分割点但 has_regime_change 均=false、最大段均值偏移仅 0.0127 °C。）
- 前后半段位移（σ 口径）：全部 52 列前后半段均值位移最大 0.219σ（审计复算 0.2187σ）——远低于工况阶跃量级。（按审计 MINOR-02 指令，工件 "<0.35%" 的百分比表述不可复算，本报告一律改用 σ 口径。）

### 4.2 八个本体导出引用相关对（全部以 lag-0 r 为准值）

| # | 变量对 | 机理类别 | lag-0 r（准值） | 验证 |
|---|---|---|---|---|
| 1 | XMV_3 ~ XMEAS_1 | 执行器律 Q=f(opening) | 0.9966 | verified_real |
| 2 | XMV_6 ~ XMEAS_10 | 执行器律（放空阀-流量） | 0.9518 | verified_real |
| 3 | XMV_9 ~ XMEAS_19 | 执行器律（蒸汽阀-蒸汽流量） | 0.9873 | verified_real |
| 4 | XMEAS_19 ~ XMEAS_18 | 蒸汽潜热加热 Q=ṁ_steam·λ | 0.9535 | verified_real |
| 5 | XMEAS_7 ~ XMEAS_13 | 串联压降物理 | 0.9967 | verified_real |
| 6 | XMV_10 ~ XMEAS_9 | 闭环反馈（冷却阀-反应器温度） | +0.6818 | verified_real |
| 7 | XMEAS_21 ~ XMEAS_9 | 闭环热平衡（冷却出口温度-反应器温度） | -0.3298 | verified_real |
| 8 | XMEAS_12 ~ XMV_7 | 液位控制器 1:1 跟踪（控制实现细节，非独立物理证据） | 1.0000 | verified_real |

（数值来源：`02_processed/causal_evidence_map.json`，judge 与 Step 5b 审计对 `00_input/data.csv` 全 960 行独立复算逐位吻合。）

**滞后口径的诚实披露（审计 MINOR-01 修正）**：8 对的 |r| 全局峰值均在 **lag 0**（复算确认：XMV_10~XMEAS_9 lag0=+0.6818、XMEAS_21~XMEAS_9 lag0=-0.3298；lag±1 仅 -0.23~-0.30 量级）。上游工件 `02_processed/time_lag_analysis.json` 标注的"闭环对最优 lag 1-2（r=0.6828/-0.3310）"经审计复算**不可复现**，本报告不采用该归因，改述为："lag-0 主峰 + 1-2 采样次级 CCF 结构（与分钟级热惯性相容）"。附带地，审计复算实际**加强**了因果方向读法：XMV_9 领先 XMEAS_19 约 1 采样（r=0.9898 > lag0 的 0.9873），XMEAS_19 领先 XMEAS_18 约 3 采样（r=0.9620 > lag0 的 0.9535），落在本体 1-4 采样（3-12 分钟）热惯性带内。

### 4.3 反伪相关基线与稳健性

- 基线全净：0 Simpson 悖论、0 趋势混淆相关、0 离群驱动相关、0 Spearman 分歧、0 fatal/serious/moderate，overall_validity=**ROBUST**（`02_processed/validate_report.json`）。
- 逐对复验（`02_processed/causal_evidence_map.json`）：滞后补偿 CCF(-20..+20) + 前后半层分层（8/8 对半层一致，差值 ≤ 0.057，如 XMV_9~XMEAS_19 前后半层 0.9653/0.9923）+ 留一杠杆（最大绝对偏移 0.00533）+ 稳态过滤（excluded_rows=0）→ **8/8 verified_real、0 flagged**。高相关不是离群点或时段伪象。

### 4.4 两处"符号矛盾"的定量解释（健康签名，非故障）

开环本体预测冷却阀开度与反应器温度反相、冷却出口温度与反应器温度同相；实测恰相反（+0.6818 / -0.3298，lag-0）。`02_processed/physics_check.json` closed_loop_sign_inversions 给出完整控制语义链：T9 升 → 温度 PI 开大冷却阀 XMV_10 → 冷却出口 T21 降——闭环反馈把开环反号协方差反转为同号。前后半层符号一致（0.6889/0.6749 与 -0.3524/-0.3077），留一偏移 ≤ 0.00533。**矛盾没有被掩盖，而是被解释**——这是"正常稳态"判定的核心物理论证。

### 4.5 唯一动态特征：汽提塔蒸汽回路的有界瞬态

- 6 个瞬态窗（起止索引 232-237 / 287-318 / 524-563 / 756-779 / 804-862 / 887-935，时长 18-177 分钟），块均值相对全局 -2.4σ 至 +1.8σ（复算逐窗吻合：1.303/-1.286/-1.379/1.426/-2.398/1.763 σ，Step 5b 审计 INFO-05）。
- 幅值有界：XMEAS_18 全部观测落在 [64.304, 66.975] °C（总跨度 2.67 °C），XMV_9 全程 [39.353, 55.624]% 远离 0/100% 饱和限（均经审计从 `00_input/data.csv` 精确复算）。
- 可回复：4/6 窗后回复全局均值；其余 2 窗紧邻序列末端，其后 240 样本块均值在审计的三种口径下均有界（+0.0149σ / +0.0682σ / +0.142σ，全部远小于 0.5σ 判据；XMEAS_18 持久漂移仅 0.145σ）。rolling-40 最大游走 2.817σ（审计复算 2.8156σ，ddof 差异）判为有色噪声游走而非工况阶跃。
- 质量后果缺席：产品纯度 G+H 均值 97.584 mole% [95.312, 99.694] 与本体基准 97.6 吻合——瞬态未冲击产品质量。蒸汽回路有效增益 ≤ 0.17 °C/%（审计复算 0.1642），为正常回路量级。

### 4.6 孤立 3σ 点的归因（审计 MINOR-03 修正）

XMEAS_9 的 7 个孤立单样本 3σ 点（|z|=3.01-3.03，全部擦着阈值、无集聚、无转变事件）定性为 **0.01 °C 量化步长下的阈值擦边伪迹**。按审计 MINOR-03 指令，本报告不将其归因于 XMEAS_9 自身的 0.994 有色噪声自相关（该自相关属蒸汽回路变量 XMV_9/XMEAS_18；XMEAS_9 自身 lag-1 自相关仅 -0.218），也不引用手工验证 M5 的"统计期望比 ~1"（审计复算：高斯白噪声期望约 2.6 点 vs 实测 7 点，该论证数量上不成立）。该归因修正**不动摇判定**：单样本、无集聚、无转变、回路 CV 0.016%、纯度正常五项事实独立成立。

### 4.7 视觉通道（元数据级，诚实降级）

`03_figures/visual_analysis.json` 为 pre-VLM skeleton（observation_mode='skeleton_pre_vlm'，7 张 overlay 图 read_status 全部 READ_FAILED，vlm-visual-analyzer 未运行）。其元数据摘要记录：synchronous_groups=[]、precedence_signals=[]、"no sustained cross-parameter band shift anywhere in the run"——与单一稳态结论一致。本报告不基于未读图像作任何像素级视觉断言（诊断与报告全程以 [元数据/caption 模式] 显式标注）。

![本体导出引用变量对的滞后补偿CCF曲线](03_figures/fig_cited_pairs_ccf.png)

图 4-1（caption 级）：8 对滞后补偿 CCF 曲线（-20..+20 采样）；阀门-流量对峰值在 lag 0 且 r ≥ 0.95，串联压力对 lag0 r=0.9967，闭环对呈 lag-0 主峰 + 次级 CCF 结构、符号与反馈反相预测一致。

## 5. 竞争假设检验与排除逻辑

| 假设 | 机制类 | 内容 | 判定 | 置信 |
|---|---|---|---|---|
| H1 | OPERATION | 正常闭环稳态运行（含正常反馈签名与有界可回复瞬态） | **存活** | 92/100 |
| H2 | DRIFT | 缓慢工艺漂移/催化剂失活/设定值偏移 | 排除（STATISTICAL） | 排除置信 95 |
| H3 | WEAR/OPERATION | 汽提塔蒸汽回路故障（阀卡涩/传感器失效/失控振荡） | 排除（COMBINED） | 排除置信 93 |
| H4 | ENVIRONMENT | 测量/传感器伪影或 GC 死区伪相关 | 排除（COMBINED） | 排除置信 92 |

- **排除逻辑（摘要）**：H2 被时间结构排除——持久漂移 0.268σ < 0.5σ、0 转变事件、前后半段均值位移 0.219σ、趋势混淆指纹为 0；H3 被幅值/行程/完好性/质量后果四重独立判据排除——瞬态有界 [64.304, 66.975] °C、XMV_9 ∈ [39.353, 55.624]% 无饱和、执行器律 r=0.9873 完好、纯度 97.584% 未受冲击；H4 被物理闭合排除——5 个独立闭合关系（组成和/压降/纯度/温度带）同时 PASS，伪影无法协同伪造，且伪相关统计指纹全零。每个被排除假设均附量化复活条件（见 §8.2）。
- **可区分性**：全部 6 个假设对 DISCRIMINABLE（判别信号具体可用，`04_diagnostics/diagnosis.json` discriminability_matrix）——不存在 INDISTINGUISHABLE 对，DETERMINED 路径合法，65/50 置信封顶不适用。
- **H5（进料组成扰动）**：并入 H1/H4 判据——进料组成未测量，其效应只能经由组成闭合（进料和 94.80 稳定）与产品纯度（97.584% 正常）体现，二者均正常（`04_diagnostics/reasoning_chain.json` R4）。

## 6. 根因结论

### 6.1 诊断结论

**DETERMINED：无故障。48h 全段为单一闭环稳态工况，观测波动全部由正常控制与物理机制产生；无需检修动作。**核心证据：持久漂移 ≤ 0.268σ（严口径 0.426σ，均 < 0.5σ）+ 0 转变事件；8/8 引用相关为闭环控制签名（lag-0 准值）；唯一动态特征为有界可回复的汽提塔蒸汽回路瞬态（纯度不受影响）；5/5 物理闭合校验 PASS。H1 置信 92，总体置信 90（HIGH）。

### 6.2 物理机理链与推理过程

六条链路全部 ALL_LINKS_VALIDATED（`04_diagnostics/diagnosis.json` chain_link_validation），每条链路有治理方程 + lag-0 准值 + 分层/留一稳定：

1. **进料执行器律**：XMV_3（24.62%±3.04）→ Q=f(opening) → XMEAS_1（0.2502±0.0309 kscmh），r=0.9966@lag0，前后半层 0.9951/0.9975，留一偏移 6e-05。
2. **蒸汽执行器律**：XMV_9（48.41%±2.86，行程带 [39.35, 55.62]%）→ Q_steam=f(opening) → XMEAS_19（234.02±10.79 kg/hr），r=0.9873@lag0，远离饱和限位。
3. **蒸汽潜热加热**：XMEAS_19 → Q=ṁ_steam·λ → XMEAS_18（65.853±0.464 °C），r=0.9535@lag0；审计复算最优对齐在约 3 采样（9 分钟）超前，落在本体 1-4 采样热惯性带——因果方向由数据自身滞后结构支持。
4. **闭环温度反馈**：XMEAS_9（120.4002±0.0198 °C）→ PI 控制律 → XMV_10 → XMEAS_21：观测 +0.6818 / -0.3298（lag-0）与闭环反相语义逐一吻合。
5. **串联压降物理**：XMEAS_7（2705.66±6.88 kPa）→ XMEAS_13（2634.42±7.17 kPa）。该物理对由**本体串联压降治理律导出**（`01_ontology/ontology.json` process_parameters[12]：P_sep = P_reactor − ΔP_condenser 管线；另见 relationships[27] P16 ≈ P13 + ΔP_pump）——按审计 INFO-06 措辞指令，表述为治理律落点而非本体 30 条 relationship 边之一。恒定压降 71.24±0.64 kPa（CV 0.9%，占操作压 2.63%），r=0.9967@lag0。
6. **组成/质量平衡自洽**：purge 八组分和 99.98 mole%（max|dev| 1.843）、进料六组分和 94.80、产品 G+H 97.584——与本体自洽基准吻合（`02_processed/physics_check.json`）。

推理过程：稳态前提先行（regime 检验）→ 高相关结构三类归位（执行器律/开环物理/闭环反馈）→ 逐对反伪复验 → 符号矛盾按控制语义定量解释 → 排除三个故障假设 → DETERMINED。本体预测、数据行为与物理机理三者一致（functional_form/lag/direction 均 MATCH，magnitude 比值 0.54 < 1，overall_proof_strength=PROVEN）。

### 6.3 推理链（R1-R8）摘要与置信体系

`04_diagnostics/reasoning_chain.json` 八段推理链完整：R1 数据表征（960×52、3 分钟、48h）→ R2 统计发现与多源融合（三类相关结构 + 视觉元数据降级使用）→ R3 验证过滤（8/8 ROBUST）→ R4 竞争假设生成（4 假设，初始置信 55/50/45/40）→ R5 可区分性（6/6 DISCRIMINABLE）→ R6 排除验证（95/93/92，无 [WEAK_EXCLUSION]）→ R7 诊断结论（DETERMINED）→ R8 不确定性界定。

置信体系（`04_diagnostics/confidence.json`）：H1 五因素分解 24+23+18+18+9=92（统计 24/25、物理 23/25、时序 18/20、混杂 18/20、症状完备 9/10）；调整日志 +15（物理 PROVEN）/+5（反伪全净）/−2（有色噪声折减）可完整重构；ALL_CRITERIA_VERIFIED 封顶 95 未触及；总体保守折减至 90。Judge 已双向验算（adjustment_log 55+10+15+5−2+9=92）。

## 7. 证据附录与证据全景

### 7.1 核心证据清单（含关键数字与出处）

| 证据 | 关键数字 | 出处 |
|---|---|---|
| 稳态/漂移检验 | n_regimes=1；持久漂移 max 0.2681σ @XMEAS_39（严口径 0.426σ）；960 行全保留 | `02_processed/production_regime_filter.json` |
| 无转变事件 | transition_events=[]；reset_found=false | `02_processed/anomaly_report.json` |
| 8/8 引用相关 | lag-0 r：0.9966/0.9518/0.9873/0.9535/0.9967/+0.6818/−0.3298/1.0000；留一 max shift 0.00533 | `02_processed/causal_evidence_map.json`（judge/审计逐位复算吻合） |
| 反伪基线 | 0 Simpson/0 趋势/0 离群/0 Spearman；ROBUST | `02_processed/validate_report.json` |
| 物理闭合 5/5 | purge 和 99.98（max dev 1.843）；进料和 94.80；G+H 97.584 [95.312,99.694]；ΔP 71.24±0.64 kPa（2.63% 操作压）；温度带 99.27% 在 ±3σ 内 | `02_processed/physics_check.json` |
| 有界性判据 | XMEAS_18 ∈ [64.304, 66.975] °C；XMV_9 ∈ [39.353, 55.624]%；有效增益 0.1642 °C/% | `00_input/data.csv`（L1 复算）+ Step 5b 审计 |
| 异常扫描 | XMEAS_9 7 个孤立 3σ 点（行 30/60/373/430/477/805/938，0.729%，max z=3.033）；全列 max z ≤ 3.97 | `02_processed/anomaly_report.json` + `00_input/data.csv` 复算 |
| 闭环符号解释 | closed_loop_sign_inversions：+0.6818 / −0.3298 为反馈预期签名 | `02_processed/physics_check.json` |
| 置信重构 | 24+23+18+18+9=92；调整 +15/+5/−2；overall 90/HIGH | `04_diagnostics/confidence.json`（judge 验算通过） |
| L1 直接复算 | XMEAS_9 mean=120.4002/std=0.0198/[120.34,120.46]，CV 0.016%；瞬态 6 窗界 | `00_input/data.csv`（960 行，venv python） |

### 7.2 对齐图与 CCF 图（caption/元数据级，VLM 未运行）

以下 7 张 overlay 图已渲染但未被 VLM 判读（read_status=READ_FAILED）；嵌入仅作形态参考，其元数据摘要（无同步组、无跨参数持续带移）已计入 §4.7，不构成像素级视觉证据。

![单工况时序对齐 overlay g1](03_figures/fig_vlm_temporal_overlay_single_product_g1.png)

![单工况时序对齐 overlay g2](03_figures/fig_vlm_temporal_overlay_single_product_g2.png)

![单工况时序对齐 overlay g3](03_figures/fig_vlm_temporal_overlay_single_product_g3.png)

![单工况时序对齐 overlay g4](03_figures/fig_vlm_temporal_overlay_single_product_g4.png)

![单工况时序对齐 overlay g5](03_figures/fig_vlm_temporal_overlay_single_product_g5.png)

![全局时序对齐 overlay](03_figures/fig_vlm_temporal_overlay.png)

![滚动相关稳定性](03_figures/fig_vlm_synchronization.png)

### 7.3 证据等级总表

| 等级 | 内容 | 置信贡献 |
|---|---|---|
| L1 直接测量 | 960 行关键变量 mean/std/min/max、有界性判据（复算） | 最高——承载 H3/H2 排除主证 |
| L3 统计分析 | 稳态检验、8 对滞后补偿 CCF、反伪基线、留一/分层 | 高——承载 H1 主证（经全部鲁棒性检验） |
| L4 图表/caption 证据 | fig_temporal_overview、fig_cited_pairs_ccf、overlay 元数据 | 中——诚实标注 caption/元数据级（VLM 缺位扣分 −2 已计入） |
| L5 领域知识/机理 | 本体治理方程、TE 基态交叉印证、手工量级验证 M1-M4 | 中——M5 统计期望论证按审计指令不进入报告 |
| 外部知识 | RAG 不可达（connection refused），未使用外部网页证据 | 不适用（已披露） |

## 8. 建议与后续（行动方案、可证伪条件与局限）

### 8.1 行动方案（P0/P1/P2）

- **P0（立即）**：维持运行，无需任何检修动作。当前纯度 97.584%、无漂移、无饱和、无转变事件——停车检修没有证据支撑。
- **P1（持续监测，1-2 周内落实）**：(1) 监测 XMEAS_39/XMEAS_40/XMEAS_41 的 240 样本持久块均值漂移（当前最大漂移列，0.268σ，距 0.5σ 判据尚有余量）；(2) 监测 XMV_9 行程带（当前 [39.4, 55.6]%，若逼近 0/100% 限位即触发 H3 复审）；(3) 监测产品纯度 G+H（若持续 < 95% 即触发双驱动故障判定）。
- **P2（条件具备时）**：(1) 加装/接入冷却水入口温度与新鲜进料组成测量（本体 confounders 清单前两项，controlled=false）——缩减共模归因的残余自由度；(2) 补跑 vlm-visual-analyzer 以获得像素级形态学证据（当前 7 图 READ_FAILED）；(3) 质检/inspection 数据集到位后补做双驱动 Path B 分析；(4) 下轮数据准备执行 Phase 2.2.5 清洗审计，补齐 cleaning_integrity；(5) RAG 引擎恢复后补做外部知识验证。

### 8.2 可证伪条件（任一触发即推翻"无故障"结论）

1. 任一变量 240 样本持久块均值漂移 > 0.5σ 或出现非空转变事件 → 转入工况偏移诊断（H2 复活）。
2. XMV_9 逼近 0%/100% 饱和且 XMEAS_18 漂移不回复全局均值 → H3 复活。
3. 产品纯度 G+H 持续 < 95%（现均值 97.584%）且与蒸汽/进料扰动同窗 → 过程-质量双驱动故障判定。
4. 8 对引用相关中任一对在滞后补偿/时间分层/留一复验下翻转为伪相关 → 闭环健康签名论据失效，重修因果图。
5. 任一物理闭合校验失败（组成闭合偏离 > 2%、压降漂移 > 5%、温度带越限占比 > 5%）→ H4 复活，重审全部相关证据。

### 8.3 局限与证据缺口（全部如实披露）

无独立质检数据集（"产品未受影响"仅由 GC 纯度列间接支撑）；VLM 形态学证据缺位（非 VLM run，视觉引用均为 caption/元数据级）；RAG 引擎不可达（外部知识验证跳过，物理推理依赖本体+机理 fallback）；cleaning_integrity 未记录（清洗溯源链不完整，但 cleaned_data 与原始数据 0 行差异经审计核对）；未测混杂变量（冷却水入口温度、进料组成、搅拌速率、控制设定）限定定量归因精度但不影响定性结论；48h 单窗口无法覆盖超长时标现象（极缓漂移、季节性冷却水温度）；normal_range 取自本段观测带（自参照基线，已用 TE 基态值交叉印证，且 0.5σ 漂移判据为绝对判据）。

## 9. 方法论说明与推理链边界

- **方法清单**：v6.5 稳态/工况检验（240 样本持久块均值漂移 + 40 样本滚动游走）→ v6.4-v6.7 反伪路径（滞后补偿 CCF ±20 采样、前后半层时间分层、留一杠杆、Simpson/趋势/离群/Spearman 基线）→ 物理闭合校验（组成和/串联压降/纯度/温度带/闭环符号分析）→ 竞争假设协议（≥3 假设、逐对可区分性、四反臆断条件、排除置信 ≥90、量化复活条件）。四反臆断条件（时间结构/统计显著/物理机理/无矛盾）对结论逐条核验通过（`04_diagnostics/diagnosis.json` anti_speculation_four_conditions）。
- **Step 5b 审计修正落实说明**：本报告已按 `05_review/optimizer_preflight.md` 第六节 5 条指令落笔——(1) 全部引用相关以 lag-0 r 为准值，闭环对改述为"lag-0 主峰 + 1-2 采样次级 CCF 结构"，不写"最优滞后 1-2"；(2) 删除 "<0.35%" 口径，改用 σ 口径（0.219σ / 0.268σ / 严口径 0.426σ）；(3) XMEAS_9 的 7 个 3σ 点定性为 0.01 °C 量化步长阈值擦边伪迹，不归因 XMEAS_9 自身有色噪声自相关，不引用 M5 期望比；(4) XMEAS_7~XMEAS_13 表述为治理律导出的物理对（process_parameters[12] + relationships[27]）；(5) "无转变"判据仅引 anomaly_report.transition_events=[] + 持久漂移检验，不引 validate_report 的 change_points_detected=0 计数器。另对审计 MINOR-05（-0.0063σ 数字口径不可复算）采用审计三种复算口径（+0.0149/+0.0682/+0.142σ）替代表述。
- **数据边界**：每个数字均可溯源——L1 数字复算自 `00_input/data.csv`（960 行，venv python），统计数字出自 `02_processed/*.json` 工件并经 judge 与 Step 5b 双重复算；闭环回路不推断控制器-PV 时间先后（双向构造），时序论证仅依赖滞后带与物理时标。
- **报告生成信息**：报告人 Engineer Zhou（reporter）；Judge 闸门 96 分 PASS 后生成；本报告与 `run_summary.json` 一同构成 Step 6 输出，primary_finding 与 `04_diagnostics/diagnosis.json` 逐字一致。
