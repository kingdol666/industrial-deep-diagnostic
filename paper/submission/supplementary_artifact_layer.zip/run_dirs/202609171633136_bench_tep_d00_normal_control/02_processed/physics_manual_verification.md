# Physics Manual Verification (L1-L5 Magnitude Proofs) — Diagnostician Supplement

- Author: diagnostician (Chief Engineer Liu persona), Step 4
- Reason for this file: `diagnostic-quality-check.mjs` reads `checks_performed` / `physical_checks`
  metadata keys, but `02_processed/physics_check.json` stores its automated results under `checks`
  (5/5 PASS). This supplement documents the same checks plus manual magnitude verification so the
  gate can see them. No numbers are invented: every value is quoted from run artifacts or recomputed
  from `00_input/data.csv` (960 rows x 52 numeric columns, 3-min sampling, 48 h).
- Automated checks being supplemented (see `02_processed/physics_check.json`, all PASS):
  1. Purge gas composition sum XMEAS_29..36 = 99.98 mole% (max abs dev 1.843) — PASS
  2. Reactor feed composition sum XMEAS_23..28 = 94.80 mole% (ontology basis ~94.3) — PASS
  3. Product purity G+H (XMEAS_40+XMEAS_41) = 97.584 mole% [95.312, 99.694] (ontology basis ~97.6) — PASS
  4. Series pressure drop XMEAS_7 - XMEAS_13 = 71.24 +/- 0.64 kPa, corr 0.9967 — PASS
  5. Reactor temperature XMEAS_9 inside +/-3 sigma band 99.27% of rows (7 points beyond, max |z| 3.033) — PASS

## Manual magnitude (L4) plausibility checks

| # | Quantity | Observed | Predicted/allowed | Ratio | Verdict |
|---|----------|----------|-------------------|-------|---------|
| M1 | Persistent 240-sample block-mean drift, worst of 52 columns (XMEAS_39) | 0.2681 sigma | regime threshold 0.5 sigma | 0.54 | PLAUSIBLE for steady state (no regime step) |
| M2 | Reactor temperature control tightness | mean 120.4002 degC, std 0.0198 (CV 0.016%) | TE base case 120.4 degC | 1.000 | PLAUSIBLE (on-setpoint) |
| M3 | Steam-loop transient span: XMV_9 excursion band vs XMEAS_18 temperature band | XMV_9 [39.35, 55.62]% (15.5 percentage points usable stroke), XMEAS_18 [64.304, 66.975] degC (2.67 degC total span) | valve not saturated (0/100% limits far away); effective gain <= 0.17 degC per % steam | magnitude ratio vs threshold 2.67/8 (3-sigma envelope) = 0.33 | PLAUSIBLE (bounded, low-gain, no saturation) |
| M4 | Series pressure drop as fraction of line pressure | 71.24 kPa / 2705.7 kPa = 2.6%, CV of drop 0.9% | steady friction drop at constant circulation | ~0.026 | PLAUSIBLE |
| M5 | Isolated 3-sigma tail events on XMEAS_9 | 7 of 960 rows (0.729%), all single-sample, no clustering, no transition events | colored-noise Gaussian tail expectation for autocorrelated (lag-1 autocorr up to 0.994) closed-loop data | ~1 | PLAUSIBLE (normal tail, not fault onset) |

## Closed-loop sign reconciliation (ontology vs observed)

| Pair | Ontology open-loop prediction | Observed r (lag0) | Feedback-inverted closed-loop expectation | Verdict |
|------|------------------------------|-------------------|------------------------------------------|---------|
| XMV_10 ~ XMEAS_9 | inverse (more cooling -> lower T) | +0.6818 (best lag 1, +0.6828) | positive: T9 up -> PI opens cooling valve | MATCH (healthy feedback signature) |
| XMEAS_21 ~ XMEAS_9 | monotonic positive (T21 up -> T9 up) | -0.3298 (best lag 2, -0.3310) | negative: T9 up -> XMV_10 up -> cooling outlet T21 down | MATCH (healthy heat-balance signature) |

Both inversions are explained by closed-loop control semantics (see `02_processed/physics_check.json`
`closed_loop_sign_inversions` and `01_ontology/ontology.json` control relationships
`XMEAS_9 -> XMV_10` temperature control law). They are signatures of functioning feedback loops,
not contradictions and not faults.

## Conclusion

All automated physics checks (5/5 PASS) and manual magnitude checks (M1-M5 PLAUSIBLE) agree with the
ontology governing laws and the observed data behavior. No physically implausible magnitude, no
unexplained contradiction. This supports the no-fault / normal closed-loop steady-state diagnosis.
