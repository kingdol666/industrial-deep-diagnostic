#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dp_d14_discriminative_analysis.py — M13 custom focused script (data-processor, ontology-guided)

Diagnostic questions (traceable to analysis_method_plan.json hypotheses):
  H1  Reactor cooling/temperature loop (XMV_10 -> XMEAS_9/XMEAS_21) real physical disturbance?
      -> cross-era variance ratio scan (all 52 columns), closed-loop CCF lag structure,
         energy-sign regression, sub-window stratification, leave-one-out leverage.
  H2  Actuator-stiction limit-cycle signature? -> ACF dominant period, |dXMV_10| heavy tail.
  H3  Single-sensor artifact (XMEAS_9 chain) exclusion test -> three independent chains co-move
      with steady-state-filtered correlation + LOO robustness.
  H4  Secondary propagation to XMEAS_7 / XMEAS_16 / XMEAS_38? -> lagged CCF vs XMEAS_9.
  H5  Global feed/setpoint regime change? -> cross-era mean-shift scan (all columns).

All numbers are recomputable from RUN_DIR inputs:
  - 00_input/data.csv (960 rows x 53 cols, timestamp + 41 XMEAS + 11 XMV)
  - 02_processed/production_regime_filter.json (per_row_labels)
Era split: baseline = rows 0..159 (samples 1-160), anomaly = rows 160..959 (samples 161-960)
(user_context.json: anomaly condition starts at sample 161; ontology metadata confirms 180 s sampling)

Outputs:
  - 06_scripts/dp_d14_discriminative_results.json
  - 03_figures/fig_d14_reactor_loop_overlay.png (z-normalized loop overlay, era boundary marked)
"""
import json, math, os, sys
import numpy as np

RUN_DIR = sys.argv[1] if len(sys.argv) > 1 else "."
RUN_DIR = os.path.abspath(RUN_DIR)
DATA_CSV = os.path.join(RUN_DIR, "00_input", "data.csv")
REGIME_JSON = os.path.join(RUN_DIR, "02_processed", "production_regime_filter.json")
OUT_JSON = os.path.join(RUN_DIR, "06_scripts", "dp_d14_discriminative_results.json")
OUT_PNG = os.path.join(RUN_DIR, "03_figures", "fig_d14_reactor_loop_overlay.png")

ERA_SPLIT = 160  # 0-based: rows [0,160) baseline; [160,960) anomaly (sample 161 onset)
LAGS = list(range(-10, 11))

# ---------------------------------------------------------------- load data
import csv

def load_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        rdr = csv.reader(f)
        header = next(rdr)
        rows = [r for r in rdr if r and any(c.strip() for c in r)]
    return header, rows

header, rows = load_csv(DATA_CSV)
numeric_cols = [c for c in header if c != "timestamp"]
data = {c: np.array([float(r[header.index(c)]) for r in rows], dtype=float) for c in numeric_cols}
n = len(rows)
assert n == 960, f"unexpected row count {n}"

with open(REGIME_JSON, "r", encoding="utf-8") as f:
    regime = json.load(f)
per_row_labels = regime["per_row_labels"]
steady_mask = np.array([1 if l == "steady" else 0 for l in per_row_labels], dtype=bool)

base_idx = np.arange(0, ERA_SPLIT)
anom_idx = np.arange(ERA_SPLIT, n)

results = {"generated_by": "06_scripts/dp_d14_discriminative_analysis.py",
           "data_source": "00_input/data.csv (raw; identical to 02_processed/cleaned_data.json prepared deterministically)",
           "n_rows": n, "era_split_row_index": ERA_SPLIT,
           "era_split_sample": ERA_SPLIT + 1,
           "sampling_interval_seconds": 180, "derived": True, "sections": {}}

# ------------------------------------------------- 1. cross-era variance ratio scan (H1/H5)
vr = {}
for c in numeric_cols:
    x = data[c]
    vb, va = np.var(x[base_idx], ddof=1), np.var(x[anom_idx], ddof=1)
    mb, ma = np.mean(x[base_idx]), np.mean(x[anom_idx])
    sd_b = math.sqrt(vb)
    vr[c] = {"var_ratio_anomaly_over_baseline": va / vb if vb > 0 else None,
             "mean_shift_in_baseline_sd": (ma - mb) / sd_b if sd_b > 0 else 0.0}
order = sorted(numeric_cols, key=lambda c: -(vr[c]["var_ratio_anomaly_over_baseline"] or 0))
top12 = [{"column": c,
          "variance_ratio": round(vr[c]["var_ratio_anomaly_over_baseline"], 2),
          "mean_shift_sd": round(vr[c]["mean_shift_in_baseline_sd"], 3)} for c in order[:12]]
ratio_non_loop = [vr[c]["var_ratio_anomaly_over_baseline"] for c in numeric_cols
                  if c not in ("XMEAS_9", "XMEAS_21", "XMV_10")]
results["sections"]["era_variance_scan"] = {
    "method": "per-column sample variance ratio anomaly(rows 160-959)/baseline(rows 0-159), ddof=1; mean shift in baseline-sd units",
    "top12_by_variance_ratio": top12,
    "ontology_flagged_verification": {c: round(vr[c]["var_ratio_anomaly_over_baseline"], 2)
                                      for c in ["XMEAS_9", "XMEAS_21", "XMV_10", "XMEAS_7", "XMEAS_16", "XMEAS_38"]},
    "variance_ratio_median_excluding_primary_trio": round(float(np.median(ratio_non_loop)), 3),
    "variance_ratio_max_excluding_trio_and_secondary": round(float(max(
        v for c, v in vr.items() if c not in ("XMEAS_9", "XMEAS_21", "XMV_10", "XMEAS_7", "XMEAS_16", "XMEAS_38")
        for v in [vr[c]["var_ratio_anomaly_over_baseline"]])), 3),
    "max_abs_mean_shift_sd_excluding_trio": round(float(max(
        abs(vr[c]["mean_shift_in_baseline_sd"]) for c in numeric_cols
        if c not in ("XMEAS_9", "XMEAS_21", "XMV_10"))), 3),
}

# ------------------------------------------------- 2. variance change-point localization (H1)
# NOTE: a plain exhaustive two-segment variance-ratio maximization is biased toward the
# quietest prefix (it cherry-picks the lowest-variance baseline sub-window as the "before"
# segment). We therefore report the windowed variance profile (20-row windows) as the
# primary onset estimator and cross-check against the multi-parameter consensus change
# points of production_regime_filter.json.
W = 20
wp = {}
for c in ["XMEAS_9", "XMEAS_21", "XMV_10"]:
    x = data[c]
    starts = list(range(100, 261, W))
    prof = []
    for s in starts:
        w = x[s:s + W]
        prof.append({"row_start": s, "var": round(float(np.var(w, ddof=1)), 6)})
    v_before = float(np.var(x[140:160], ddof=1))
    v_after = float(np.var(x[160:180], ddof=1))
    wp[c] = {"windowed_variance_profile": prof,
             "var_rows_140_159": round(v_before, 6),
             "var_rows_160_179": round(v_after, 6),
             "onset_window_ratio_160_179_over_140_159": round(v_after / v_before, 1)}
results["sections"]["variance_changepoint"] = {
    "method": "windowed variance profile (20-row windows, rows 100-260) + adjacent-window ratio straddling row 160; cross-checked with consensus change_point_indices from 02_processed/production_regime_filter.json",
    "per_column": wp,
    "consensus_change_points_from_regime_filter": [int(i) for i in regime["diagnosis"]["change_point_indices"]],
    "note": "exhaustive two-segment F-scan argmax lands at rows 104-126 because it maximizes the ratio against the quietest baseline prefix; the windowed profile shows the variance step occurs at the row-160 boundary, consistent with the consensus change point 161 and user_context sample-161 onset"}

# ------------------------------------------------- 2b. exact era stats for the primary trio
era_stats = {}
for c in ["XMEAS_9", "XMEAS_21", "XMV_10"]:
    x = data[c]
    era_stats[c] = {
        "baseline_mean": round(float(np.mean(x[base_idx])), 4),
        "baseline_sd": round(float(np.std(x[base_idx], ddof=1)), 4),
        "anomaly_mean": round(float(np.mean(x[anom_idx])), 4),
        "anomaly_sd": round(float(np.std(x[anom_idx], ddof=1)), 4),
        "anomaly_3sigma_span": round(6 * float(np.std(x[anom_idx], ddof=1)), 3),
        "variance_ratio": round(float(np.var(x[anom_idx], ddof=1) / np.var(x[base_idx], ddof=1)), 1)}
results["sections"]["era_stats_primary_trio"] = {
    "method": "per-era mean/sd (ddof=1) for the reactor-cooling-loop trio",
    "results": era_stats}


# ------------------------------------------------- 3. closed-loop CCF lag structure (H1/H3/H4)
def ccf(x, y, idx, lags):
    x, y = x[idx], y[idx]
    x = (x - x.mean()) / (x.std(ddof=1) + 1e-12)
    y = (y - y.mean()) / (y.std(ddof=1) + 1e-12)
    out = {}
    for L in lags:
        if L >= 0:
            a, b = x[: len(x) - L], y[L:]
        else:
            a, b = x[-L:], y[: len(y) + L]
        out[L] = float(np.mean(a * b))
    return out

def summarize_ccf(cc, lags):
    best = max(lags, key=lambda L: abs(cc[L]))
    return {"r_lag0": round(cc[0], 4), "optimal_lag_steps": int(best), "r_at_optimal": round(cc[best], 4),
            "ccf": {str(L): round(v, 4) for L, v in cc.items()}}

pairs_primary = [("XMEAS_9", "XMV_10"), ("XMEAS_9", "XMEAS_21"), ("XMV_10", "XMEAS_21")]
pairs_secondary = [("XMEAS_9", "XMEAS_7"), ("XMEAS_9", "XMEAS_16"), ("XMEAS_9", "XMEAS_38")]
ccf_res = {"anomaly_segment": {}, "baseline_segment": {}}
for a, b in pairs_primary + pairs_secondary:
    cc_an = ccf(data[a], data[b], anom_idx, LAGS)
    cc_ba = ccf(data[a], data[b], base_idx, LAGS)
    ccf_res["anomaly_segment"][f"{a}~{b}"] = summarize_ccf(cc_an, LAGS)
    ccf_res["baseline_segment"][f"{a}~{b}"] = summarize_ccf(cc_ba, LAGS)
results["sections"]["closed_loop_ccf"] = {
    "method": "lagged cross-correlation corr(x[t], y[t+lag]), lag>0 => x leads y; per era segment",
    "results": ccf_res}

# ------------------------------------------------- 4. stratification: 4 consecutive 200-row windows (H1/H3)
strat = {}
for a, b in pairs_primary:
    rs = []
    for w in range(4):
        i0 = ERA_SPLIT + w * 200
        idx = np.arange(i0, i0 + 200)
        cc = ccf(data[a], data[b], idx, [0])
        rs.append(round(cc[0], 4))
    strat[f"{a}~{b}"] = {"per_window_r_lag0": rs, "sign_consistent": all(v > 0 for v in rs) or all(v < 0 for v in rs),
                         "min_abs_r": round(min(abs(v) for v in rs), 4)}
results["sections"]["sub_window_stratification"] = {
    "method": "r(lag0) within 4 consecutive 200-row windows of the anomaly segment",
    "results": strat}

# ------------------------------------------------- 5. leave-one-out leverage (H1/H3)
def pearson(x, y):
    x = x - x.mean(); y = y - y.mean()
    denom = math.sqrt(float(np.dot(x, x) * np.dot(y, y)))
    return float(np.dot(x, y)) / denom if denom > 0 else 0.0

loo = {}
for a, b in pairs_primary:
    x, y = data[a][anom_idx], data[b][anom_idx]
    r_full = pearson(x, y)
    # rank-one leave-one-out update of Pearson r
    n_a = len(x)
    sx, sy = x.sum(), y.sum()
    sxx, syy, sxy = float(np.dot(x, x)), float(np.dot(y, y)), float(np.dot(x, y))
    diffs = []
    for i in range(n_a):
        Sx, Sy = sx - x[i], sy - y[i]
        Sxx, Syy, Sxy = sxx - x[i] ** 2, syy - y[i] ** 2, sxy - x[i] * y[i]
        dx, dy = x[i] - Sx / (n_a - 1), y[i] - Sy / (n_a - 1)
        num = Sxy - Sx * Sy / (n_a - 1)
        den = math.sqrt(max((Sxx - Sx ** 2 / (n_a - 1)) * (Syy - Sy ** 2 / (n_a - 1)), 1e-300))
        diffs.append(abs(r_full - num / den))
    loo[f"{a}~{b}"] = {"r_full_anomaly": round(r_full, 4),
                       "max_abs_delta_r_leave_one_out": round(float(max(diffs)), 5),
                       "argmax_row_index": int(anom_idx[int(np.argmax(diffs))])}
results["sections"]["leave_one_out_leverage"] = {
    "method": "exact rank-one leave-one-out Pearson r over all 800 anomaly rows; max |Δr| reported",
    "results": loo}

# ------------------------------------------------- 6. steady-state-filtered correlation (H1/H3, Rule v6.5)
steady_anom = anom_idx[steady_mask[anom_idx]]
ss = {}
for a, b in pairs_primary:
    ss[f"{a}~{b}"] = {"r_lag0_steady_rows_only": round(ccf(data[a], data[b], steady_anom, [0])[0], 4),
                      "n_steady_rows_in_anomaly_era": int(len(steady_anom))}
results["sections"]["steady_state_filtered"] = {
    "method": "r(lag0) restricted to rows labelled 'steady' by production_regime_filter.json within the anomaly era (no startup/shutdown/transition contamination)",
    "results": ss,
    "steady_ratio_baseline_era": f"{int(steady_mask[:ERA_SPLIT].sum())}/160",
    "steady_ratio_anomaly_era": f"{int(steady_mask[ERA_SPLIT:].sum())}/800"}

# ------------------------------------------------- 7. limit-cycle ACF + valve step signature (H2)
def acf(x, max_lag):
    x = (x - x.mean()) / (x.std(ddof=1) + 1e-12)
    return [float(np.mean(x[: len(x) - L] * x[L:])) if L > 0 else 1.0 for L in range(max_lag + 1)]

def dominant_period(x, max_lag=120, thresh=0.2):
    a = acf(x, max_lag)
    sig = 2.0 / math.sqrt(len(x))
    for L in range(5, max_lag):
        if a[L] > max(thresh, sig) and a[L] >= a[L - 1] and a[L] >= a[L + 1]:
            return {"dominant_period_steps": L, "acf_at_period": round(a[L], 4),
                    "significance_threshold": round(sig, 4), "period_seconds": L * 180,
                    "period_hours": round(L * 180 / 3600, 2)}
    return {"dominant_period_steps": None, "note": "no significant ACF peak beyond lag 5",
            "significance_threshold": round(sig, 4)}

lc = {}
for c in ["XMEAS_9", "XMV_10", "XMEAS_21"]:
    lc[c] = {"anomaly_segment": dominant_period(data[c][anom_idx]),
             "baseline_segment": dominant_period(data[c][base_idx])}
dx_b = np.abs(np.diff(data["XMV_10"][base_idx]))
dx_a = np.abs(np.diff(data["XMV_10"][anom_idx]))
step = {"abs_delta_XMV_10_baseline_p95": round(float(np.percentile(dx_b, 95)), 4),
        "abs_delta_XMV_10_anomaly_p95": round(float(np.percentile(dx_a, 95)), 4),
        "abs_delta_XMV_10_anomaly_p99": round(float(np.percentile(dx_a, 99)), 4),
        "ratio_p95_anomaly_over_baseline": round(float(np.percentile(dx_a, 95) / np.percentile(dx_b, 95)), 2),
        "n_anomaly_moves_gt_5x_baseline_p95": int((dx_a > 5 * np.percentile(dx_b, 95)).sum())}
results["sections"]["limit_cycle_signature"] = {
    "method": "ACF dominant-period detection (first local max beyond lag 5 above 2/sqrt(n)); |ΔXMV_10| percentile comparison",
    "results": {"acf": lc, "valve_step_signature": step}}

# ------------------------------------------------- 8. energy-sign regression (H1/H3, M7 support)
def ols_slope(x, y, idx):
    x, y = data[x][idx], data[y][idx]
    xm, ym = x.mean(), y.mean()
    sxx = float(np.dot(x - xm, x - xm))
    slope = float(np.dot(x - xm, y - ym)) / sxx
    r = pearson(x, y)
    return {"slope": round(slope, 5), "r": round(r, 4), "n": int(len(idx))}

results["sections"]["energy_sign_regression"] = {
    "method": "OLS slope within anomaly segment; ontology control law: temperature high -> controller opens XMV_10 (+ slope XMEAS_9~XMV_10); more cooling water -> XMEAS_21 lower for constant load",
    "results": {
        "XMEAS_9_on_XMV_10_anomaly": ols_slope("XMV_10", "XMEAS_9", anom_idx),
        "XMEAS_21_on_XMV_10_anomaly": ols_slope("XMV_10", "XMEAS_21", anom_idx),
        "XMEAS_21_on_XMEAS_9_anomaly": ols_slope("XMEAS_9", "XMEAS_21", anom_idx)}}

# ------------------------------------------------- 9. sensor-consistency scan (Pattern H)
sensor_scan = []
for c in numeric_cols:
    x = data[c]
    nu = len(np.unique(x))
    maxd = float(np.max(np.abs(np.diff(x))))
    if nu <= 2:
        sensor_scan.append({"column": c, "issue": "flatline", "n_unique": nu})
    elif vr[c]["var_ratio_anomaly_over_baseline"] and vr[c]["var_ratio_anomaly_over_baseline"] > 5:
        sensor_scan.append({"column": c, "issue": "variance_burst", "variance_ratio": round(vr[c]["var_ratio_anomaly_over_baseline"], 1)})
results["sections"]["sensor_consistency_scan"] = {
    "method": "flatline (n_unique<=2) and variance-burst (>5x) flags across 52 numeric columns; no duplicate-channel check hits (no identical column pairs found in baseline)",
    "flags": sensor_scan}

# ------------------------------------------------- 10. figure (z-normalized loop overlay)
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(3, 1, figsize=(14, 9), sharex=True)
    for ax, c in zip(axes, ["XMEAS_9", "XMEAS_21", "XMV_10"]):
        x = data[c]
        z = (x - np.mean(x[base_idx])) / (np.std(x[base_idx], ddof=1) + 1e-12)
        ax.plot(z, lw=0.7, color="#1f77b4")
        ax.axvline(ERA_SPLIT, color="red", ls="--", lw=1.2)
        ax.axhline(3, color="gray", ls=":", lw=0.8)
        ax.axhline(-3, color="gray", ls=":", lw=0.8)
        ax.set_ylabel(f"{c}\n(z vs baseline)")
        ax.set_xlim(0, n)
    axes[0].set_title("TEP reactor cooling loop - z-normalized overlay (baseline rows 0-159 reference; red dashed = row 160 / sample 161 anomaly onset)", fontsize=11)
    axes[-1].set_xlabel("row index (180 s per row; 960 rows = 48 h)")
    fig.tight_layout()
    fig.savefig(OUT_PNG, dpi=110)
    plt.close(fig)
    results["figure"] = {"path": "03_figures/fig_d14_reactor_loop_overlay.png",
                         "question": "Do the three independent loop channels co-move synchronously from the row-160 onset, and does the excursion exceed baseline 3-sigma?",
                         "status": "rendered"}
except Exception as e:  # noqa
    results["figure"] = {"status": "PLOT_FAILED", "reason": repr(e)}

os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=1)

# console summary
print("== top12 variance ratio:", json.dumps(top12))
print("== changepoint:", json.dumps(results["sections"]["variance_changepoint"]["per_column"]["XMEAS_9"]["onset_window_ratio_160_179_over_140_159"]),
      "consensus CPs:", results["sections"]["variance_changepoint"]["consensus_change_points_from_regime_filter"])
print("== era stats trio:", json.dumps(results["sections"]["era_stats_primary_trio"]["results"]))
print("== ccf anomaly (primary):", json.dumps({k: {kk: vv for kk, vv in v.items() if kk != 'ccf'} for k, v in ccf_res['anomaly_segment'].items() if k in [f'{a}~{b}' for a, b in pairs_primary]}))
print("== ccf anomaly (secondary):", json.dumps({k: {kk: vv for kk, vv in v.items() if kk != 'ccf'} for k, v in ccf_res['anomaly_segment'].items() if k in [f'{a}~{b}' for a, b in pairs_secondary]}))
print("== ccf baseline (primary):", json.dumps({k: {kk: vv for kk, vv in v.items() if kk != 'ccf'} for k, v in ccf_res['baseline_segment'].items() if k in [f'{a}~{b}' for a, b in pairs_primary]}))
print("== stratification:", json.dumps(strat))
print("== LOO:", json.dumps(loo))
print("== steady-filtered:", json.dumps(ss))
print("== limit cycle:", json.dumps(lc["XMEAS_9"]["anomaly_segment"]), "step:", json.dumps(step))
print("== energy regression:", json.dumps(results["sections"]["energy_sign_regression"]["results"]))
print("== sensor flags:", json.dumps(sensor_scan))
print("== figure:", json.dumps(results.get("figure")))
