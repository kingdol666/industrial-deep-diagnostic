# -*- coding: utf-8 -*-
"""Enrich image_captions.json with actual-number key_observations (protocol Phase 6)."""
import json

RUN = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171640072_bench_tep_d14_reactor_valve_sticking"
p = RUN + "/03_figures/image_captions.json"
d = json.load(open(p, encoding="utf-8"))
figs = d["figures"]

ENRICH = {
    "fig_d14_reactor_loop_overlay.png": {
        "key_observations": [
            "XMEAS_9 方差比 189.4（基线 sd 0.0186 → 异常段 sd 0.2564），均值 120.3999→120.4005 °C 不变",
            "XMEAS_21 方差比 115.8（sd 0.1279 → 1.3761）；对 XMEAS_9 滞后 5 步（900 s）r=-0.965",
            "XMV_10 方差比 221.5（sd 0.4988 → 7.4239）；与 XMEAS_9 零滞后 r=0.997（LOO |Δr|≤3e-5）",
            "行160边界相邻窗口方差比 121.7/116.1/149.2；生产状态共识变点 161 与 user_context 声明样本161起点一致",
            "异常段 XMEAS_9 自相关主周期 7 步（21 分钟，ACF=0.512）；基线段无此周期结构"
        ],
        "diagnostic_implication": "三条独立测量/执行链自样本161同步进入方差爆炸并构成闭环振荡链（控制器响应 lag0 + 物理响应 lag5），指向反应器冷却执行/供给环节真实扰动；metadata-backed 说明：观察来自统计元数据，非图像目视读图"
    },
    "fig_vlm_temporal_overlay_single_product.png": {
        "key_observations": [
            "全 52 列 z 归一（基线行0-159参考）：仅 reactor_thermal_loop 三变量越过基线 ±3σ 包络",
            "次级变量 XMEAS_7/13/16/38 方差比 1.43-1.75，未越 3σ 主包络",
            "进料组（XMEAS_1-4/XMV_1-4）方差比 1.0-1.4，无同步扰动"
        ],
        "diagnostic_implication": "扰动被严格定位于反应器冷却回路；metadata-backed（统计元数据）观察"
    },
    "fig_vlm_temporal_overlay.png": {
        "key_observations": [
            "全局 overlay 与单产品版一致：方差爆炸簇唯一，位于 XMEAS_9/XMEAS_21/XMV_10",
            "其余 49 列方差比中位数 1.084、最大 1.43（XMEAS_13）"
        ],
        "diagnostic_implication": "全局视图确认无第二扰动源；metadata-backed（统计元数据）观察"
    },
    "fig_vlm_synchronization.png": {
        "key_observations": [
            "滚动相关稳定性：异常段 XMEAS_9~XMV_10 相关稳定在 0.9927-0.9936（四个 200 行子窗）",
            "基线段同对 r0 仅 0.555——异常段出现结构同步性突变"
        ],
        "diagnostic_implication": "同步组在异常段内全程稳定，非孤立尖峰；metadata-backed（统计元数据）观察"
    }
}
for fname, e in ENRICH.items():
    if fname in figs:
        figs[fname]["key_observations"] = e["key_observations"]
        figs[fname]["diagnostic_implication"] = e["diagnostic_implication"]
        figs[fname]["metadata_backed"] = True
json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("enriched captions for", len(ENRICH), "figures")
