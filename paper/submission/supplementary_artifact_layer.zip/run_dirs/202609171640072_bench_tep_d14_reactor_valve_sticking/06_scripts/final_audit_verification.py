# -*- coding: utf-8 -*-
"""Step 7 FINAL_AUDIT independent recomputation (report-reviewer / Auditor Sun).

Data source: 00_input/data.csv (960 raw rows). No truth files touched.
Verifies the load-bearing numbers cited in report.md against the raw layer.
"""
import csv, json, math, os

RUN = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV = os.path.join(RUN, "00_input", "data.csv")

rows = []
with open(CSV, newline="", encoding="utf-8") as f:
    r = csv.DictReader(f)
    cols = r.fieldnames
    for row in r:
        rows.append(row)

n = len(rows)
print("n_rows =", n, "| n_cols(incl ts) =", len(cols))

def series(name):
    return [float(x[name]) for x in rows]

S9 = series("XMEAS_9"); S21 = series("XMEAS_21"); S10 = series("XMV_10")

B = slice(0, 160)      # baseline rows 0-159
A = slice(160, 960)    # anomaly rows 160-959

def mean(v): return sum(v) / len(v)
def var(v):  # ddof=1
    m = mean(v); return sum((x - m) ** 2 for x in v) / (len(v) - 1)
def sd(v): return math.sqrt(var(v))

def corr(x, y):
    mx, my = mean(x), mean(y)
    num = sum((a - mx) * (b - my) for a, b in zip(x, y))
    den = math.sqrt(sum((a - mx) ** 2 for a in x) * sum((b - my) ** 2 for b in y))
    return num / den

def ccf_best(x, y, max_lag=10):
    """corr(x[t], y[t+lag]) for lag in [-max..max]; returns (lag, r) maximizing |r|."""
    best = (None, 0.0)
    out = {}
    for lag in range(-max_lag, max_lag + 1):
        if lag >= 0:
            xx, yy = x[: n - lag], y[lag:]
        else:
            xx, yy = x[-lag:], y[: n + lag]
        r = corr(xx, yy)
        out[lag] = r
        if abs(r) > abs(best[1]):
            best = (lag, r)
    return best, out

print("\n== 1. cross-era variance / mean-freeze (row-160 split, ddof=1) ==")
for name, v in (("XMEAS_9", S9), ("XMEAS_21", S21), ("XMV_10", S10)):
    vb, va = var(v[B]), var(v[A])
    mb, ma = mean(v[B]), mean(v[A])
    shift_sd = (ma - mb) / sd(v[B])
    print(f"{name}: VR={va/vb:.2f}  sd_base={sd(v[B]):.4f}  sd_anom={sd(v[A]):.4f}  "
          f"mean {mb:.4f}->{ma:.4f}  shift={shift_sd:.3f} sd  6sig_span={6*sd(v[A]):.3f}")

print("\n== 2. closed-loop CCF ==")
print("lag0 r(X9,X10) anomaly      =", round(corr(S9[A], S10[A]), 4))
best, _ = ccf_best(S9[A], S21[A])
print("best lag X9->X21 anomaly    =", best)
best2, _ = ccf_best(S10[A], S21[A])
print("best lag X10->X21 anomaly   =", best2)
lag0_9_21 = corr(S9[A], S21[A])
print("lag0 r(X9,X21) anomaly      =", round(lag0_9_21, 4))
r_lag5_a = corr(S9[A][: -5], S21[A][5:])
r_lag5_b = corr(S10[A][: -5], S21[A][5:])
print("lag5 r(X9[t],X21[t+5]) anomaly =", round(r_lag5_a, 4))
print("lag5 r(X10[t],X21[t+5]) anomaly=", round(r_lag5_b, 4))

print("\n== 3. baseline lag structure (evidence.json口径 0.555/0.331/0.414) ==")
b921, _ = ccf_best(S9[B], S21[B]);  print("baseline best X9~X21 :", b921)
b910, _ = ccf_best(S9[B], S10[B]);  print("baseline best X9~X10 :", b910)
b1021, _ = ccf_best(S10[B], S21[B]); print("baseline best X10~X21:", b1021)

print("\n== 4. valve step signature ==")
d_base = [abs(S10[i] - S10[i - 1]) for i in range(1, 160)]
d_anom = [abs(S10[i] - S10[i - 1]) for i in range(160, n)]  # 800 intervals, rows 159..959
def pct(v, q):
    s = sorted(v); k = (len(s) - 1) * q; lo = int(k); hi = min(lo + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)
p95b = pct(d_base, 0.95); p95a = pct(d_anom, 0.95); p99a = pct(d_anom, 0.99)
big = sum(1 for d in d_anom if d > 5 * p95b)
print(f"p95_base={p95b:.4f}  p95_anom={p95a:.4f}  ratio={p95a/p95b:.2f}  p99_anom={p99a:.4f}")
print(f"n_anom_intervals={len(d_anom)}  n_big(>5x base p95)={big}")

print("\n== 5. ACF(7) limit cycle ==")
def acf(v, lag):
    m = mean(v); num = sum((v[i] - m) * (v[i + lag] - m) for i in range(len(v) - lag))
    den = sum((x - m) ** 2 for x in v)
    return num / den
thr = 1.96 / math.sqrt(len(S9[A]))
for name, v in (("XMEAS_9", S9), ("XMEAS_21", S21), ("XMV_10", S10)):
    print(f"{name}: ACF(7) anomaly={acf(v[A],7):.4f}  baseline={acf(v[B],7):.4f}  (95% thr≈{thr:.4f})")

print("\n== 6. onset window ratio var[160:180)/var[140:160) ==")
for name, v in (("XMEAS_9", S9), ("XMEAS_21", S21), ("XMV_10", S10)):
    print(f"{name}: {var(v[160:180])/var(v[140:160]):.1f}")

print("\n== 7. contrast-face VR and column-count口径 (49-col vs 46-col) ==")
primary = {"XMEAS_9", "XMEAS_21", "XMV_10"}
secondary = {"XMEAS_7", "XMEAS_16", "XMEAS_38", "XMEAS_13"}
num_cols = [c for c in cols if c != "timestamp"]
vrs = {}
for c in num_cols:
    v = series(c)
    vrs[c] = var(v[A]) / var(v[B])
excl3 = [vrs[c] for c in num_cols if c not in primary]
excl7 = [vrs[c] for c in num_cols if c not in primary and c not in secondary]
excl3.sort(); excl7.sort()
def median(v):
    m = len(v) // 2
    return v[m] if len(v) % 2 else (v[m - 1] + v[m]) / 2
print(f"49-col口径 (excl trio)        : n={len(excl3)}  median={median(excl3):.4f}  max_mean_shift_check skipped")
print(f"46-col口径 (excl trio+4 sec)  : n={len(excl7)}  median={median(excl7):.4f}")
for c in ("XMEAS_22", "XMV_11", "XMEAS_5", "XMEAS_20", "XMEAS_18", "XMEAS_19", "XMV_9",
          "XMEAS_16", "XMEAS_38", "XMEAS_7", "XMEAS_13", "XMEAS_40", "XMEAS_41"):
    print(f"  VR {c} = {vrs[c]:.3f}")
# XMV_10 anomaly range (saturation check)
print("XMV_10 anomaly range:", round(min(S10[A]), 2), "~", round(max(S10[A]), 2))

print("\n== 8. energy sign regression (X9 ~ X10, anomaly OLS) ==")
xa, ya = S10[A], S9[A]
mx, my = mean(xa), mean(ya)
sxy = sum((a - mx) * (b - my) for a, b in zip(xa, ya))
sxx = sum((a - mx) ** 2 for a in xa)
slope = sxy / sxx
r = corr(xa, ya)
print(f"slope(X9 per %)={slope:.5f}  r={r:.4f}  inverse slope={1/slope:.2f} %/°C")

print("\n== 9. sub-window r (4x200) and lag5 slope identity (M2) ==")
sw = []
for i in range(4):
    seg = slice(160 + i * 200, 160 + (i + 1) * 200)
    sw.append(corr(S9[seg], S10[seg]))
print("4x200 subwindow r:", [round(x, 4) for x in sw], " min~max =", round(min(sw), 4), "~", round(max(sw), 4))
# lag5 regression slope X21 per % using anomaly segment aligned series
x_l = S10[A][: -5]; y_l = S21[A][5:]
mxl, myl = mean(x_l), mean(y_l)
slope5 = sum((a - mxl) * (b - myl) for a, b in zip(x_l, y_l)) / sum((a - mxl) ** 2 for a in x_l)
pred_span = abs(slope5) * 6 * sd(S10[A])
obs_span = 6 * sd(S21[A])
print(f"lag5 slope={slope5:.4f} °C/%  pred6σ={pred_span:.3f} °C  obs6σ={obs_span:.3f} °C  "
      f"ratio={pred_span/obs_span:.4f}  vs |r_lag5|={abs(r_lag5_b):.4f}")

print("\n== 10. steady-state rows (from production_regime_filter.json) ==")
prf = os.path.join(RUN, "02_processed", "production_regime_filter.json")
with open(prf, encoding="utf-8") as f:
    prfj = json.load(f)
def find_steady(obj):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in ("steady_state_rows", "steady_rows", "steady_row_indices") and isinstance(v, list):
                return v
            r = find_steady(v)
            if r is not None: return r
    elif isinstance(obj, list):
        for it in obj:
            r = find_steady(it)
            if r is not None: return r
    return None
steady = find_steady(prfj)
if steady is None:
    print("steady row list key not found; top-level keys:", list(prfj.keys()))
else:
    steady = [i for i in steady if 160 <= i < 960]
    x_s = [S9[i] for i in steady]; y_s = [S10[i] for i in steady]
    print(f"steady rows in anomaly segment: {len(steady)}  r(X9,X10) within = {corr(x_s, y_s):.4f}")
