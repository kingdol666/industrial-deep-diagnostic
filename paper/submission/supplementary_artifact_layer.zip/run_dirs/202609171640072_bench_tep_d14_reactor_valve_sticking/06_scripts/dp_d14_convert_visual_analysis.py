# -*- coding: utf-8 -*-
"""Convert visual_analysis.py skeleton_pre_vlm -> metadata_backed_inference (non-VLM environment).
Script-signed provenance; observations grounded ONLY in computed statistics (no PNG pixel claims)."""
import json

RUN = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171640072_bench_tep_d14_reactor_valve_sticking"
p = RUN + "/03_figures/visual_analysis.json"
d = json.load(open(p, encoding="utf-8"))

d["observation_mode"] = "metadata_backed_inference"
d["vlm_chart_count"] = 0
d["chart_design_purpose"] = ("诊断问题：反应器冷却回路三变量（XMEAS_9/XMEAS_21/XMV_10）是否自样本161同步进入方差爆炸并构成闭环振荡链；"
                             "回路扰动是否向下游传播。本环境无 VLM：所有 observations 均为统计元数据支撑（metadata-backed），"
                             "不包含对 PNG 像素内容的直接目视读图。")
d["analysis_provenance"] = {
    "source_agent": "visual_analysis.py (script-signed; non-VLM environment — data-processor semantic phase converted skeleton to metadata-backed mode)",
    "stage": "metadata_backed_inference",
    "skeleton_overwritten": True,
    "context_files_read": [
        "02_processed/cleaned_data.csv", "02_processed/feature_summary.json", "02_processed/validate_report.json",
        "01_ontology/ontology.json", "02_processed/production_regime_filter.json", "02_processed/anomaly_report.json",
        "06_scripts/dp_d14_discriminative_results.json", "02_processed/data_analysis_conclusion.json"
    ],
    "figure_inputs_attempted": [],
    "figure_inputs_read_successfully": [],
    "grounding_summary": ("非 VLM 环境（无图像读图）：visual_observations 全部由已验证的统计元数据"
                          "（06_scripts/dp_d14_discriminative_analysis.py 的跨era方差扫描、闭环滞后 CCF、ACF 极限环、分层/LOO/稳态过滤）"
                          "与本体物理角色支撑生成，未对任何 PNG 内容做目视断言；图表本身由 visual_analysis.py 与 06_scripts 脚本"
                          "从 02_processed/cleaned_data.csv 确定性渲染。"),
    "grounding_sources": [
        "01_ontology/ontology.json", "06_scripts/dp_d14_discriminative_results.json",
        "02_processed/validate_report.json", "02_processed/production_regime_filter.json", "02_processed/anomaly_report.json"
    ]
}
NOT_READ = "non-VLM environment — image not read; metadata-backed mode only"
inv = {i["figure"]: i for i in d["chart_inventory"]}
for i in d["chart_inventory"]:
    i["read_status"] = "READ_FAILED"
    i["read_failure_reason"] = NOT_READ
    i.setdefault("diagnostic_weight", "MODERATE")
d["chart_inventory"].append({
    "figure": "fig_d14_reactor_loop_overlay.png", "read_status": "READ_FAILED", "read_failure_reason": NOT_READ,
    "purpose": ("M13 自定义诊断图：反应器冷却回路三变量以基线(行0-159)均值/标准差 z 归一的全时序叠加；"
                "红虚线=行160(样本161)异常起点，灰点线=基线±3σ。回答：三链是否同步越过基线3σ。"),
    "visual_questions": ["XMEAS_9/XMEAS_21/XMV_10 是否自行160同步进入大幅振荡？", "振荡幅度是否越过基线3σ且全程持续？"],
    "read_order": 1, "diagnostic_weight": "CRITICAL"})
for fig, w in [("fig_vlm_temporal_overlay_single_product.png", "CRITICAL"),
               ("fig_vlm_temporal_overlay.png", "STRONG"), ("fig_vlm_synchronization.png", "MODERATE")]:
    if fig in inv:
        inv[fig]["diagnostic_weight"] = w
for k, i in enumerate(d["chart_inventory"], start=1):
    i["read_order"] = k

d["visual_observations"] = [
    {"figure": "fig_d14_reactor_loop_overlay.png",
     "observations": [
        {"type": "temporal_synchronization",
         "description": "[metadata-backed，非图像读图] 统计元数据：自行160（样本161）起 XMEAS_9/XMEAS_21/XMV_10 三条独立测量/执行链同步进入高方差状态（跨era方差比 189.4/115.8/221.5），均值不动（≤0.114 sd）；XMEAS_9 与 XMV_10 零滞后 r=0.997。",
         "parameters_involved": ["XMEAS_9", "XMEAS_21", "XMV_10"], "estimated_lag": "0 (synchronous, XMEAS_9~XMV_10)",
         "confidence": "high",
         "diagnostic_implication": "三链同步方差爆炸将扰动定位于反应器冷却/温度闭环内部，排除外部进料/工况切换作为源。",
         "statistical_cross_reference": {"correlation": 0.997, "source_file": "06_scripts/dp_d14_discriminative_results.json", "validation_note": "LOO max|dr|=3e-5；4子窗 r=0.9927~0.9936；稳态行(683)过滤后 r=0.9968"},
         "ontology_context": {"parameter_physical_meanings": {"XMEAS_9": "反应器内物料温度（C），由 XMV_10 调节", "XMEAS_21": "反应器冷却水出口温度（C），移热负荷直接指示器", "XMV_10": "反应器冷却水流量调节阀开度（%）"}, "process_stage": "S2_reaction（反应器反应与移热）"}},
        {"type": "temporal_synchronization",
         "description": "[metadata-backed，非图像读图] 滞后结构元数据：XMEAS_9 领先 XMEAS_21 恰 5 步（900 s）且 r=-0.965；XMV_10~XMEAS_21 同为 5 步 r=-0.9646；基线段仅 lag1 r=-0.33——异常段滞后结构由 1 步变为 5 步。",
         "parameters_involved": ["XMEAS_9", "XMEAS_21", "XMV_10"], "estimated_lag": "5 steps (900 s), XMEAS_9/XMV_10 lead XMEAS_21",
         "confidence": "high",
         "diagnostic_implication": "固定滞后的强物理响应是真实执行/热力响应指纹——单传感器伪迹无法在独立热变量上伪造该结构；方向与本体 inverse 预测一致。",
         "statistical_cross_reference": {"correlation": -0.9649, "source_file": "06_scripts/dp_d14_discriminative_results.json", "validation_note": "sections.closed_loop_ccf.anomaly_segment.XMEAS_9~XMEAS_21"},
         "ontology_context": {"parameter_physical_meanings": {"XMV_10": "反应器温度控制器操纵变量：开大→冷却水流量增大→XMEAS_21 下降", "XMEAS_21": "T_out = T_in + Q_rx/(m_cw·Cp_w)"}, "process_stage": "S2_reaction/CWR-100 反应器冷却水系统"}},
        {"type": "trend_morphology",
         "description": "[metadata-backed，非图像读图] 周期结构元数据：异常段 XMEAS_9 自相关主周期 7 步（21 分钟，ACF=0.512，阈值 0.071）；阀位 |delta| p95 为基线 16.16 倍，800 个间隔中 633 次阶跃超过基线 p95 的 5 倍；基线段无此周期（33 步弱峰 0.277）。",
         "parameters_involved": ["XMEAS_9", "XMV_10"], "estimated_lag": "N/A — cross-sectional (ACF)",
         "confidence": "high",
         "diagnostic_implication": "21 分钟极限环 + 阀位阶跃签名与执行机构粘滞（stiction）类故障一致，是诊断员第一候选（候选1）的直接数据支撑。",
         "statistical_cross_reference": {"source_file": "06_scripts/dp_d14_discriminative_results.json", "validation_note": "sections.limit_cycle_signature"},
         "ontology_context": {"parameter_physical_meanings": {"XMEAS_9": "反应器温度 PV", "XMV_10": "温度控制器 MV（阀位）"}, "process_stage": "S2_reaction"}},
        {"type": "anomaly_clustering",
         "description": "[metadata-backed，非图像读图] 传播面元数据：次级变量方差比 XMEAS_16 ×1.75、XMEAS_38 ×1.60、XMEAS_7 ×1.52、XMEAS_13 ×1.43，但与 XMEAS_9 的滞后 CCF 最强仅 |r|=0.19（XMEAS_7 lag3）；XMEAS_40/41（产品 G/H 纯度）方差比约1.0。",
         "parameters_involved": ["XMEAS_7", "XMEAS_13", "XMEAS_16", "XMEAS_38", "XMEAS_9"], "estimated_lag": "unclear（弱线性耦合）",
         "confidence": "medium",
         "diagnostic_implication": "次级方差增大应视为上游热扰动的下游回声而非并列根因；产品纯度未见确定性退化。",
         "statistical_cross_reference": {"source_file": "06_scripts/dp_d14_discriminative_results.json", "validation_note": "sections.era_variance_scan + sections.closed_loop_ccf.anomaly_segment 次级对"},
         "ontology_context": {"parameter_physical_meanings": {"XMEAS_7": "反应器压力 kPa(g)", "XMEAS_16": "汽提塔压力 kPa(g)", "XMEAS_38": "产品E摩尔分数（纯度指标）"}, "process_stage": "S3_condense_sep / S4_stripping"}}
     ]}
]
cta = d["cross_parameter_temporal_alignment"]
cta["summary"] = ("[metadata-backed] 异常段（行160-959）内 XMEAS_9 与 XMV_10 零滞后同步（r=0.997，控制器响应通道）；"
                  "XMEAS_21 滞后 5 步强负响应（r=-0.965，物理响应通道）；进料/液位/汽提等其余回路与该振荡无强耦合（方差比中位数 1.084）。"
                  "滞后结构由基线的 1 步变为异常段 5 步，为回路动力学改变的直接时序证据。")
cta["synchronous_groups"] = [
    {"group_id": "reactor_cooling_loop_controller_pair", "parameters": ["XMEAS_9", "XMV_10"],
     "description": "[metadata-backed] 控制器同采样作用对：r(lag0)=0.997（异常段），LOO 稳健（|dr|<=3e-5）",
     "estimated_group_lag": "0 (synchronous)", "synchronous_with_quality": False,
     "group_diagnostic_implication": "闭环控制器响应通道——方向为温度高→开阀，须按闭环语义解读"},
    {"group_id": "reactor_cooling_loop_physical_pair", "parameters": ["XMEAS_9", "XMEAS_21"],
     "description": "[metadata-backed] 物理响应对：XMEAS_9 领先 XMEAS_21 5 步（900 s），r=-0.965（阀开大→出口温度下降）",
     "estimated_group_lag": "5 steps (900 s)", "synchronous_with_quality": False,
     "group_diagnostic_implication": "真实执行/热力响应指纹，排除单传感器伪迹"}
]
cta["precedence_signals"] = [
    {"earlier": "XMEAS_9", "later": "XMEAS_21",
     "description": "[metadata-backed] 滞后 CCF：corr(XMEAS_9[t], XMEAS_21[t+5])=-0.965，5 步=900 s",
     "visual_confidence": "HIGH", "diagnostic_implication": "温度/阀位先动、冷却水出口温度后动——执行链方向证据"}
]
cta["independent_parameters"] = [
    {"parameters": ["XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4", "XMV_1", "XMV_2", "XMV_3", "XMV_4"],
     "description": "[metadata-backed] 进料组 8 变量方差比 1.0-1.4、均值偏移 <=0.17 sd，与主振荡无强耦合", "diagnostic_weight": "WEAK"},
    {"parameters": ["XMEAS_18", "XMEAS_19", "XMV_9"],
     "description": "[metadata-backed] 汽提塔温度/蒸汽回路方差比约1.0，未受主振荡扰动", "diagnostic_weight": "WEAK"}
]
d["process_fluctuation_visual_findings"] = [
    {"parameter": "XMEAS_9", "pattern_type": "variance_burst", "time_window_or_group": "rows 160-959 (samples 161-960)",
     "visual_basis": "[metadata-backed] 方差比 189.4（基线 sd 0.0186 → 异常段 sd 0.2564），均值 120.40 C 不变", "diagnostic_implication": "反应器温度在受控均值下剧烈振荡——回路内部扰动",
     "statistical_cross_reference": {"source_file": "06_scripts/dp_d14_discriminative_results.json"}},
    {"parameter": "XMV_10", "pattern_type": "variance_burst", "time_window_or_group": "rows 160-959",
     "visual_basis": "[metadata-backed] 方差比 221.5（sd 0.4988 → 7.4239），|delta| p95 ×16.16，阶跃式动作", "diagnostic_implication": "控制器大幅频繁动作/执行机构异常的直接 MV 侧证据",
     "statistical_cross_reference": {"source_file": "06_scripts/dp_d14_discriminative_results.json"}},
    {"parameter": "XMEAS_21", "pattern_type": "variance_burst", "time_window_or_group": "rows 160-959",
     "visual_basis": "[metadata-backed] 方差比 115.8（sd 0.1279 → 1.3761），对 XMV_10 滞后5步 r=-0.965", "diagnostic_implication": "真实移热过程随之振荡——独立于 XMEAS_9 测量链的物理确认",
     "statistical_cross_reference": {"source_file": "06_scripts/dp_d14_discriminative_results.json"}}
]
d["pipeline_warnings"] = [
    {"warning": "非 VLM 环境：未执行任何图像读图；visual_observations 全部为统计元数据支撑（metadata-backed），不构成对 PNG 像素内容的目视证据。", "severity": "WARNING"},
    {"warning": "数据视图 process_only：无质量/检验侧数据，dual_drive_visual_findings 不适用（留空）。", "severity": "INFO"},
    {"warning": "per_product overlays 退化单产品全局 overlay（fig_vlm_temporal_overlay_single_product.png）：无分组列。", "severity": "INFO"}
]
d["synthesis"] = ("[metadata-backed 综合结论，非图像读图] 三条相互独立的测量/执行链（反应器温度 XMEAS_9、冷却水阀位 XMV_10、冷却水出口温度 XMEAS_21）"
                  "自样本161同步进入方差爆炸（×189/×222/×116），均值全程受控；XMEAS_9 与 XMV_10 零滞后锁定（r=0.997），"
                  "XMEAS_21 以固定 5 步（900 s）滞后强负响应（r=-0.965），叠加 21 分钟极限环与阀位阶跃签名（×16）——"
                  "统计证据面共同指向反应器冷却/温度闭环内部的真实物理扰动（执行机构粘滞类最优先），"
                  "排除单传感器伪迹、全局工况切换与循环气路节流。")
d["reading_guide"] = [
    {"for_agent": "diagnostician",
     "primary_sections_to_read": ["visual_observations", "cross_parameter_temporal_alignment", "process_fluctuation_visual_findings", "pipeline_warnings"],
     "key_insights": ["observations 为 metadata-backed（统计支撑），非图像目视读图；引用时标注 'metadata-backed'",
                      "滞后语义：XMEAS_9~XMV_10 lag0=控制器响应；XMEAS_9→XMEAS_21 lag5=物理响应",
                      "候选1（阀粘滞）vs 候选2（冷却水供给侧）共享签名，区分需外部信息"]}
]
json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("converted to metadata_backed_inference; observations:", len(d["visual_observations"][0]["observations"]),
      "charts:", len(d["chart_inventory"]))
