# -*- coding: utf-8 -*-
"""Normalize every supporting_sources / evidence_artifacts / supporting_artifacts / source entry
in data_analysis_conclusion.json to a literal existing run-dir-relative path (leading path token)."""
import json, os

RUN = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609171640072_bench_tep_d14_reactor_valve_sticking"
p = RUN + "/02_processed/data_analysis_conclusion.json"
d = json.load(open(p, encoding="utf-8"))

def to_path(s):
    # take the first whitespace-delimited token that maps to an existing file; strip "; ..." tails
    for tok in s.replace(";", " ").split():
        if os.path.exists(os.path.join(RUN, tok)):
            return tok
    return s

KEYS = {"supporting_sources", "evidence_artifacts", "supporting_artifacts"}

def walk(o, key=None):
    if isinstance(o, dict):
        out = {}
        for k, v in o.items():
            out[k] = walk(v, k)
        return out
    if isinstance(o, list):
        if key in KEYS:
            res = []
            for v in o:
                if isinstance(v, str):
                    res.append(to_path(v))
                else:
                    res.append(walk(v, key))
            seen, dedup = set(), []
            for v in res:
                if v not in seen:
                    seen.add(v)
                    dedup.append(v)
            return dedup
        return [walk(v, key) for v in o]
    if key == "source" and isinstance(o, str):
        return to_path(o)
    return o

d = walk(d)
json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# verify
bad = []
def check(o, key=None):
    if isinstance(o, dict):
        for k, v in o.items():
            check(v, k)
    elif isinstance(o, list):
        if key in KEYS:
            for v in o:
                if isinstance(v, str) and not os.path.exists(os.path.join(RUN, v)):
                    bad.append((key, v))
        else:
            for v in o:
                check(v, key)
    elif key == "source" and isinstance(o, str):
        if not os.path.exists(os.path.join(RUN, o)):
            bad.append(("source", o))
check(d)
print("non-path entries remaining:", bad if bad else "NONE")
