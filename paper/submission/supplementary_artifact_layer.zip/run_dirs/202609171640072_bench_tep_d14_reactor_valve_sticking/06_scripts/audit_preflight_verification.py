#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Step 5b PRE-REPORT physical audit (report-reviewer, Auditor Sun) — independent
quantitative re-verification of the key claims in 04_diagnostics/*.json
directly from 00_input/data.csv (raw data, NOT pipeline summaries).

All claims re-verified here are quoted with their artifact source in
05_review/optimizer_preflight.md. This script only READS; it writes nothing
except stdout. derived=true (auditor recomputation).
"""
import json
import math
import numpy as np
import pandas as pd

RUN = "."
CSV = RUN + "/00_input/data.csv"
PRF = RUN + "/02_processed/production_regime_filter.json"

df = pd.read_csv(CSV)
n = len(df)
print(f"[A0] rows={n} cols={len(df.columns)} (expect 960 rows, 53 incl timestamp)")
ts = pd.to_datetime(df["timestamp"])
dt = ts.diff().dropna().dt.total_seconds()
print(f"[A0] time monotonic increasing: {bool(ts.is_monotonic_increasing)}; "
      f"interval uniform 180s: {bool((dt == 180).all())}")

cols = [c for c in df.columns if c != "timestamp"]
X = {c: df[c].to_numpy(dtype=float) for c in cols}

B = slice(0, 160)      # baseline rows 0-159 (samples 1-160)
A = slice(160, 960)    # anomaly rows 160-959 (samples 161-960)
TRIO = ["XMEAS_9", "XMEAS_21", "XMV_10"]

def era_stats(v):
    vb, va = np.var(v[B], ddof=1), np.var(v[A], ddof=1)
    mb, ma = np.mean(v[B]), np.mean(v[A])
    sdb = math.sqrt(vb)
    return dict(vr=va / vb, mean_shift_sd=(ma - mb) / sdb,
                b_mean=mb, b_sd=sdb, a_mean=ma, a_sd=math.sqrt(va))

print("\n[A1] era variance ratios / mean shifts (claim: 189.37 / 115.82 / 221.5, shifts<=0.114 sd)")
for c in TRIO:
    s = era_stats(X[c])
    print(f"  {c}: VR={s['vr']:.2f} mean_shift={s['mean_shift_sd']:+.3f} sd  "
          f"b_mean={s['b_mean']:.4f} b_sd={s['b_sd']:.4f} a_mean={s['a_mean']:.4f} a_sd={s['a_sd']:.4f}  "
          f"6sigma_span_a={6*s['a_sd']:.3f}")

print("\n[A2] quiet-control-surface VRs (claim: 22=1.04, XMV11=1.06, 5=0.84, 20=1.08, 18=1.26, 19=1.21; median others=1.084; max mean shift excl trio=0.285)")
for c in ["XMEAS_22", "XMV_11", "XMEAS_5", "XMEAS_20", "XMEAS_18", "XMEAS_19"]:
    print(f"  {c}: VR={era_stats(X[c])['vr']:.3f}")
exclude = set(TRIO) | {"XMEAS_7", "XMEAS_16", "XMEAS_38", "XMEAS_13"}
vrs, msh = [], []
for c in cols:
    if c in exclude:
        continue
    s = era_stats(X[c])
    vrs.append((s["vr"], c)); msh.append((abs(s["mean_shift_sd"]), c))
vrs.sort(); msh.sort(reverse=True)
print(f"  median VR excl trio+secondary: {np.median([v for v,_ in vrs]):.3f}  "
      f"max|mean_shift| excl trio: {msh[0][0]:.3f} sd ({msh[0][1]})")

def pearson(x, y):
    if len(x) != len(y):
        m = min(len(x), len(y)); x, y = x[:m], y[:m]
    return float(np.corrcoef(x, y)[0, 1])

print("\n[A3] closed-loop CCF (claim: lag0 r=0.997/0.9982; lag5 r=-0.9649/-0.9646; baseline lag1 |r|<=0.33/0.414)")
r0_9v10 = pearson(X["XMEAS_9"][A], X["XMV_10"][A])
r5_9_21 = pearson(X["XMEAS_9"][A][:795], X["XMEAS_21"][A][5:])
r5_10_21 = pearson(X["XMV_10"][A][:795], X["XMEAS_21"][A][5:])
print(f"  anomaly lag0 XMEAS_9~XMV_10 : {r0_9v10:.4f}")
print(f"  anomaly lag5 XMEAS_9->XMEAS_21: {r5_9_21:.4f}")
print(f"  anomaly lag5 XMV_10->XMEAS_21: {r5_10_21:.4f}")
def best_lag(x, y, lags=range(-10, 11)):
    best = max(lags, key=lambda L: abs(pearson(x[max(0,-L): len(x)-max(0,L)], y[max(0,L): len(y)-max(0,-L)])) if (min(len(x),len(y))-abs(L))>2 else 0)
    return best
b_9_21 = best_lag(X["XMEAS_9"][B], X["XMEAS_21"][B])
b_10_21 = best_lag(X["XMV_10"][B], X["XMEAS_21"][B])
print(f"  baseline best lag XMEAS_9~XMEAS_21: {b_9_21} r={pearson(*(lambda L:(X['XMEAS_9'][B][max(0,-L):160-max(0,L)], X['XMEAS_21'][B][max(0,L):160-max(0,-L)]))(b_9_21)):.4f}")
print(f"  baseline best lag XMV_10~XMEAS_21: {b_10_21} r={pearson(*(lambda L:(X['XMV_10'][B][max(0,-L):160-max(0,L)], X['XMEAS_21'][B][max(0,L):160-max(0,-L)]))(b_10_21)):.4f}")
print(f"  anomaly lag0 XMEAS_9~XMEAS_21 (structural dependence): {pearson(X['XMEAS_9'][A], X['XMEAS_21'][A]):.4f}")

print("\n[A4] robustness (claim: LOO max|dr|=3e-5; 4x200 subwindows 0.9927-0.9936)")
x9, x10 = X["XMEAS_9"][A], X["XMV_10"][A]
nA = len(x9)
r_full = pearson(x9, x10)
sx, sy = x9.std(ddof=1), x10.std(ddof=1)
sxy = np.sum((x9 - x9.mean()) * (x10 - x10.mean()))
maxd, argi = 0.0, -1
for i in range(nA):
    dxy = sxy - (x9[i] - x9.mean()) * (x10[i] - x10.mean())
    dvx = (nA - 1) * sx**2 - (x9[i] - x9.mean())**2
    dvy = (nA - 1) * sy**2 - (x10[i] - x10.mean())**2
    dr = abs(dxy / math.sqrt(dvx * dvy) - r_full)
    if dr > maxd:
        maxd, argi = dr, i
print(f"  LOO max|dr|={maxd:.2e} at row {160+argi} (claim 3e-05 @ row 559)")
sw = [pearson(x9[i*200:(i+1)*200], x10[i*200:(i+1)*200]) for i in range(4)]
print(f"  4x200 subwindow lag0 r: {[f'{v:.4f}' for v in sw]}")

print("\n[A5] limit cycle ACF (claim: dominant period 7 steps=21 min, ACF~0.512 all trio; baseline none)")
for c in TRIO:
    v = X[c][A] - X[c][A].mean()
    ac = np.array([np.corrcoef(v[:nA-k], v[k:])[0, 1] for k in range(0, 15)])
    thr = 2 / math.sqrt(nA)
    k = int(np.argmax(ac[6:9])) + 6
    print(f"  {c}: ACF(7)={ac[7]:.4f} (claim ~0.512), threshold={thr:.4f}, local ACF 5..9: {np.round(ac[5:10],3)}")
for c in TRIO:
    v = X[c][B] - X[c][B].mean()
    ac = {k: np.corrcoef(v[:160-k], v[k:])[0, 1] for k in range(1, 60)}
    kbest = max(ac, key=lambda k: ac[k])
    print(f"  {c} baseline: max ACF in 1..59 at lag {kbest} = {ac[kbest]:.3f} (claim: weak peaks 33-52, <=0.28)")

print("\n[A6] valve step signature (claim: base p95=1.3309, anom p95=21.5135 p99=23.2408, x16.16, 633 moves >5x)")
db = np.abs(np.diff(X["XMV_10"][B])); da = np.abs(np.diff(X["XMV_10"][A]))
p95b = np.percentile(db, 95); p95a = np.percentile(da, 95); p99a = np.percentile(da, 99)
print(f"  |dXMV_10| baseline p95={p95b:.4f} anomaly p95={p95a:.4f} p99={p99a:.4f} ratio={p95a/p95b:.2f} "
      f"n>5x_base={int((da > 5*p95b).sum())}/{len(da)}")
print(f"  anomaly |d| distribution: median={np.median(da):.2f} p25={np.percentile(da,25):.2f} p75={np.percentile(da,75):.2f} "
      f"-> fraction of intervals that are 'big' moves(>5x base)={float((da>5*p95b).mean()):.2%}")
big = da[da > 5 * p95b]
print(f"  big-move magnitudes: p25={np.percentile(big,25):.2f} median={np.median(big):.2f} p75={np.percentile(big,75):.2f} "
      f"(clustered slip-jump? p99={np.percentile(big,99):.2f})")
print(f"  XMV_10 anomaly range: min={X['XMV_10'][A].min():.2f} max={X['XMV_10'][A].max():.2f} (0/100 saturation check)")

print("\n[A7] onset coincidence (claim: window var ratio 121.7/116.1/149.2 at row-160 boundary)")
for c in TRIO:
    r = np.var(X[c][160:180], ddof=1) / np.var(X[c][140:160], ddof=1)
    print(f"  {c}: var[160:180)/var[140:160) = {r:.1f}")

print("\n[A8] energy sign regression (claim: slope +0.0345 r=0.9982 n=800)")
sl = float(np.polyfit(X["XMV_10"][A], X["XMEAS_9"][A], 1)[0])
print(f"  XMEAS_9 on XMV_10 anomaly: slope={sl:.5f} r={r0_9v10:.4f} n={nA}")

print("\n[A9] lag-5 amplitude closure (claim: slope -0.1784 C/% x 44.5% span = -7.95 C vs 8.26 C, ratio 0.96)")
xs, ys = X["XMV_10"][A][:795], X["XMEAS_21"][A][5:]
slope5 = float(np.polyfit(xs, ys, 1)[0])
span_x = 6 * X["XMV_10"][A].std(ddof=1); span_y = 6 * X["XMEAS_21"][A].std(ddof=1)
print(f"  lag5 slope XMEAS_21 on XMV_10 = {slope5:.4f} C/%  |slope|*span_x={abs(slope5)*span_x:.3f} C  span_y={span_y:.3f} C  ratio={abs(slope5)*span_x/span_y:.4f}  (== |r|={abs(r5_10_21):.4f} identity check)")

print("\n[A10] physics flow check (claim: P/flow^2 mean 3.7355 CV=1.65%)")
p = X["XMEAS_7"]; q = X["XMEAS_5"]
ratio = p / q**2
print(f"  XMEAS_7/XMEAS_5^2: mean={ratio.mean():.4f} cv={ratio.std(ddof=1)/ratio.mean()*100:.2f}%  flow_range=[{q.min():.3f},{q.max():.3f}] P_range=[{p.min():.1f},{p.max():.1f}]")

print("\n[A11] secondary propagation (claim: max |r| XMEAS_9->XMEAS_7/16/38 <= 0.193)")
for c, lagexp in [("XMEAS_7", 3), ("XMEAS_16", 0), ("XMEAS_38", 0)]:
    best = (0, None)
    for L in range(-10, 11):
        r = pearson(X["XMEAS_9"][A][max(0, -L):nA - max(0, L)], X[c][A][max(0, L):nA - max(0, -L)])
        if abs(r) > abs(best[0]):
            best = (r, L)
    print(f"  XMEAS_9~{c}: best lag={best[1]} r={best[0]:.4f} (claim {best[1] if best[1]==lagexp else 'lag'+str(lagexp)} -0.193/0.083/0.011)")

print("\n[A12] steady-state filtered r (claim: 683 steady rows in anomaly era, r=0.9968)")
prf = json.load(open(PRF, encoding="utf-8"))
def find_steady(o):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in ("steady_rows", "steady_indices", "steady_row_indices") and isinstance(v, list):
                return v
            r = find_steady(v)
            if r is not None:
                return r
    elif isinstance(o, list):
        for v in o:
            r = find_steady(v)
            if r is not None:
                return r
    return None
sr = find_steady(prf)
if sr is None:
    print("  keys:", list(prf.keys()))
    print("  [warn] steady row list not located by name; searching per-row labels...")
    def find_labels(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if "label" in k.lower() and isinstance(v, list) and len(v) == n:
                    return v
                r = find_labels(v)
                if r is not None:
                    return r
        elif isinstance(o, list):
            for v in o:
                r = find_labels(v)
                if r is not None:
                    return r
        return None
    lab = find_labels(prf)
    if lab:
        idx = [i for i in range(160, n) if lab[i] in ("steady", "STEADY", True, 1)]
        print(f"  steady rows in anomaly era: {len(idx)}  r={pearson(x9[idx], x10[idx]):.4f}")
else:
    idx = [i for i in sr if i >= 160]
    print(f"  steady rows in anomaly era: {len(idx)}  r(lag0 XMEAS_9~XMV_10)={pearson(x9[idx], x10[idx]):.4f}")

print("\n[A13] quantization / stick-slip waveform check on XMV_10 anomaly segment")
u = np.unique(np.round(X["XMV_10"][A], 4))
per7 = [float(np.std(X["XMV_10"][A][i:i+7], ddof=1)) for i in range(0, 770, 7)]
print(f"  unique values (4dp)={len(u)}; zero-ish moves(|d|<0.5%): {int((da<0.5).sum())}/800; "
      f"per-7-step window sd: min={min(per7):.2f} median={np.median(per7):.2f} (flat-topped limit cycle -> some near-zero sd windows expected)")
small = int((da < p95b).sum())
print(f"  moves smaller than baseline p95: {small}/800 ({small/8:.1f}% — stick phases)")
print("\nDONE — all numbers above recomputed from 00_input/data.csv")
