# 工业诊断报告 — TEP反应器冷却水调节阀粘滞（bench_tep_d14_reactor_valve_sticking）

- **运行编号**：202609171640072_bench_tep_d14_reactor_valve_sticking
- **报告人**：reporter（工程师周，技术报告，Step 6）
- **报告时间**：2026-09-17T21:00Z（UTC）
- **诊断结论类型**：DETERMINED（唯一存活假设）｜**置信度**：80/100（HIGH，自报上界82）
- **质量门禁**：Judge 94/100，verdict=pass（05_review/judge_feedback.json，Step 5a）；物理预检 PREFLIGHT_PASS，FATAL=0 / MAJOR=0 / MINOR=5 / INFO=6（05_review/optimizer_preflight.md，Step 5b）。预检 5 项 MINOR 修复指令（M1-M5）已全部落实于本报告（落实位置见 §7.4 对照表）。
- **数据真值声明**：本报告全部承重数字来自运行工件与 `00_input/data.csv`（960 行原始层）独立复算（Step 5b 审计脚本 `06_scripts/audit_preflight_verification.py`），未使用任何外部真值信息（`truth_withheld=true` 遵守）。

---

## 1. 执行摘要

**一句话结论**：自样本161（第8小时，行160边界）起，反应器温度控制回路进入方差爆炸型21分钟极限环；根因确定为反应器冷却水调节阀 **XMV_10 的粘滞（stiction）类执行机构故障**（04_diagnostics/diagnosis.json，DETERMINED，置信度80/100）。

**核心证据（三条独立链同步突变）**：反应器温度 XMEAS_9、冷却水出口温度 XMEAS_21、阀位 XMV_10 三通道在行160边界同时发生"均值冻结 + 方差爆炸"——方差比 ×189.4 / ×115.8 / ×221.5 而均值偏移仅 0.033 / 0.094 / 0.114 sd；阀位阶跃活动放大约16.2倍（800个间隔中633次超过基线p95的5倍）；三通道共享7步（1260 s = 21分钟）极限环主周期（ACF≈0.512，显著性阈值0.071）；回路滞后结构由基线1步被改写为异常段5步。单传感器伪迹、全局进料/工况切换、循环气路节流、蒸汽侧扰动、全厂冷却水共源扰动五个候选均被定量排除（排除置信度90%~96%）。

**业务影响（厂长视角）**：

- 反应器温度以 ±0.77 °C（3σ跨度1.538 °C）等幅振荡，均值钉在设定值120.40 °C——产品纯度测点（XMEAS_40/41，方差比1.13/0.78）**尚未**出现确定性退化，但下游压力/组成面已出现轻度回声（方差比1.43~1.75），窗口期尚在，越早处理代价越小。
- 阀位以约 ±22% 开度（6σ跨度44.5%）、p99=23.24%/3min 的速率大幅往返，折合约 **380次/天** 大阶跃（derived：633次/40小时）——控制阀填料与执行机构在加速磨损，放任发展的终点是阀门失效或振荡发散，届时被迫停车处理。
- 冷却水量大幅振荡推高公用工程消耗；扰动严格局域于单一回路（其余列方差比中位数约1.06~1.08），**无**全厂性扰动，不影响其他装置单元。

**推荐行动**（详见 §8）：P0——48小时内对 XMV_10 执行离线冲程测试并调阅/加装阀杆位置反馈（当场证实或证伪粘滞）；P1——补装 CWR-100 支路冷却水流量与入口温度测点、调阅样本161前后 DCS 整定与维护记录；P2——部署回路粘滞在线检测、提高阀位信号采样分辨率、将阀门纳入周期维护计划。**不建议**在阀门检查前先行重整定控制器（整定无法解释 ×16.2 的阶跃幅度突变，且会污染现场证据）。

---

## 2. 诊断背景与数据概况

**装置与用户问题**：Tennessee Eastman（TE）化工过程——反应器-冷凝器-气液分离器-汽提塔+循环压缩机（00_input/user_context.json）。XMEAS_1..41 为过程测量、XMV_1..11 为操纵变量，3分钟（180 s）采样。用户问题："诊断本次异常的根本原因"；用户声明第161样本（第8小时）起进入异常工况。声明起点仅用作 era 边界候选，起点本身由数据内三重证据独立定位（§4.2）。

**数据集**：`00_input/data.csv`，960行 × 53列（timestamp + 52个数值通道：41 XMEAS + 11 XMV），180 s 等间隔共48小时，自2020-01-01T00:00:00起单调递增（02_processed/validate_report.json sorting_validation：time_sorted=true，n_rows=960；Step 5b 复算确认全部间隔恰为180 s）。

**场景判定**：process_only 单产品连续化工工况（02_processed/scenario_classification.json：process_fluctuation_diagnosis / continuous_chemical / confidence=high）。本体 metadata：product_grades=[]、batch_id=null——双驱动联动（过程→质量）与按产品分层 Simpson 检验均 not_applicable（02_processed/data_analysis_conclusion.json adaptive_decision_audit.data_view_mode='process_only'），本诊断仅由过程波动视图驱动。

**本体注册**：01_ontology/ontology.json 定义 7 台设备、S1-S4 工艺阶段、52 个变量物理赋义与 governing laws。关键配对：XMEAS_9（反应器温度，PV，setpoint 120.4）、XMV_10（反应器温度控制器操纵变量，MV，setpoint 41.108%）、XMEAS_21（CWR-100 冷却水出口温度）同属 parameter_groups.reactor_thermal_loop 与设备 CWR-100。RAG 引擎不可达，降级为技能内置 fallback 库（00_input/rag_deep_understanding.json rag_status=UNAVAILABLE_FALLBACK_USED）；诊断物理主张不依赖 RAG 提取内容（05_review/judge_feedback.json physics_source_audit：PASS）。六项参数歧义全部 AUTO_RESOLVED（00_input/clarification_needed.json，AR-1~AR-6：TE标准赋义/单位/无单一目标列/基线窗口=行1-160/XMV-XMEAS回路配对/时区）。

---

## 3. 数据质量评估

| 维度 | 结论 | 依据 |
|:--|:--|:--|
| 完整性 | 960行时间戳无缺失、单调；52个数值通道全量可用 | 02_processed/validate_report.json sorting_validation |
| 时间维 | 180 s 等间隔、time_sorted=true（复算确认） | validate_report + Step 5b 复算 |
| 生产状态 | 稳态行 806/960（83.96%），无开停车/切换标记；异常段 683/800 行为稳态标签 | 02_processed/production_regime_filter.json（三算法融合） |
| 反伪迹扫描 | 0 项 Simpson 悖论、0 项趋势混淆、0 项离群驱动、0 项 Spearman 分歧、0 fatal；overall_validity=ROBUST | 02_processed/validate_report.json anti_spurious.summary |
| 均值级变化 | XMEAS_21 于行161分段均值相对变化 0.0%、has_regime_change=false——异常纯为方差维度 | validate_report change_point_detection |
| 传感器健康 | 全列扫描仅三通道 variance_burst，无 flatline/重复通道 | 06_scripts/dp_d14_discriminative_results.json sensor_consistency_scan |

**已披露缺口（Judge 非阻塞警告，本节如实转述）**：

1. **清洗溯源不完整**（Judge 警告3）：02_processed/data_analysis_conclusion.json data_cleaning_provenance 自述 cleaning_integrity not recorded（Phase 2.2.5 未运行）。Step 5b 审计证实 `02_processed/cleaned_data.csv` 与 `00_input/data.csv` 数值逐元素相等（allclose）——清洗未改动任何数值，实际影响为零；且本诊断全部承重统计已自原始层独立复算命中。该缺口应向下游可见，建议 data-processor 后续轮次补齐记录。
2. **基线窗口较短**（Judge 警告4）：基线 era 仅160行（8小时），全部方差比的分母基于该较短窗口；三重起点定位稳定，但基线非平稳性（慢漂移混入）理论上可影响 VR 幅值（详见 §9 假设与局限）。
3. **非 VLM 环境**（Judge 警告2）：03_figures/visual_analysis.json observation_mode=metadata_backed_inference——全部图表观察为统计元数据支撑，无像素级目视断言；各 PNG read_status=READ_FAILED 原因如实记录。图像证据等级按 rank 4（L4 metadata-backed）使用。

---

## 4. 统计分析发现

### 4.1 主信号簇：方差爆炸 + 均值冻结（方差-only 工况切换）

跨era方差扫描（06_scripts/dp_d14_discriminative_results.json era_variance_scan / era_stats_primary_trio；分界=行160，异常段行160-959 / 基线行0-159，ddof=1）：

| 通道 | 角色 | 基线 sd | 异常段 sd | 方差比 | 均值偏移 | 3σ/6σ跨度 |
|:--|:--|:--|:--|:--|:--|:--|
| XMEAS_9 | 反应器温度 PV | 0.0186 °C | 0.2564 °C | ×189.4 | 0.033 sd（120.3999→120.4005 °C） | 1.538 °C（3σ） |
| XMEAS_21 | 冷却水出口温度 | 0.1279 °C | 1.3761 °C | ×115.8 | 0.094 sd（94.5946→94.6067 °C） | 8.257 °C（3σ） |
| XMV_10 | 阀位 MV | 0.4988 % | 7.4239 % | ×221.5 | 0.114 sd（41.1081→41.1648 %） | 44.543 %（6σ） |

**解读**：均值不动 + 方差爆炸两个数量级，是闭环内部自激振荡的特征指纹，排除设定值迁移、反应放热异常与均值漂移类候选（放热异常需组成/进料先行变化，而全部组成/进料列安静）。异常段 XMV_10 范围 29.19~53.72%（复算），远离 0/100 饱和——排除"限幅削波伪造极限环"的数据伪影路径（Step 5b P-6）。

### 4.2 起点三重共定位

- **窗口化方差**（20行窗）：var[160:180)/var[140:159] 起点比 XMEAS_9=121.7、XMEAS_21=116.1、XMV_10=149.2，三通道在行160边界同时跃变（02_processed/anomaly_report.json anomaly_onset_coincidence；Step 5a 复算精确命中）。
- **生产状态共识变点**：production_regime_filter 变点序列含 161。
- **用户声明**：样本161。
- 三者精确重合；F-scan 变点（行104-126）经裁决弃用（其 argmax 落在最安静基线前缀的对比上，06_scripts 判别性工件已记录该差异与裁决理由）。

### 4.3 阀位阶跃签名（stick-slip 指纹）

|ΔXMV_10|（/3min）：基线 p95=1.3309% → 异常段 p95=21.5135%（**×16.16**），p99=23.2408%；800 个间隔中 **633 次**超过基线 p95 的 5 倍（折合约380次/天，derived）。大阶跃幅度四分位聚类 12.4/16.6/19.3%（Step 5b P-2），支持"固定死区释放跳变"而非平滑反馈补偿。79% 的间隔为大步移动——180 s 采样下"滞驻（stick）"细节不可直辨，stick-slip 的量化特征保持为"更高分辨率采样下的预测可观测量"（Step 5b I5），不作为已证事实陈述。

### 4.4 极限环（ACF 主周期）

异常段三通道共享主周期 **7步（1260 s = 21分钟）**：ACF(7)=0.5123/0.5136/0.5116（Step 5b 复算 0.5112/0.5136/0.5126，容差内；显著性阈值 0.0707），全程800行稳定无衰减。基线段无该结构——直接复算基线 ACF(7)=-0.021/-0.252/-0.092（工件"弱峰33/35/52步、ACF≤0.277"系"lag>5起搜"的方法产物，承重命题"基线无21分钟周期"经直接复算成立，Step 5b I1）。闭环 CCF 形态与此自洽：XMEAS_9~XMV_10 的 CCF 呈近正弦对称衰减（lag7 处 0.5104/0.5155），与7步振荡一致。

### 4.5 滞后结构改变：基线1步 → 异常段5步（M5 口径）

闭环滞后 CCF（corr(x[t], y[t+lag])，lag>0 即 x 领先 y）：

| 数对 | 异常段最优滞后 | 异常段 r（工件/复算） | 基线段最优滞后 | 基线 r |
|:--|:--|:--|:--|:--|
| XMEAS_9 ~ XMV_10 | 0 步（同步） | 0.997 / 0.9982 | 1 步 | 最优\|r\|≤0.555 |
| XMEAS_9 → XMEAS_21 | 5 步（900 s） | −0.9649 / **−0.9638** | 1 步 | −0.331（复算 −0.3312） |
| XMV_10 → XMEAS_21 | 5 步（900 s） | −0.9646 / **−0.9637** | 1 步 | 最优\|r\|≤0.414 |

说明（落实 M5）：诊断工件中"基线 |r|≤0.33"的表述**仅适用于** XMEAS_9~XMEAS_21 对；基线段三数对最优滞后均为1步、最优 |r| 分别 ≤0.555/0.331/0.414（04_diagnostics/evidence.json closed_loop_ccf 口径），本报告按该口径陈述。滞后结构由1步变为5步，是回路动力学被执行非线性改写的直接时序证据。XMEAS_9~XMEAS_21 在 lag0 处 r=−0.0062、lag5 处 −0.9649 的强结构依赖，是排除瞬时耦合伪影与单传感器伪迹（H2）的关键（复算精确命中 −0.0062）。

### 4.6 闭环相关的稳健性（落实 M1：引用复算值并披露工件差异）

04_diagnostics/diagnosis.json 与 06_scripts/dp_d14_discriminative_results.json 引用的三项稳健性指标未能自原始数据逐位复现；Step 5b 审计（06_scripts/audit_preflight_verification.py，venv python，数据源 00_input/data.csv）复算值如下，**本报告一律引用复算值**：

| 指标 | 工件引用值 | Step 5b 复算值 | 判定 |
|:--|:--|:--|:--|
| 4×200行子窗 r（XMEAS_9~XMV_10） | 0.9927~0.9936 | **0.9977~0.9986** | 未逐位复现（差约0.005，方向更有利） |
| 稳态行过滤 r（XMEAS_9~XMV_10） | 683行，r=0.9968 | **683行（行数精确命中），r=0.9982** | r 值未复现（Δ0.0014，方向更有利） |
| lag5 CCF（9→21 / MV→21） | −0.9649 / −0.9646 | **−0.9638 / −0.9637** | 偏差0.0011/0.0009，方向更有利 |
| 精确留一法 LOO max\|Δr\| | 3e-5 | 2.54e-5（同 argmax 行559；引用为进位取整） | 命中 |

全部偏差 ≤0.006 且**方向均更有利**（复算值更强），不改变任何结论方向；已作为工件-复算差异显式披露。稳健性结论：r=0.9982 的共变结构不依赖任何单点（LOO 无杠杆行）、任何子段（4子窗稳定）、任何过渡态污染（683/800 稳态行内 r=0.9982；稳态标签在7步相位上分布均匀，无相位偏倚）。

### 4.7 对照面安静与扰动局域性（落实 M3：写明口径）

- **排除主回路三通道后的49列**（仅除三通道）：方差比中位数 1.084（06_scripts 工件口径；Step 5a 复算 1.0893）；最大均值偏移 0.285 sd。
- **再剔除次级信号 XMEAS_7/16/38 后的46列口径**：中位数 1.060（Step 5b 复算；若将 XMEAS_13 亦计入次级集则为45列口径，结论不变）。
- 两种口径下"**对照面安静、扰动严格局域**"结论均成立：进料阀组 XMV_1-4、冷凝器冷却 XMV_11/XMEAS_22（VR 1.056/1.044）、汽提蒸汽 XMV_9/XMEAS_19（VR 1.22/1.21）、循环 XMEAS_5/XMEAS_20（VR 0.839/1.084）、汽提塔温 XMEAS_18（VR 1.258）全部安静（Step 5b 逐一复算 ±0.01 内命中）。

### 4.8 次级回声与反伪迹门禁

- 次级信号方差比：XMEAS_16 ×1.75、XMEAS_38 ×1.60、XMEAS_7 ×1.52、XMEAS_13 ×1.43——真实轻度增大，但与 XMEAS_9 的滞后 CCF 最强仅 |r|=0.193（XMEAS_7 lag3，复算 −0.1930；9~16 为 0.0831、9~38 为 0.0114）。线性证据不足以区分"积分平滑传播"与"独立轻度波动"，按诚实三态记 **INDETERMINATE**，仅作"下游回声"假设，不参与根因判定。
- 产品纯度 XMEAS_40/41 方差比 1.13/0.78、均值偏移 −0.143/−0.049 sd——无确定性退化。
- 反伪迹门禁全通过（v6.4-v6.7 强制项）：时间排序有效；M8 产品分层 not_applicable（以异常段4个连续200行子窗做等效分层替代）；M6 过程→质量滞后补偿 not_applicable（process_only，引用数对的时序排序由闭环 CCF 覆盖）；M3 批次完整性 not_applicable（无批列）；M5 生产状态检测通过；LOO/子窗/稳态过滤通过。全部门禁零降级、零撤销。

---

## 5. 假设检验（竞争假设协议）

6 个机制异类假设全部带控制方程因果链、支持/反对证据与可证伪条件（04_diagnostics/diagnosis.json hypotheses；04_diagnostics/confidence.json 五因子分解）：

| 假设 | 内容 | 裁决 | 置信/排除置信度 | 关键依据 |
|:--|:--|:--|:--|:--|
| H1 | XMV_10 粘滞类执行机构故障引发温度闭环21分钟极限环 | **存活** | 80/100 | 三通道签名+极限环+阶跃+滞后改写+局域性全部闭合 |
| H2 | XMEAS_9 单传感器伪迹 | EXCLUDED | 96% | 独立变送器 XMEAS_21 固定5步强负响应无法伪造；能量衡算约束（阀位±22%摆动若无真实温度响应则移热失衡且无补偿变量）；lag0/lag5 结构依赖；LOO/子窗/稳态不变性 |
| H3 | 全局进料/生产速率工况切换 | EXCLUDED | 95% | 49列安静（VR中位1.084）与"全局公共原因"预测结构矛盾；进料阀组正常；无切换标记；均值级零漂移 |
| H4 | 循环气路节流/积垢 | EXCLUDED | 93% | P∝ṁ² 成立（P/flow² 均值3.735、CV=1.65%，02_processed/physics_check.json FLOW_QUADRATIC_PLAUSIBLE）；循环列安静（XMEAS_5 0.839/XMEAS_20 1.084）；节流为渐变，与行160离散型突变矛盾 |
| H5 | 下游汽提/蒸汽侧扰动上行 | EXCLUDED | 90% | 汽提回路安静（XMEAS_18/19/XMV_9 VR 1.26/1.21/1.22）且无任何汽提侧变量领先反应器回路 |
| H6 | 全厂冷却水公用工程共源扰动 | EXCLUDED | 90% | 冷凝器冷却支路安静（XMEAS_22 VR=1.044、XMV_11 VR=1.056）——共源扰动应同时扰动两个冷却回路（CWR-100 与 CWC-100 为独立系统） |

**可判别性矩阵**：全部存活-排除配对均为 ONE_SIDE_EXCLUDED，判别信号可用；存活集内仅 H1，无 INDISTINGUISHABLE 存活对——**COMPETING_SET 的65封顶不触发，DETERMINED 成立**（04_diagnostics/diagnosis.json discriminability_matrix）。

**已披露的机制归属残余（未强行排除）**：H1 内部"粘滞 vs 冷却水支路专属供给波动 vs 控制器重整定"三者共享可观测签名，且仪器面（无流量/入口温度/阀杆反馈/整定日志）不支持切分。按诚实原则不作伪判别：前两者作为 H1 的 contradicting_evidence 保留（未达 ≥90 排除置信度，量化为置信调整 −2），重整定列入 data_gaps（无法解释 p95=21.5%/3min、p99=23.2% 的 MV 阶跃物理量级与阶跃统计的离散型突变）。等权并列将掩盖可判定的定位证据——把"未穷尽"误当"不可区分"会造成伪 COMPETING_SET；此为工程裁量，已在置信 80 中定价（05_review/optimizer_preflight.md §2.4 认可）。最不利退化路径："冷却支路执行/供给环节扰动"——**定位级结论不变**。

---

## 6. 根因结论

### 6.1 诊断结论（根因判定）

**DETERMINED**：样本161（行160边界）起，反应器冷却水调节阀 XMV_10 执行机构粘滞（stick-slip）类故障 → 阀位大幅阶跃释放 → 冷却水流量振荡 → 移热通道振荡 → 反应器温度围绕设定值等幅极限环（周期7步=21分钟）→ 控制器反向调节构成闭环自激。置信度 **80/100**（HIGH）。

### 6.2 物理逻辑链（六环，04_diagnostics/diagnosis.json hypotheses.surviving[0]）

| # | 环节 | 证据状态 | 量化 |
|:--|:--|:--|:--|
| 1 | 阀杆粘滞 → 阀位大幅阶跃（stick-slip） | OBSERVED | \|Δ\|p95 ×16.16、633/800 大阶跃、p99=23.24%；MV 均值仅偏移0.114 sd（大幅动作围绕同一均值——滞驻-跳跃而非设定值迁移） |
| 2 | 阀位阶跃 → 冷却水流量振荡（阀门方程 Q=Cv·f(x)·√(ΔP/ρ)） | INFERRED | 无流量变送器（DATA_LINK_MISSING）；流量振荡的热力脚印由 XMEAS_21 固定5步强负响应（r=−0.9638，复算口径）独立证实——唯一能与三通道签名同时闭合的中间变量 |
| 3 | 流量振荡 → 移热振荡 → 温度等幅极限环（能量衡算 ρCp·V·dT/dt=−U·A·ΔT_lm+Σ(−ΔH_r)·r_j+焓项） | OBSERVED | XMEAS_9 异常段 sd 0.2564 °C（基线0.0186，×189.4），均值120.4005 vs 120.3999 °C |
| 4 | 温度振荡 → 控制器反向调节（控制律：温度高→开大阀） | OBSERVED | 能量符号回归（异常段 OLS，n=800）：斜率 +0.0345 °C/%、r=0.9982——方向与本体控制律一致（复算逆回归 28.90 %/°C 自洽） |
| 5 | 阀位/温度振荡 → 出口温度反向滞后响应（T_out=T_in+Q_rx/(ṁ_cw·Cp_w)） | OBSERVED | 固定5步滞后 r=−0.9637/−0.9638（复算口径），方向与本体 inverse 预测一致 |
| 6 | stick-slip 非线性 → 稳定极限环（粘滞继电特性+PI控制器+一阶热过程） | KNOWN_PHYSICS（L5） | 三通道共享 ACF 主周期7步（≈0.512>阈值0.0707）且全程稳定；基线无此结构 |

### 6.3 本体-数据-物理四要素证明

01_ontology/ontology.json governing laws 与观测对比（ontology_data_physics_proof=STRONG_EVIDENCE）：功能形式 **MATCH**（本体预测"移热/执行异常激发控制器大幅动作并形成回路振荡"——观测到闭环极限环+MV大幅阶跃）；方向 **MATCH**（inverse 与控制律均被 lag5 响应与能量符号回归证实）；滞后 **PARTIAL**（本体先验针对正常工况：基线1步一致而异常段5步偏离——偏离本身是执行非线性改写回路动力学的诊断性发现）；幅值见下。

**幅值内检的正确表述（落实 M2）**：lag5 回归斜率 −0.1784 °C/% × XMV_10 异常段6σ跨度 44.543% ≈ 7.95 °C，与 XMEAS_21 观测6σ跨度 8.257 °C 之比为 0.962。**该比值在数学上恒等于 |r(lag5)|=0.9637（斜率=r·sy/sx 恒等式）——它是线性一致性的重述，不是独立的能量衡算幅值预测**；独立的幅值预测因无冷却水流量变送器不可构造（DATA_LINK_MISSING 已在 data_gaps 披露）。方向与符号的物理验证不受此影响。无任何超出物理可能的量级（Step 5b §4：阀位 ±10% 弛豫摆动无饱和、21分钟周期在奈奎斯特内、局域性物理自洽）。

### 6.4 符号与滞后结构的闭环解读（落实 M4）

本体 9→21 关系预测 monotonic **正向**（反应器温度↑ → ΔT_lm↑ → 出口温度↑），而异常段观测 lag5 强**负**（r=−0.9638）——表面矛盾的解释为**双通道叠加**：直接的 ΔT 通道为弱正贡献，流量介导的 inverse 通道占主导（流量变化 ±18% 远大于温差贡献 ~3%，Step 5b R-4）；lag0 处 r≈−0.006 恰为两通道抵消的形态。同时，5步滞后应解读为**闭环极限环内的相位关系**（7步周期下 5/7 周期≈257°，由执行非线性+控制器积分+热惯性多阶环节共同决定），而非纯粹的900 s 传输延迟。evidence.json physical_evidence[0] 未展开该解释，本节按预检指令补齐。

### 6.5 置信度构成与可证伪性

**置信度 80/100**（04_diagnostics/confidence.json）：五因子 统计22 + 物理18 + 时序17 + 混杂免疫18 + 症状完备7 = 82（上界），残余调整 −2（机制归属两替代未达90排除）→ 80；与 reasoning_chain.json 假设演化路径（60 → +10+15+10 −8 −7 = 80）双路径重建一致（05_review/judge_feedback.json stability_reproducibility_audit：PASS）。主要扣分：闭环数据不可开环分解 PV/MV 因果（−3）、粘滞为签名推断而非直测（XMV_10 为控制器指令信号非阀杆位置反馈，−7 因子内）、极限环内事件先序不可建立（−3）、支路内部未测混杂（−2）、次级传导未闭合（−3）。

**预测可观测**（若粘滞持续）：阀位阶跃统计特征不变；三通道维持7步相位锁定（PV~MV 同步、出口温度滞后5步反相）；三通道均值保持设定值附近；其余回路 VR≈1.0；更高采样分辨率下应见 stick-slip 阶梯量化特征。

### 6.6 推理链与详细推导（R1-R8 摘要，04_diagnostics/reasoning_chain.json）

| 段 | 步骤 | 输出结论 | 段内置信 |
|:--|:--|:--|:--|
| R1 | 数据特征化与场景判定 | process_only 单产品连续 TE 场景，时间维有效，era 边界=行160（样本161） | 98 |
| R2 | 统计发现与证据融合 | 方差-only 工况切换严格局域于反应器冷却回路三通道（97）；闭环振荡链：lag0 同步 r=0.997、lag5 反相 r=−0.9646、21分钟极限环、×16.2 阶跃（96） | — |
| R3 | 验证过滤器与反伪迹门禁 | 全部引用相关性通过反伪迹四重门禁+生产状态门禁，零降级（96）；异常确认为方差-only、均值维度零漂移（95） | — |
| R4 | 假设生成与本体-数据-物理证明 | 6 个竞争假设各带控制方程链+可证伪条件，H1 闭合度最高（STRONG_EVIDENCE，85）；两条链缺口（阀位→流量 DATA_LINK_MISSING、次级传导 CORRELATION_ABSENT）诚实记录（100） | — |
| R5 | 可判别性评估 | 全部 5 对存活-排除组合均为 ONE_SIDE_EXCLUDED，存活集单一 → DETERMINED 成立（85）；机制归属残余不可切分，量化为 −2 调整而非伪判别（90） | — |
| R6 | 排除验证 | 5 项排除（H2-H6）全部 ≥90 置信度且各带复活条件；2 个次级替代诚实保留为残余（92） | — |
| R7 | 诊断结论与可证伪性 | DETERMINED：四反投机条件全部满足；次级传导 INDETERMINATE 不影响根因判定（80/85） | — |
| R8 | 不确定性界定与建议测量 | 置信上界 82（当前 80）；测量杠杆排序：阀杆位置反馈 > 流量/入口温度测点 > 维护日志 > header 记录（88/90） | — |

假设演化轨迹：H1 由初始 60 分经 R2（+10）、R3（+15）、R4（+10）、R4 扣减（−8）、R5 扣减（−7）至 80；H2 30→4、H3 25→5、H4 20→7、H5 15→7、H6 20→8，全部经 R6 排除收尾。

**五条可执行证伪条件**（任一成立即推翻或修正结论）：(1) 阀杆/定位器反馈显示平滑跟随无滞驻-跳跃、且流量测点显示上游独立振荡 → 改判"支路供给波动"；(2) 维护/整定记录显示样本161控制器重整定且阀台位测试无粘滞 → 改判 OPERATION 类；(3) XMEAS_9/XMEAS_21 被证实共用测量总线且复测响应消失 → H2 复活；(4) 离线冲程测试全行程自由且在线极限环消失 → H1 被现场证据证伪；(5) header 记录显示支路入口条件阶跃且阀杆动作平滑 → 供给侧替代成立。

---

## 7. 证据附录

### 7.1 证据全景：等级总览

| 等级 | 本案证据 | 承重结论 |
|:--|:--|:--|
| L1 直接测量 | 00_input/data.csv 960行原始层（Step 5b/5a 双重复算30+项命中） | 方差比/均值冻结/CCF/ACF/阶跃/对照面 |
| L2 用户文档 | 00_input/user_context.json（过程描述、起点声明） | era 边界候选（数据内三重定位独立确认） |
| L3 统计分析 | 06_scripts/dp_d14_discriminative_results.json、02_processed/{validate_report,anomaly_report,production_regime_filter}.json | 全部签名统计量与四重稳健性门禁 |
| L4 图表视觉证据 | 03_figures/plot_manifest.json 5图 + visual_analysis.json（**metadata-backed，非VLM**） | 图表设计问题由统计元数据回答 |
| L5 领域知识 | 01_ontology/ontology.json governing laws + 粘滞极限环控制物理 | 机制归属（L3+L5 合成级，非 L1 直测） |
| L6 外部参考 | 无（RAG 降级未引用） | — |
| L7 未支撑假设 | 无 | — |

结论整体受"粘滞为签名推断"约束在 **L3+L5 合成级**——80 分置信度与该证据等级相称（05_review/optimizer_preflight.md §2.5：降级不对称检查通过，非直测机制恰当定价区间 70-85）。

### 7.2 工件索引与关键数字

| 工件 | 关键内容 |
|:--|:--|
| `00_input/data.csv` | 960×53 原始层；全部承重统计复算源 |
| `06_scripts/dp_d14_discriminative_results.json` | VR 221.5/189.37/115.82；CCF lag0=0.997、lag5=−0.9649/−0.9646；ACF(7)=0.5123；阶跃 ×16.16、633/800；LOO 3e-5；子窗/稳态过滤（数值口径差异见 §4.6 M1 披露） |
| `02_processed/anomaly_report.json` | 起点窗口比 121.7/116.1/149.2；能量符号回归 +0.0345（r=0.9982） |
| `02_processed/validate_report.json` | 反伪迹 0 项红旗；time_sorted=true；has_regime_change=false；ROBUST |
| `02_processed/production_regime_filter.json` | 稳态 83.96%；共识变点 161；异常段 683/800 稳态行 |
| `02_processed/physics_check.json` | P/flow² 均值3.735、CV=1.65%（FLOW_QUADRATIC_PLAUSIBLE）；其余7项检验 not_applicable 原因记录 |
| `02_processed/data_analysis_conclusion.json` | process_only 视图审计；方法覆盖矩阵；hypothesis_verdicts（H1/H2 supported、H3/H5 refuted、H4 indeterminate）；清洗溯源缺口自述 |
| `01_ontology/ontology.json` | CWR-100 物理链三关系；XMV_10 discrepancy_signal 指向执行环节；6 条 CONTRADICTED 全部被诊断引用 |
| `04_diagnostics/diagnosis.json` | DETERMINED 主结论、H1 六环因果链、H2-H6 排除、discriminability_matrix、6 data_gaps + 3 inference_gaps |
| `04_diagnostics/confidence.json` | 五因子 82→80；adjustment_log 全量可重建 |
| `04_diagnostics/reasoning_chain.json` | R1-R8 八段；假设演化 60→80；不确定性三分解 |
| `06_scripts/audit_preflight_verification.py` | Step 5b 独立复算脚本（本报告复算值来源） |
| `05_review/judge_feedback.json` | 94/100 pass；10 组抽样复算 10/10 命中；4 条非阻塞警告 |
| `05_review/optimizer_preflight.md` | PREFLIGHT_PASS；FATAL=0/MAJOR=0/MINOR=5/INFO=6；M1-M5 修复指令 |

### 7.3 对齐图与图表证据（全部为 metadata-backed，非像素读图）

![反应器冷却回路三变量z归一全时序叠加](03_figures/fig_d14_reactor_loop_overlay.png)

**fig_d14_reactor_loop_overlay.png**（MANDATORY，06_scripts/dp_d14_discriminative_analysis.py）：反应器冷却回路三变量以基线均值/标准差 z 归一的全时序叠加，红虚线=行160起点，灰点线=基线±3σ。视觉-统计对齐：图的设计问题"三链是否自样本161同步越过基线3σ"由其统计元数据直接回答——三通道方差比 ×189.4/×115.8/×221.5、均值偏移 ≤0.114 sd（非 VLM 环境，图仅证明按设计渲染，`06_scripts/dp_d14_discriminative_results.json` figure.status=rendered）。

![关键过程变量时序总览](03_figures/fig_temporal_overview.png)

**fig_temporal_overview.png**：全变量时序网格。视觉-统计对齐：异常的严格局域性（反应器冷却回路高方差振荡 vs 其余回路窄带平稳）与 era_variance_scan 的"49列 VR 中位 1.084"一致——全局扰动类候选（H3/H5/H6）与图像层设计观察不符。

![单产品全局z归一时序叠加](03_figures/fig_vlm_temporal_overlay_single_product.png)

**fig_vlm_temporal_overlay_single_product.png**（visual_analysis.py Phase 2，无分组列退化为全局 overlay）：主振荡三通道加粗。视觉-统计对齐：synchronous_groups（controller_pair lag0 r=0.997；physical_pair lag5 r=−0.965）与 precedence_signals（XMEAS_9 领先 XMEAS_21，visual_confidence=HIGH）均为 metadata-backed 判定（03_figures/visual_analysis.json）。

![滚动相关稳定性热图](03_figures/fig_vlm_synchronization.png)

**fig_vlm_synchronization.png**（Phase 5 滚动相关热图）：诊断问题"相关性随时间的稳定性"由 LOO/子窗/稳态过滤回答（§4.6）。

![全局全数据z归一叠加](03_figures/fig_vlm_temporal_overlay.png)

**fig_vlm_temporal_overlay.png**：跨段同步组与趋势形态的全局参照层。视觉-统计对齐：独立参数清单（进料组/汽提组与主振荡无强耦合）与 §4.7 对照面复算一致。

### 7.4 预检修复指令（M1-M5）落实对照与 Judge 警告处置

| 项 | 内容 | 本报告落实位置 |
|:--|:--|:--|
| M1 | 子窗 r 0.9927~0.9936 与稳态行 r 0.9968 未逐位复现（复算 0.9977~0.9986 / 0.9982），lag5 CCF 偏差 ≤0.0011 | §4.6（引用复算值并披露工件差异） |
| M2 | "幅值内检0.96"≡\|r(lag5)\|，非独立能量衡算验证 | §6.3（改述为线性一致性重述） |
| M3 | "其余46列中位数1.084"口径混合 | §4.7（写明49列/46列两口径） |
| M4 | 本体 9→21 符号反转需显式解释 | §6.4（双通道叠加+闭环相位解读专段） |
| M5 | 基线"|r|≤0.33"仅适用 9~21 对 | §4.5（采用 evidence.json 三对口径） |
| Judge 警告1（列计数措辞） | 同 M3 | §4.7 |
| Judge 警告2（非VLM） | 图表证据降级披露 | §3、§7.3；建议见 §8 |
| Judge 警告3（cleaning_integrity 缺口） | 如实披露+原始层复算兜底 | §3 |
| Judge 警告4（基线仅160行） | 保留于假设与局限 | §3、§9 |

---

## 8. 建议与后续

### 8.1 分级行动计划

| 优先级 | 行动 | 具体操作 | 预期效果 | 验证方法 | 时间/成本 |
|:--|:--|:--|:--|:--|:--|
| **P0**（48h内） | XMV_10 现场验证 | 离线冲程测试（全行程检查粘滞/填料摩擦/执行机构）；调阅现有定位器或阀杆位置反馈记录 | 当场证实或证伪粘滞——五条证伪条件中最直接的路径 | 冲程测试记录 vs 本报告 falsification_conditions(1)(4) | 1个班次；低（可结合计划检修窗口） |
| **P0**（并行） | 控制阀检查/维修 | 若确认粘滞：填料润滑/更换、执行机构检修；修复后在线观察极限环是否消失 | 消除21分钟极限环；中止阀门磨损（≈380次/天大阶跃） | 修复后 24h：XMEAS_9 sd 回落至基线量级（≈0.019 °C）、阶跃 p95 回落至 ≈1.3%/3min | 视检修窗口 |
| **P1**（72h内） | 仪器补装 | CWR-100 支路临时冷却水流量变送器 + 入口温度测点 | 打通"阀位→流量"链（现 DATA_LINK_MISSING）；切开"阀侧 vs 供给侧"机制切分，可把置信 80 → 90+ | 流量与 XMV_10 的开环相关及相位检验 | 临时仪表租赁+安装，1-2天 |
| **P1**（并行） | 记录审计 | 调阅样本161前后 DCS 控制器整定/维护记录；冷却水 header 压力/温度记录 | 排除 OPERATION 类替代（重整定）与残余共源可能 | 对照 falsification_conditions(2)(5) | 0.5天；零成本 |
| **P2**（1-3月） | 长效机制 | 回路性能监测中部署粘滞在线检测（MV 阶跃统计+极限环 ACF）；阀位信号采样分辨率评估提升；阀门纳入周期维护计划 | 早发现同类故障，避免加速磨损发展到失效 | 月度回路审计指标 | 常规技改预算 |
| **P2**（环境允许时） | 证据层补强 | VLM 可用时对 fig_d14_reactor_loop_overlay.png 补一次目视读图（Judge 警告2/预检 I4 建议）；data-processor 补齐 cleaning_integrity 记录（Judge 警告3 建议） | 形态学独立确认层；完整清洗审计链 | visual_analysis.json observation_mode 升级 | 低 |

### 8.2 运行侧临时建议

在阀门修复前：保持对该回路的强化监视（报警阈值按异常段波动特征临时放宽，避免告警风暴）；**不建议**以重整定控制器作为掩盖手段——整定过紧产生的振荡幅度受过程增益限制，无法解释 ×16.2 的 MV 阶跃突变，且会改变回路动力学、污染后续现场验证证据。

---

## 9. 方法论说明与局限

**分析方法**：9 阶段流水线 Step 0-6 产物（四个编号体系——Pipeline Step / Agent Phase / R1-R8 推理段 / Method Stage——各自独立，本报告不混用）。统计核心为 M13 自定义判别性分析（跨era方差扫描、窗口化方差变点、闭环滞后 CCF、ACF 极限环检测、阀位阶跃签名、精确留一法、4×200 子窗分层、稳态行过滤、能量符号回归、传感器一致性扫描），配合 M5 生产状态检测（三算法融合）、M7 物理检验（P∝ṁ²）与 validate 全套反伪迹门禁；全部脚本以 venv python 对原始层复算可重现（02_processed/data_analysis_conclusion.json expert_review_summary）。诊断遵循竞争假设协议（≥3 个机制异类假设、四反投机条件：时间起点三重共定位 + 统计显著性四重门禁 + 物理机制闭合 + 无矛盾观测——本案四条件全部满足）。

**假设**（04_diagnostics/confidence.json assumptions）：XMEAS_9 与 XMEAS_21 为物理独立变送器（AR-1，H2 排除的前提）；TE 标准控制结构配对 XMV_10↔反应器温度（AR-5，置信 medium——若配对赋义错误，方向论证需重估）；180 s 采样下的 CCF/ACF 结构可代表回路动力学（21分钟周期在奈奎斯特内充分）；基线行 0-159 代表正常工况（AR-4，用户声明）。

**局限与数据缺口**（04_diagnostics/diagnosis.json data_gaps；Judge 警告4 保留于此）：

1. 无冷却水流量变送器与入口温度：ṁ_cw 不可直测，阀位→流量链以 XMEAS_21 热力脚印替代验证；M9 配对差分不可构造。
2. 无阀杆位置/定位器反馈：stick-slip 为签名推断（L3+L5），非 L1 直测；冷却水支路专属供给波动未达 ≥90 排除置信度，作为已披露残余保留。
3. 无控制器整定/维护日志：样本161种子事件（粘滞发生 vs 重整定）数据内不可证伪，依赖现场记录。
4. 次级传导（XMEAS_7/16/38）滞后 CCF |r|≤0.193：180 s 采样 + 组成分析器积分平滑，定量传播链 INDETERMINATE。
5. 非 VLM 环境：图像层证据停留在 metadata-backed，无像素级形态学确认。
6. 基线 era 仅160行（8小时）：方差比分母基于较短窗口，基线非平稳性理论上可影响 VR 幅值（起点定位与结论方向不受影响）。

**不确定性三分解**：aleatory——过程湍流/测量噪声（基线 sd 0.0186 °C / 0.1279 °C / 0.4988% 为噪声地板）与极限环相位的采样混叠（周期估计精度 ±1采样步，1260±180 s），不可消解但量级已知；epistemic——机制归属三分残余（粘滞/支路供给/重整定），可通过 §8 P0/P1 测量消解（置信 80→90+ 或推翻）；model——线性 CCF 对执行非线性的描述力有限、闭环数据原则上不可开环分解 PV/MV 因果。即便全部门禁通过，置信上界 82——**进一步提高置信需要新增仪器证据而非更多统计**（04_diagnostics/reasoning_chain.json R8）。

**报告边界**：本报告结论层级限定于"定位级 + 机制类"——根因位于 CWR-100 反应器冷却支路执行环节（XMV_10 粘滞类故障）；部件级维修指令以 §8 P0 现场验证结果为准。报告为中文行文，枚举字段保留英文（DETERMINED、EXCLUDED、OBSERVED、INFERRED、KNOWN_PHYSICS、DATA_LINK_MISSING、INDETERMINATE 等）。本报告未读取 results/ 与 scripts/benchmark/ 目录（红线遵守），未使用网络。
