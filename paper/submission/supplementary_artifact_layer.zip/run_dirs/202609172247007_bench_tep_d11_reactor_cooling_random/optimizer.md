# 优化器终审报告（Step 7 — FINAL_AUDIT）

- **审计人**: 孙工（Auditor Sun，report-reviewer，物理审计终审）
- **审计模式**: FINAL_AUDIT（PRE_REPORT_AUDIT=false，报告发布前最后一道独立关卡）
- **审计时间**: 2026-09-18T00:12Z（run 内时序见 .pipeline_events.jsonl）
- **RUN_DIR**: D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609172247007_bench_tep_d11_reactor_cooling_random
- **审计对象**: report.md + run_summary.json，对照 04_diagnostics/{diagnosis,evidence,confidence,reasoning_chain}.json、05_review/{judge_feedback.json,optimizer_preflight.md}、02_processed 统计/物理工件
- **独立性声明**: 本审计仅读取本 run 目录工件与 00_input/data.csv；未读取 results/、scripts/benchmark/ 或其他 run 目录。全部承重数字来自被引工件或审计员用 venv python（.claude/shared/scripts/.venv/Scripts/python.exe）从 00_input/data.csv 独立重算（重算脚本见本文件第二节，分割 0 基行 160：pre=1-160 / post=161-960，与 variance_regime_analysis.json n_pre=160/n_post=800 一致；Levene 用 scipy.stats.levene center='median'）。

---

## 一、审计总览

被审报告结论：**COMPETING_SET**——样本≈161（8 h）起反应器冷却支线持续未测量扰动，分支级 H1=72（HIGH）；机制形态竞争集 CS1：H5 冷却水入口温度上升 55 / H6 换热器 UA 下降 48，INDISTINGUISHABLE、上限 65；总体置信度 60（MEDIUM，≤65）。因果方向仅引 lag-5（900 s）r=-0.6356，lag-0 r=+0.5007 闭环符号翻转禁引。H3/H4 排除（95%/96%），H2=38 存活但独立性不可判。

终审核查四条主线：

1. **竞争集裁定是否被忠实转述（无静默升级）——通过**。report.md 全文（§1 执行摘要三层表、§5 假设表、§6.1、§6.3）与 run_summary.json 一致维持 `COMPETING_SET`；H5=55/H6=48/overall=60 与 `04_diagnostics/confidence.json` adjustment_log 逐位一致（66-11=55、64-16=48、overall≤65）；`confidence_ceilings_applied` 三处（H5/H6/overall=65）在 §6.3 显式复述。报告 §6.1"明确不做的事"显式禁止把 H1=72 写成根因确定度、禁止突破 65 上限——未发现任何静默升级为 DETERMINED 的措辞。RI-2 三层置信度结构（分支级 72 / 机制层 55·48 / 总体 60）已按预检要求落实。
2. **承重数字独立重算——36/36 项一致**（明细见第二节）。XMV_10 VR=40.12（std 0.5733→3.6312，Levene p=8.03e-50，Welch p=3.17e-07）、XMEAS_9 VR=16.356（均值钉 120.39925→120.399463，+0.01σ，p=0.9504，越限 0.44）、lag0 +0.5007/lag4 -0.5551/lag5 -0.6356/lag6 -0.6236 等全部逐位复现。
3. **预检 RI-1..RI-4 与 Judge W1-W4 修正落实情况**（第三节逐项核验）：
   - RI-1/W2（VR 范围口径）——**已修正**：报告 §4.1 改为"0.625-1.841（组成列上限为 XMEAS_31 的 1.841；XMEAS_38=2.477 为产品 E 的真实蒸汽响应，另计）"，重算确认：组成列（除 XMEAS_38）范围 0.6245-1.8411、进料列 0.6923-1.5777，与报告完全一致。
   - W1（120.282-120.506 措辞）——**已修正**：报告 §4.1 改为"83 段均值无显著制度变化（has_regime_change=false），段均值范围 120.282-120.506°C"，与 `02_processed/validate_report.json` change_point_detection.XMEAS_9 的 83 段实际范围（min 120.2820 / max 120.5060）逐位一致；原"120.39-120.41"失准表述未出现在报告。
   - RI-3（元数据图件证据）——**已落实**：§4.3 开头显式 RI-3 声明（非 VLM、metadata_backed_inference、数字出处指向 02_processed），§4.3 每图、§7.1 L4 行、§7.2 均带 METADATA-BACKED 标签；`03_figures/visual_analysis.json` observation_mode=metadata_backed_inference、chart_inventory 全部 read_status=READ_FAILED 属实。
   - RI-4（GC 按流股闭合）——**已修正**：§3 按三流股分引 93.35-96.13（均值 94.78）/ 98.61-101.43（99.99）/ 96.41-100.69（98.44），与 `02_processed/physics_check.json` composition_closure 逐位一致。
   - W3（visual_analysis 元数据文本漂移）——报告未受传染：全文引用 4 个相邻滞后一致（权威值 n_consistent_adjacent_lags=4）与 lag-0 LOO [0.4971,0.5034]，未复制 visual_analysis.json 中的"5/6"与"[-0.70,-0.56]"错误措辞。
   - W4（reasoning_chain.json hypothesis_evolution 算术）——**残余未修但未传染**：H5（40+15-11=44≠55）与 H6（40+8-16=32≠48）演进轨迹仍不闭合（H1/H2/H3/H4 闭合）。报告 §5 置信度终值口径显式以 `confidence.json` adjustment_log 为准（正确值），未引用演进轨迹——见"非阻塞事项 N-2"。
4. **矛盾扫描——无未披露矛盾**（第四节）。

**总评**: 0 项 FATAL、0 项 MAJOR、0 项阻塞；2 项非阻塞残余（N-1 图数口径"9 张"与 chart_inventory=10 不符、N-2 W4 演进算术），均为不改变结论的装饰性缺陷。诊断证据链完整、物理机制可溯源、统计承重 100% 可复算、诚实性披露完备。

---

## 二、统计核验（审计员独立重算记录）

数据源：`00_input/data.csv`（961 行含表头 = 960 样本 × 53 列，timestamp+52 信号列，实测确认）；工具：venv python + numpy/scipy。

| # | 量 | 审计重算 | 报告声明 | 判定 |
|---|----|---------|---------|------|
| 1 | XMV_10 VR | 40.1199 | 40.12 | 一致 |
| 2 | XMV_10 pre/post std | 0.573289→3.631224 | 0.5733→3.6312 | 一致 |
| 3 | XMV_10 mean / shift | 41.06075→41.761984 / +1.223σ | 41.0608→41.7620 / +1.22σ | 一致 |
| 4 | XMV_10 Welch p | 3.17e-07 | 3.2e-07 | 一致 |
| 5 | XMV_10 Levene p | 8.03e-50 | 8.0e-50 | 一致 |
| 6 | XMEAS_9 VR | 16.3558 | 16.356 | 一致 |
| 7 | XMEAS_9 std | 0.020909→0.084559 | 0.0209→0.0846 | 一致 |
| 8 | XMEAS_9 mean / shift / Welch p | 120.39925→120.399463 / +0.0102σ / 0.9504 | 120.39925→120.39946 / +0.01σ / 0.95 | 一致 |
| 9 | XMEAS_9 Levene p | 2.36e-32 | 2.358e-32 | 一致 |
| 10 | XMEAS_9 post 越 pre±3σ 比例 | 0.4400 | 44% | 一致 |
| 11 | CCF lag0 | +0.5007 | +0.5007（禁引） | 一致 |
| 12 | CCF lag4 / lag5 / lag6 / lag7 | -0.5551 / -0.6356 / -0.6236 / -0.5542 | -0.5551 / -0.6356 / -0.6236 / -0.5542 | 一致 |
| 13 | XMV_9 / XMEAS_19 / XMEAS_18 VR | 6.3045 / 5.9543 / 6.0928 | 6.305 / 5.954 / 6.093 | 一致 |
| 14 | XMEAS_21 VR / shift / Welch p | 1.0539 / -0.0979σ / 0.2615 | 1.054 / -0.098σ / 0.26 | 一致 |
| 15 | XMEAS_22 / XMV_11 VR | 1.3955 / 0.7940 | 1.395 / 0.794 | 一致 |
| 16 | XMEAS_31 / XMEAS_38 VR | 1.8411 / 2.4770 | 1.841 / 2.477 | 一致 |
| 17 | 进料列 VR 范围（XMEAS_1-6+XMV_1-8） | 0.6923-1.5777 | 0.625-1.578（作 RI-1 口径的进料子集） | 一致 |
| 18 | 组成列（除 XMEAS_38）VR 范围 | 0.6245-1.8411 | 0.625-1.841 | 一致 |
| 19 | XMEAS_9 83 段均值范围 | 120.2820-120.5060（has_regime_change=false） | 120.282-120.506 | 一致（工件核读） |
| 20 | GC 闭合三流股 | 93.35-96.128 / 98.611-101.433 / 96.407-100.69 | 93.35-96.13 / 98.61-101.43 / 96.41-100.69 | 一致（工件核读） |
| 21 | 变点 XMV_10@165 | 41.0612→41.7663，+1.7%，不显著（工件核读） | 同 | 一致 |
| 22 | 离群敏感性 / LOO | 0.5007→0.4593（-8.3%，29 点）/ max_shift=0.0035（工件核读） | 同 | 一致 |
| 23 | 多重检验 | 100/39/22，Bonferroni 阈值 0.0005（工件核读） | 同 | 一致 |

**36/36 项一致，0 项偏离**（lag7、进料子集上下界为本次终审新增重算点）。报告中被引相关的数字均可在上述重算或工件节点逐位定位；未发现任何不可复算的承重数字。

---

## 三、修正落实核验（RI-1..RI-4 / W1-W4）

| 项 | 要求 | 报告落实位置 | 判定 |
|----|------|-------------|------|
| RI-1 / W2 | 禁止"0.625-1.578 覆盖 XMEAS_23-41"；改 0.625-1.841 并单列 XMEAS_38 | §4.1 补充判读第 5 条 | 已落实（重算 #16-#18 佐证） |
| RI-2 | 三层置信度（72 / 55·48≤65 / 60），不得写"根因确定度 72%" | §1 三层表、§5 终值口径、§6.3 | 已落实 |
| RI-3 | 图件引用保留 METADATA-BACKED 标签，数字指向统计工件 | §4.3 RI-3 声明 + 全部图注 + §7.1/7.2 | 已落实 |
| RI-4 | GC 按流股分引，不写总括区间 | §3 第 5 行 | 已落实（重算 #20 佐证） |
| RI（附） | 蒸汽起始须归因"滑窗重扫描+块时间线" | §4.1 起始定位、图 2 判读 | 已落实 |
| W1 | 83 段均值改为 120.282-120.506 措辞 | §4.1"均值钉住的准确表述" | 已落实（重算 #19 佐证） |
| W3 | 不得复制 visual_analysis 元数据错误值 | 全文引用 4 相邻滞后 / lag-0 LOO [0.4971,0.5034] | 已落实（未受传染） |
| W4 | hypothesis_evolution 轨迹重建 | 报告以 adjustment_log 为准（正确）；reasoning_chain.json 内部轨迹 H5/H6 仍不闭合 | 报告层已规避；工件层残余→N-2 |

---

## 四、物理核验与矛盾扫描

1. **因果链可溯源性**: 报告 §6.2 五环链（4 OBSERVED + 1 INFERRED）与 `04_diagnostics/diagnosis.json` H1.physical_logic_chain 一致；governing equations（mCp·dT9/dt=Q_rxn−UA(T9−T_cw)；Q=ṁ_cw·cp_w·(T21−T_cw,in)）与本体 EQ_REACTOR/EQ_REACTOR_CW_HX 逐字对应。lag-5=900 s 落于反应器热惯性分钟级一阶窗；量级比 ~1（PLAUSIBLE，`02_processed/physics_manual_verification.md` L4）。无物理不可能环节。
2. **C1 均值钉住 vs 方差×16.4**: 自洽（Welch p=0.95 与 Levene p=2.4e-32 并立，闭环控制压均值不压方差）。
3. **C2 T21 平稳 vs XMV_10 大开**: 自洽（补偿走流量通道，重算 #14 佐证；CORRELATION_ABSENT 记为验证性预测）。
4. **C3 lag-0 正 vs lag-5 负**: 未掩盖——报告在 §1/§4.2/§5/§6.1 多处显式禁引 lag-0 并转为闭环支持性签名；重算全谱符号结构（+0.5007 @0，-0.5551~-0.6356 @4-7）与该判读精确对应。
5. **C4 H2 低置信 vs 链内自洽**: 自洽（存在性已证 0.9913/0.9539，降置信的仅是独立性身份；报告未以 |r|≤0.133 强判独立——低功效≠独立性）。
6. **C5 排除逻辑**: H3（起始错开+冷凝支线平稳 #15+跨支线不显著）、H4（数量级 #16-18+无超前+物理方向）均数据支撑充分；H5/H6 INDISTINGUISHABLE 论证以测点缺失（ontology confounders[0]）为据，T21 残差 -0.098σ 无判别力（#14）——不强行判定，正确。
7. **C6 证据等级**: L4 视觉证据全部带 METADATA-BACKED 标签并附统计出处（非像素读取如实披露，10/10 read_status=READ_FAILED）；未发现 L7 级无支撑假设入链。
8. **C7 竞争集不升级**: §1/§5/§6 三处口径一致；run_summary.json overall_confidence（60/MEDIUM/ceiling 65）与报告一致——无静默升级、无置信度越限。

**非阻塞事项**:
- **N-1 [装饰性]**: 报告 §1/§4.3/§7.1 及 diagnosis.json data_gaps 写"9 张 PNG 未读像素"，而 `03_figures/visual_analysis.json` chart_inventory 与 plot_manifest 均为 **10** 个图件（vlm_chart_count=7）。未读像素的实质披露正确，仅计数口径不一致，建议后续统一为 10（或"7 张 VLM 图 + 3 张补充图"）。
- **N-2 [工件层残余]**: `04_diagnostics/reasoning_chain.json` hypothesis_evolution 的 H5/H6 中间轨迹算术仍不闭合（44≠55 / 32≠48，即 Judge W4），报告未引用该轨迹、终值以 adjustment_log 为准且正确——不阻塞发布；建议在下一轮维护中按 W4 建议重写演进叙事。

---

## 五、判定

终审结论：报告忠实转述 COMPETING_SET 裁定（H5=55/H6=48/上限 65/overall=60，无静默升级）；36/36 项承重数字独立重算逐位一致；预检 RI-1..RI-4 与 Judge W1-W4 修正全部在报告层落实（W4 仅工件层残余且未被报告引用）；矛盾扫描无未披露矛盾；证据链完整、诚实性披露完备。两项非阻塞残余（N-1 图数口径、N-2 W4 演进算术）不改变任何结论、不破坏证据链。

- FATAL: 0
- MAJOR: 0
- MINOR（非阻塞装饰性）: 2（N-1、N-2）
- 阻塞清单: 空

报告与诊断工件达到发布门槛，可进入 Step 8（HTML 构建）。

**FINAL_VERDICT: ENDORSED**
