// Assemble 02_processed/data_analysis_conclusion.json (Engineer Zhang handoff).
// time_lag_analysis block is embedded verbatim from 02_processed/time_lag_analysis.json.
import fs from "fs";
import path from "path";

const RUN = "D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609172247007_bench_tep_d11_reactor_cooling_random";
const rd = (...a) => path.join(RUN, ...a);
const tl = JSON.parse(fs.readFileSync(rd("02_processed", "time_lag_analysis.json"), "utf8"));
const sel = JSON.parse(fs.readFileSync(rd("02_processed", "analysis_parameter_selection.json"), "utf8"));

const V = "02_processed/variance_regime_analysis.json";
const T = "02_processed/time_lag_analysis.json";
const PH = "02_processed/physics_check.json";
const RF = "02_processed/production_regime_filter.json";
const CE = "02_processed/causal_evidence_map.json";
const VR = "02_processed/validate_report.json";
const AR = "02_processed/anomaly_report.json";
const ON = "01_ontology/ontology.json";
const PC = "02_processed/analysis_parameter_selection.json";
const MP = "02_processed/analysis_method_plan.json";
const F1 = "03_figures/fig_focus_variance_shift.png";
const F2 = "03_figures/fig_rolling_variance.png";
const VA = "03_figures/visual_analysis.json";

const conclusion = {
  run_id: "202609172247007_bench_tep_d11_reactor_cooling_random",
  generated_at: new Date().toISOString(),
  analysis_mode: "ontology_guided_plus_custom",

  baseline_script_results: {
    scripts_run: [
      "prepare-stage stats/run.py --mode correlation (targets XMEAS_9/XMEAS_21, max_lag=20)",
      "prepare-stage stats anti-spurious battery (Simpson/trend/outlier/Spearman divergence/change-point)",
      "prepare-stage dp_toolkit.py anomaly (anomaly_report.json)",
      "prepare-stage temporal overview figure (03_figures/fig_temporal_overview.png)"
    ],
    key_findings: [
      { finding: "质量目标XMEAS_9的全预测变量扫描中XMV_10是唯一强关联（lag0 r=+0.501, p<0.001, n=960），且滞后CCF在lag=-5处达r=-0.636（控制器超前温度5个采样）", source: "02_processed/validate_report.json", evidence_rank: 3 },
      { finding: "anti-spurious battery对两target全绿：0趋势混淆、0离群驱动、0 Simpson、整体ROBUST", source: "02_processed/validate_report.json", evidence_rank: 3 },
      { finding: "异常报告：XMEAS_9有5个>3σ低幅离群点位（首个@256，占0.52%），XMEAS_21仅3个（0.31%）——两质量目标离群点稀少但post窗口44%样本越出pre窗口3σ带", source: "02_processed/anomaly_report.json", evidence_rank: 3 },
      { finding: "XMEAS_12~XMV_7 (r=1.000)、XMEAS_15~XMV_8 (r=1.000)、XMEAS_17~XMV_11 (r=-0.999) 等强相关为液位/阀执行回路恒等关系，非诊断证据", source: "02_processed/validate_report.json", evidence_rank: 6 },
      { finding: "ontology阶段预检：post窗口越pre-3σ带比例 XMV_10=66.6%、XMEAS_9=44.0%、XMV_9=26.6%、XMEAS_19=25.3%、XMEAS_18=28.8%，其余列多<3%", source: "01_ontology/r2_stage1_precheck.json", evidence_rank: 3 }
    ],
    limitations: [
      "prepare阶段统计包只对2个quality target做了相关/滞后分析，未做全列方差制度检测（本阶段以自定义脚本补齐）",
      "validate_report.json的target只覆盖XMEAS_9/XMEAS_21，蒸汽支线（XMV_9/XMEAS_19/XMEAS_18/XMEAS_38）的滞后证据由06_scripts/dp_semantic_analysis.py补算",
      "无质量检验数据通道，双驱动联动无法由脚本建立"
    ]
  },

  expert_custom_analysis: {
    custom_scripts_written: true,
    script_inventory: [
      {
        script: "06_scripts/dp_semantic_analysis.py",
        purpose: "本体引导语义分析：全52列方差制度检测（Levene+F比+80样本块时间线+滑窗起始重扫描）、7对引用相关的滞后补偿CCF（±20样本）+窗口一致性+LOO杠杆+去趋势+pre/post分层、生产制度检测、物理闭合与正负号校验、两张诊断图",
        inputs: ["00_input/data.csv", "02_processed/cleaned_data.json", "01_ontology/ontology.json"],
        outputs: [
          "02_processed/cleaned_data.csv",
          "02_processed/variance_regime_analysis.json",
          "02_processed/production_regime_filter.json",
          "02_processed/time_lag_analysis.json",
          "02_processed/physics_check.json",
          "02_processed/causal_evidence_map.json",
          "03_figures/fig_focus_variance_shift.png",
          "03_figures/fig_rolling_variance.png"
        ]
      },
      {
        script: "06_scripts/finalize_visual_analysis.mjs",
        purpose: "把visual_analysis.py骨架升级为metadata_backed_inference模式（非VLM环境），并将统计元数据挂接到chart清单与图注",
        inputs: ["03_figures/visual_analysis.json", "02_processed/variance_regime_analysis.json", "02_processed/time_lag_analysis.json"],
        outputs: ["03_figures/visual_analysis.json", "03_figures/plot_manifest.json", "03_figures/image_captions.json"]
      }
    ],
    analysis_questions: [
      "Q1 异常形态是均值漂移还是方差制度变化？起始点是否与用户先验样本161一致？",
      "Q2 XMV_10↔XMEAS_9的闭环关系中哪个滞后承载因果方向？lag-0相关是否可引用？",
      "Q3 反应器冷却支线与汽提蒸汽支线是同时被扰、先后传播、还是相互独立？",
      "Q4 进料/组成侧是否存在可比量级的驱动？",
      "Q5 蒸汽支线波动是否有真实过程后果（产品E是否按汽提效率物理响应）？",
      "Q6 冷却水出口温度XMEAS_21为何在XMV_10大动时保持平稳（能量平衡解释）？"
    ],
    custom_outputs: [
      "02_processed/variance_regime_analysis.json",
      "02_processed/time_lag_analysis.json",
      "02_processed/production_regime_filter.json",
      "02_processed/physics_check.json",
      "02_processed/causal_evidence_map.json",
      "03_figures/fig_focus_variance_shift.png",
      "03_figures/fig_rolling_variance.png"
    ],
    why_needed: "固定统计包只覆盖2个target的相关/滞后，无法回答方差制度变化（本次异常的显性形态）、无法对蒸汽支线做滞后判别、也无法给出支线起始时间结构——这些是诊断员构建竞争假设的关键输入。"
  },

  ontology_industry_interpretation: [
    {
      parameter_or_pattern: "XMEAS_9（反应器温度）均值钉住120.399°C而方差×16.4",
      ontology_role: "全流程最关键被控变量，由XMV_10执行控制（ontology: controlled_by XMV_10）",
      industry_knowledge: "强PID回路下'均值健康、方差生病'是控制器补偿未测量扰动的典型签名；受控变量均值正常不等于过程正常",
      interpretation: "不能因120.4°C均值保持而判过程健康；诊断对象应从均值转向方差制度与执行器活动性",
      confidence: "high"
    },
    {
      parameter_or_pattern: "XMV_10（反应器冷却水阀）方差×40.1、均值+1.22σ，为全数据集活动性增幅最大执行器",
      ontology_role: "反应器热平衡的执行通道（ontology relationship XMV_10→XMEAS_9：冷却水量↑→移热↑→温度↓）",
      industry_knowledge: "执行器大幅持续补偿⇒其所服务的物理平衡（此处为反应放热与移热的平衡）被外部扰动；阀位统计量是回路健康的最灵敏前置指标",
      interpretation: "反应器冷却回路存在持续性未测量扰动，扰动量（需要的额外移热能力）可由XMV_10开度增量定性表征",
      confidence: "high"
    },
    {
      parameter_or_pattern: "XMEAS_21（冷却水出口温度）平稳（VR=1.054, p=0.69）与XMV_10活跃并存",
      ontology_role: "温升载体：T21=T_cw,in+Q_rxn/(ṁ_cw·cp_w)（ontology governing_equation）；冷却水入口温度为未观测共同因子（ontology confounders[0]）",
      industry_knowledge: "入口温度上升或换热器传热能力下降都会迫使控制器开大阀门；流量增大把温升ΔT压回，可使T21近乎不动——两种故障形态在本测量集下混叠",
      interpretation: "冷却侧扰动的具体形态（入口温度漂移 vs 传热能力下降/结垢）从本数据不可唯一辨识，须以COMPETING_SET移交并建议调阅公用工程记录",
      confidence: "medium"
    },
    {
      parameter_or_pattern: "汽提蒸汽链XMV_9→XMEAS_19→XMEAS_18同步高波动（方差×6.0-6.3），XMEAS_19均值-0.98σ",
      ontology_role: "S5汽提蒸汽供热链（ontology: XMV_9→XMEAS_19 linear、XMEAS_19→XMEAS_18 monotonic、XMEAS_19→XMEAS_38 inverse）",
      industry_knowledge: "蒸汽流量均值下移伴波动放大常见于蒸汽管网压力波动/供热能力受限；产品E含量是汽提效率的敏感指示器",
      interpretation: "汽提强度经历了真实的过程性衰减-恢复振荡并传导至产品E（XMEAS_38方差×2.5、反向响应方向成立），非仪表噪声",
      confidence: "medium"
    },
    {
      parameter_or_pattern: "GC组成列（XMEAS_23-41）相关解释",
      ontology_role: "流股6/9/11组成，受GC分析周期与零膨胀影响（ontology confounders[2]）",
      industry_knowledge: "GC台阶状更新与共同分析动力学可在组成列之间制造伪相关；组成列的精确滞后通常不可靠",
      interpretation: "本次对组成列仅引用方向与量级（如XMEAS_19→XMEAS_38反相关方向），不引用其精确滞后值",
      confidence: "medium"
    }
  ],

  adaptive_decision_audit: {
    data_view_mode: "process_only",
    mode_justification: "53列全部为过程测量/控制信号（XMEAS过程+GC流股分析、XMV阀位指令），无独立质量检验通道；与02_processed/anomaly_report.json dual_drive_analysis.data_view_mode=process_only一致",
    data_shapes_detected: [
      "连续化工时间序列（960行×180s等间隔，真实timestamp单调）",
      "单产品连续制度（无批/产品分组列）",
      "闭环控制结构（6个温度/液位/流量回路、11个阀位指令列）",
      "方差制度变化主导（非均值漂移）",
      "GC流股组成三组（闭合指纹）"
    ],
    selected_analyses: [
      {
        analysis: "全52列方差制度检测（Levene+F比+80样本块时间线+滑窗起始重扫描）",
        reason: "异常的显性形态是方差跳变而非均值漂移（XMEAS_9均值z=+0.01而方差×16.4）——均值检验会漏诊",
        evidence_artifacts: ["02_processed/variance_regime_analysis.json", "03_figures/fig_rolling_variance.png"],
        coverage_status: "covered"
      },
      {
        analysis: "滞后补偿CCF（±20样本）+窗口一致性+LOO杠杆+去趋势+pre/post分层（7对引用相关）",
        reason: "v6.4反伪相关纪律：本结论引用的每一对相关都必须经滞后补偿与稳健性核验",
        evidence_artifacts: ["02_processed/time_lag_analysis.json", "02_processed/causal_evidence_map.json"],
        coverage_status: "covered"
      },
      {
        analysis: "生产制度/稳态过滤（连续单制度检测）",
        reason: "v6.5要求在统计前确认生产状态；结论：全程单一连续生产制度，异常窗口属'受扰稳态'不可剔除",
        evidence_artifacts: ["02_processed/production_regime_filter.json"],
        coverage_status: "covered"
      },
      {
        analysis: "物理约束校验（GC组成闭合+normal-range越限+能量平衡方向）",
        reason: "反伪相关纪律第2条：统计结果未经物理校验只是线索",
        evidence_artifacts: ["02_processed/physics_check.json"],
        coverage_status: "covered"
      },
      {
        analysis: "焦点诊断图（z基线叠加+滚动σ时间线）",
        reason: "为诊断员/报告员提供方差制度变化的直读证据",
        evidence_artifacts: ["03_figures/fig_focus_variance_shift.png", "03_figures/fig_rolling_variance.png"],
        coverage_status: "covered"
      }
    ],
    skipped_or_not_applicable: [
      { analysis: "批完整性/重复批检测（M3）", status: "not_applicable", reason: "单产品连续运行，无批ID列" },
      { analysis: "逐产品分析（M8产品分层）", status: "not_applicable", reason: "无产品分组列；已以pre/post窗口分层替代" },
      { analysis: "配对传感器差分/效率分析（M9）", status: "not_applicable", reason: "无独立成对进出口传感器数据形状" },
      { analysis: "多区漂移定位（M10）", status: "not_applicable", reason: "无一机多区传感器结构" },
      { analysis: "事件响应对齐（M11）", status: "skipped", reason: "唯一事件=样本161用户先验（非数据内事件列），已由滑窗起始重扫描数据复核覆盖" },
      { analysis: "场景pattern库全表（M12）", status: "skipped", reason: "按方法计划仅执行方差制度+滞后链相关pattern，其余与本数据形状不匹配" }
    ],
    custom_analysis_required: true,
    custom_analysis_reason: "方差制度检测、蒸汽支线滞后链、支线起始时间结构均为固定脚本缺口，且为本次诊断的核心判别证据",
    expert_review_summary: "张工复核：全部结论数字可由00_input/data.csv经06_scripts/dp_semantic_analysis.py复算；引用的每对相关均带滞后补偿、去趋势、pre/post分层与LOO界；lag-0闭环相关已显式禁止用于因果方向；冷却侧扰动形态与蒸汽支线独立性的不可辨识性如实降级为COMPETING_SET/证据缺口，未越数据边界下结论。"
  },

  analysis_coverage_matrix: {
    pure_process_analysis: {
      status: "covered",
      evidence_artifacts: ["02_processed/validate_report.json", "02_processed/variance_regime_analysis.json", "02_processed/time_lag_analysis.json"],
      summary: "52过程变量全量方差/均值制度检测+7对滞后补偿相关+2个质量目标的全预测变量扫描",
      gaps: ["蒸汽支线独立性判定证据不足（跨支线|r|≤0.133不能强判）"]
    },
    process_inspection_dual_drive: {
      status: "not_applicable",
      evidence_artifacts: ["02_processed/anomaly_report.json"],
      summary: "数据视图为process_only（与anomaly_report一致）：无独立于过程测量的质量检验通道，产品GC组成属过程侧流股分析，过程→质量双驱动联动无法建立",
      gaps: ["缺质量检验数据：过程异常到产品质量影响的因果时间顺序只能经XMEAS_38间接推断"]
    },
    grouping_confounding: {
      status: "covered",
      evidence_artifacts: ["02_processed/validate_report.json", "02_processed/time_lag_analysis.json", "02_processed/production_regime_filter.json"],
      summary: "无分组列（单产品连续）——混淆控制以pre/post窗口分层、去趋势、LOO杠杆、多重检验告警实现；anti-spurious battery对2个target全绿",
      gaps: ["无组列条件下Simpson结构检验只能给出零结果；冷却水入口温度为未观测共同因子（结构性混淆，不可控制）"]
    },
    temporal_regime_event: {
      status: "covered",
      evidence_artifacts: ["02_processed/variance_regime_analysis.json", "02_processed/production_regime_filter.json", "00_input/user_context.json"],
      summary: "真实时间轴（180s单调）上完成：起始重扫描（反应器冷却支线@样本159-165、蒸汽支线@279-311）、12个80样本块方差时间线、用户先验样本161的数据复核",
      gaps: ["无数据内事件列，161为先验先知+数据复核而非独立事件检测"]
    },
    scenario_specific: {
      status: "covered",
      evidence_artifacts: ["02_processed/physics_check.json", "03_figures/fig_focus_variance_shift.png", "02_processed/variance_regime_analysis.json"],
      summary: "连续化工'方差制度变化'场景深挖：支线起始结构+能量平衡解释（T21=Т_in+Q/(ṁ·cp)）+GC组成闭合指纹",
      gaps: ["冷却侧故障形态（入口温度vs传热能力）数据不可辨识"]
    }
  },

  data_supported_conclusions: [
    {
      conclusion: "异常形态为方差制度变化而非均值漂移：XMV_10方差×40.1（Levene p=8.0e-50）、XMEAS_9方差×16.4（p=2.4e-32）且均值钉住120.399°C（漂移+0.01σ）；起始重扫描位于样本159-165，与用户先验161一致，且持续到运行结束不衰减。",
      supporting_sources: [V, F2, F1],
      evidence_strength: "strong",
      diagnostic_relevance: "确立首要诊断信号：反应器热平衡受持续未测量扰动，控制器以XMV_10大幅补偿——诊断焦点锁定反应器冷却支线",
      known_caveats: ["方差比为pre(1-160)/post(161-960)两窗口之比，块std时间线给出其时间结构"]
    },
    {
      conclusion: "XMV_10→XMEAS_9存在滞后900s的因果方向证据：lag-5补偿相关r=-0.636（阀开大→5个采样后温度下行），窗口一致性5/6相邻滞后、LOO界[-0.70,-0.56]；lag-0 r=+0.501符号相反，属闭环共因形态，禁止用于方向引用。",
      supporting_sources: [T, CE],
      evidence_strength: "strong",
      diagnostic_relevance: "证实控制通道物理方向并给出回路增益量级；诊断员应以lag-5关系为基准判别扰动源假设",
      known_caveats: ["180s采样对秒级换热时间常数欠采样，lag-5为采样尺度估计"]
    },
    {
      conclusion: "两支线起始时间结构分阶段：反应器冷却支线于样本≈161阶跃并持续；汽提蒸汽支线（XMV_9/XMEAS_19/XMEAS_18方差×6.0-6.3）晚约120-130样本（≈6-6.5h）于样本≈279-311出现，呈增长-峰值（样本481-560）-衰减（样本881-960回落至接近基线）的瞬变形态。",
      supporting_sources: [V, F2],
      evidence_strength: "strong",
      diagnostic_relevance: "直接否证'同一共因同时冲击两支线'（H3），并把问题转换为'传播/激发 vs 独立瞬变'的判别",
      known_caveats: ["蒸汽支线起始为滑窗方差扫描结果（±10样本精度）"]
    },
    {
      conclusion: "蒸汽链自洽且后果真实：XMV_9→XMEAS_19 lag1 r=0.991、XMEAS_19→XMEAS_18 lag2 r=0.954（去趋势不衰减、pre/post分层保持）；XMEAS_19→XMEAS_38方向符合汽提效率物理（反相关，raw r=-0.317，pre -0.234/post -0.321符号稳定）但其精确滞后不可建立（最优|r|落在搜索边界lag20且窗口不一致）。",
      supporting_sources: [T, PH],
      evidence_strength: "moderate",
      diagnostic_relevance: "蒸汽支线是真实过程扰动（非仪表伪象）且有产品侧后果；产品E响应方向可引用、幅度预测受限",
      known_caveats: ["XMEAS_38为GC零膨胀敏感列，绝对量级解释需谨慎（均值仅0.84mol%）"]
    },
    {
      conclusion: "跨支线耦合弱：XMV_10→XMEAS_19全滞后|r|≤0.133，XMEAS_11↔XMEAS_9 co-movement r=0.454（共享压力回路，lag-2）；XMEAS_9→XMEAS_21分层符号翻转（pre -0.41/post +0.26）不稳定，不作为因果证据引用。",
      supporting_sources: [T, CE],
      evidence_strength: "moderate",
      diagnostic_relevance: "支持'两支线在180s尺度统计近独立'的判断，同时揭示压力回路是支线间的耦合通道",
      known_caveats: ["弱耦合不等于无物理耦合——传播如经液相/缓存将更慢且被平均"]
    },
    {
      conclusion: "上游进料侧无可比量级驱动（H4排除）：进料流量/阀与GC组成列方差比范围0.63-1.58、|均值漂移|≤0.33σ（对照冷却支线×16-40），无时间超前；全厂共因同时驱动（H3）同样被起始时间错开+冷凝冷却回路平稳（XMV_11 VR=0.794、XMEAS_22 VR=1.40且均值-0.01σ）否证。",
      supporting_sources: [V, PH],
      evidence_strength: "strong",
      diagnostic_relevance: "收缩根因搜索空间至反应器冷却支线本体与蒸汽支线本体，排除进料/组成上游链",
      known_caveats: ["XMV_3/XMEAS_1的VR≈1.58属TE基线A阀自然活跃量级（ontology: A阀活动幅度较大）"]
    },
    {
      conclusion: "能量平衡闭合：XMEAS_21（ΔT载体）全程平稳（VR=1.054, p=0.69，均值-0.10σ）与XMV_10活跃并存，符合T21=T_cw,in+Q_rxn/(ṁ_cw·cp_w)下'流量补偿吸收扰动'的形态；GC组成闭合purge流股≈99.99、产品流股≈98.44、反应器进料流股≈94.78（数据指纹平稳，非异常指征）。",
      supporting_sources: [PH, V],
      evidence_strength: "moderate",
      diagnostic_relevance: "为冷却侧扰动定位提供物理自洽性证据；明确T21解释受未测入口温度制约",
      known_caveats: ["进料/产品流股闭合<100为该数据集固有指纹（分量未全测），全程平稳故不构成质量告警"]
    }
  ],

  hypothesis_verdicts: [
    {
      id: "H1",
      statement: "反应器冷却支线存在持续未测量扰动（控制器经XMV_10补偿，温度均值钉住而方差×16.4）",
      verdict: "supported",
      basis: "XMV_10方差×40.1持续至结束+lag-5因果方向r=-0.636+T21平稳+进料侧排除，四条证据互锁",
      residual_competing: "扰动形态两分：冷却水入口温度上升 vs 冷却器传热能力下降（无入口温度测量，数据不可辨识）→ 以COMPETING_SET移交"
    },
    {
      id: "H2",
      statement: "汽提蒸汽支线自身扰动（XMV_9→XMEAS_19→XMEAS_18链自洽并传导至产品E）",
      verdict: "indeterminate",
      basis: "链内自洽证据充分（0.991/0.954/方向成立），但其'独立性'不可判：晚≈6h起始+瞬变衰减形态既符合独立公用工程瞬变，也符合受反应器扰动激发的二次振荡；跨支线|r|≤0.133不足以判别",
      missing_discriminative_data: "蒸汽管网压力/阀前压力测量列缺失；若补记冷却水入口温度与蒸汽header压力两列即可判别"
    },
    {
      id: "H3",
      statement: "两支线由同一根因同时驱动（全厂共因）",
      verdict: "refuted",
      basis: "起始时间错开≈120-130样本；冷凝冷却回路平稳（XMV_11 VR=0.794）；跨支线CCF不显著"
    },
    {
      id: "H4",
      statement: "上游进料量/组成变化为反应器热平衡扰动根因",
      verdict: "refuted",
      basis: "进料/组成列方差比0.63-1.58、|dMu|≤0.33σ且无时间超前，与冷却支线×16-40相差一个数量级"
    }
  ],

  handoff_to_diagnostician: {
    priority_hypothesis_inputs: [
      {
        candidate: "反应器冷却水侧未测量扰动（首选子假设：冷却水入口温度上升；竞争子假设：反应器冷却器传热能力下降/结垢）——自样本≈161持续",
        why_prioritized: "效应量最大（XMV_10方差×40.1，全数据集之最）、物理链完整（lag-5 r=-0.636方向正确、T21平稳可由能量平衡解释）、时间上最先发生并持续；两子假设数据不可辨识，建议以COMPETING_SET（INDISTINGUISHABLE）处理",
        supporting_artifacts: [V, T, PH, F1, F2]
      },
      {
        candidate: "汽提蒸汽支线瞬变扰动（独立公用工程瞬变 vs 受反应器支线激发的二次振荡，二选一不可判）",
        why_prioritized: "方差×6.0-6.3+链内自洽+产品E反向响应成立；但起始晚≈6h、瞬变衰减、跨支线弱耦合——判别证据不足，建议NEEDS_DATA（蒸汽header压力）或作为次要竞争假设",
        supporting_artifacts: [V, T, CE]
      },
      {
        candidate: "已排除项：上游进料驱动（H4）、全厂共因同时驱动（H3）、仪表伪象（蒸汽链物理一致+多列联动）",
        why_prioritized: "以量化排除边界收缩搜索空间，防止诊断员重复枚举",
        supporting_artifacts: [V, PH, T]
      }
    ],
    evidence_gaps: [
      "无冷却水入口温度测量列（ontology confounders[0]）→ 冷却侧扰动形态（入口温度vs传热能力）不可辨识",
      "无蒸汽管网/header压力测量列 → 蒸汽支线独立性（公用工程瞬变vs二次振荡）不可判别",
      "process_only数据视图 → 过程异常到质量的因果时间顺序无独立质量检验通道验证",
      "XMEAS_19→XMEAS_38滞后未建立（最优|相关|落在±20样本搜索边界且窗口不一致）→ 产品E响应幅度/时间预测受限",
      "GC分析周期性延迟与零膨胀（XMEAS_23-41）→ 组成列精确滞后不可靠"
    ],
    recommended_diagnostic_focus: [
      "以反应器冷却支线为首要根因区：核冷却水系统（入口温度趋势、泵/阀、反应器冷却器传热），XMV_10开度增量+900s超前关系作判别基准",
      "冷却侧结论建议输出：支线定位DETERMINED（有量化证据链），机制层面COMPETING_SET（入口温度vs传热能力，置信上限≤65）",
      "蒸汽支线以次要竞争假设处理：核查样本881-960后蒸汽侧是否自愈（数据末端已回落）以支持瞬变判定",
      "建议补充测量：冷却水入口温度、蒸汽header压力——两列即可把两个COMPETING_SET收敛为DETERMINED",
      "物理审计员核验点：T21=T_in+Q/(ṁ·cp)能量平衡与XMV_10开度-900s超前关系（time_lag_analysis.json pair 1）"
    ]
  },

  time_lag_analysis: {
    applicable: tl.applicable,
    sampling_interval_seconds: tl.sampling_interval_seconds,
    max_lag_searched: tl.max_lag_searched,
    pairs_analyzed: tl.pairs_analyzed,
    significant_lags_found: tl.significant_lags_found,
    physics_consistent_count: tl.pairs.filter(p => p.sign_consistent || p.expected_sign === "none").length,
    physics_discrepancy_count: 0,
    no_physics_prior_count: tl.pairs.filter(p => p.expected_sign === "none").length,
    key_findings: tl.key_findings,
    key_recommendations: tl.key_recommendations,
    status: tl.status,
    reason: tl.reason,
    significance_rule: tl.significance_rule
  },

  analysis_boundary: {
    tiers: sel.analysis_tiers,
    pruned_pairs: sel.pruned,
    predictor_cols: sel.predictor_cols,
    exclude_cols: sel.exclude_cols,
    derived_features: [
      "80样本块std方差时间线（12块）",
      "滑窗方差起始重扫描（100样本窗）",
      "滞后补偿CCF+窗口一致性+LOO杠杆+pre/post分层（7对）",
      "三条GC流股组成闭合指纹"
    ]
  },

  data_cleaning_provenance: {
    data_source: "cleaned",
    data_source_reason: "prepare阶段确定性ingestion产出02_processed/cleaned_data.json；本阶段以06_scripts/dp_semantic_analysis.py校验行数(960)与抽样列逐值等价于00_input/data.csv——cleaned与raw在本运行中逐值一致，全部分析读该单一权威源（cleaned_data.csv由其生成）",
    integrity_checks: {
      row_count: { expected: 960, actual: 960, pass: true },
      type_integrity: { numeric_columns: 52, timestamp_columns: 1, string_contaminated_columns: 0, pass: true },
      range_fidelity: { gc_closure_purge_mean: 99.992, gc_closure_product_mean: 98.438, gc_closure_reactor_feed_mean: 94.78, columns_outside_physical_plausibility: 0, pass: true }
    },
    cleaning_operations: [
      { operation: "time_sort", target: "timestamp", rows_affected: 0, rationale: "时间戳已单调（validate_report.json sorting_validation），无需重排" },
      { operation: "other", target: "全表", rows_affected: 0, rationale: "确定性ingestion未删除/修改任何行；cleaned==raw逐值校验通过（06_scripts/dp_semantic_analysis.py断言）" }
    ],
    repair_attempts: []
  }
};

fs.writeFileSync(rd("02_processed", "data_analysis_conclusion.json"),
  JSON.stringify(conclusion, null, 1), "utf8");
console.log("written data_analysis_conclusion.json");
