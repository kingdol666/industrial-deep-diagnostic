# -*- coding: utf-8 -*-
"""R2 Stage-1 pre-check (ontology-builder) — NOT full statistical analysis (that is data-processor's job).

Computes per-column descriptive stats for:
  - pre-fault window:  rows 1..160   (user_context: anomaly starts at sample 161)
  - post-fault window: rows 161..960
and a coarse shift indicator: (post_mean - pre_mean) / pre_std  [z-like, pre-fault sigma]
plus fraction of post-fault samples outside pre-fault mean +/- 3*pre_std.
Source: RUN_DIR/00_input/data.csv (raw, no cleaning).
"""
import json, os, sys
import numpy as np
import pandas as pd

RUN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(RUN_DIR, "00_input", "data.csv")
OUT = os.path.join(RUN_DIR, "01_ontology", "r2_stage1_precheck.json")

PRE_N = 160  # user-provided anomaly onset at sample 161 (1-based)

df = pd.read_csv(DATA)
result = {
    "purpose": "R2 stage-1 pre-check for ontology construction (coarse shift detection only)",
    "data_source": "00_input/data.csv (raw, uncleaned)",
    "rows_total": int(len(df)),
    "pre_fault_window": {"rows": [1, PRE_N], "basis": "user_context.json: 异常自第161样本(8h)起"},
    "post_fault_window": {"rows": [PRE_N + 1, int(len(df))]},
    "columns": {},
}
cols = [c for c in df.columns if c != "timestamp"]
for c in cols:
    v = pd.to_numeric(df[c], errors="coerce").astype(float)
    pre = v.iloc[:PRE_N]
    post = v.iloc[PRE_N:]
    pre_mean, pre_std = float(pre.mean()), float(pre.std(ddof=1))
    post_mean, post_std = float(post.mean()), float(post.std(ddof=1))
    sigma = (pre_std if pre_std > 1e-12 else 1e-12)
    shift_z = (post_mean - pre_mean) / sigma
    lo3, hi3 = pre_mean - 3 * pre_std, pre_mean + 3 * pre_std
    frac_out = float(((post < lo3) | (post > hi3)).mean())
    result["columns"][c] = {
        "pre_mean": round(pre_mean, 6), "pre_std": round(pre_std, 6),
        "pre_min": round(float(pre.min()), 6), "pre_max": round(float(pre.max()), 6),
        "post_mean": round(post_mean, 6), "post_std": round(post_std, 6),
        "post_min": round(float(post.min()), 6), "post_max": round(float(post.max()), 6),
        "shift_z_pre_sigma": round(shift_z, 3),
        "frac_post_outside_pre_3sigma": round(frac_out, 4),
    }

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=1)
print("WROTE", OUT)
# Print compact summary of significant shifts
for c in cols:
    d = result["columns"][c]
    if abs(d["shift_z_pre_sigma"]) >= 1.5 or d["frac_post_outside_pre_3sigma"] >= 0.05:
        print(f"SHIFT {c}: z={d['shift_z_pre_sigma']:+.2f} frac_out={d['frac_post_outside_pre_3sigma']:.2f} "
              f"pre={d['pre_mean']:.4g}±{d['pre_std']:.4g} post={d['post_mean']:.4g}±{d['post_std']:.4g}")
