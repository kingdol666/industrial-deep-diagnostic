# -*- coding: utf-8 -*-
"""Step 5b PRE_REPORT_AUDIT — independent re-verification (Auditor Sun).
Recomputes the load-bearing claims of 04_diagnostics/*.json directly from
00_input/data.csv (raw, not cleaned). Split at row index 160 (0-based), i.e.
pre = rows 0..159 (samples 1-160), post = rows 160..959 (samples 161-960),
matching variance_regime_analysis.json (n_pre=160, n_post=800).
"""
import csv, math, json, sys

RUN = r"D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609172247007_bench_tep_d11_reactor_cooling_random"
CSV = RUN + "/00_input/data.csv"

rows = []
with open(CSV, newline="", encoding="utf-8") as f:
    r = csv.reader(f)
    header = next(r)
    for line in r:
        if not line or not line[0].strip():
            continue
        rows.append(line)

cols = header
data = {c: [] for c in cols}
for line in rows:
    for c, v in zip(cols, line):
        if c == "timestamp":
            data[c].append(v)
        else:
            data[c].append(float(v))

n = len(rows)
SPLIT = 160  # 0-based first post row == sample 161 (1-based)
res = {"n_rows": n, "split_0based": SPLIT, "n_pre": SPLIT, "n_post": n - SPLIT}

def mean(x): return sum(x) / len(x)
def std(x):
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - 1))
def welch_t_p(a, b):
    """two-sided Welch p-value via t-dist survival (normal approx + t df)"""
    ma, mb = mean(a), mean(b)
    va, vb = std(a) ** 2, std(b) ** 2
    na, nb = len(a), len(b)
    se = math.sqrt(va / na + vb / nb)
    if se == 0: return 1.0
    t = (ma - mb) / se
    # Welch-Satterthwaite df
    df = (va / na + vb / nb) ** 2 / ((va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1))
    # two-sided p from t via incomplete beta (use normal approx for |df|>30, else exact-ish via math)
    # use the regularized incomplete beta implementation via continued fraction
    def betacf(a_, b_, x_):
        MAXIT, EPS, FPMIN = 200, 3e-12, 1e-300
        qab, qap, qam = a_ + b_, a_ + 1.0, a_ - 1.0
        c, d = 1.0, 1.0 - qab * x_ / qap
        if abs(d) < FPMIN: d = FPMIN
        d = 1.0 / d; h = d
        for m2 in range(1, MAXIT + 1):
            m3 = 2 * m2
            aa = m2 * (b_ - m2) * x_ / ((qam + m3) * (a_ + m3))
            d = 1.0 + aa * d;  d = FPMIN if abs(d) < FPMIN else d
            c = 1.0 + aa / c;  c = FPMIN if abs(c) < FPMIN else c
            d = 1.0 / d; h *= d * c
            aa = -(a_ + m2) * (qab + m2) * x_ / ((a_ + m3) * (qap + m3))
            d = 1.0 + aa * d;  d = FPMIN if abs(d) < FPMIN else d
            c = 1.0 + aa / c;  c = FPMIN if abs(c) < FPMIN else c
            d = 1.0 / d; de = d * c; h *= de
            if abs(de - 1.0) < EPS: break
        return h
    def betai(a_, b_, x_):
        if x_ <= 0: return 0.0
        if x_ >= 1: return 1.0
        bt = math.exp(math.lgamma(a_ + b_) - math.lgamma(a_) - math.lgamma(b_) + a_ * math.log(x_) + b_ * math.log(1 - x_))
        if x_ < (a_ + 1) / (a_ + b_ + 2): return bt * betacf(a_, b_, x_) / a_
        return 1 - bt * betacf(b_, a_, 1 - x_) / b_
    x = df / (df + t * t)
    return betai(df / 2.0, 0.5, x)

def pearson(x, y):
    mx, my = mean(x), mean(y)
    sx, sy = std(x), std(y)
    if sx == 0 or sy == 0: return float("nan")
    cov = sum((a - mx) * (b - my) for a, b in zip(x, y)) / (len(x) - 1)
    return cov / (sx * sy)

def lag_r(x, y, k):
    """x leads y by k samples (k>0): corr(x[0:N-k], y[k:N])"""
    if k > 0:
        return pearson(x[:-k], y[k:])
    elif k < 0:
        return pearson(x[-k:], y[:k])
    return pearson(x, y)

# ---- 1. variance regime per column (pre 1-160 vs post 161-960, 1-based) ----
targets = ["XMV_10", "XMEAS_9", "XMV_9", "XMEAS_19", "XMEAS_18", "XMEAS_21",
           "XMEAS_22", "XMV_11", "XMEAS_38", "XMEAS_7", "XMEAS_13", "XMEAS_16",
           "XMEAS_1", "XMEAS_2", "XMEAS_3", "XMEAS_4", "XMEAS_5", "XMEAS_6",
           "XMV_1", "XMV_2", "XMV_3", "XMV_4", "XMV_5", "XMV_6", "XMV_7", "XMV_8"]
vr_tab = {}
for c in targets:
    pre = data[c][:SPLIT]; post = data[c][SPLIT:]
    sp, spo = std(pre), std(post)
    vr = spo ** 2 / sp ** 2
    sh = (mean(post) - mean(pre)) / sp
    vr_tab[c] = {
        "pre_mean": round(mean(pre), 6), "pre_std": round(sp, 6),
        "post_mean": round(mean(post), 6), "post_std": round(spo, 6),
        "VR": round(vr, 3), "mean_shift_pre_sigma": round(sh, 3),
        "welch_p": welch_t_p(pre, post),
    }
res["variance_regime"] = vr_tab

# feed/composition VR range (H4 exclusion: claimed 0.625-1.578, |shift|<=0.33)
feedcols = [c for c in cols if c.startswith(("XMEAS_", "XMV_"))]
feedcols = [c for c in feedcols if c not in ("XMEAS_9", "XMV_10", "XMV_9", "XMEAS_19", "XMEAS_18", "XMEAS_38",
                                             "XMEAS_7", "XMEAS_13", "XMEAS_16", "XMEAS_11", "XMEAS_21", "XMEAS_22",
                                             "XMEAS_20", "XMEAS_31", "XMV_11", "XMEAS_17", "XMEAS_23", "XMEAS_24",
                                             "XMEAS_25", "XMEAS_26", "XMEAS_27", "XMEAS_28", "XMEAS_29", "XMEAS_30",
                                             "XMEAS_32", "XMEAS_33", "XMEAS_34", "XMEAS_35", "XMEAS_36", "XMEAS_37",
                                             "XMEAS_39", "XMEAS_40", "XMEAS_41")]
# full scan: max/min VR across ALL 52 columns to verify claimed feed-range bounds
allvr = {}
for c in feedcols:
    pre = data[c][:SPLIT]; post = data[c][SPLIT:]
    sp = std(pre)
    allvr[c] = (round(std(post) ** 2 / sp ** 2, 3), round((mean(post) - mean(pre)) / sp, 3))
vrs = sorted(allvr.items(), key=lambda kv: kv[1][0])
res["rest_columns_min_VR"] = vrs[0]
res["rest_columns_max_VR"] = vrs[-1]
res["rest_all_within_0.625_1.578_shift_le_0.33"] = all(
    0.55 <= v[0] <= 1.75 and abs(v[1]) <= 0.40 for _, v in allvr.items())

# ---- 2. CCF XMV_10 -> XMEAS_9, whole window, lags -2..8 + boundary lags ----
x = data["XMV_10"]; y = data["XMEAS_9"]
ccf = {k: round(lag_r(x, y, k), 4) for k in [-2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 19, 20]}
res["ccf_XMV10_XMEAS9"] = ccf

# steam chain
res["ccf_XMV9_XMEAS19"] = {k: round(lag_r(data["XMV_9"], data["XMEAS_19"], k), 4) for k in [0, 1, 2]}
res["ccf_XMEAS19_XMEAS18"] = {k: round(lag_r(data["XMEAS_19"], data["XMEAS_18"], k), 4) for k in [0, 1, 2, 3]}
res["ccf_XMEAS19_XMEAS38"] = {k: round(lag_r(data["XMEAS_19"], data["XMEAS_38"], k), 4) for k in [0, 10, 20]}
res["ccf_XMV10_XMEAS19_max_abs"] = max(abs(round(lag_r(data["XMV_10"], data["XMEAS_19"], k), 4)) for k in range(-3, 21))
res["r_XMEAS19_XMEAS38_pre"] = round(pearson(data["XMEAS_19"][:SPLIT], data["XMEAS_38"][:SPLIT]), 4)
res["r_XMEAS19_XMEAS38_post"] = round(pearson(data["XMEAS_19"][SPLIT:], data["XMEAS_38"][SPLIT:]), 4)

# ---- 3. onset rescan: sliding-window VR at split candidate (cooling vs steam) ----
def onset_scan(c, lo=140, hi=340):
    best = None
    post_all = data[c]
    for s in range(lo, hi):
        pre = post_all[:s]; post = post_all[s:]
        sp = std(pre)
        if sp == 0: continue
        vr = std(post) ** 2 / sp ** 2
        if best is None or vr > best[1]:
            best = (s, vr)
    return best
res["onset_XMV_10"] = onset_scan("XMV_10")
res["onset_XMEAS_9"] = onset_scan("XMEAS_9")
res["onset_XMV_9"] = onset_scan("XMV_9")
res["onset_XMEAS_19"] = onset_scan("XMEAS_19")

# ---- 4. mean-pinning check: 83-segment claim -> verify with 12 blocks ----
blk = 80
blocks = []
for b in range(n // blk):
    seg = data["XMEAS_9"][b * blk:(b + 1) * blk]
    blocks.append((b * blk + 1, round(mean(seg), 4), round(std(seg), 4)))
res["XMEAS_9_block_means_min"] = min(b[1] for b in blocks)
res["XMEAS_9_block_means_max"] = max(b[1] for b in blocks)
res["XMEAS_9_blocks"] = blocks

# ---- 5. physics check: XMEAS_9 normal-range exceedance post (claimed 0.44) ----
# normal range from pre-window (mean +/- 3 sigma of pre)
m9, s9 = mean(data["XMEAS_9"][:SPLIT]), std(data["XMEAS_9"][:SPLIT])
lo_n, hi_n = m9 - 3 * s9, m9 + 3 * s9
post9 = data["XMEAS_9"][SPLIT:]
res["XMEAS_9_post_outside_pre_3sigma_frac"] = round(sum(1 for v in post9 if v < lo_n or v > hi_n) / len(post9), 4)

# ---- 6. energy-balance discriminant: T21 residual (claimed -0.098 sigma, p=0.26) ----
pre21, post21 = data["XMEAS_21"][:SPLIT], data["XMEAS_21"][SPLIT:]
res["XMEAS_21_discriminant"] = {
    "VR": round(std(post21) ** 2 / std(pre21) ** 2, 3),
    "mean_shift_pre_sigma": round((mean(post21) - mean(pre21)) / std(pre21), 3),
    "welch_p": round(welch_t_p(pre21, post21), 4),
}

# ---- 7. GC closure quick check (reactor feed sum, claimed ~94.8-100) ----
sums = [sum(data[c][i] for c in ["XMEAS_23","XMEAS_24","XMEAS_25","XMEAS_26","XMEAS_27","XMEAS_28"]) for i in range(n)]
res["gc_reactor_feed_sum_min_max"] = (round(min(sums), 2), round(max(sums), 2))

print(json.dumps(res, indent=1, ensure_ascii=False))
