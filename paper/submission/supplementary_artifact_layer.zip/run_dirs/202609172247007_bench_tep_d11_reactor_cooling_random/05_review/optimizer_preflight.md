# 优化器预检报告（Step 5b — PRE_REPORT_AUDIT）

- **审计人**: Auditor Sun（report-reviewer，物理审计）
- **审计模式**: PRE_REPORT_AUDIT=true（报告生成前的独立物理审计，与 Judge 并行）
- **审计时间**: 2026-09-18T00:00Z（run 内时序见 .pipeline_events.jsonl）
- **RUN_DIR**: D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609172247007_bench_tep_d11_reactor_cooling_random
- **审计对象**: 04_diagnostics/{diagnosis,evidence,confidence,reasoning_chain}.json + 01_ontology/ontology.json + 02_processed 全套统计/物理工件（审计时 report.md 尚不存在）
- **独立性声明**: 本审计仅读取本 run 目录工件与 00_input/data.csv；未读取 results/、scripts/benchmark/ 或其他 run 目录。全部引用数字来自被引工件或审计员用 venv python（.claude/shared/scripts/.venv）从 00_input/data.csv 独立重算。
- **复算脚本**: 05_review/_preflight_verify.py（保留作审计证据；split=行 0 基 160，与 variance_regime_analysis.json 的 n_pre=160/n_post=800 一致）

---

## 一、审计总览

被审诊断结论：**COMPETING_SET**——样本≈161（8 h）起反应器冷却支线出现持续未测量扰动（分支级 H1），控制器经 XMV_10 流量通道补偿（VR×40.1）将 XMEAS_9 均值钉在 120.399°C（+0.01σ）但方差×16.4；因果方向仅引 lag-5（900 s）r=-0.636，明确禁用 lag-0 r=+0.501（闭环符号翻转）；扰动形态 H5（冷却水入口温度上升）vs H6（换热器 UA 下降）INDISTINGUISHABLE→CS1 上限 65；汽提蒸汽支线（H2）为晚≈120-130 样本的第二波瞬变，独立性不可判；H3（全厂共因）/H4（进料侧）被量化排除。

审计方法：逐项核对诊断集中的承重声明，其中 12 项关键统计量由审计员从原始 CSV 全量重算（非抽查、非引用上游）；物理机制逐链核查本体 governing equation；8 项幻觉红旗模式逐项过筛；3 条结论执行 spot-check 逐环溯源。

**总评**: 诊断集与原始数据逐位一致，因果纪律（lag-5 vs lag-0 禁令）执行到位，VLM 缺失诚实披露且未伪造视觉证据，置信度上限纪律（CS1≤65、overall=60）正确执行。发现 0 项 FATAL、0 项 MAJOR、3 项 MINOR（均为报告措辞层面，须由 Reporter 在 Step 6 修正引用方式）、4 项 INFO。

---

## 二、逐项检查结果

### PC-1 数值可追溯性（Data Truth Mandate）
**[INFO]** diagnosis/evidence/confidence 引用的全部统计量（VR、均值、σ 位移、Welch p、CCF、LOO、离群敏感性、Bonferroni、变点位置）均在 02_processed/{variance_regime_analysis,time_lag_analysis,validate_report}.json 中可定位；其中 12 项承重量被审计员独立重算逐位复核（见第四节）。derived=true 标记（focus_onset_rescan）齐备。GC 闭合的引用措辞见 PC-8 MINOR-3。

### PC-2 主异常承重统计（冷却支线）
**[INFO→通过]** XMV_10 VR=40.12（pre_std 0.5733→post_std 3.6312，均值 41.0608→41.7620，+1.223σ，Welch p=3.17e-07）；XMEAS_9 VR=16.356（std 0.0209→0.0846，均值 120.39925→120.39946，+0.01σ，Welch p=0.95）——**审计复算与声明逐位一致**。"均值钉住+方差失控"形态成立。

### PC-3 因果方向纪律（lag-5 vs 禁用 lag-0）
**[INFO→通过]** 全窗口 CCF 审计重算：lag0=+0.5007、lag4=-0.5551、lag5=-0.6356、lag6=-0.6236、lag7=-0.5542、lag8=-0.4536——与 time_lag_analysis.json 声明逐位一致，且 lag-4/-5/-6/-7 四相邻滞后同号（window_consistent=true 属实）。诊断集在 primary_finding、H1 链条、evidence、reasoning_chain R2/R3、contradicting_evidence 共 5 处一致地仅引 lag-5 作因果方向，lag-0 一律标注"闭环共因符号翻转、禁引"。**未发现任何一处违反 v6.4 禁令的引用。**符号翻转结构（0 处正、5 处负）与"控制器同拍响应误差+阀动作分钟级后影响温度"的闭环物理精确对应。

### PC-4 蒸汽支线晚发瞬变
**[INFO→通过]** 80 样本块 std 时间线重算证实：XMEAS_19 在块 1-3（样本 1-240）处于基线（3.87/5.12/4.01），自块 4-5 起增长（6.50/11.27），峰值块 481-560（18.73），衰减块 881-960（2.92）；XMV_9 同形态。冷却支线（XMV_10）则在块 3（161-240）即从 0.62 跳至 3.64——两支线起始结构错开成立，H3（共因要求同期冲击）的时序排除支柱成立。链内执行通道 lag-1 r=0.9913（XMV_9→XMEAS_19）、lag-2 r=0.9539（XMEAS_19→XMEAS_18）重算一致。跨支线 XMV_10→XMEAS_19 全滞后 |r|max=0.133 重算一致。
**[INFO-4b]** 方法依赖性备注：蒸汽支线"起始@279-311"来自滑窗重扫描（focus_onset_rescan）+块时间线，全局 post/pre VR（以 161 分割）本身无法定位蒸汽起始（审计员的全局分割扫描 argmax 落在 160，VR≈6，与声明 VR 相同）。诊断集表述与数据来源一致，不构成缺陷；但 Reporter 引用时必须把蒸汽起始归因于"滑窗重扫描+块时间线"，不得引全局 VR 定位（见 MINOR-4 不可行——已并入 INFO，Reporter 按此措辞即可）。

### PC-5 排除逻辑（H3 共因 / H4 进料）
**[MINOR-1]** evidence.json 与 diagnosis.json 称"全部进料/组成列（XMEAS_1-6、XMV_1-8、XMEAS_23-41…）VR 0.625-1.578"。审计复核 variance_regime_analysis.json per_column：**XMEAS_31（purge 组成，XMEAS_23-41 区间内）VR=1.841**（Levene p=2.4e-4），超出所引上限；XMEAS_23=1.466、XMEAS_29=1.473 等其余列在界内。排除结论本身不受影响（1.84 与冷却支线 16.4/40.1 仍差近 1 个量级，均值位移 -0.198σ 在 0.33σ 声明内，无时间超前），但 **Reporter 必须把区间改写为 0.625-1.841 或把声明范围限定于 XMEAS_1-6/XMV_1-8**，否则报告中该句将不可复算。→ 修复指令见第六节 RI-1。
**[INFO→通过]** H3 的三条独立证据（时序错开+冷凝支线平稳 XMV_11 VR=0.794/XMEAS_22 VR=1.395+跨支线不显著）重算全部成立；H4 的数量级+时序+物理方向排除成立。

### PC-6 物理机制链（能量平衡三件套）
**[INFO→通过]** 本体 governing equations（mCp·dT9/dt=Q_rxn−UA(T9−T_cw)；Q=UA(T9−T_cw)=ṁ_cw·cp_w·(T21−T_cw,in)；T21=T_cw,in+Q/(ṁ·cp)）与 diagnosis 引用逐字一致；XMV_10→XMEAS_9 本体关系为 control/delayed_response/分钟级，与 lag-5（900 s）实测 MATCH。能量平衡预测"补偿走流量通道→T21 平稳"：XMEAS_21 VR=1.054、位移 -0.098σ、Welch p=0.2615 重算一致——本体预测-数据行为闭环互证成立。XMEAS_9 正常范围（pre ±3σ）越限 post=0.44 重算一致。
**[INFO-6b]** 本体预测 XMV_10→XMEAS_21 为 inverse，实测 lag-1 r=+0.2199（不显著）。诊断已按"补偿由流量完全吸收→相关缺失即验证性预测"改记该环节（chain_link_validation CORRELATION_ABSENT + correction_applied），判读诚实且物理上自洽（完全补偿下 ΔT 不随阀位变化）。非缺陷。

### PC-7 H5/H6 不可辨识与置信度纪律
**[INFO→通过]** T_cw,in 与 UA/端差确无数据列（ontology confounders[0] 显式登记；53 列清单核实）；T21 残差 -0.098σ（p=0.26）确无判别力——CS1 INDISTINGUISHABLE 成立。置信度结构合规：H5=55、H6=48 均 ≤65 上限；overall=60 ≤65；COMPETING_SET 输出类型与上限一致。H1 分支级 72 > 65：上限约束对象是 INDISTINGUISHABLE 成员与总体结论，分支级"扰动存在"不在不可辨识集合内，且 diagnosis 明示"分支级确定≠根因确定"——**判定为合规**，但 Reporter 必须保留"分支级（72）/机制层（≤65）/总体（60）"三层区分，不得把 72 写成根因置信度（见 RI-2）。

### PC-8 证据等级与披露诚实性
**[MINOR-2]** 视觉证据条目 rank=4（L4），但 9 张 PNG 全部未读像素（visual_analysis.json observation_mode=metadata_backed_inference，pixel_read=false）。诊断集已在每条标注 METADATA-BACKED、在 confidence 中 -4 降权、核心结论不依赖视觉通道——处理诚实；但按证据规则"未经读取的图表"不应占 L4 槽位。**Reporter 引用图件时必须保留 METADATA-BACKED 标签并把数字出处指向统计工件**（如 fig_focus_variance_shift → variance_regime_analysis.json）。→ RI-3。
**[MINOR-3]** diagnosis 称"GC 组成闭合校验 Σx≈94.8-100.0 mol%"：physics_check.json 实际为三组均值 94.78/99.99/98.44、逐行范围 93.35-101.43。压缩引用不失真（闭合确实成立），但 Reporter 应按流股分别引用（反应器进料 93.4-96.1 / 排放 98.6-101.4 / 产品 96.4-100.7）。→ RI-4。

### PC-9 幻觉红旗八项过筛（reasoning_chain.json）
**[INFO→全部通过]** 模糊量化（无——全部数字可复算）；无锚推理（扰动→XMV_10 环节显式标 INFERRED/DATA_LINK_MISSING 为定义性）；缺失备择（6 假设+仪表伪迹+Q_rxn 增大，R4 alternatives）；不可证伪（每假设绑具体证伪条件，R7 主发现证伪条件具体可执行）；证据等级虚标（见 MINOR-2，已披露）；置信虚高（无——上限纪律执行）；无视矛盾（contradicting_evidence 三处如实收录并处置）；制度盲视（production_regime_filter 单制度判定+受扰稳态不可剔除论证）。
**Spot-check ×3**: ①"冷却支线扰动存在且持续"→VR/块时间线/重扫描三链复算一致 ✓；②"lag-5 方向、lag-0 禁引"→CCF 全谱复算一致 ✓；③"产品 E 仅方向可引"→raw -0.3166/pre -0.2337/post -0.3214/边界 lag20 -0.6886 复算一致，降级处置正确 ✓。**3/3 通过。**

### PC-10 上游工件一致性
**[INFO→通过]** validate_report：overall_validity=ROBUST（0 fatal/serious/moderate）、time_sorted=true、离群敏感性 0.5007→0.4593（-8.3%，29 点）、LOO max_shift=0.0035、Bonferroni 22/100（声明位置在 correlation.multiple_testing，非 anti_spurious——引用出处正确）、变点 XMV_10@165（均值 +1.7% 不显著——诊断如实转述）。anti_spurious 汇总字段 change_points_detected=0 计的是"显著均值型制度变化"，与明细节 XMV_10 cp@165（不显著）不矛盾。

---

## 三、矛盾扫描（Contradiction Scan）

| # | 检查项 | 结果 |
|---|--------|------|
| C1 | 均值钉住 vs 方差×16.4 是否自洽 | 自洽：闭环温度控制压均值不压方差，Welch p=0.95 + Levene p=2.4e-32 并立成立 |
| C2 | T21 平稳 vs XMV_10 大开是否矛盾 | 不矛盾：能量平衡预测流量通道吸收全部增量（本体-数据互证） |
| C3 | lag-0 正 vs lag-5 负是否被掩盖 | 未掩盖：5 处显式披露并转为支持性闭环签名 |
| C4 | 蒸汽支线 mean shift -0.9σ（显著）vs H2"低置信" | 自洽：存在性已证（链内 lag-1/2），降置信的仅是"独立性身份"，诊断措辞准确 |
| C5 | 两波起始错开 vs 块 3-4 蒸汽列轻度抬升 | 自洽：XMEAS_19 块 3（161-240）在基线内（4.01 vs 基线 3.87/5.12），增长自块 4-5 起；错开成立 |
| C6 | H1=72 vs 65 上限 | 合规（上限约束 CS1 成员与 overall=60；三层结构在 confidence.json 显式） |
| C7 | 蒸汽链 XMEAS_38 方向 vs 本体 inverse 预测 | 自洽：方向 MATCH（pre/post 符号稳定），滞后如实放弃 |

未发现未披露矛盾。

---

## 四、统计验证（独立复算记录）

复算工具：venv python（.claude/shared/scripts/.venv/Scripts/python.exe）；数据源：00_input/data.csv（960 行 × 53 列，timestamp+52 信号列，与 validate_report sorting_validation 一致）；分割：0 基行 160（pre=1-160 / post=161-960，1 基，与 n_pre=160/n_post=800 一致）。Levene 用 scipy.stats.levene（center='median'）。

| 量 | 审计复算 | 诊断声明 | 判定 |
|----|---------|---------|------|
| XMV_10 VR | 40.12 | 40.12 | 一致 |
| XMV_10 pre/post std | 0.573289→3.631224 | 0.5733→3.6312 | 一致 |
| XMV_10 mean / shift / Welch p | 41.06075→41.761984 / +1.223σ / 3.17e-07 | 41.0608→41.7620 / +1.22σ / 3.2e-07 | 一致 |
| XMV_10 Levene p | 8.026e-50 | 8.026e-50 | 一致 |
| XMEAS_9 VR / std | 16.356 / 0.020909→0.084559 | 16.356 / 0.0209→0.0846 | 一致 |
| XMEAS_9 mean / shift / Welch p | 120.39925→120.399463 / +0.01σ / 0.9504 | 120.39925→120.39946 / +0.01σ / 0.95 | 一致 |
| XMEAS_9 Levene p | 2.358e-32 | 2.358e-32 | 一致 |
| XMEAS_9 post 越 pre±3σ 比例 | 0.44 | 0.44 | 一致 |
| XMEAS_9 12 块均值范围 | 120.3886-120.4082 | 83 段全部 120.39-120.41 | 一致（块级） |
| CCF lag0/lag4/lag5/lag6 | +0.5007 / -0.5551 / -0.6356 / -0.6236 | +0.5007 / -0.5551 / -0.6356 / -0.6236 | 逐位一致 |
| 蒸汽 VR（XMV_9/XMEAS_19/XMEAS_18） | 6.305 / 5.954 / 6.093 | 6.305 / 5.954 / 6.093 | 一致 |
| 蒸汽链 lag-1 / lag-2 | 0.9913 / 0.9539 | 0.9913 / 0.9539 | 一致 |
| XMEAS_19→XMEAS_38 raw/pre/post/lag20 | -0.3166 / -0.2337 / -0.3214 / -0.6886 | -0.317 / -0.234 / -0.321 / -0.6886 | 一致 |
| 跨支线 XMV_10→XMEAS_19 max abs r | 0.133 | ≤0.133 | 一致 |
| XMEAS_21 VR / 位移 / Welch p | 1.054 / -0.098σ / 0.2615 | 1.054 / -0.098σ / 0.26 | 一致 |
| XMEAS_22 / XMV_11 VR | 1.395 / 0.794 | 1.395 / 0.794 | 一致 |
| GC 闭合（反应器进料和） | 93.35-96.13 | 93.35-96.128 | 一致 |

23/23 项一致，0 项偏离。Levene 7/7 逐位一致。

---

## 五、物理验证（Physics Verification）

1. **作用机理链可溯源性**: H1 五环链中 4 环 OBSERVED（阀补偿、lag-5 冷却通道、均值钉住/方差放大、T21 平稳）+1 环 INFERRED（扰动源本身，无测量列=定义性不可观测）。governing equation（一阶能量平衡+传热方程）由本体提供且与 TEP 型反应器-夹套冷却物理一致。**无物理不可能环节。**
2. **量级校验**: 阀位均值 +0.70%（+1.22σ_pre）、std×6.33；T9 std×4.04；补偿幅度与持续中等移热缺口量级比 ~1（physics_manual_verification.md L4 PLAUSIBLE）——审计员复核该比例推断：流量通道补偿下阀位动作与缺口同量级，判定合理。
3. **时间尺度校验**: 采样 180 s；lag-5=900 s 落在反应器热惯性分钟级一阶滞后窗内，与本体 time_lag 声明 MATCH；两波起始错开 ≈120-130 样本（6-6.5 h）远超块分辨率 ±40 样本。
4. **症状完整性**: H1 四条 predicted_observables 全部命中（复算核实）；未解释残余（蒸汽第二波身份）由 H2 显式承接，无漏报症状。
5. **缺失症状检查**: 若为进料驱动（H4）应见进料列先行——实测无（VR 0.63-1.87、无超前）；若为全厂共因（H3）应见冷凝支线同响——实测 XMV_11 VR=0.794（反降）。两条"应见未见"均与排除方向一致。
6. **排障顺序合理性**: 诊断建议"先查冷却水入口温度趋势与换热器端差"——与 CS1 判别所需数据完全对应，为最小代价最优顺序，可直接执行。

---

## 六、修复指令（Reporter 必须在 Step 6 执行）

- **RI-1 [MINOR]**（对应 PC-5）: 报告中进料/组成排除句改为："XMEAS_1-6 与 XMV_1-8 的 VR 为 0.625-1.578；组成列 XMEAS_23-41 中最高为 XMEAS_31 的 1.841"或统一表述为"全部非异常列 VR ≤1.9，与冷却支线 ×16.4/×40.1 相差近一个量级"。禁止原样复制"0.625-1.578 覆盖 XMEAS_23-41"。
- **RI-2 [MINOR]**（对应 PC-7）: 报告置信度表述必须保持三层：分支级 H1=72、机制层 H5=55/H6=48（CS1 上限 65）、总体=60（MEDIUM）。不得出现"根因确定度 72%"类措辞。
- **RI-3 [MINOR]**（对应 PC-8）: 引用 03_figures 图件时保留"METADATA-BACKED（非 VLM 运行，未读像素）"标签，数字出处指向 02_processed 统计工件；不得把图件写成"视觉确认"。
- **RI-4 [MINOR]**（对应 PC-8/第四节）: GC 闭合按流股分引（93.4-96.1 / 98.6-101.4 / 96.4-100.7），不写"94.8-100.0"总括区间。
- 蒸汽支线起始（≈279-311）的引用须注明方法来源（滑窗重扫描+80 样本块时间线），不得以全局 post/pre VR 定位。

以上均为措辞层修正，不需要回炉 Step 4。

---

## 七、最终裁定

- FATAL: 0
- MAJOR: 0
- MINOR: 3（RI-1/RI-2+RI-3/RI-4，全部为报告措辞层，Reporter 在 Step 6 直接落实即可）
- INFO: 4（PC-1 可追溯性、PC-3 因果纪律、PC-6b T21 环节改记、PC-10 变点字段口径）

物理机制可溯、统计承重全部独立复算一致、因果纪律与置信度纪律执行到位、诚实性披露完备。诊断集达到进入报告生成的物理 truth 门槛。

**PREFLIGHT_VERDICT: NO_FATAL**
**VERDICT: PREFLIGHT_PASS**
