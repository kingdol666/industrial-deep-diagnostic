# Analysis Plan — data-processor（张工）— bench_tep_d11_reactor_cooling_random

## Data View Mode

**process_only**（与 02_processed/anomaly_report.json 的 dual_drive_analysis.data_view_mode 一致）。
53 列 = timestamp + XMEAS_1..41 + XMV_1..11； ontology 将全部信号标为 predictor/control 角色。
没有独立于过程测量的"质量检验"数据通道（产品 GC 组成 XMEAS_37-41 属过程侧流股分析），
过程→质量双驱动联动不可建立，作为证据缺口记录。

## Ontology-Guided Analysis Architecture

质量目标（ontology 意义上的受控目标）：XMEAS_9（反应器温度，120.4°C，XMV_10 执行）、
XMEAS_21（反应器冷却水出口温度，ΔT 载体）。prepare 阶段已按
02_processed/analysis_parameter_selection.json 对这两个 target 跑了全预测变量
Pearson/Spearman/去趋势/滞后 CCF（max_lag 20）+ 反spurious battery。

### 关键未观测共同因子（ontology confounders[0]，本计划的核心约束）

冷却水入口温度无测量列。XMEAS_21/22 必须按"温升 ΔT=Q/(ṁ·cp)"变量解读，
不得把入口温度漂移误读为设备故障，反之亦然——冷却侧扰动的具体形态（入口温度 vs 传热系数）
从本数据不可唯一辨识，如实作为边界移交。

## Hypothesis-Method Map

详见 `02_processed/analysis_method_plan.json`（Phase 1.2 决策枢纽产物）：

| ID | 假设 | 判别方法 | 预期判别力 |
|----|------|---------|-----------|
| H1 | 反应器冷却支线未测量扰动（入口温度↑或传热能力↓），样本≈161起持续 | M13 方差制度检测 + M6 滞后CCF + M7 能量平衡 | 高：XMV_10 方差×40、XMEAS_9 均值钉住、lag-5 符号翻转、T21 平稳，四条证据互锁 |
| H2 | 汽提蒸汽支线自身扰动（XMV_9→XMEAS_19→XMEAS_18→XMEAS_38 链） | M6 滞后CCF（链内3对）+ M13 起始扫描 | 高（链内自洽）；但"独立性"本身不可判 → indeterminate |
| H3 | 两支线同一根因同时驱动 | M13 两支线起始对比 + M6 跨支线探针 + 冷凝回路旁证 | 高：起始相差≈120-130样本、冷凝回路平稳、跨支线|r|≤0.133 → refuted |
| H4 | 上游进料侧驱动 | M13 全52列方差比+Levene+均值漂移 + M7 组成闭合 | 高：进料/组成列 VR≤1.58、|dMu|≤0.33σ → refuted |

### Deviations from default battery（被跳过的传统必跑项及理由）

M3 批完整性（无批列）、M5 以等价自定义实现（连续单制度）、M8 以 pre/post 窗口分层替代
产品分层、M9/M10 数据形状不匹配、M11 已被 M6 覆盖、M12 已被 H1-H4 定向覆盖。
`full_battery_justified=false`——未跑全 battery，每个跳过项有案可查。

## Adaptive Decision Audit

| 数据形状观察 | 决策 |
|--------------|------|
| 连续化工、180s 等间隔、960 行、真实 timestamp 列 | 允许时序/滞后结论（time_alignment 真实轴） |
| 方差跳变主导而均值钉住（XMEAS_9） | 以方差制度检测（Levene+滑窗VR+80样本块时间线）为主武器，而非均值漂移检验 |
| 闭环控制（XMV_10↔XMEAS_9） | lag-0 相关判方向无效（+0.501），必须用 lag-5 补偿值（-0.636） |
| 无产品分组 | 单产品全局分析；分层改用 pre/post 窗口 |
| process_only | 双驱动联动 = not_applicable，写缺口 |

## Analysis Coverage Matrix（实际执行状态）

- pure_process_analysis: covered — validate_report.json + variance_regime_analysis.json + time_lag_analysis.json
- process_inspection_dual_drive: not_applicable — process_only 数据视图（缺口记录）
- grouping_confounding: covered — LOO 杠杆 + pre/post 分层 + 去趋势 + 多重检验告警（validate_report.json anti_spurious）；无分组列（not applicable 部分）
- temporal_regime_event: covered — onset 重扫描 + 方差时间线 + production_regime_filter.json（真实时间轴）
- scenario_specific: covered — 连续化工"方差制度变化"场景深挖（variance_regime_analysis.json + physics_check.json）

## What I will NOT do

- 不读 PNG 像素（非 VLM 环境）——visual_analysis.json 只做元数据推断并逐条标注来源
- 不把冷却侧扰动细分为"入口温度 vs 结垢"（数据不可辨识，移交诊断员/物理审计员）
- 不对蒸汽支线"独立性 vs 传播振荡"下强结论（跨支线证据不足）
