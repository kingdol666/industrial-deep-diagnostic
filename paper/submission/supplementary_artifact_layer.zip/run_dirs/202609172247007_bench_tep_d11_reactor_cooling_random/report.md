# 工业诊断报告 — TEP反应器冷却支线未测量扰动（bench_tep_d11_reactor_cooling）

- 运行目录：`D:/codes/myskills/industrial-deep-diagnostic/workspace/diagnostic-runs/202609172247007_bench_tep_d11_reactor_cooling_random`
- 报告人：周工（reporter，Pipeline Step 6）
- 结论类型：`COMPETING_SET`（竞争集，不升级为 `DETERMINED`）
- 总体置信度：60/100（MEDIUM，受 CS1 不可辨识上限 65 约束）
- 质量门：Judge 93 分 / `pass`（`05_review/judge_feedback.json`）；Step 5b 物理预检 `PREFLIGHT_PASS`、0 FATAL / 0 MAJOR（`05_review/optimizer_preflight.md`）

## 1. 执行摘要

**一句话结论**：自样本 ≈161（约 8 h）起，反应器冷却支线出现持续性**未测量移热缺口**；温度控制器被迫经 XMV_10（反应器冷却水阀）大幅补偿（方差 ×40.1，Levene p=8.0e-50），把反应器温度 XMEAS_9 的均值钉在 120.399°C（位移仅 +0.01σ，Welch p=0.95），但温度方差放大 ×16.4、正常范围越限比例升至 44%——典型的"补偿成功、波动失控"受扰稳态形态。

**结论必须分三层读**（不得把分支级确定误读为根因确定）：

| 层次 | 结论 | 置信度 |
|------|------|--------|
| 分支级 | H1：冷却支线存在持续未测量扰动（移热缺口型），控制器经 XMV_10 流量通道补偿 | 72（HIGH） |
| 机制形态层 | H5 冷却水入口温度上升（55） vs H6 换热器传热能力 UA 下降/结垢（48），`INDISTINGUISHABLE`（竞争集 CS1，上限 65） | 55 / 48 |
| 总体 | `COMPETING_SET`，总体置信度 60（MEDIUM，≤65） | 60 |

**主要发现**：

1. 冷却通道因果方向由滞后补偿 CCF 唯一确立：lag-5（900 s）r=-0.6356；lag-0 的 r=+0.5007 为闭环共因符号翻转，按 v6.4 纪律**明确禁止**用作因果方向证据（`02_processed/time_lag_analysis.json`）。
2. 汽提蒸汽支线（XMV_9/XMEAS_19/XMEAS_18，方差 ×6.3/×6.0/×6.1）为第二波事件：起始比冷却支线晚约 120-130 样本（≈6-6.5 h），呈"增长-峰值(481-560)-衰减(881-960)"瞬变；链内执行通道自洽（lag-1 r=0.9913、lag-2 r=0.9539），但独立性不可判（H2=38）。
3. 排除项：H3 全厂共因（排除置信度 95%）、H4 进料侧驱动（96%）——均有三条独立量化证据。
4. 环境说明：本 run 为非 VLM 运行（9 张 PNG 未读像素），全部图件引用均为 METADATA-BACKED 元数据推断；判别 H5/H6 所需的冷却水入口温度列与 UA/端差监测在 53 列数据中均不存在（本体 confounders[0] 显式登记）。

**P0 行动**：立即调取/加装冷却水入口温度测量并核查换热器端差——两项中任一数据即可把 CS1 竞争集裁决为单一根因（详见 §8）。

## 2. 诊断背景与数据概况

- **用户问题**：诊断本次异常的根本原因（`00_input/user_context.json`；truth_withheld=true，盲测场景）。
- **工艺背景**：Tennessee Eastman 化工过程——反应器-冷凝器-气液分离器-汽提塔 + 循环压缩机；XMEAS_1..41 过程测量（含 GC 流股组成）、XMV_1..11 阀位指令。
- **数据形状**：`00_input/data.csv`，960 行 × 53 列（timestamp + 52 信号列），180 s 等间隔（约 48 h 连续运行），0 缺失；timestamp 单调（960 个唯一值，`02_processed/validate_report.json` sorting_validation time_sorted=true）。
- **用户先验**：第 161 样本（8 h）起进入异常工况。该先验仅作窗口划分依据，最终起始由数据驱动重扫描复核（XMV_10 @165 / XMEAS_9 @159，match=true）。
- **分析路径**：53 列全部为过程测量/控制信号，无独立质量检验通道 → 纯过程波动分析（View A，`02_processed/data_analysis_conclusion.json` adaptive_decision_audit.data_view_mode=process_only）。

## 3. 数据质量评估

| 检查项 | 结果 | 出处 |
|--------|------|------|
| 时间排序 | time_sorted=true，960 行/960 唯一时间值 | `02_processed/validate_report.json` |
| 缺失/完整性 | 0 缺失（53 列 × 960 行） | `00_input/input_inspection.json` |
| 生产制度 | 单一连续制度（n_regimes=1，steady_fraction=1.0），无批/产品分组列；index≥160 判为"控制器补偿下的受扰稳态"，**不可剔除**（剔除将抹除诊断信号） | `02_processed/production_regime_filter.json` |
| 批完整性 | not_applicable（无批 ID 列） | 同上 |
| GC 组成闭合 | 按流股分别核验（Σx=100 mol% 正常化）：反应器进料（流股 6，XMEAS_23-28）逐行 93.35-96.13 mol%（均值 94.78）；排放（流股 9，XMEAS_29-36）98.61-101.43（均值 99.99）；产品（流股 11，XMEAS_37-41）96.41-100.69（均值 98.44）——分析通道无系统漂移 | `02_processed/physics_check.json` composition_closure |
| 已登记混杂 | 冷却水入口温度 T_cw,in 未测量（confounders[0]）；环境/昼夜温度（confounders[1]）；GC 分析延迟与零膨胀（confounders[2]，XMEAS_37 存在小幅负值） | `01_ontology/ontology.json` |

## 4. 统计分析发现

### 4.1 方差制度跳变：主异常的显性形态

异常的显性形态是**方差制度变化而非均值漂移**（XMEAS_9 均值检验会漏诊）。pre(0-159)/post(160-959) 窗口统计（`02_processed/variance_regime_analysis.json`）：

| 参数 | post/pre 方差比 | std 变化 | 均值变化 | Levene p | 判读 |
|------|----------------|----------|----------|----------|------|
| XMV_10（反应器冷却水阀） | **40.12** | 0.5733→3.6312 | 41.0608→41.7620（+0.70%=+1.22σ_pre，Welch p=3.2e-07） | 8.026e-50 | 控制器持续大幅补偿的闭环签名 |
| XMEAS_9（反应器温度） | **16.356** | 0.0209→0.0846°C | 120.39925→120.39946（+0.01σ，Welch p=0.95） | 2.358e-32 | 均值被钉住、方差失控 |
| XMV_9 / XMEAS_19 / XMEAS_18（蒸汽支线） | 6.305 / 5.954 / 6.093 | — | — | ≤1.5e-16 | 第二波瞬变 |
| XMEAS_21（冷却水出口温） | 1.054 | 块 std 0.12-0.18 | -0.098σ（Welch p=0.26，噪声内） | 0.6936 | 平稳——补偿走流量通道的验证性预测 |
| XMEAS_22 / XMV_11（冷凝器支线） | 1.395 / 0.794 | 0.243→0.287°C | -0.007σ | — | 平稳/反降——排除全厂共因的关键 |

补充判读：

- **起始定位**：滑窗起始重扫描（derived=true）给出 XMV_10 @165、XMEAS_9 @159，与用户先验 161 一致；变点分析给出 XMV_10 唯一变点 @165（均值 41.0612→41.7663，+1.7%，不显著——变化在方差）。
- **均值钉住的准确表述**（按 Judge W1 修正）：变点分析将 XMEAS_9 分为 83 段，**各段均值无显著制度变化（has_regime_change=false），段均值范围 120.282-120.506°C（约 ±0.11°C）**，均值整体钉在 120.399°C（+0.01σ，Welch p=0.95）——"均值无制度变化、变化在方差"的结论由 Welch/Levene 双检验独立成立。
- **持续性**：80 样本块 std 时间线显示 XMV_10 从异常前 0.53/0.62 跳至 3.64 后持续 3.6-4.3 直到结束（阶跃+持续，约 36 h 不衰减），非瞬变。
- **压力三管（XMEAS_7/13/16）**：彼此 r=0.97-0.998，方差爆发集中于样本 401-640 块，与蒸汽支线峰值块（481-560）时段重合、与主异常起始（161）不重合——判为蒸汽事件的气相负荷伴随现象，非独立根因通道。
- **进料/组成侧无扰动信号**（按预检 RI-1/Judge W2 修正口径）：非异常列（进料阀/流量 XMEAS_1-6、XMV_1-8 与组成列 XMEAS_23-41，除已单独归因于蒸汽支线的产品 E XMEAS_38）方差比范围 **0.625-1.841**（组成列上限为 XMEAS_31 的 1.841；XMEAS_38=2.477 为产品 E 的真实蒸汽响应，另计），|mean shift|≤0.33σ_pre，且相对冷却支线起始无时间超前——与冷却支线 ×16.4/×40.1 相差 1-2 个数量级。

### 4.2 因果方向：滞后补偿 CCF 与 lag-0 禁令

`02_processed/time_lag_analysis.json`（±20 样本搜索，180 s/步）：

- **XMV_10→XMEAS_9**：最优 lag-5（900 s）**r=-0.6356**；lag-4 -0.5551、lag-6 -0.6236 同号（window_consistent=true，4 个相邻滞后一致）；期望负号、符号一致；lag-0 LOO 界 [0.4971, 0.5034] 稳定。
- **lag-0 r=+0.5007 为闭环共因符号翻转，禁引**：lag-0 的正相关反映"温度升高→阀即时开大"的控制器同拍动作，lag-5 的负相关才是"阀开大→900 s 后温度下降"的冷却因果通道。`time_lag_analysis.json` key_recommendations 明确禁止以 lag-0 作因果方向证据，诊断与证据集全部执行该纪律（物理预检 PC-3 全谱复算 0 处违规）。
- **蒸汽链内部**：XMV_9→XMEAS_19 lag-1 r=0.9913（去趋势 0.9881，LOO [0.9881,0.9883]）；XMEAS_19→XMEAS_18 lag-2 r=0.9539——执行通道自洽。
- **XMEAS_19→XMEAS_38（产品 E）**：raw r=-0.317（pre -0.234 / post -0.321 符号稳定），符合汽提效率反相关物理；最优 |r|=-0.6886 落在搜索边界 lag-20 且窗口不一致（2/4）——**按纪律只引方向、不引滞后**。
- **跨支线探针 XMV_10→XMEAS_19**：全滞后 |r|≤0.133，不显著——不显著是低统计功效而非独立性证明，H2 的身份因此不可判（R5/R6 纪律裁定）。
- **离群稳健性**（`02_processed/validate_report.json`）：XMV_10→XMEAS_9 全样本 r=0.5007→剔除 29 个离群点后 0.4593（-8.3%，outlier_driven=false）；LOO max_shift=0.0035；anti_spurious overall_validity=**ROBUST**（0 fatal/serious/moderate；simpson=0、trend_confounded=0、spearman_divergence=0）。多重检验：total_tests=100、名义显著 39、Bonferroni 阈值 0.0005 下显著 22（期望假阳性 5.0）——被引关系远超随机显著水平。

### 4.3 关键对齐图解读（全部为 METADATA-BACKED 元数据推断）

> **RI-3 声明**：本 run 非 VLM 环境，`03_figures/visual_analysis.json` observation_mode=metadata_backed_inference、全部 9 张 PNG pixel_read=false。以下图件解读是**元数据推断而非像素级视觉确认**；每个数字的出处均指向 `02_processed` 统计工件（经 Judge/预检 venv python 从 `00_input/data.csv` 独立复算逐位一致）。

**图 1** 全时序网格（±3σ 红线）——图上所见：52 列中极端 |z|>3 的点稀少（最高 XMEAS_26 max|z|=3.78、XMEAS_9 max|z|=3.73，占比 ≤0.5%）。统计互证：异常主体不是离群点而是方差制度变化（离群敏感性 -8.3% 不翻结论）。物理判读：持续型扰动+闭环补偿的形态，与点状干扰（会表现为孤立尖峰）不符。

![关键变量时序网格图](03_figures/fig_temporal_overview.png)

**图 2** 关键变量 z 分数叠加（z 基线=样本 1-160，红线=样本 161 先验起始）——图上所见：XMV_10 波动带自 ≈161 起展宽并持续（统计出处：`02_processed/variance_regime_analysis.json` VR=40.12）；XMEAS_9 带宽 ×16.4 而中心线不动；XMEAS_19/XMV_9/XMEAS_18 迟至 ≈280-310 起展宽。统计互证：滑窗重扫描 @159-165 与 @279-311（match 用户先验 161=true / false）。物理判读：两波时间结构错开是排除共因 H3 的时序支柱。

![关键变量方差制度跳变叠加](03_figures/fig_focus_variance_shift.png)

**图 3** 21 样本滚动标准差（相对异常前中位数）——图上所见：XMV_10 滚动 σ 自 ≈160 升至基线 2-4 倍并保持；蒸汽三列约 ×1.5-2.5 且呈增长-峰值-衰减；XMEAS_38 温和抬升；XMEAS_21/22 全程窄带（统计出处：80 样本块 std 时间线，块 881-960 蒸汽回落至 0.68/2.92/0.13）。物理判读：冷却支线为阶跃型持续扰动，蒸汽支线为瞬变——两种形态对后续监视策略意义不同。

![滚动方差时间线](03_figures/fig_rolling_variance.png)

**图 4** 全参数 z 归一化叠加——图上所见：冷却支线与蒸汽支线**分时**进入高方差；XMEAS_21/XMEAS_22 全程平稳（VR=1.054/1.395，统计出处同 §4.1）。物理判读：补偿经流量通道（ṁ_cw）吸收全部移热增量，温升 ΔT 通道按 T21=T_cw,in+Q/(ṁ·cp) 保持近恒定——本体能量平衡预测与观测闭环互证。

![全参数时序叠加](03_figures/fig_vlm_temporal_overlay.png)

**图 5** 滚动相关同步性热图——图上所见：蒸汽链内部高同步（统计出处：lag-1 0.9913 / lag-2 0.9539，`02_processed/time_lag_analysis.json`）；跨支线弱耦合（|r|≤0.133）。物理判读：蒸汽支线扰动有真实过程后果（非仪表噪声），但其与冷却支线的耦合不足以裁决"独立瞬变 vs 受激振荡"。

![滚动相关同步性热图](03_figures/fig_vlm_synchronization.png)

**图 6-10** 分组叠加 g1-g5（z 归一化、时间对齐；单产品连续制度下的参数组视图）——观察与图 2/图 4 一致（METADATA-BACKED，出处同上）。

![分组叠加g1](03_figures/fig_vlm_temporal_overlay_single_product_g1.png)

![分组叠加g2](03_figures/fig_vlm_temporal_overlay_single_product_g2.png)

![分组叠加g3](03_figures/fig_vlm_temporal_overlay_single_product_g3.png)

![分组叠加g4](03_figures/fig_vlm_temporal_overlay_single_product_g4.png)

![分组叠加g5](03_figures/fig_vlm_temporal_overlay_single_product_g5.png)

## 5. 竞争假设检验与排除逻辑

六个假设覆盖能量平衡全部扰动入口 + 两大备择源（`04_diagnostics/diagnosis.json`）：

| ID | 假设 | 终局 | 置信度/排除置信度 | 关键证据 |
|----|------|------|-------------------|----------|
| H1 | 反应器冷却支线存在持续未测量扰动（分支级伞结论） | 存活（分支级成立） | 72（HIGH） | XMV_10 VR=40.12 + XMEAS_9 钉住/×16.4 + lag-5 r=-0.6356 + T21 平稳，四条件（时间先行/统计显著/物理机制/无矛盾）齐备，本体-数据-物理四要素全 MATCH（STRONG_EVIDENCE） |
| H2 | 汽提蒸汽支线自身扰动（独立瞬变 vs 受激振荡不可判） | 存活（身份未决） | 38（LOW） | 链内 lag-1/2 自洽 + XMEAS_38 方向性反相关；起始晚 120-130 样本（对主异常无时间先行性）；跨支线 \|r\|≤0.133 低功效 |
| H5 | 形态 A：冷却水入口温度 T_cw,in 上升 | 存活（CS1 成员） | 55（MEDIUM，上限 65） | 通道物理由本体 confounders[0]/[1] 确立；判别环节 T_cw,in→T21 残差 DATA_LINK_MISSING（-0.098σ 噪声内，无判别力） |
| H6 | 形态 B：换热器 UA 下降/结垢 | 存活（CS1 成员） | 48（LOW，上限 65） | WEAR 机制与 EQ_REACTOR_CW_HX 设备类型相容；UA/端差无测量列；阶跃起始对缓发结垢形态略偏不利 |
| H3 | 全厂共因（公用工程漂移同击两支线） | **排除** | 95% | 三重独立证据：起始错开 ≈120-130 样本 + 冷凝支线平稳（XMV_11 VR=0.794、XMEAS_22 VR=1.395）+ 跨支线 CCF 不显著 |
| H4 | 进料量/组成驱动 | **排除** | 96% | 数量级（非异常列 VR 0.625-1.841 vs 冷却支线 ×16-40）+ 无时序超前 + 物理方向不符（进料驱动应先见进料列变化） |

**CS1 竞争集（H5 vs H6）为何不可辨识**：H5 与 H6 在全部 52 列可观测通道上预测**完全相同**的信号——判别所需的冷却水入口温度列与换热器端差/UA 监测均不存在（本体 confounders[0] 显式登记）；XMEAS_21 残差 -0.098σ（Welch p=0.26）在噪声内，其点估计方向不具统计判别力，按反投机纪律不得用于强行判定。`INDISTINGUISHABLE` 成立 → 置信度上限 65 同时施加于 H5、H6 与 overall。与 data-processor 移交时的 residual_competing（H1 residual_competing="形态两分→以 COMPETING_SET 移交"）独立复核一致。

**H2 为何不予排除**："跨支线相关不显著"是低统计功效而非独立性证据——以此排除违反诚实排除纪律。H2 的链内存在性证据扎实（0.9913/0.9539/方向稳定），故以"独立性不可判的存活假说"保留。

**置信度终值口径**（按 Judge W4：以 `04_diagnostics/confidence.json` adjustment_log 为准）：H1 = 五因素合计 80 −4（形态 fork 不确定性传导）−4（非 VLM 视觉降权）= **72**；H2 = 44 −6（独立性不可判）= **38**；H5 = 66 −11（CS1 上限）= **55**；H6 = 64 −16（CS1 上限，T21 微负残差不给方向加权）= **48**；overall = 60（MEDIUM，≤65 上限）。

## 6. 根因结论

### 6.1 诊断结论

**diagnosis_type = `COMPETING_SET`**。主发现（与 `04_diagnostics/diagnosis.json` primary_finding 一致）：样本 ≈161（8 h）起反应器冷却支线出现持续未测量扰动——控制器经 XMV_10 补偿性开大冷却水流量（方差 ×40.1，Levene p=8.0e-50），把反应器温度均值钉在 120.399°C（均值位移仅 0.01σ）但温度方差 ×16.4；因果方向由 lag-5（900 s）r=-0.636 确立（lag-0 +0.501 为闭环符号翻转，禁引）。分支级结论 H1 成立；但扰动具体形态——冷却水入口温度上升（H5）vs 换热器传热能力下降/结垢（H6）——在现有测点下不可辨识，且汽提蒸汽支线（H2，晚 ≈120-130 样本的瞬变）的独立性不可判，故整体以 `COMPETING_SET` 移交。

**明确不做的事**：不把 H1 的分支级 72 表述为"根因确定度 72%"；不把 H5/H6 任一分支写成已定根因；不把总体置信度写成高于 60 或突破 65 上限。

### 6.2 因果物理链与推理过程

 governing law（`01_ontology/ontology.json` EQ_REACTOR / EQ_REACTOR_CW_HX）：

```
mCp·dT9/dt = Q_rxn − UA(T9 − T_cw)
Q_rxn = UA(T9 − T_cw,in) = ṁ_cw·cp_w·(T21 − T_cw,in)
```

五环因果链（`04_diagnostics/diagnosis.json` H1.physical_logic_chain，4 环 OBSERVED + 1 环 INFERRED）：

1. 未测量移热缺口（T_cw,in↑ 或 UA↓）出现于样本 ≈159-165 并持续至结束（INFERRED——扰动源无测量列，属"未测量扰动"的定义性不可观测；存在性由闭环签名反推）。
2. 移热缺口 → 温度控制器持续开大 XMV_10（OBSERVED：均值 +0.70%=+1.22σ_pre、Welch p=3.2e-07；80 样本块 std ×6 后持续不落回）。
3. XMV_10 开大 → 900 s 后反应器温度下降（OBSERVED：lag-5 r=-0.6356，窗口一致、方向与本体 delayed_response 负向控制一致；lag-0 禁引）。
4. 补偿钉住均值但压不住波动（OBSERVED：均值 +0.01σ / 方差 ×16.4 / 越限 0→44%）。
5. 补偿走流量通道 → 温升 ΔT 不承担增量 → XMEAS_21 平稳（OBSERVED：VR=1.054、-0.098σ、p=0.69——相关缺失恰为该物理预测的验证，chain_link_validation 记 CORRELATION_ABSENT 为验证性证据）。

量级校验：阀位补偿幅度（均值 +0.70%、std ×6.33）与持续中等移热缺口量级比 ~1（PLAUSIBLE，`02_processed/physics_manual_verification.md` L4）。仪表伪迹备择已排除：伪迹无法制造物理一致的 lag-5 负反馈响应；GC 闭合（按 §3 三流股分列）排除组成分析通道漂移。

### 6.3 置信度三层结构（RI-2）

| 层 | 数值 | 说明 |
|----|------|------|
| 分支级 H1 | 72（HIGH） | "冷却支线存在持续未测量扰动"——四条件齐备 |
| 机制层 H5 / H6 | 55 / 48 | CS1 `INDISTINGUISHABLE`，上限 65（confidence_ceilings_applied 三处登记并执行） |
| 总体 | 60（MEDIUM，≤65） | "方向确定、形态未决"的诚实状态 |

三层不确定度：aleatory（过程/测量噪声、GC 量化噪声）；epistemic（扰动源身份因测量缺失不可知、H2 身份未决）；model（一阶能量平衡+比例控制近似、CCF 对称性限制因果推断强度）。

## 7. 证据附录

### 7.1 证据全景（按证据等级 L1-L7）

| 等级 | 证据 | 来源（真实工件） | 关键数字 |
|------|------|------------------|----------|
| L1 直接测量 | 原始数据时序 | `00_input/data.csv`（960×53，180 s） | XMEAS_9 均值 120.39925→120.39946°C；XMV_10 41.0608→41.7620 |
| L3 统计分析 | 方差制度分析 | `02_processed/variance_regime_analysis.json` | XMV_10 VR=40.12（p=8.026e-50）；XMEAS_9 VR=16.356（p=2.358e-32）；蒸汽 ×6.305/5.954/6.093；XMEAS_21 VR=1.054 |
| L3 统计分析 | 滞后补偿 CCF | `02_processed/time_lag_analysis.json` | lag-5 r=-0.6356；lag-1 0.9913；lag-2 0.9539；跨支线 ≤0.133 |
| L3 统计分析 | 稳健性核验 | `02_processed/validate_report.json` | ROBUST（0 红旗）；离群 -8.3%；LOO 0.0035；Bonferroni 22/100；变点 XMV_10@165 |
| L4 图件视觉（METADATA-BACKED） | 非像素推断的图件观察 | `03_figures/visual_analysis.json` + `03_figures/plot_manifest.json` | observation_mode=metadata_backed_inference；9 张 PNG read_status 均为 READ_FAILED（如实披露） |
| L5 领域知识/过程逻辑 | 本体物理 | `01_ontology/ontology.json` | 能量平衡 governing equations；confounders[0] T_cw,in 未测量 |
| L5 物理校验 | 物理约束 | `02_processed/physics_check.json`、`02_processed/physics_manual_verification.md` | 符号校验 5/5 pass；GC 闭合（分流股见 §3）；量级比 ~1 PLAUSIBLE |

被引相关的全部数字经 Judge 与物理预检两条独立链路用 venv python 从 `00_input/data.csv` 复算（23/23 项一致，`05_review/optimizer_preflight.md` 第四节；Judge spot-check 6 组核心统计逐位一致）。

### 7.2 图件清单（全部 METADATA-BACKED）

`03_figures/`：fig_temporal_overview.png、fig_focus_variance_shift.png、fig_rolling_variance.png、fig_vlm_temporal_overlay.png、fig_vlm_temporal_overlay_single_product_g1..g5.png、fig_vlm_synchronization.png（渲染可用，plot_manifest rendering_available=true；本 run 无像素读取）。

### 7.3 工件索引

| 阶段 | 工件 |
|------|------|
| 本体 | `01_ontology/ontology.json`、`01_ontology/rag_deep_understanding.json` |
| 数据分析 | `02_processed/data_analysis_conclusion.json`、`variance_regime_analysis.json`、`time_lag_analysis.json`、`validate_report.json`、`production_regime_filter.json`、`physics_check.json`、`physics_manual_verification.md`、`anomaly_report.json`、`causal_evidence_map.json` |
| 诊断 | `04_diagnostics/diagnosis.json`、`evidence.json`、`confidence.json`、`reasoning_chain.json` |
| 评审 | `05_review/judge_feedback.json`（93/pass）、`05_review/optimizer_preflight.md`（PREFLIGHT_PASS） |
| 图件 | `03_figures/plot_manifest.json`、`visual_analysis.json`、`image_captions.json` |

## 8. 建议与后续（行动方案与验证）

**P0（立即，<24 h）——直接命中 CS1 判别通道**：

1. 调取/加装冷却水入口温度测量（T_cw,in）。判读规则：若 T_cw,in 自样本 ≈161 起持续上升并与 XMV_10 方差制度同步 → H5 确立、结论升级 `DETERMINED`；若平稳（Δ<测量噪声）→ H5 被证伪、H6 成为唯一存活形态。这是最廉价的裁决途径。
2. 核查换热器端差/UA 性能（或安排停车检查管束/夹套结垢）。判读规则：UA 同步退化 → H6 确立；UA 正常且入口温度确在上升 → H5 确立。
3. 运行监护：XMV_10 处于 std ×6.33 的高方差工况（阀磨损与执行器寿命风险）；XMEAS_9 越限比例 44%——复核报警阈值是否按"受扰稳态"合理设定，防止告警疲劳。

**P1（1-2 周）**：

4. 加装蒸汽管网/header 压力表——裁决 H2 身份：header 压力与 XMEAS_19 同步波动 → 独立公用工程瞬变；平稳且更长数据窗显示低频跨支线耦合 → 受激二次振荡。
5. 以更长数据窗/更高采样率对冷却→蒸汽方向做低频 Granger 型检验（当前 180 s 瞬时相关功效不足，|r|≤0.133 不构成独立性证据）。
6. 监视压力三管（XMEAS_7/13/16）在蒸汽支线峰值期（481-560 块形态）的气相负荷联动。

**P2（条件具备时）**：

7. 对 9 张 PNG 补做 VLM 像素级读取，将视觉证据从 METADATA-BACKED 升级为真实 L4（本 run read_status 均为 READ_FAILED）。
8. 为 GC 组成列建立采样延迟/零膨胀补偿模型（confounders[2]）后再用于精细定量推断。

**证伪条件（主发现）**：若补记 T_cw,in/UA 数据后显示移热缺口不存在（例如阀位漂移由回路重整引起）→ H1 被证伪；若 XMV_10 高方差时段与 T9 响应解耦（lag-5 负反馈消失）→ 阀位信号为仪表/回路伪迹，H1 被证伪；若数据重扫描证明方差跳变起始晚于蒸汽支线（时序倒置）→ H1 作为主异常根因被证伪。H3/H4 的复活条件见 `04_diagnostics/diagnosis.json` eliminated 条目。

## 9. 方法论说明与局限

### 9.1 方法

方差制度检测（Levene + F 比 + 80 样本块时间线 + 滑窗起始重扫描）→ 滞后补偿 CCF（±20 样本，五重反伪核验：滞后补偿/窗口一致性/LOO 杠杆/去趋势/pre-post 分层）→ 本体引导的竞争假设生成与逐环链验证 → 可判别性矩阵（`INDISTINGUISHABLE`→上限 65）→ 量化排除（每条 ≥2 重独立证据 + 排除置信度 + 复活条件）→ 三层置信度评定（五因素分解 + adjustment_log）。生产状态判定先于统计（v6.5），全程单一连续制度、受扰稳态不可剔除。

### 9.2 推理链（R1-R8）摘要

R1 数据表征（95）→ R2 统计发现与两波结构（90/88）→ R3 反伪相关过滤（92）→ R4 假设生成与本体-数据-物理证明（88/90）→ R5 可判别性评估（90）→ R6 排除验证（93）→ R7 结论裁定（60）→ R8 不确定性定界与补测排序（90）。详见 `04_diagnostics/reasoning_chain.json`。

### 9.3 局限与数据缺口

1. **判别量结构性缺失**：T_cw,in、换热器 UA/端差、蒸汽 header 压力均无测量列——H5/H6 形态与 H2 身份不可判的根因是测点设计而非分析不足。
2. **非 VLM 运行**：视觉证据仅为元数据推断，无像素级独立交叉验证（已全量披露，核心结论不依赖视觉通道）。
3. **因果推断强度**：方向由对称 CCF 滞后结构推断（lag-5 负峰 + lag-0 符号翻转），非严格 Granger 型先行检验；缓解因素为窗口一致性、LOO 稳定与本体物理先验独立一致。
4. **偶然限度**：180 s 采样对秒级快动态欠采样；48 h 窗长对小时级以上慢共因功效有限；GC 分析延迟与零膨胀（XMEAS_37 小幅负值）。
5. **数据范围**：960 样本、单一工况、无独立质量检验通道；本报告全部数字限于本 run 目录工件与 `00_input/data.csv` 可复算范围，未引用任何外部运行的结果。

---

*报告生成：reporter（Engineer Zhou），Pipeline Step 6；依据 Judge 93/pass 质量门与 Step 5b 物理预检 PREFLIGHT_PASS 授权生成。*
